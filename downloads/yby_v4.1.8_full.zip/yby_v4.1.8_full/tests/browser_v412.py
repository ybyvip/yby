"""Actual editor fit, shared revision form, cancellation shading and date grouping."""
from pathlib import Path
import importlib.util
import os
import sys
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v412-screens'))
screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    c.save({'cards':[{'id':1,'num':'TEST-CARD-0412','group':'서울','status':'available','company':'시험 카드사'}]},c.admin)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        page=browser.new_page(viewport={'width':1366,'height':1000});errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('dialog',lambda dialog:dialog.accept())
        page.goto(f'http://127.0.0.1:{c.server.server_port}/')
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>document.getElementById('appContainer').style.display==='flex'")
        page.evaluate("stopLiveSync();switchView('v_card_rent',document.getElementById('nav_v_card_rent'))")
        page.evaluate("async()=>{await businessOperation('/api/cards/rent',{cardId:1,dept:'재무팀',user:'시험 사용자',purpose:'업무 정산',dueDate:'2099-01-01'});openReturnModal(1)}")
        assert page.locator('#returnExpenseFields').is_hidden()
        page.check('#returnUsedCheckbox');assert page.locator('#returnExpenseFields').is_visible()
        page.check('#returnUnusedCheckbox');assert page.locator('#returnExpenseFields').is_hidden()
        page.check('#returnUsedCheckbox');assert not page.is_checked('#returnUnusedCheckbox')
        page.select_option('#returnExpenseCategory','식대');page.fill('#returnExpensePurpose','거래처 업무 협의 및 출장 정산')
        page.fill('#returnExpenseAttendees','시험 참석자');page.fill('#returnExpenseNote','첫 번째 전달사항\n두 번째 전달사항')
        rows=page.locator('#returnExpenseLines tr')
        rows.nth(0).locator('.line-merchant').fill('업무협의 식당 <&>')
        rows.nth(0).locator('.line-description').fill('거래처 업무협의 식사')
        rows.nth(0).locator('.line-quantity').fill('2');rows.nth(0).locator('.line-price').fill('10000')
        page.locator('button').filter(has_text='+ 사용 건 추가').click()
        rows.nth(1).locator('.line-category').fill('교통·출장');rows.nth(1).locator('.line-merchant').fill('택시')
        rows.nth(1).locator('.line-description').fill('거래처 방문 이동');rows.nth(1).locator('.line-price').fill('5000')
        assert page.inner_text('#returnExpenseTotal')=='25,000'
        # Changing the default date updates defaulted rows without overwriting an explicit date.
        rows.nth(1).locator('.line-date').fill('2026-10-16')
        page.fill('#returnExpenseDate','2026-10-15');page.locator('#returnExpenseDate').dispatch_event('change')
        assert rows.nth(0).locator('.line-date').input_value()=='2026-10-15'
        assert rows.nth(1).locator('.line-date').input_value()=='2026-10-16'
        page.set_input_files('#returnExpenseFileInput',{'name':'시험 영수증.txt','mimeType':'text/plain','buffer':b'fixture receipt only'})
        signature=page.evaluate("()=>Array.from(document.querySelectorAll('[data-settlement-section]')).filter(s=>['basic','usage','lines'].includes(s.dataset.settlementSection)).map(s=>({section:s.dataset.settlementSection,fields:Array.from(s.querySelectorAll('input,select,textarea')).map(x=>[x.id||x.className,x.tagName,x.type])}))")
        def check_fit(mode):
            for width,height in [(1366,1000),(1024,768),(768,900),(390,844),(320,740)]:
                page.set_viewport_size({'width':width,'height':height})
                metrics=page.evaluate("""()=>{
                    const body=document.getElementById('modalBody'),table=document.querySelector('.settlement-lines-table'),bounds=body.getBoundingClientRect();
                    return {bodyWidth:body.clientWidth,bodyScroll:body.scrollWidth,tableWidth:table.clientWidth,tableScroll:table.scrollWidth,
                      outside:Array.from(document.querySelectorAll('.settlement-form input:not([type=radio]):not([type=checkbox]),.settlement-form textarea,.settlement-form select,.settlement-lines-table output')).filter(x=>x.offsetParent!==null).filter(x=>{const r=x.getBoundingClientRect();return r.left<bounds.left-1||r.right>bounds.right+1;}).map(x=>x.id||x.className)};
                }""")
                assert metrics['bodyScroll']<=metrics['bodyWidth']+1,(mode,width,metrics)
                assert metrics['tableScroll']<=metrics['tableWidth']+1,(mode,width,metrics)
                assert not metrics['outside'],(mode,width,metrics)
            page.set_viewport_size({'width':1366,'height':1000})
        check_fit('initial')
        page.locator('[data-settlement-section=lines]').scroll_into_view_if_needed()
        page.locator('.modal-card').screenshot(path=str(screens/'yby_v4.1.8_initial_form.png'))
        page.set_viewport_size({'width':390,'height':844});page.locator('[data-settlement-section=lines]').scroll_into_view_if_needed()
        page.locator('.modal-card').screenshot(path=str(screens/'yby_v4.1.8_mobile_form.png'))
        page.set_viewport_size({'width':1366,'height':1000})
        page.click('#returnCardSubmitButton');page.wait_for_selector('#commonModal',state='hidden')
        original=a.get_state()['expense'][0];assert original['amount']==25000 and len(original['lineItems'])==2 and len(original['attachments'])==1
        assert original['note']=='첫 번째 전달사항\n두 번째 전달사항'
        page.evaluate("switchView('v_expense',document.getElementById('nav_v_expense'))")
        page.locator('#expenseTable').get_by_role('button',name='승인',exact=True).click();page.wait_for_function('()=>expenseData.length===0')
        page.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
        row=page.locator('#expenseHistoryTable tr').filter(has_text='승인완료')
        before=row.locator('td').first.evaluate('(x)=>getComputedStyle(x).backgroundColor')
        row.locator('button').filter(has_text='승인 취소·정정').click()
        page.fill('#correctionReason','영수증 내역을 확인하여 금액을 정정해 주세요.');page.fill('#correctionPassword','Admin-test-pass!')
        page.locator('#modalFooter button').filter(has_text='승인취소 후 재보고 요청').click()
        page.wait_for_function("()=>expenseData.some(x=>x.status==='재보고대기')")
        page.locator('#expenseTable button').filter(has_text='정정 작성·재보고').click()
        revision=page.evaluate("()=>Array.from(document.querySelectorAll('[data-settlement-section]')).filter(s=>['basic','usage','lines'].includes(s.dataset.settlementSection)).map(s=>({section:s.dataset.settlementSection,fields:Array.from(s.querySelectorAll('input,select,textarea')).map(x=>[x.id||x.className,x.tagName,x.type])}))")
        # Per-row accessible IDs intentionally differ; class, element and control types remain the same.
        for sections in (signature,revision):
            for section in sections:
                section['fields']=[[('line-field' if str(name).startswith('settlementLine') else name),tag,kind] for name,tag,kind in section['fields']]
        assert signature==revision,(signature,revision)
        assert page.input_value('#returnExpenseNote')=='첫 번째 전달사항\n두 번째 전달사항'
        assert page.locator('[data-keep-attachment]:checked').count()==1
        assert page.input_value('#returnExpenseCategory')==original['category']
        check_fit('revision')
        page.locator('[data-settlement-section=lines]').scroll_into_view_if_needed()
        page.locator('.modal-card').screenshot(path=str(screens/'yby_v4.1.8_revision_form.png'))
        rows.nth(0).locator('.line-price').fill('11000')
        page.fill('#resubmissionMessage','금액을 확인하여 27,000원으로 재보고합니다.')
        assert page.inner_text('#returnExpenseTotal')=='27,000'
        page.click('#resubmitExpenseButton');page.wait_for_selector('#commonModal',state='hidden')
        assert a.get_state()['expense'][0]['amount']==27000
        assert a.get_state()['expense'][0]['attachments']==original['attachments']
        page.locator('#expenseTable').get_by_role('button',name='승인',exact=True).click();page.wait_for_function('()=>expenseData.length===0')
        page.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
        cancelled=page.locator('#expenseHistoryTable tr[data-status="승인취소"]')
        assert cancelled.count()==1
        assert cancelled.locator('td').first.evaluate('(x)=>getComputedStyle(x).backgroundColor')!=before
        assert cancelled.locator('.expense-state.cancelled').count()==1
        assert cancelled.locator('.history-requested').evaluate('(x)=>x.nextElementSibling.classList.contains("history-decided")')
        page.locator('#v_expense_history .expense-history-wrap').evaluate('(x)=>x.scrollLeft=0')
        page.locator('#v_expense_history').screenshot(path=str(screens/'yby_v4.1.8_history.png'))
        cancelled.locator('button').filter(has_text='상세 보기').click()
        assert page.locator('.expense-status-summary.cancelled').count()==1
        assert page.locator('[data-date=requested]').evaluate('(x)=>x.nextElementSibling.dataset.date==="decided"')
        assert page.locator('[data-date=cancelled]').count()==1
        assert '영수증 내역' in page.inner_text('#expenseDetailPrintArea')
        assert '<&>' in page.inner_text('#expenseDetailPrintArea')
        assert page.locator('#expenseDetailPrintArea img,#expenseDetailPrintArea script').count()==0
        page.locator('.modal-card').screenshot(path=str(screens/'yby_v4.1.8_cancelled_detail.png'))
        page.evaluate('()=>{window.print=()=>{};printExpenseDetailReport()}')
        page.emulate_media(media='print');assert page.locator('[data-date=cancelled]').is_visible();page.emulate_media(media='screen')
        page.evaluate("document.body.classList.remove('print-expense-detail')")
        page.evaluate('closeModal()')
        # Non-settlement dialogs keep their original width after leaving the shared editor.
        page.evaluate('openAddAccountModal()');assert page.locator('.modal-card').evaluate('(x)=>x.getBoundingClientRect().width')<=820
        assert not errors,errors
        print('PASS: initial/revision share fields and element types; 1366/1024/768/390/320 widths fit with no horizontal editor overflow; quantity/price/total and explicit dates preserved',flush=True)
        print('PASS: actual two-line return + receipt + multiline notes -> own approval -> cancellation -> same revision form -> retained receipt -> edited resubmission -> approval',flush=True)
        print('PASS: cancelled row/status/detail shading; adjacent request/decision times; distinct original approval/cancellation times; escaped text; print dates visible; no dialog style leakage; no JavaScript errors',flush=True)
        browser.close()
finally:
    fixture.SecurityTests.tearDownClass()

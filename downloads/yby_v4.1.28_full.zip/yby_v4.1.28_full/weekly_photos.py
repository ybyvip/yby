"""Account-independent, weekly presentation photos; no business state is modified."""
from datetime import date,datetime,timedelta,timezone
import json
SCENES={'day':('login-day-v416.jpg','따뜻한 낮의 풍경'),'sunrise':('login-sunrise-v416.jpg','부드러운 아침 햇살'),'sunset':('login-sunset-v416.jpg','고요한 노을'),'night':('login-night-v416.jpg','차분한 밤 풍경'),'rain':('login-rain-v416.jpg','비 오는 날의 휴식'),'snow':('login-snow-v416.jpg','포근한 겨울 풍경'),'classic':('login-classic-v416.jpg','여유로운 자연 풍경'),'beach':('login-beach-v415.jpg','시원한 해변 풍경')}
POOLS={'rain':('rain','classic','night'),'snow':('snow','night','classic'),'cloudy':('classic','day','rain'),'spring':('sunrise','day','beach'),'summer':('beach','day','sunset'),'autumn':('sunset','classic','sunrise'),'winter':('snow','sunrise','night')}
def initialize(c):c.execute('CREATE TABLE IF NOT EXISTS weekly_photos(week_start TEXT PRIMARY KEY,payload_json TEXT NOT NULL)')
def weekly(a,c):
 initialize(c);today=date.fromisoformat(a.business_date());start=today-timedelta(days=today.weekday());key=start.isoformat()
 cached=c.execute('SELECT payload_json FROM weekly_photos WHERE week_start=?',(key,)).fetchone()
 if cached:return dict(ok=True,**json.loads(cached[0]))
 season='spring' if 3<=today.month<=5 else 'summer' if 6<=today.month<=8 else 'autumn' if 9<=today.month<=11 else 'winter'
 try:weather=a.LOGIN_WEATHER.snapshot()
 except Exception:weather={}
 if not isinstance(weather,dict):weather={}
 condition=None
 try:
  now=datetime.fromisoformat(a.now().replace('Z','+00:00'));stamp=datetime.fromisoformat(str(weather.get('forecastAt','')).replace('Z','+00:00'))
  if now.tzinfo is not None and stamp.tzinfo is not None and -3600<=(now-stamp).total_seconds()<=10800 and weather.get('ready') is True and weather.get('condition') in ('clear','cloudy','rain','snow'):condition=weather['condition']
 except (TypeError,ValueError):pass
 pool=POOLS.get(condition,POOLS[season]);prior=c.execute('SELECT payload_json FROM weekly_photos WHERE week_start<? ORDER BY week_start DESC LIMIT 1',(key,)).fetchone();previous=json.loads(prior[0])['photos'] if prior else {}
 photos={};chosen=set();offset=start.toordinal()//7
 for i,surface in enumerate(('complaint','report')):
  old=previous.get(surface,{}).get('scene');choices=[pool[(offset+i+j)%len(pool)] for j in range(len(pool))];scene=next(x for x in choices if x!=old and x not in chosen);chosen.add(scene);filename,label=SCENES[scene];photos[surface]=dict(scene=scene,url='/static/'+filename,description=label)
 value=dict(version=1,weekStart=key,weekEnd=(start+timedelta(days=6)).isoformat(),timezone='Asia/Seoul',season=season,condition=condition,city='청주시' if condition else None,forecastAt=weather.get('forecastAt') if condition else None,basis='날씨·계절 참고' if condition else '날씨 미수신 · 계절 기준',photos=photos)
 c.execute('INSERT INTO weekly_photos VALUES(?,?)',(key,json.dumps(value,ensure_ascii=False)))
 return dict(ok=True,**value)

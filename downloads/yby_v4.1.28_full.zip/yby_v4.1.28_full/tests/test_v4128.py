"""V4.1.28 guidance and weekly photos never change financial business records."""
import copy,json,unittest
from unittest.mock import patch
from concurrent.futures import ThreadPoolExecutor
import test_v4127 as base
from weekly_photos import SCENES
class Polish128Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.Upgrade127Tests.setUpClass()
 @classmethod
 def tearDownClass(cls):base.Upgrade127Tests.tearDownClass()
 def setUp(self):
  self.t=base.Upgrade127Tests();self.t.setUp();self.a=self.t.a;self.c=self.t.c
  with self.a.db() as db:db.execute('DELETE FROM weekly_photos');db.commit()
 def get(self,path,cookie=None):return self.t.get(path,cookie)
 def photo(self,cookie=None):return self.get('/api/presentation/weekly-photo',cookie)
 def weather(self,condition='rain',**extra):return dict(ready=True,condition=condition,forecastAt=self.a.now())|extra
 def seed(self):
  self.t.t.seed();self.t.mutate(lambda s:s['expenseHistory'].extend([dict(s['expenseHistory'][0],id=20,historicalImport=True,status='이관완료',amount=None),dict(s['expenseHistory'][0],id=21,used=False,amount=0),dict(s['expenseHistory'][0],id=22,status='승인취소'),dict(s['expenseHistory'][0],id=23,selfApproved=True),dict(s['expenseHistory'][0],id=24,historicalImport=True,status='이관완료',amount=0),dict(s['expenseHistory'][0],id=25,group='인천',user='타지점 비밀')]))
 def test_six_guides_match_metrics_and_leave_business_state_unchanged(self):
  self.seed();before=copy.deepcopy(self.a.get_state());sizes={'approved':2,'imported':2,'missingAmount':1,'unused':2,'cancelled':1,'selfApproved':1}
  for metric,n in sizes.items():
   code,v,*_=self.get('/api/business-review/details?period=2026-10&metric='+metric);self.assertEqual(code,200,v);self.assertEqual(v['total'],n,metric);g=v['procedure'];self.assertEqual(len(g['steps']),6);self.assertGreater(len(g['scope']),20);self.assertTrue(g['evidence']);self.assertTrue(g['caution']);self.assertNotIn('타지점 비밀',json.dumps(v,ensure_ascii=False))
  self.assertEqual(self.a.get_state(),before)
 def test_guides_respect_permission_and_unknown_metric(self):
  cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get('/api/business-review/details?period=2026-10&metric=approved',cookie)[0],403);self.assertEqual(self.get('/api/business-review/details?period=2026-10&metric=unknown')[0],400);self.assertEqual(self.c.request('/api/business-review/details?period=2026-10&metric=approved')[0],401)
 def test_guides_preserved_on_empty_results_and_pagination(self):
  self.seed();code,v,*_=self.get('/api/business-review/details?period=2026-10&metric=approved&offset=50');self.assertEqual(code,200);self.assertEqual(v['rows'],[]);self.assertTrue(v['procedure']['steps']);self.assertEqual(self.get('/api/business-review/details?period=2026-10&metric=missingAmount&offset=-1')[0],400)
 def test_week_is_korean_monday_to_sunday_and_stays_stable(self):
  with patch.object(self.a,'business_date',return_value='2026-10-25'),patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=self.weather()):first=self.photo()[1]
  self.assertEqual((first['weekStart'],first['weekEnd']),('2026-10-19','2026-10-25'));self.assertEqual(first['condition'],'rain');self.assertEqual(first['city'],'청주시');self.assertEqual(first['timezone'],'Asia/Seoul')
  with patch.object(self.a,'business_date',return_value='2026-10-21'),patch.object(self.a.LOGIN_WEATHER,'snapshot',side_effect=RuntimeError('provider down')):self.assertEqual(self.photo()[1],first)
 def test_new_week_changes_both_photos_and_keeps_previous_selection(self):
  with patch.object(self.a,'business_date',return_value='2026-10-25'),patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=self.weather('snow')):first=self.photo()[1]
  with patch.object(self.a,'business_date',return_value='2026-10-26'),patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=self.weather('snow')):second=self.photo()[1]
  for kind in ['report','complaint']:self.assertNotEqual(first['photos'][kind]['scene'],second['photos'][kind]['scene'])
  self.assertEqual(second['weekStart'],'2026-10-26')
  with self.a.db() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM weekly_photos').fetchone()[0],2)
 def test_seasons_and_weather_failure_fallback_do_not_affect_business(self):
  before=copy.deepcopy(self.a.get_state())
  for when,season in [('2027-04-01','spring'),('2027-07-01','summer'),('2027-10-01','autumn'),('2028-01-01','winter')]:
   with patch.object(self.a,'business_date',return_value=when),patch.object(self.a.LOGIN_WEATHER,'snapshot',side_effect=RuntimeError('offline')):result=self.photo();self.assertEqual(result[0],200);self.assertEqual(result[1]['season'],season);self.assertIsNone(result[1]['condition']);self.assertIsNone(result[1]['city']);self.assertIn('계절',result[1]['basis'])
  self.assertEqual(self.a.get_state(),before)
 def test_stale_unknown_and_naive_weather_never_claim_live_weather(self):
  for i,value in enumerate([self.weather(forecastAt='2000-01-01T00:00:00Z'),self.weather(forecastAt='2026-10-22T00:00:00'),self.weather(condition='javascript:x'),self.weather(ready=False)]):
   with patch.object(self.a,'business_date',return_value='2027-02-'+str(1+i*7).zfill(2)),patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=value):self.assertIsNone(self.photo()[1]['condition'])
 def test_photos_are_shared_by_accounts_without_business_identifiers(self):
  cookie=self.c.login('readonly','Branch-test-pass!')
  with patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=self.weather()):v=self.photo()[1];self.assertEqual(self.photo(cookie)[1],v);self.assertEqual(self.photo(self.c.admin)[1],v)
  raw=json.dumps(v);self.assertNotIn('branch',raw);self.assertNotIn('card',raw);self.assertNotIn('username',raw);self.assertEqual(self.c.request('/api/presentation/weekly-photo')[0],401)
 def test_concurrent_first_load_creates_one_stable_week(self):
  with patch.object(self.a.LOGIN_WEATHER,'snapshot',return_value=self.weather()):
   with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:self.photo(),range(2)))
  self.assertTrue(all(x[0]==200 for x in results),results);self.assertEqual(results[0][1],results[1][1]);self.assertNotEqual(results[0][1]['photos']['report']['scene'],results[0][1]['photos']['complaint']['scene'])
  with self.a.db() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM weekly_photos').fetchone()[0],1)
 def test_selected_photos_are_existing_local_images_and_new_assets_are_served(self):
  for kind,photo in self.photo()[1]['photos'].items():self.assertIn(photo['scene'],SCENES);status,raw,headers=self.get(photo['url']);self.assertEqual(status,200);self.assertTrue(raw.startswith(b'\xff\xd8\xff'));self.assertIn('image/jpeg',headers['Content-Type'])
  for asset in ['app-polish-v4128.js','app-polish-v4128.css']:self.assertEqual(self.get('/static/'+asset)[0],200)
 def test_schema15_upgrade_preserves_accounts_documents_reviews_and_weekly_photos(self):
  self.seed();self.photo();before=copy.deepcopy(self.a.get_state())
  with self.a.db() as db:
   accounts=[tuple(x) for x in db.execute('SELECT username,password_hash FROM users ORDER BY username')];photos=[tuple(x) for x in db.execute('SELECT * FROM weekly_photos')];db.execute('DELETE FROM schema_versions');db.execute("INSERT INTO schema_versions VALUES(15,'2026-10-22')");db.commit()
  self.a.prepare_db();self.assertEqual(self.a.get_state(),before)
  with self.a.db() as db:self.assertEqual([tuple(x) for x in db.execute('SELECT username,password_hash FROM users ORDER BY username')],accounts);self.assertEqual([tuple(x) for x in db.execute('SELECT * FROM weekly_photos')],photos);self.assertEqual(db.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],16)
if __name__=='__main__':unittest.main()

"""Read-only metric drilldown and durable, editable statement comparisons."""
from datetime import date,datetime
LABELS={'user':'사용자','dept':'부서','date':'사용일','merchant':'사용처','category':'정산 구분','purpose':'사용 목적','amount':'금액 (원)','returnDate':'반납일','title':'보고서 제목','author':'기안자','type':'보고서 유형','content':'본문 발췌 (최대 4,000자)'}
def fields(source,kind):
 keys=('title','author','type','date','content') if kind=='report' else ('user','dept','date','merchant','category','purpose','amount','returnDate')
 return {k:(source.get(k) if k=='amount' else str(source.get(k) or '')[:4000]) for k in keys}
def safe(source,kind):
 return dict(id=str(source.get('id','')),recordKind=kind,group=source.get('group',''),requester=source.get('requester',''),cardLast4=str(source.get('cardNum') or '')[-4:],status=source.get('status',''),approvedBy=source.get('approvedBy',''),approvedAt=source.get('approvedAt',''),fields=fields(source,kind))
def source_for(state,target):
 kind=target.get('recordKind') or ('report' if target.get('view')=='v_report_box' else 'expense')
 candidates=[r for r in state.get('reports' if kind=='report' else 'expenseHistory',[]) if str(r.get('id',''))==str(target.get('id','')) and r.get('group')==target.get('group')]
 if target.get('requester'):candidates=[r for r in candidates if r.get('requester','')==target['requester']]
 elif len(candidates)>1:candidates=[r for r in candidates if r.get('requester','')==target.get('requester','')]
 return candidates[0] if len(candidates)==1 else None

def require_followup(a,user,previous):
 if a.user_scope(user)!='ALL' and previous.get('actor')!=user:raise PermissionError('후속점검은 작성자와 최고관리자만 열 수 있습니다.')

def details(a,c,state,user,params):
 import business_review as b
 value=b.snapshot(a,c,state,user,params.get('period',[a.business_date()[:7]])[0],params.get('group',[''])[0]);scope=a.user_scope(user);group=value['group']
 ledger=[r for r in state.get('expenseHistory',[]) if (group=='ALL' or r.get('group')==group) and str(r.get('date','')).startswith(value['period'])]
 metric=params.get('metric',[''])[0]
 if metric:
  unused=lambda r:r.get('used',r.get('manualUsed',True)) is False
  imported=lambda r:r.get('historicalImport') and not unused(r) and r.get('status')!='승인취소'
  predicates={'approved':lambda r:r.get('status')=='승인완료' and not unused(r),'imported':imported,'missingAmount':lambda r:imported(r) and r.get('amount') is None,'unused':lambda r:unused(r) or imported(r) and r.get('amount')==0,'cancelled':lambda r:r.get('status')=='승인취소','selfApproved':lambda r:bool(r.get('selfApproved') or r.get('selfDecision'))}
  if metric not in predicates:raise ValueError('집계 항목을 확인하세요.')
  try:offset=int(params.get('offset',['0'])[0]);assert offset>=0
  except (ValueError,AssertionError):raise ValueError('페이지를 확인하세요.')
  rows=[safe(r,'expense') for r in ledger if predicates[metric](r)]
  from review_guides import GUIDES
  return dict(ok=True,metric=metric,procedure=GUIDES[metric],rows=rows[offset:offset+50],total=len(rows),offset=offset,limit=50)
 target=None
 if params.get('reviewId'):
  previous=next((r for r in value['reviews'] if r['id']==params['reviewId'][0]),None)
  if previous:
   require_followup(a,user,previous);target=previous.get('target')
 else:
  target=next((r for r in value['issues'] if str(r['id'])==params.get('targetId',[''])[0] and r['group']==params.get('recordGroup',[''])[0] and r.get('requester','')==params.get('requester',[''])[0] and r.get('recordKind','expense')==params.get('recordKind',['expense'])[0]),None)
 if not target:raise a.StateConflict('점검 대상이 변경되었거나 확인 권한이 없습니다. 다시 조회하세요.')
 source=source_for(state,target)
 if source and scope not in ('ALL',source['group']):raise PermissionError('점검 원문 조회 권한이 없습니다.')
 if not source:
  # Retained snapshot is viewable by its author/admin, even if an original is unavailable.
  if not params.get('reviewId'):raise a.StateConflict('점검 원문이 없습니다. 목록을 다시 조회하세요.')
  saved=previous.get('sourceSnapshot')
  return dict(ok=True,source=saved or dict(id=str(target.get('id','')),recordKind=target.get('recordKind','expense'),group=target.get('group',''),fields={}),labels=LABELS,target=target,sourceFingerprint=target.get('sourceFingerprint'),unavailable=True,message='현재 원문을 찾을 수 없어 저장 당시 기록을 표시합니다. 원문 재대조 완료로 저장할 수 없습니다.')
 return dict(ok=True,source=safe(source,target.get('recordKind','expense')),labels=LABELS,target=target,sourceFingerprint=b.source_fingerprint(source))
def comparison(state,target,items,status):
 source=source_for(state,target)
 if source is None:raise ValueError('점검 원문이 없습니다.')
 current=fields(source,target.get('recordKind','expense'))
 if not isinstance(items,list) or len(items)!=len(current):raise ValueError('명세대조 항목을 모두 확인하세요.')
 result=[];seen=set()
 for item in items:
  if not isinstance(item,dict) or set(item)!={'field','observed','checked'}:raise ValueError('명세대조 입력 형식 오류')
  key=item['field'];observed=item['observed']
  if not isinstance(key,str) or key not in current or key in seen:raise ValueError('허용되지 않거나 중복된 대조 항목입니다.')
  seen.add(key)
  if type(item['checked'])!=bool or status=='완료' and not item['checked']:raise ValueError('완료하려면 모든 항목을 대조 확인하세요.')
  if key=='amount':
   if observed is not None and (type(observed)!=int or not 0<=observed<=10**12):raise ValueError('대조 금액은 미기재 또는 0~1조 원의 정수입니다.')
  else:
   if not isinstance(observed,str) or len(observed)>4000:raise ValueError('대조 내용은 항목별 4,000자 이내입니다.')
   observed=observed.strip()
   if key in ('date','returnDate') and observed:
    try:
     if key=='date' and target.get('recordKind')=='report' and len(observed)>10:datetime.fromisoformat(observed.replace('Z','+00:00'))
     else:date.fromisoformat(observed)
    except ValueError:raise ValueError('대조 날짜를 확인하세요.')
  result.append(dict(field=key,label=LABELS[key],original=current[key],observed=observed,checked=item['checked'],differs=current[key]!=observed))
 return dict(sourceSnapshot=safe(source,target.get('recordKind','expense')),comparison=result,differenceCount=sum(r['differs'] for r in result))

"""Reconnect to an identified, healthy server; never remove or bypass its DB lock."""
import json
import os
from pathlib import Path
import ssl
import subprocess
import urllib.request
import webbrowser
import process_identity


def probe(root):
    root = Path(root).resolve()
    try:
        meta = json.loads((root / 'server.pid').read_text(encoding='utf-8'))
        if Path(meta['app']).resolve() != root / 'app.py':
            return None
        if not process_identity.owns_app(meta['pid'], root / 'app.py'):
            return None
        if meta.get('data') and Path(meta['data']).resolve() != root / 'data':
            return None
        port = int(meta['port'])
        if not 1 <= port <= 65535:
            return None
        scheme = meta.get('scheme', 'https' if meta['host'] not in ('127.0.0.1', 'localhost') else 'http')
        if scheme not in ('http', 'https'):
            return None
        # No proxy and no redirects: a local PID record must identify this local server.
        context = ssl.create_default_context(cafile=str(root / 'certificates/root-ca.pem')) if scheme == 'https' else None
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *args, **kwargs):
                return None
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(), urllib.request.HTTPSHandler(context=context))
        url = f'{scheme}://localhost:{port}/'
        with opener.open(url + 'health', timeout=2) as response:
            info = json.loads(response.read(8192))
        if info.get('ok') is not True or info.get('database') is not True or not str(info.get('version', '')).startswith('4.'):
            return None
        return dict(meta, url=url, version=info['version'])
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        return None


def trust_server(root, helper_root=None, open_browser=True):
    if os.name != 'nt':
        return True
    script = Path(helper_root or root) / 'tools/client_templates/client_connect.ps1'
    command = ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script), '-ServerRoot', str(root)]
    if not open_browser:
        command += ['-NoBrowser']
    result = subprocess.run(command)
    if result.returncode:
        print('인증서 등록 또는 연결 확인이 완료되지 않았습니다. 서버는 유지합니다.', flush=True)
        print('서버 PC: CONNECT_SERVER.bat / 다른 PC: LAN_CLIENT\\INSTALL_AND_CONNECT.bat', flush=True)
        return False
    return True


def reconnect(root, *, no_browser=False, local=False, lan=False, port=None, server_ip=None, helper_root=None):
    info = probe(root)
    if not info:
        return False
    if port is not None and port != int(info['port']):
        raise RuntimeError('기존 서버의 포트를 바꾸려면 STOP_SERVER.bat로 종료한 후 다시 실행하세요.')
    if (local and info['url'].startswith('https:')) or (lan and info['url'].startswith('http:')):
        raise RuntimeError('기존 서버와 요청한 실행 모드가 다릅니다. STOP_SERVER.bat로 종료한 후 다시 실행하세요.')
    if server_ip:
        settings = json.loads((Path(root) / 'lan_settings.json').read_text(encoding='utf-8'))
        if settings['server_ip'] != server_ip:
            raise RuntimeError('IP 변경 전 STOP_SERVER.bat로 기존 서버를 종료하세요.')
    print('이미 실행 중인 YBY 서버를 확인했습니다. 중복 서버를 만들지 않습니다.', flush=True)
    print(f"현재 실행 버전: V{info['version']} / 접속 주소: {info['url']}", flush=True)
    if info['version'] != '4.1.4':
        print('V4.1.4 업데이트 적용: 이 새 폴더의 STOP_SERVER.bat 실행 → RUN_LAN_WINDOWS.bat 재실행', flush=True)
    if not no_browser:
        if info['url'].startswith('https:') and os.name == 'nt':
            trust_server(root, helper_root)
        else:
            webbrowser.open(info['url'], new=1)
    print('기존 서버 실행 창을 열어 두세요. LAN_CLIENT 위치: ' + str(Path(root) / 'LAN_CLIENT'), flush=True)
    return True

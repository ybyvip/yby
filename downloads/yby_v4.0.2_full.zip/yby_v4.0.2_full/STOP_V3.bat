@echo off
setlocal
chcp 65001 >nul
set "YBY_RUN_DIR=%~dp0"
if exist "%LOCALAPPDATA%\YBY\app\app.py" set "YBY_RUN_DIR=%LOCALAPPDATA%\YBY\app\"
cd /d "%YBY_RUN_DIR%"
where py.exe >nul 2>&1
if errorlevel 1 (python "%YBY_RUN_DIR%stop_server.py") else (py -3 "%YBY_RUN_DIR%stop_server.py")
pause

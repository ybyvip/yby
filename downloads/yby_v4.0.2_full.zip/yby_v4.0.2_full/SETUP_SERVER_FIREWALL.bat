@echo off
setlocal
chcp 65001 >nul
set "YBY_RUN_DIR=%~dp0"
if exist "%LOCALAPPDATA%\YBY\app\lan_settings.json" set "YBY_RUN_DIR=%LOCALAPPDATA%\YBY\app\"
cd /d "%YBY_RUN_DIR%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%YBY_RUN_DIR%tools\setup_firewall.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo 이 도구는 서버에서 관리자 권한으로 실행합니다. 회사 보안 정책이 차단하면 IT 관리자에게 문의하세요.
pause
exit /b %RESULT%

@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상을 설치하고 PATH에 추가하세요.
pause
exit /b 1
:use_py
py -3 "%~dp0windows_bootstrap.py" --lan %*
goto finished
:use_python
python "%~dp0windows_bootstrap.py" --lan %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo 서버가 종료되었습니다. 오류가 있으면 위의 안내와 README_LAN_KO.md를 확인하세요.
pause
exit /b %RESULT%

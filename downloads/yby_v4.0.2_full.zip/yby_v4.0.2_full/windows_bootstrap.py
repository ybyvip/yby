"""Copy Windows runtime to a writable user directory; preserve existing data."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime,timezone
from db_lock import DatabaseLock
import startup_diagnostics as diagnostics

SOURCE=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def source_files(source):
    manifest=json.loads((source/'MANIFEST.json').read_text(encoding='utf-8'))
    files=[]
    for name,sha in manifest['files'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts:raise RuntimeError('패키지 경로가 잘못되었습니다: '+name)
        if Path(name).parts[0] in ('data','certificates','LAN_CLIENT'):continue
        original=source/name;path=original.resolve()
        if not path.is_relative_to(source.resolve()) or original.is_symlink():raise RuntimeError('패키지 경로가 잘못되었습니다: '+name)
        if digest(path)!=sha:raise RuntimeError('패키지가 변경되었거나 불완전합니다. 새 ZIP을 전체 압축 해제하세요: '+name)
        files.append(name)
    return files

def atomic_json(path,value):
    temp=path.with_name(path.name+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=True,indent=2)+'\n',encoding='utf-8');os.replace(temp,path)

def writable_copy(path):
    if path.is_file():path.chmod(0o600);return
    path.chmod(0o700)
    for item in path.rglob('*'):item.chmod(0o700 if item.is_dir() else 0o600)

def prepare_runtime(source,target):
    source=Path(source).resolve();target=Path(target).resolve()
    if source==target:return target
    if target.is_relative_to(source) or source.is_relative_to(target):raise RuntimeError('원본과 실행 폴더는 별도 경로여야 합니다.')
    diagnostics.stage('원본 패키지 무결성 확인',source)
    files=source_files(source)
    if (source/'server.pid').exists():raise RuntimeError('기존 서버의 실행 기록이 있습니다. 기존 STOP_V3.bat로 서버를 종료한 후 다시 실행하세요.')
    diagnostics.stage('사용자 전용 실행 폴더 확인',target)
    target.mkdir(parents=True,exist_ok=True)
    with DatabaseLock(target/'data'):
        with tempfile.TemporaryDirectory(prefix='.write-check-',dir=target) as temp:
            probe=Path(temp)/'probe';probe.write_bytes(b'write-check');os.replace(probe,probe.with_name('renamed'))
        imports_path=target/'source_data_imports.json'
        imports=json.loads(imports_path.read_text()) if imports_path.exists() else {}
        incoming=source/'data/corporate_card_system.db';existing=target/'data/corporate_card_system.db'
        incoming_hash=digest(incoming) if incoming.exists() else None
        if incoming_hash and existing.exists():
            if imports.get(str(source))!=incoming_hash and digest(existing)!=incoming_hash:
                raise RuntimeError('실행 폴더와 새 패키지에 서로 다른 업무 DB가 있습니다. 덮어쓰지 않았습니다. 실행 자료: '+str(target/'data'))
        elif incoming_hash:
            diagnostics.stage('기존 업무 자료 복사(원본 보존)',incoming.parent)
            with tempfile.TemporaryDirectory(prefix='.data-import-',dir=target) as temp:
                imported=Path(temp)/'data';shutil.copytree(source/'data',imported)
                writable_copy(imported)
                if digest(imported/'corporate_card_system.db')!=incoming_hash:raise RuntimeError('복사 중 원본 DB가 바뀌었습니다. 기존 서버를 종료하세요.')
                data=target/'data'
                if data.exists():os.replace(data,target/('data_before_import_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')))
                os.replace(imported,data)
        if incoming_hash:imports[str(source)]=incoming_hash
        for name in ('certificates','lan_settings.json','LAN_CLIENT'):
            src=source/name;dest=target/name
            if src.exists() and not dest.exists():
                diagnostics.stage('기존 접속 설정 복사',src)
                if src.is_dir():shutil.copytree(src,dest)
                else:shutil.copy2(src,dest)
                writable_copy(dest)
        changed=[name for name in files if (target/name).exists() and digest(target/name)!=digest(source/name)]
        if changed:
            saved=target/'program_backups'/datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
            for name in changed:
                previous=saved/name;previous.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target/name,previous)
        diagnostics.stage('프로그램 파일 준비',target)
        for name in files+['MANIFEST.json']:
            src=source/name;dest=target/name
            if not dest.resolve().is_relative_to(target):raise RuntimeError('실행 폴더 외부로 연결된 경로가 있습니다: '+name)
            if dest.exists() and digest(src)==digest(dest):continue
            dest.parent.mkdir(parents=True,exist_ok=True)
            temp=dest.with_name(dest.name+'.installing');shutil.copyfile(src,temp);os.replace(temp,dest)
        (target/'data').mkdir(exist_ok=True)
        atomic_json(imports_path,imports)
    return target

def main():
    os.umask(0o077)
    if os.name!='nt':return subprocess.call([sys.executable,str(SOURCE/'run_ready.py'),*sys.argv[1:]],cwd=SOURCE)
    local=os.environ.get('LOCALAPPDATA')
    if not local:raise RuntimeError('LOCALAPPDATA 경로가 없습니다. 정상 Windows 사용자 계정으로 실행하세요.')
    target=prepare_runtime(SOURCE,Path(local)/'YBY'/'app')
    print('실제 실행 폴더: '+str(target),flush=True)
    print('실제 업무 자료: '+str(target/'data'),flush=True)
    print('다른 PC에 전달할 폴더: '+str(target/'LAN_CLIENT'),flush=True)
    diagnostics.stage('프로그램 시작',target/'run_ready.py')
    return subprocess.call([sys.executable,str(target/'run_ready.py'),*sys.argv[1:]],cwd=target)

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:diagnostics.report(error,SOURCE);raise SystemExit(1)

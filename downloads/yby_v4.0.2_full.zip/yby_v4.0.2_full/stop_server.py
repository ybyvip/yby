"""Stop only the verified server owned by this application directory."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
    marker=ROOT/'server.pid'
    if not marker.exists():print('이 폴더에서 시작한 서버 기록이 없습니다.');return
    meta=json.loads(marker.read_text());pid=int(meta['pid']);app=ROOT/'app.py'
    if Path(meta['app']).resolve()!=app:raise RuntimeError('서버 경로가 다릅니다.')
    if os.name=='nt':
        # PID alone can be reused; require an exact path argument in process metadata.
        script=f"$OutputEncoding=[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new(); $p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if($p){{$p.CommandLine}}"
        command=subprocess.check_output(['powershell','-NoProfile','-Command',script],text=True,encoding='utf-8').strip()
    else:
        proc=Path(f'/proc/{pid}/cmdline')
        if not proc.exists():marker.unlink();print('서버가 이미 종료되었습니다.');return
        arguments=[os.fsdecode(value) for value in proc.read_bytes().split(b'\0') if value]
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        shell=ctypes.WinDLL('shell32',use_last_error=True)
        shell.CommandLineToArgvW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_int)]
        shell.CommandLineToArgvW.restype=ctypes.POINTER(wintypes.LPWSTR)
        count=ctypes.c_int();argv=shell.CommandLineToArgvW(command,ctypes.byref(count))
        if not argv:raise ctypes.WinError(ctypes.get_last_error())
        try:arguments=[argv[i] for i in range(count.value)]
        finally:
            kernel=ctypes.WinDLL('kernel32');kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
            kernel.LocalFree(argv)
    if str(app) not in arguments:raise RuntimeError('해당 PID가 다른 프로그램입니다. 종료하지 않았습니다.')
    os.kill(pid,signal.SIGTERM);marker.unlink(missing_ok=True);print('이 폴더의 서버만 종료 요청했습니다.')


if __name__=='__main__':
    try:main()
    except Exception as e:print('오류:',e,file=sys.stderr);raise SystemExit(1)

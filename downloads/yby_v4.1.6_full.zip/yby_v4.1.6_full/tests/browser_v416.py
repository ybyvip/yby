"""Compact dynamic backdrop, weather resilience, motion controls and auth lifecycle.
Weather responses are fixtures; live MET API access is independently reported.
"""
from pathlib import Path
from datetime import datetime,timezone
import importlib.util,json,os,sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v416-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        context=browser.new_context(viewport={'width':440,'height':690},reduced_motion='reduce')
        context.add_init_script("window.__resizeCalls=[];window.resizeTo=(w,h)=>window.__resizeCalls.push([w,h]);window.moveTo=()=>{}")
        page=context.new_page();errors=[];external=[];weather_requests=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('request',lambda request:external.append(request.url) if not request.url.startswith('http://127.0.0.1:') else None)
        stamp=datetime.now(timezone.utc).isoformat()
        payload={'ready':True,'loading':False,'city':'청주시','condition':'clear','description':'맑음','temperatureC':18.5,'forecastAt':stamp,'stale':False}
        def weather(route):
            weather_requests.append(route.request)
            route.fulfill(status=200,content_type='application/json',body=json.dumps({'ready':False,'loading':True} if len(weather_requests)==1 else payload))
        page.route('**/api/login-weather',weather)
        base=f'http://127.0.0.1:{c.server.server_port}/'
        page.goto(base+'?desktop=1&managed=1')
        page.wait_for_function("()=>document.getElementById('loginWeather').textContent.includes('19°C')")
        assert len(weather_requests)>=2,'Cold-start forecast must appear without waiting ten minutes'
        assert all('cookie' not in r.headers for r in weather_requests)
        assert page.get_attribute('#loginModal','data-motion')=='off'
        assert page.locator('.login-scene').first.evaluate('(e)=>getComputedStyle(e).animationPlayState')=='paused'
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','typing-kept')
        page.click('#loginMotion');assert page.get_attribute('#loginModal','data-motion')=='on'
        assert page.evaluate("localStorage.getItem('ybyLoginMotion')")=='on'
        page.click('#loginMotion');assert page.get_attribute('#loginModal','data-motion')=='off'
        assert page.input_value('#loginPasswordInput')=='typing-kept'
        page.evaluate('clearInterval(loginBackdrop.timer)')
        assert page.evaluate("[selectLoginScene(4,'clear'),selectLoginScene(5,'clear'),selectLoginScene(8,'clear'),selectLoginScene(9,'clear'),selectLoginScene(16,'clear'),selectLoginScene(17,'clear'),selectLoginScene(18,'clear'),selectLoginScene(19,'clear'),selectLoginScene(12,'rain'),selectLoginScene(12,'snow'),selectLoginScene(23,'rain')]")==['night','sunrise','sunrise','day','day','sunset','sunset','night','rain','snow','night']
        def set_scene(hour,condition):
            page.evaluate('''({hour,condition})=>{const date=new Date(Date.UTC(2026,9,17,hour-9));loginBackdrop.manualUntil=0;loginBackdrop.weather={ready:true,condition,description:condition==='rain'?'비':condition==='snow'?'눈':'맑음',temperatureC:18,forecastAt:date.toISOString()};updateLoginAtmosphere(date);}''',{'hour':hour,'condition':condition})
        for hour,condition,key in [(7,'clear','sunrise'),(12,'clear','day'),(18,'clear','sunset'),(22,'clear','night'),(12,'rain','rain'),(12,'snow','snow')]:
            set_scene(hour,condition)
            page.wait_for_function('(key)=>loginBackdrop.scene===key',arg=key)
            assert page.input_value('#loginPasswordInput')=='typing-kept'
            assert page.evaluate('window.__resizeCalls')==[]
            assert page.get_attribute('#loginModal','data-weather')==condition
            bounds=page.locator('.login-box').bounding_box()
            assert bounds['height']<=330,bounds
            assert bounds['y']>=340,bounds
            page.screenshot(path=str(screens/f'yby_v4.1.6_{key}.png'))
        page.evaluate("loginBackdrop.manualUntil=Date.now()+300000;applyLoginScene('classic')")
        page.wait_for_function("()=>loginBackdrop.scene==='classic'")
        page.screenshot(path=str(screens/'yby_v4.1.6_classic.png'))
        # Animated background actually changes its transform while enabled.
        page.click('#loginMotion')
        current=page.locator('.login-scene.is-active')
        t1=current.evaluate('(e)=>getComputedStyle(e).transform')
        page.wait_for_timeout(250)
        t2=current.evaluate('(e)=>getComputedStyle(e).transform');assert t1!=t2,(t1,t2)
        page.click('#loginMotion')
        before=page.evaluate('loginBackdrop.scene');page.click('#loginNextScene')
        page.wait_for_function('(before)=>loginBackdrop.scene!==before',arg=before)
        assert page.locator('#loginAutoScene').is_visible()
        page.click('#loginAutoScene');assert page.locator('#loginAutoScene').is_hidden()
        # Use a fresh renderer: an already decoded image correctly survives an outage from memory.
        failure_context=browser.new_context(viewport={'width':440,'height':690})
        failure=failure_context.new_page()
        failure.route('**/api/login-weather',lambda route:route.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
        failure.route('**/static/login-sunset-v416.jpg',lambda route:route.abort())
        failure.goto(base+'?desktop=1&managed=1')
        failure.fill('#loginUserSelect','admin');failure.fill('#loginPasswordInput','kept-during-outage')
        previous=failure.evaluate('loginBackdrop.scene')
        failure.evaluate("loginBackdrop.manualUntil=Date.now()+300000;applyLoginScene('sunset')")
        failure.wait_for_function("()=>document.getElementById('loginSceneLabel').textContent.includes('사진 연결 대기')")
        assert failure.evaluate('loginBackdrop.scene')==previous
        assert failure.input_value('#loginPasswordInput')=='kept-during-outage'
        assert not failure.locator('#loginSubmitButton').is_disabled()
        failure_context.close()
        # UTC midnight is Korea morning; a stale response cannot choose a weather scene.
        page.evaluate("()=>{loginBackdrop.manualUntil=0;loginBackdrop.weather={ready:true,condition:'snow',temperatureC:1,forecastAt:'2020-01-01T00:00:00Z'};updateLoginAtmosphere(new Date('2026-10-17T00:00:00Z'));}")
        page.wait_for_function("()=>loginBackdrop.scene==='day'")
        assert '시간대 배경' in page.inner_text('#loginWeather')
        assert page.get_attribute('#loginModal','data-weather')=='clear'
        page.set_viewport_size({'width':320,'height':600})
        page.locator('#loginPasswordInput').scroll_into_view_if_needed()
        for width,height in [(320,600),(390,640),(440,690),(1366,900)]:
            page.set_viewport_size({'width':width,'height':height})
            m=page.locator('#loginModal').evaluate('''e=>({width:e.clientWidth,scroll:e.scrollWidth,fields:[...e.querySelectorAll('input,button')].filter(n=>n.offsetParent!==null).map(n=>{let r=n.getBoundingClientRect();return {x:r.x,right:r.right}})})''')
            assert m['scroll']<=m['width']+1 and all(f['x']>=0 and f['right']<=width+1 for f in m['fields']),m
        page.set_viewport_size({'width':440,'height':690})
        page.fill('#loginPasswordInput','')
        set_scene(12,'clear');page.wait_for_function("()=>loginBackdrop.scene==='day'")
        page.screenshot(path=str(screens/'yby_v4.1.6_login.png'))
        # Weather failure must not stop Enter login; no weather polling remains in business mode.
        page.unroute('**/api/login-weather')
        page.route('**/api/login-weather',lambda route:route.abort())
        page.evaluate('async()=>await refreshLoginWeather()')
        for _ in range(3):
            page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter')
            page.wait_for_function("()=>currentUser==='admin'&&document.documentElement.dataset.ybyScreen==='app'")
            assert page.evaluate('loginBackdrop.active===false&&loginBackdrop.timer===null&&loginBackdrop.weatherTimer===null&&loginBackdrop.controller===null')
            assert page.title()=='YBY 법인카드 · 하이패스'
            assert page.input_value('#loginPasswordInput')==''
            page.evaluate('async()=>await handleLogout()')
            page.wait_for_function("()=>currentUser===null&&document.documentElement.dataset.ybyScreen==='login'")
            assert page.evaluate('loginBackdrop.active===true&&loginBackdrop.timer!==null')
            assert page.title()=='YBY 로그인'
        assert page.evaluate('window.__resizeCalls')==[]
        assert not errors,errors
        assert not external,external
        assert not page.evaluate("JSON.stringify(localStorage).includes('Admin-test-pass!')")
        print('PASS: compact <=330px panel at fixed 440x690 viewport; six automatic photos plus original manual photo and KST/day/rain/snow/night boundaries; cold-start weather retry; anonymous weather request; stale/failure fallback; actual CSS motion and pause preference; manual preview/auto; image failure preserves photo and credentials; responsive 320/390/440/1366; login/logout x3 clears passwords and weather timers; managed host resize unchanged; no JS errors.',flush=True)
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

"""Scenic login asset, compact form and managed desktop mode across repeated logouts.
Native HWND sizing is separately exercised by VERIFY_LOGIN_WINDOW_WINDOWS.bat.
"""
from pathlib import Path
import importlib.util,sys,os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v415-screens'));screens.mkdir(exist_ok=True,parents=True)
try:
    c.setUp()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        context=browser.new_context(viewport={'width':440,'height':690})
        context.add_init_script("window.__resizeCalls=[];window.resizeTo=(w,h)=>window.__resizeCalls.push([w,h]);window.moveTo=()=>{}")
        page=context.new_page();errors=[];external=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('request',lambda request:external.append(request.url) if not request.url.startswith('http://127.0.0.1:') else None)
        base=f'http://127.0.0.1:{c.server.server_port}/'
        page.goto(base+'?desktop=1&managed=1')
        page.wait_for_function("()=>document.getElementById('loginAccountStatus').textContent.includes('활성 계정')")
        result=page.request.get(base+'static/login-day-v416.jpg')
        assert result.status==200 and result.headers['content-type']=='image/jpeg'
        assert result.body()==(ROOT/'static/login-day-v416.jpg').read_bytes()
        assert result.headers['x-content-type-options']=='nosniff'
        for path in ['static/login-day-v416.jpg/../../data/corporate_card_system.db','static/unknown.jpg','static/login-day-v416.jpg.bak']:
            assert page.request.get(base+path).status==404,path
        assert 'login-day-v416.jpg' in page.locator('.login-scene').first.evaluate('(e)=>getComputedStyle(e).backgroundImage')
        for width,height in [(440,690),(390,640),(320,600),(1366,900)]:
            page.set_viewport_size({'width':width,'height':height})
            m=page.locator('#loginModal').evaluate('''e=>({width:e.clientWidth,scroll:e.scrollWidth,fields:[...e.querySelectorAll('input,button')].filter(n=>n.offsetParent!==null).map(n=>{let r=n.getBoundingClientRect();return {x:r.x,right:r.right,width:r.width}})})''')
            assert m['scroll']<=m['width']+1 and all(f['x']>=0 and f['right']<=width+1 for f in m['fields']),m
        page.set_viewport_size({'width':440,'height':690})
        assert page.locator('#loginSubmitButton').bounding_box()['y']+46<690
        assert page.locator('.login-version').bounding_box()['y']+15<690
        page.screenshot(path=str(screens/'yby_v4.1.6_login.png'))
        for iteration in range(3):
            assert page.title()=='YBY 로그인'
            assert page.evaluate('document.documentElement.dataset.ybyScreen')=='login'
            assert page.evaluate('window.__resizeCalls')==[]
            assert page.input_value('#loginPasswordInput')==''
            page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter')
            page.wait_for_function("()=>currentUser==='admin'&&document.documentElement.dataset.ybyScreen==='app'")
            assert page.title()=='YBY 법인카드 · 하이패스'
            assert page.evaluate('window.__resizeCalls')==[]
            page.set_viewport_size({'width':1366,'height':900})
            page.evaluate('async()=>await handleLogout()')
            page.wait_for_function("()=>currentUser===null&&document.documentElement.dataset.ybyScreen==='login'")
            # Simulate the geometry applied by the native host; JS must not compete.
            page.set_viewport_size({'width':440,'height':690})
        assert not errors,errors
        assert not external,external
        assert c.request('/health')[1]['database']
        print('PASS: bundled JPEG bytes/MIME/cache/public access; asset traversal denied; no external image/service requests; form 320/390/440/1366 widths; submit/footer fit 440x690; managed desktop login/logout x3 emits exact modes/titles without JS resize races; password cleared; no JS errors. Win32 resizing not executed here.',flush=True)
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

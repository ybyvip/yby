import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import active_runtime
import process_identity
from db_lock import DatabaseLock,DatabaseBusyError


class ReconnectTests(unittest.TestCase):
    def test_pid_reuse_or_app_substring_is_not_process_ownership(self):
        app=ROOT/'app.py'
        with patch.object(process_identity,'arguments',return_value=['python',str(app)+'.unrelated']):
            self.assertFalse(process_identity.owns_app(123,app))
        with patch.object(process_identity,'arguments',return_value=['python',str(app)]):
            self.assertTrue(process_identity.owns_app(123,app))

    def test_stale_pid_never_opens_an_unrelated_http_service(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'server.pid').write_text(json.dumps({'pid':123,'port':5000,'host':'127.0.0.1','app':str(root/'app.py')}))
            with patch.object(process_identity,'owns_app',return_value=False),patch('urllib.request.build_opener') as opener:
                self.assertIsNone(active_runtime.probe(root));opener.assert_not_called()

    def test_lock_collision_is_typed_and_lock_is_retained(self):
        with tempfile.TemporaryDirectory() as folder:
            data=Path(folder)/'data'
            with DatabaseLock(data):
                with self.assertRaises(DatabaseBusyError):
                    with DatabaseLock(data):pass
                self.assertTrue((Path(folder)/'data.runtime.lock').exists())
            with DatabaseLock(data):pass

    def test_new_version_never_claims_it_updated_an_active_old_server(self):
        info={'port':5000,'url':'https://localhost:5000/','version':'4.0.3'}
        import contextlib,io
        output=io.StringIO()
        with patch.object(active_runtime,'probe',return_value=info),contextlib.redirect_stdout(output):
            self.assertTrue(active_runtime.reconnect(ROOT,no_browser=True,lan=True))
        self.assertIn('현재 실행 버전: V4.0.3',output.getvalue())
        self.assertIn('STOP_SERVER.bat',output.getvalue())

    def test_mode_or_port_change_requires_orderly_stop(self):
        info={'port':5000,'url':'https://localhost:5000/','version':'4.1.6'}
        with patch.object(active_runtime,'probe',return_value=info):
            for options in ({'local':True},{'port':5443}):
                with self.assertRaisesRegex(RuntimeError,'STOP_SERVER'):
                    active_runtime.reconnect(ROOT,no_browser=True,**options)


if __name__=='__main__':unittest.main()

"""Complete, checksummed, offline-restorable backup archives."""
from datetime import datetime, timezone
import hashlib
from contextlib import closing
import json
import os
from pathlib import Path
import shutil
import sqlite3
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED


def create(db_path,attachments,output,version='4.1.6'):
    db_path,attachments,output=map(Path,(db_path,attachments,output))
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as t:
        stage=Path(t);data=stage/'data';data.mkdir()
        with closing(sqlite3.connect(db_path)) as source,closing(sqlite3.connect(data/db_path.name)) as dest:
            source.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('백업 DB 무결성 검사 실패')
        if attachments.exists():
            if any(p.is_symlink() for p in attachments.rglob('*')):raise ValueError('첨부 폴더의 심볼릭 링크를 먼저 정리하세요.')
            shutil.copytree(attachments,data/'attachments')
        for name in ('password_display.key','admin_password_vault.key'):
            key=db_path.parent/name
            if key.exists():shutil.copy2(key,data/key.name)
        files={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in data.rglob('*') if p.is_file()}
        manifest={'version':version,'database':db_path.name,'created_at':datetime.now(timezone.utc).isoformat(),'files':files}
        (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
        temp=stage/'archive.zip'
        with ZipFile(temp,'w',ZIP_DEFLATED) as z:
            for p in stage.rglob('*'):
                if p.is_file() and p!=temp:z.write(p,str(p.relative_to(stage)))
        os.replace(temp,output);os.chmod(output,0o600)
    return output


def verify(archive,stage):
    stage=Path(stage)
    with ZipFile(archive) as z:
        names=set();total=0
        for item in z.infolist():
            p=Path(item.filename);total+=item.file_size
            if p.is_absolute() or '..' in p.parts or '\\' in item.filename or item.filename in names or (item.external_attr>>16)&0o170000==0o120000:
                raise ValueError('안전하지 않은 백업 경로입니다.')
            names.add(item.filename)
        if total>2*1024**3 or len(names)>100000:raise ValueError('백업 크기 제한 초과')
        if z.testzip():raise ValueError('백업 ZIP 손상')
        z.extractall(stage)
    manifest=json.loads((stage/'manifest.json').read_text())
    actual={str(p.relative_to(stage)) for p in (stage/'data').rglob('*') if p.is_file()}
    if actual!=set(manifest['files']):raise ValueError('백업 파일 목록 불일치')
    for name,digest in manifest['files'].items():
        p=Path(name)
        if p.is_absolute() or '..' in p.parts or p.parts[0]!='data':raise ValueError('잘못된 매니페스트 경로')
        if hashlib.sha256((stage/p).read_bytes()).hexdigest()!=digest:raise ValueError('백업 체크섬 불일치: '+name)
    dbname=manifest['database']
    if Path(dbname).name!=dbname:raise ValueError('잘못된 DB 이름')
    with closing(sqlite3.connect((stage/'data'/dbname).as_uri()+'?mode=ro',uri=True)) as c:
        if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('복원 DB 무결성 실패')
    return manifest


def restore(archive,data_dir):
    data_dir=Path(data_dir).resolve();data_dir.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=data_dir.parent) as t:
        stage=Path(t);manifest=verify(archive,stage)
        original=None
        if data_dir.exists():
            original=data_dir.parent/('data_before_restore_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f'))
            os.replace(data_dir,original)
        try:os.replace(stage/'data',data_dir)
        except BaseException:
            if original is not None:os.replace(original,data_dir)
            raise
    return {'restored':str(data_dir),'preserved_original':str(original) if original else None,'version':manifest['version']}

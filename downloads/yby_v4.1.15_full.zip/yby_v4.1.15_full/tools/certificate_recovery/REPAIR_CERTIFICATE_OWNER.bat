@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0repair_certificate_owner.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo PASS가 표시되면 기존 RUN_LAN_WINDOWS.bat를 일반 권한으로 실행하세요.
pause
exit /b %RESULT%

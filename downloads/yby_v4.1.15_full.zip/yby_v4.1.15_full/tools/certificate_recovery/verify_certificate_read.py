"""Read/SSL check only: run by the original non-elevated Windows user."""
import argparse
import ctypes
import hashlib
from pathlib import Path
import ssl
import sys

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',required=True,type=Path)
    args=parser.parse_args()
    if sys.platform=='win32' and ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('읽기 검사는 일반 권한으로 해야 합니다. 복구 BAT를 더블클릭하여 실행하세요.')
    directory=args.directory
    for name in ('root-ca.cer','root-ca.pem','server.pem','server-key.pem'):
        with (directory/name).open('rb') as stream:
            if not stream.read(1):raise RuntimeError('빈 인증서/키 파일: '+name)
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(directory/'server.pem'),str(directory/'server-key.pem'))
    ssl.create_default_context(cafile=str(directory/'root-ca.pem'))
    print('PASS: 원래 사용자의 일반 권한 Python에서 인증서 읽기·서버 키 로드 성공')
    print('CA SHA-256: '+hashlib.sha256((directory/'root-ca.cer').read_bytes()).hexdigest().upper())
    print('기존 RUN_LAN_WINDOWS.bat를 일반 권한으로 실행하세요.')

if __name__=='__main__':
    try:main()
    except Exception as error:print('검사 실패: '+str(error),file=sys.stderr);raise SystemExit(1)

﻿YBY 인증서 소유권·접근권한 1회 복구

현재 RUN_LAN_WINDOWS.bat가 root-ca.cer의 권한을 바꾸는 단계에서 Access is denied로 중단되는 상태에 적용합니다. 기존 일반 권한 복구로 해결되지 않는 파일 소유권/변경 권한을 관리자 승인으로 복구합니다. 기존 V4.0.3 전체 프로그램은 그대로 사용합니다.

실행:
1. 종료된 프로그램 창을 닫습니다.
2. 이 ZIP을 새 폴더에 전체 압축 해제합니다.
3. REPAIR_CERTIFICATE_OWNER.bat를 평소 사용자 계정으로 더블클릭합니다. 시작부터 관리자 권한으로 실행하지 마세요.
4. 도구가 표시하는 사용자 인증서 폴더 경로를 확인하고 Windows 관리자 승인(UAC)을 진행합니다. 관리자 권한/인증 정보가 없으면 IT 담당자의 승인이 필요합니다.
5. 관리자 작업이 끝나면 자동으로 원래 사용자의 일반 권한 Python에서 인증서 읽기와 서버 인증서/개인키 로드를 검사합니다.
6. PASS가 표시되면 기존 RUN_LAN_WINDOWS.bat를 일반 권한으로 다시 실행합니다.

대상과 변경:
- 원래 사용자의 AppData/Local/YBY/app/certificates 폴더와 고정된 인증서 파일 5개만 대상으로 합니다.
- root-ca.cer, root-ca.pem, server.pem, server-key.pem, 선택적인 root-ca-key.pem입니다.
- 파일/폴더의 소유권을 Administrators 그룹으로 복구하고, 원래 사용자 SID·SYSTEM·Administrators에 파일 직접 F 권한을 부여합니다. 원래 사용자는 이후 일반 권한으로 읽기/권한 변경이 가능합니다.
- 다른 관리자 계정으로 UAC 승인을 받아도 원래 사용자의 경로와 SID를 유지합니다.
- 업무 DB·인증서 파일 내용·키·CA를 삭제하거나 새로 발급하지 않습니다. 프로그램 코드나 Windows 전체 보안 설정을 바꾸지 않습니다. Everyone 권한을 추가하지 않습니다.
- 재귀 takeown, 드라이브 전체 처리, 와일드카드를 사용하지 않습니다. 링크/리디렉션 경로와 EFS 암호화 파일은 자동 처리하지 않고 중단합니다.

진단:
원래 사용자의 AppData/Local/YBY/diagnostics/owner_repair_*.json.log에서 결과를 확인합니다. 인증서나 키 내용은 로그에 출력하지 않습니다. PASS가 나오지 않으면 표시된 오류와 이 로그를 전달하세요. 관리자 권한 없이 파일 소유권을 강제로 복구할 수는 없습니다.

검증 범위:
이 도구의 경로 제한·권한 요청 분리·파일 내용 보존·Python 읽기/SSL 검사 로직을 확인합니다. 클라우드는 Linux이므로 실제 Windows takeown/UAC/NTFS 실행 결과로 표시하지 않습니다. 해당 PC의 성공 여부는 원래 사용자 일반 권한 검사 PASS로 확인합니다. PASS는 파일 접근과 SSL 키 로드 확인이며 VPN·다른 PC 연결 전체의 보증은 아닙니다.

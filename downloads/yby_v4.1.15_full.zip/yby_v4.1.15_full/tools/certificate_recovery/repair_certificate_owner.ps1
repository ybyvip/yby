﻿param([switch]$Elevated,[string]$RequestPath)
$ErrorActionPreference='Stop'
$OutputEncoding=[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
$admin=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin=$admin.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$allowedNames=@('root-ca.cer','root-ca.pem','server.pem','server-key.pem','root-ca-key.pem')

function Run-Native([string]$Executable,[string[]]$Arguments) {
    $previous=$ErrorActionPreference
    try { $ErrorActionPreference='Continue'; $output=& $Executable @Arguments 2>&1; $code=$LASTEXITCODE }
    finally { $ErrorActionPreference=$previous }
    $output | ForEach-Object { Write-Host $_ }
    if ($code -ne 0) { throw ('Native repair failed ('+$code+'): '+$Executable) }
}

try {
    if (-not $Elevated) {
        if ($isAdmin) { throw 'Start REPAIR_CERTIFICATE_OWNER.bat normally (double-click), not as administrator. The tool requests elevation for only the repair step.' }
        $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        $certificates=Join-Path $env:LOCALAPPDATA 'YBY\app\certificates'
        if (-not (Test-Path -LiteralPath $certificates -PathType Container)) { throw ('Certificate directory not found: '+$certificates) }
        $logs=Join-Path $env:LOCALAPPDATA 'YBY\diagnostics'
        New-Item -ItemType Directory -Path $logs -Force | Out-Null
        $request=Join-Path $logs ('owner_repair_'+[Guid]::NewGuid().ToString('N')+'.json')
        @{ sid=$sid; directory=[IO.Path]::GetFullPath($certificates) } | ConvertTo-Json | Set-Content -LiteralPath $request -Encoding UTF8
        Write-Host ('Target: '+$certificates)
        Write-Host 'The following UAC request repairs only this YBY certificate directory and the named certificate files. It does not change database/certificate contents or regenerate certificates.'
        $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$PSCommandPath+'"'),'-Elevated','-RequestPath',('"'+$request+'"'))
        $process=Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        if ($process.ExitCode -ne 0) { throw ('Administrator repair failed. See '+$request+'.log') }
        # Back in the ORIGINAL normal token: do not confuse administrator readability with user readability.
        $verifier=Join-Path $PSScriptRoot 'verify_certificate_read.py'
        if (Get-Command py.exe -ErrorAction SilentlyContinue) { & py.exe -3 $verifier --directory $certificates }
        elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { & python.exe $verifier --directory $certificates }
        else { throw 'Python was not found in the original user account.' }
        if ($LASTEXITCODE -ne 0) { throw ('Normal-user Python check failed. Diagnostic: '+$request+'.log') }
        Write-Host ('Diagnostic: '+$request+'.log')
        exit 0
    }

    if (-not $isAdmin) { throw 'This step requires the approved administrator token.' }
    if (-not $RequestPath) { throw 'Missing repair request.' }
    $request=Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $sid=[Security.Principal.SecurityIdentifier]::new([string]$request.sid)
    $ownerSid=(Get-Acl -LiteralPath $RequestPath).GetOwner([Security.Principal.SecurityIdentifier]).Value
    if ($ownerSid -ne $sid.Value) { throw 'Repair request must be owned by the original user.' }
    # Resolve the original user's profile, even when UAC credentials belong to another administrator.
    $userProfileRoot=(Get-ItemProperty -LiteralPath ('HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\'+$sid.Value)).ProfileImagePath
    $userProfileRoot=[Environment]::ExpandEnvironmentVariables($userProfileRoot)
    $expected=[IO.Path]::GetFullPath((Join-Path $userProfileRoot 'AppData\Local\YBY\app\certificates'))
    $directory=[IO.Path]::GetFullPath([string]$request.directory)
    if ($directory.TrimEnd('\') -ine $expected.TrimEnd('\')) { throw 'Repair request does not match the original user profile and YBY certificate directory.' }
    # No recursive takeown, no wildcard and no junction/symlink traversal.
    foreach ($part in @($userProfileRoot,(Join-Path $userProfileRoot 'AppData'),(Join-Path $userProfileRoot 'AppData\Local'),(Join-Path $userProfileRoot 'AppData\Local\YBY'),(Join-Path $userProfileRoot 'AppData\Local\YBY\app'),$directory)) {
        $entry=Get-Item -LiteralPath $part -Force
        if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw ('Reparse point is not supported: '+$part) }
    }
    $log=$RequestPath+'.log'
    Start-Transcript -LiteralPath $log -Force | Out-Null
    try {
        Write-Host ('Target original user SID: '+$sid.Value)
        Write-Host ('Target: '+$directory)
        $takeown=Join-Path $env:SystemRoot 'System32\takeown.exe'
        $icacls=Join-Path $env:SystemRoot 'System32\icacls.exe'
        Run-Native $takeown @('/F',$directory,'/A')
        Run-Native $icacls @($directory,'/grant:r',('*'+$sid.Value+':(OI)(CI)F'),'*S-1-5-18:(OI)(CI)F','*S-1-5-32-544:(OI)(CI)F')
        $entries=@(Get-ChildItem -LiteralPath $directory -Force)
        foreach ($entry in $entries) {
            if ($allowedNames -notcontains $entry.Name) { continue }
            if ($entry.PSIsContainer -or (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { throw ('Unexpected directory/link: '+$entry.FullName) }
            if (($entry.Attributes -band [IO.FileAttributes]::Encrypted) -ne 0) { throw ('EFS encryption detected; restore access through the original EFS account/key: '+$entry.FullName) }
            Run-Native $takeown @('/F',$entry.FullName,'/A')
            Run-Native $icacls @($entry.FullName,'/grant:r',('*'+$sid.Value+':F'),'*S-1-5-18:F','*S-1-5-32-544:F')
        }
        foreach ($name in @('root-ca.cer','root-ca.pem','server.pem','server-key.pem')) {
            if ($entries.Name -notcontains $name) { throw ('Required certificate is missing: '+$name) }
        }
        Write-Host 'Administrator ownership/ACL repair complete. Returning to the original normal-user Python check.'
    } finally { Stop-Transcript | Out-Null }
    exit 0
} catch {
    Write-Host ('FAILED: '+$_.Exception.Message) -ForegroundColor Red
    if ($Elevated) { Start-Sleep -Seconds 8 }
    exit 1
}

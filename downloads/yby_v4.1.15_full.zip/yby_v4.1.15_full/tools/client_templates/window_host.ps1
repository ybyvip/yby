﻿param([string]$BrowserPath, [string]$ProfileHome, [string]$Url, [switch]$VerifyWindowSizing)
$ErrorActionPreference = 'Stop'
$mutex = $null
$ownsMutex = $false
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections.Generic;
public static class YbyWindow {
    public delegate bool EnumProc(IntPtr handle, IntPtr param);
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc proc, IntPtr param);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out Rect rect);
    [DllImport("user32.dll", EntryPoint="GetWindowLongW")] static extern int GetStyle32(IntPtr h, int index);
    [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetStyle64(IntPtr h, int index);
    [DllImport("user32.dll", EntryPoint="SetWindowLongW")] static extern int SetStyle32(IntPtr h, int index, int value);
    [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW")] static extern IntPtr SetStyle64(IntPtr h, int index, IntPtr value);
    [DllImport("user32.dll", SetLastError=true)] static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int w, int t, uint flags);
    [DllImport("user32.dll")] static extern uint GetDpiForWindow(IntPtr h);
    [DllImport("user32.dll")] static extern bool SetProcessDpiAwarenessContext(IntPtr mode);
    [DllImport("shell32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr CommandLineToArgvW(string line, out int count);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr block);
    static readonly Dictionary<IntPtr,long> originals = new Dictionary<IntPtr,long>();
    public static void EnableDpi() { try { SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch(EntryPointNotFoundException) {} }
    public static long Style(IntPtr h) { return IntPtr.Size==8 ? GetStyle64(h,-16).ToInt64() : (long)(uint)GetStyle32(h,-16); }
    static void Style(IntPtr h,long value) { if(IntPtr.Size==8)SetStyle64(h,-16,new IntPtr(value));else SetStyle32(h,-16,unchecked((int)value)); }
    public static string Title(IntPtr h) { var text=new StringBuilder(1024);GetWindowText(h,text,text.Capacity);return text.ToString(); }
    public static string Mode(string title) {
        if(title=="YBY 로그인" || title.StartsWith("YBY 로그인 - ") || title.StartsWith("YBY 로그인 — "))return "login";
        if(title=="YBY 법인카드 · 하이패스" || title.StartsWith("YBY 법인카드 · 하이패스 - ") || title.StartsWith("YBY 법인카드 · 하이패스 — "))return "app";
        return "";
    }
    // Exact argv matching prevents matching another profile whose path shares a prefix.
    public static bool OwnProfile(string commandLine,string profile) {
        if(String.IsNullOrEmpty(commandLine))return false;
        int count;IntPtr block=CommandLineToArgvW(commandLine,out count);if(block==IntPtr.Zero)return false;
        try {
            bool match=false;
            for(int i=1;i<count;i++) {
                string arg=Marshal.PtrToStringUni(Marshal.ReadIntPtr(block,i*IntPtr.Size));
                if(arg=="--type" || arg.StartsWith("--type=",StringComparison.OrdinalIgnoreCase))return false;
                string value=null;
                if(arg.StartsWith("--user-data-dir=",StringComparison.OrdinalIgnoreCase))value=arg.Substring(16);
                else if(arg.Equals("--user-data-dir",StringComparison.OrdinalIgnoreCase) && i+1<count)value=Marshal.PtrToStringUni(Marshal.ReadIntPtr(block,++i*IntPtr.Size));
                if(value!=null) {
                    try { match=String.Equals(System.IO.Path.GetFullPath(value).TrimEnd('\\'),profile.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase); }
                    catch(ArgumentException) { return false; }
                }
            }
            return match;
        } finally { LocalFree(block); }
    }
    public static IntPtr[] Windows(int[] pids) {
        var ids=new HashSet<int>(pids);var handles=new List<IntPtr>();
        EnumWindows(delegate(IntPtr h,IntPtr param) {
            uint pid;GetWindowThreadProcessId(h,out pid);
            if(!ids.Contains((int)pid) || !IsWindowVisible(h))return true;
            var name=new StringBuilder(128);GetClassName(h,name,name.Capacity);
            if(name.ToString()=="Chrome_WidgetWin_1")handles.Add(h);
            return true;
        },IntPtr.Zero);
        return handles.ToArray();
    }
    public static double Scale(IntPtr h) { try { uint dpi=GetDpiForWindow(h);return dpi==0?1:dpi/96.0; } catch(EntryPointNotFoundException) { return 1; } }
    public static void Forget(IntPtr h) { originals.Remove(h); }
    public static void Apply(IntPtr h,bool login,bool transition,int left,int top,int workWidth,int workHeight) {
        if(!IsWindow(h) || (!login && !transition))return;
        long style=Style(h);
        if(!originals.ContainsKey(h))originals[h]=style | 0x00050000L;
        long wanted=login ? originals[h] & ~0x00050000L : originals[h]; // WS_THICKFRAME | WS_MAXIMIZEBOX
        if(style!=wanted) {
            Style(h,wanted);
            SetWindowPos(h,IntPtr.Zero,0,0,0,0,0x0037); // frame changed, no size/move/z-order/activation
        }
        if(IsIconic(h))return; // A deliberately minimized window stays minimized.
        if(IsZoomed(h))ShowWindow(h,9); // Restore before shrinking: JS resizeTo cannot reliably do this.
        double scale=Scale(h);
        int width=Math.Min(workWidth,(int)Math.Round((login?440:1360)*scale));
        int height=Math.Min(workHeight,(int)Math.Round((login?720:900)*scale));
        Rect rect;if(!GetWindowRect(h,out rect))return;
        int x=transition?left+(workWidth-width)/2:Math.Max(left,Math.Min(rect.Left,left+workWidth-width));
        int y=transition?top+(workHeight-height)/2:Math.Max(top,Math.Min(rect.Top,top+workHeight-height));
        if(rect.Right-rect.Left!=width || rect.Bottom-rect.Top!=height || rect.Left!=x || rect.Top!=y)
            if(!SetWindowPos(h,IntPtr.Zero,x,y,width,height,0x0014) && IsWindow(h))throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    }
}
'@
    [YbyWindow]::EnableDpi()
    function Set-YbyMode([IntPtr]$Handle, [bool]$Login, [bool]$Transition) {
        $work = [Windows.Forms.Screen]::FromHandle($Handle).WorkingArea
        [YbyWindow]::Apply($Handle,$Login,$Transition,$work.Left,$work.Top,$work.Width,$work.Height)
    }
    if ($VerifyWindowSizing) {
        # Native test requires a real Windows desktop, but never opens company data or installs certificates.
        $test = New-Object Windows.Forms.Form
        $other = New-Object Windows.Forms.Form
        try {
            $test.Text = 'YBY 로그인'; $test.Size = New-Object Drawing.Size(900,850)
            $other.Text = 'Unrelated window'; $other.Size = New-Object Drawing.Size(600,400)
            $test.Show(); $other.Show(); [Windows.Forms.Application]::DoEvents()
            $unrelated = $other.Bounds
            for ($i=0; $i -lt 3; $i++) {
                Set-YbyMode $test.Handle $false $true
                $test.WindowState = [Windows.Forms.FormWindowState]::Maximized
                [Windows.Forms.Application]::DoEvents()
                Set-YbyMode $test.Handle $true $true
                [Windows.Forms.Application]::DoEvents()
                $rect = New-Object YbyWindow+Rect
                [void][YbyWindow]::GetWindowRect($test.Handle,[ref]$rect)
                $work = [Windows.Forms.Screen]::FromHandle($test.Handle).WorkingArea
                $scale = [YbyWindow]::Scale($test.Handle)
                if ([YbyWindow]::IsZoomed($test.Handle) -or ($rect.Right-$rect.Left) -ne [Math]::Min($work.Width,[Math]::Round(440*$scale)) -or ($rect.Bottom-$rect.Top) -ne [Math]::Min($work.Height,[Math]::Round(720*$scale))) { throw '로그아웃 후 로그인 창 크기 검사 실패' }
                if (([YbyWindow]::Style($test.Handle) -band 0x50000) -ne 0) { throw '로그인 창 크기 고정 검사 실패' }
                if ($other.Bounds -ne $unrelated) { throw '다른 창 영향 검사 실패' }
            }
            $fixtureProfile = 'C:\Users\test\AppData\Local\YBY\desktop\ABCDEF0123456789-5000-server'
            if (-not [YbyWindow]::OwnProfile(('msedge.exe --user-data-dir="'+$fixtureProfile+'"'),$fixtureProfile)) { throw '프로필 일치 검사 실패' }
            if ([YbyWindow]::OwnProfile(('msedge.exe --user-data-dir="'+$fixtureProfile+'-other"'),$fixtureProfile)) { throw '다른 프로필 구분 실패' }
            if ([YbyWindow]::OwnProfile(('msedge.exe --type=renderer --user-data-dir="'+$fixtureProfile+'"'),$fixtureProfile)) { throw '하위 프로세스 구분 실패' }
            Write-Host 'PASS: native login 440x720 (DPI adjusted), maximized logout x3, fixed resize/maximize controls, unrelated window untouched, exact browser profile.' -ForegroundColor Green
        } finally { $test.Close();$test.Dispose();$other.Close();$other.Dispose() }
        exit 0
    }
    if (-not $BrowserPath -or -not $ProfileHome -or -not $Url) { throw '로그인 창 실행 정보가 없습니다.' }
    $BrowserPath = [IO.Path]::GetFullPath($BrowserPath)
    $ProfileHome = [IO.Path]::GetFullPath($ProfileHome).TrimEnd('\')
    $profileBase = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'YBY\desktop')).TrimEnd('\') + '\'
    if (-not $ProfileHome.StartsWith($profileBase,[StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $ProfileHome) -notmatch '^[0-9A-F]{16}-[0-9]{1,5}-(server|client)$') { throw 'YBY 전용 프로필 경로가 아닙니다.' }
    $browserName = [IO.Path]::GetFileName($BrowserPath)
    if ($browserName -notin @('msedge.exe','chrome.exe') -or -not (Test-Path -LiteralPath $BrowserPath -PathType Leaf)) { throw 'Edge 또는 Chrome을 찾을 수 없습니다.' }
    $address = [Uri]$Url
    if ($address.Scheme -ne 'https' -or $address.UserInfo -or $address.Query -or $address.Fragment -or $address.AbsolutePath -ne '/') { throw '보안 접속 주소가 잘못되었습니다.' }
    $hash = [Security.Cryptography.SHA256]::Create()
    try { $key = [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($ProfileHome.ToLowerInvariant()))).Replace('-','') } finally { $hash.Dispose() }
    $mutex = New-Object Threading.Mutex($false,('Local\YBYWindow-'+$key))
    try { $ownsMutex = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $ownsMutex=$true }
    # The existing per-profile host also manages a newly opened window. No Windows autostart is registered.
    $browserArguments = '--app="' + $Url.TrimEnd('/') + '/?desktop=1&managed=1" --window-size=440,720 --no-first-run --no-default-browser-check --user-data-dir="' + $ProfileHome + '"'
    Start-Process -FilePath $BrowserPath -ArgumentList $browserArguments
    if (-not $ownsMutex) { exit 0 }
    $states = @{}; $seenWindow=$false; $missingSince=Get-Date; $refresh=[DateTime]::MinValue
    $browserIds = @()
    while ($true) {
        if (((Get-Date)-$refresh).TotalSeconds -ge 1) {
            $browserIds = @(Get-CimInstance Win32_Process -Filter ("Name = '"+$browserName+"'") | Where-Object {
                $_.ExecutablePath -and $_.ExecutablePath.Equals($BrowserPath,[StringComparison]::OrdinalIgnoreCase) -and [YbyWindow]::OwnProfile($_.CommandLine,$ProfileHome)
            } | ForEach-Object { [int]$_.ProcessId })
            $refresh=Get-Date
        }
        $handles = @([YbyWindow]::Windows([int[]]$browserIds))
        $tracked = @()
        foreach ($handle in $handles) {
            $id = $handle.ToInt64().ToString()
            $mode = [YbyWindow]::Mode([YbyWindow]::Title($handle))
            if (-not $mode -and -not $states.ContainsKey($id)) { continue }
            $tracked += $id
            if ($mode) {
                Set-YbyMode $handle ($mode -eq 'login') ($states[$id] -ne $mode)
                $states[$id]=$mode
            }
        }
        foreach ($old in @($states.Keys)) { if ($old -notin $tracked) { [YbyWindow]::Forget([IntPtr][long]$old); $states.Remove($old) } }
        if ($tracked.Count -gt 0) { $seenWindow=$true; $missingSince=Get-Date }
        elseif (((Get-Date)-$missingSince).TotalSeconds -ge $(if($seenWindow){6}else{45})) {
            if (-not $seenWindow) { throw 'YBY 로그인 창을 찾지 못했습니다. 회사 정책의 Edge/Chrome 앱 실행 허용 여부를 확인하세요.' }
            break
        }
        Start-Sleep -Milliseconds 300
    }
} catch {
    $message = $_.Exception.Message
    try {
        $diagnostics = Join-Path $env:LOCALAPPDATA 'YBY\diagnostics'
        New-Item -ItemType Directory -Path $diagnostics -Force | Out-Null
        [IO.File]::WriteAllText((Join-Path $diagnostics ('login_window_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')),$message,[Text.Encoding]::UTF8)
        [void][Windows.Forms.MessageBox]::Show(('로그인 창을 준비하지 못했습니다.'+"`n`n"+$message+"`n`n회사 서버는 계속 실행됩니다. CONNECT_SERVER.bat로 다시 실행하세요."),'YBY 로그인 창',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Warning)
    } catch { }
    Write-Host $message -ForegroundColor Red
    exit 1
} finally {
    if ($ownsMutex -and $mutex) { $mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
}

﻿param([Parameter(Mandatory=$true)][string]$RequestPath, [Parameter(Mandatory=$true)][string]$OutputPath)
$ErrorActionPreference = 'Stop'
$request = Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
$ip = [System.Net.IPAddress]::Parse($request.server_ip)
if ($ip.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) { throw 'IPv4 required' }
if ($request.hostname -notmatch '^[A-Za-z0-9.-]{1,253}$') { throw 'Invalid hostname' }
$provider = 'Microsoft Enhanced RSA and AES Cryptographic Provider'
if ($request.root_thumbprint) {
    $root = Get-Item -LiteralPath ('Cert:\CurrentUser\My\' + $request.root_thumbprint)
    if (-not $root.HasPrivateKey) { throw 'Existing YBY CA private key is unavailable. Restore the server certificate store.' }
} else {
    $root = New-SelfSignedCertificate -Type Custom -Subject ('CN=YBY LAN Root ' + $request.id) -CertStoreLocation 'Cert:\CurrentUser\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -KeySpec Signature -Provider $provider -KeyUsage @('CertSign','CRLSign') -TextExtension @('2.5.29.19={critical}{text}ca=1&pathlength=0') -NotAfter (Get-Date).AddYears(5)
}
$san = '2.5.29.17={text}DNS=localhost&DNS=' + $request.hostname + '&IPAddress=127.0.0.1&IPAddress=' + $request.server_ip
$leaf = New-SelfSignedCertificate -Type Custom -Subject ('CN=' + $request.hostname) -Signer $root -CertStoreLocation 'Cert:\CurrentUser\My' -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 -KeyExportPolicy Exportable -KeySpec KeyExchange -Provider $provider -KeyUsage @('DigitalSignature','KeyEncipherment') -TextExtension @($san,'2.5.29.19={critical}{text}ca=0','2.5.29.37={text}1.3.6.1.5.5.7.3.1') -NotAfter (Get-Date).AddDays(365)
try {
    $rsa = $leaf.PrivateKey
    $parameters = $rsa.ExportParameters($true)
    $export = @{}
    foreach ($name in @('Modulus','Exponent','D','P','Q','DP','DQ','InverseQ')) { $export[$name] = [Convert]::ToBase64String($parameters.$name) }
    $result = @{ certificate=[Convert]::ToBase64String($leaf.RawData); root_certificate=[Convert]::ToBase64String($root.RawData); root_thumbprint=$root.Thumbprint; parameters=$export; expires_utc=$leaf.NotAfter.ToUniversalTime().ToString('o') }
    $result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $OutputPath -Encoding ASCII
} finally {
    if ($rsa) { $rsa.Dispose() }
    Remove-Item -LiteralPath ('Cert:\CurrentUser\My\' + $leaf.Thumbprint) -DeleteKey
}

/* Pure ledger calculations shared by the screen, exports and report. */
(function (root) {
    'use strict';
    const key = values => JSON.stringify(values.map(value => String(value ?? '')));
    const branchRows = (rows, scope) => (rows || []).filter(row => scope === 'ALL' || row.group === scope);
    const cardKey = row => key([row.group, row.cardNum ?? row.num]);
    const eventKey = row => key([row.group, row.id]);
    const expenseKey = row => key([row.group, row.requester, row.id]);
    function eventTime(row) {
        const raw = String(row.time || (row.type === '반납' ? row.returnDate : row.rentDate) || '');
        // Older YBY Korean wall times have no zone; newer server times are UTC.
        const normalized = raw.replace(' ', 'T');
        const ms = Date.parse(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/.test(normalized) ? normalized + '+09:00' : /^\d{4}-\d{2}-\d{2}$/.test(normalized) ? normalized+'T00:00:00+09:00' : normalized);
        return Number.isFinite(ms) ? ms : -Infinity;
    }
    function newest(rows) {
        return rows.map((row, index) => ({row, index})).sort((a, b) => {
            const at=eventTime(a.row), bt=eventTime(b.row);
            if (at !== bt) return at > bt ? -1 : 1;
            const ai=Number(a.row.id), bi=Number(b.row.id);
            if (Number.isFinite(ai) && Number.isFinite(bi) && ai !== bi) return bi-ai;
            return b.index-a.index;
        }).map(item => item.row);
    }
    function cardContext(history, cards, expenses, scope) {
        const rows=branchRows(history, scope), counts=new Map(), pairs=new Map(), issues=new Map(), open=new Map(), uncertain=new Set();
        const chronological=newest(rows).reverse();
        for (const row of chronological) {
            const ckey=cardKey(row);
            if (row.type === '불출') {
                if (String(row.user || '').trim()) {
                    const ukey=key([row.group, String(row.user).trim()]);
                    counts.set(ukey, (counts.get(ukey) || 0)+1);
                }
                issues.set(eventKey(row), row);
                if (open.has(ckey)) {uncertain.add(open.get(ckey));uncertain.add(row);}
                open.set(ckey, row);
            } else if (row.type === '반납') {
                const explicit=row.rentalEventId != null ? issues.get(key([row.group, row.rentalEventId])) : null;
                const candidate=row.rentalEventId != null?explicit:open.get(ckey);
                const compatible=candidate && cardKey(candidate)===ckey &&
                    (!row.user || !candidate.user || row.user===candidate.user) &&
                    (!row.dept || !candidate.dept || row.dept===candidate.dept);
                if (compatible && !pairs.has(candidate) && (explicit || !uncertain.has(candidate))) {
                    pairs.set(candidate,row); pairs.set(row,candidate);
                }
                if (open.get(ckey)===candidate || row.rentalEventId == null) open.delete(ckey);
            }
        }
        const expenseMap=new Map(branchRows(expenses,scope).map(row=>[expenseKey(row),row]));
        const currentCards=branchRows(cards,scope);
        function progress(row) {
            let returned=row.type==='반납'?row:pairs.get(row);
            if (!returned) {
                const current=currentCards.find(card=>cardKey(card)===cardKey(row));
                const last=open.get(cardKey(row));
                const exact=current && current.status==='rented' &&
                    (current.rentalEventId != null ? String(current.rentalEventId)===String(row.id) :
                        last===row && !uncertain.has(row) && current.user===row.user && current.rentDate===(row.rentDate || String(row.time || '').slice(0,10)));
                return exact?{label:'대여중 · 반납대기',tone:'pending'}:{label:'반납 연결 확인 필요',tone:'neutral'};
            }
            // An issue is complete as soon as its own matching return exists.
            // Settlement/approval progress belongs to the return event only.
            if (row.type==='불출') return {label:'불출완료',tone:'complete'};
            if (returned.used === false) return {label:'반납완료 · 미사용',tone:'complete'};
            const ref=returned.expenseRef;
            let expense=ref?expenseMap.get(expenseKey(ref)):null;
            if (expense && cardKey(expense)!==cardKey(returned)) expense=null;
            if (!expense) return {label:returned.used===true?'반납완료 · 정산 이력 확인':'반납완료',tone:'complete'};
            const seen=new Set();
            while (expense.resubmissionId && !seen.has(expenseKey(expense))) {
                seen.add(expenseKey(expense));
                const next=expenseMap.get(key([expense.group,expense.requester,expense.resubmissionId]));
                if (!next) break;
                expense=next;
            }
            const status=expense.status || '정산 확인';
            return {label:'반납완료 · '+status,tone:status==='승인완료'?'complete':status==='반려됨'||status==='승인취소'?'attention':'pending'};
        }
        return {count:row=>String(row.user || '').trim()?counts.get(key([row.group,String(row.user).trim()])) || 0:null,progress};
    }
    function effectiveApproved(row) {
        return row.status==='승인완료' && !row.isCorrection && !row.correctionId && !row.resubmissionId;
    }
    function lines(row) {
        if (Array.isArray(row.lineItems) && row.lineItems.length) return row.lineItems;
        return [{date:row.date,category:row.category || '미분류',amount:Number(row.amount) || 0,merchant:row.merchant}];
    }
    function summary(rows, scope) {
        const visible=branchRows(rows,scope), categories=new Map(), statuses=new Map();
        let usageCount=0,amount=0,approvedDocuments=0,invalidAmounts=0;
        const validMoney=value=>(typeof value==='number' || (typeof value==='string' && /^\d+$/.test(value))) && Number.isSafeInteger(Number(value)) && Number(value)>0;
        const add=(a,b)=>{const n=Number(b); if (!Number.isSafeInteger(n) || !Number.isSafeInteger(a+n)) {invalidAmounts++;return a;} return a+n;};
        for (const row of visible) {
            const state=row.status || '상태 미확인';
            statuses.set(state,(statuses.get(state) || 0)+1);
            if (!effectiveApproved(row)) continue;
            approvedDocuments++;
            const touched=new Set();
            const itemTotal=lines(row).reduce((total,item)=>total+Number(item.amount),0);
            if (!validMoney(row.amount) || !Number.isSafeInteger(itemTotal) || itemTotal!==Number(row.amount)) invalidAmounts++;
            for (const item of lines(row)) {
                if (!validMoney(item.amount)) invalidAmounts++;
                const name=String(item.category || row.category || '미분류');
                if (!categories.has(name)) categories.set(name,{name,documents:0,count:0,amount:0});
                const cat=categories.get(name);
                if (!touched.has(name)) {cat.documents++;touched.add(name);}
                cat.count++;usageCount++;
                cat.amount=add(cat.amount,item.amount);amount=add(amount,item.amount);
            }
        }
        return {documents:visible.length,approvedDocuments,usageCount,amount,invalidAmounts,
            rejected:statuses.get('반려됨') || 0,cancelled:statuses.get('승인취소') || 0,
            categories:[...categories.values()].sort((a,b)=>b.amount-a.amount || a.name.localeCompare(b.name,'ko')),
            statuses:[...statuses].map(([name,count])=>({name,count}))};
    }
    const api=Object.freeze({newest,cardContext,effectiveApproved,summary,lines});
    root.YbyLedger=api;
    if (typeof module==='object' && module.exports) module.exports=api;
})(globalThis);

/* One scoped approved dataset for all statistic dimensions and exports. */
(function(root){
'use strict';
const dimensions=['group','dept','user','purpose'];
function purpose(row){const value=String(row.purpose||'미지정').trim();const bracket=value.match(/^\[([^\]]+)\]/);return bracket?bracket[1].replace(/\s*[,，]\s*/g,'·'):value||'미지정';}
function build(pending,history,scope,current,comparison,filters={}){
    const unique=new Map();for(const row of [...(pending||[]),...(history||[])]){if(!row||!(scope==='ALL'||row.group===scope))continue;unique.set(JSON.stringify([row.group,row.requester,String(row.id)]),row);}
    const rows=[];let invalid=0;
    for(const row of unique.values()){
        if(row.status!=='승인완료'||row.isCorrection||row.correctionId||row.resubmissionId)continue;
        if(filters.company&&row.cardCompany!==filters.company||filters.card&&row.cardNum!==filters.card)continue;
        const amount=Number(String(row.amount??'').replace(/,/g,''));if(!Number.isSafeInteger(amount)||amount<=0){invalid++;continue;}
        rows.push({...row,amount,purpose:purpose(row),group:String(row.group||'미지정'),dept:String(row.dept||'미지정'),user:String(row.user||row.requester||'미지정'),month:String(row.date||'').slice(0,7),usage:Array.isArray(row.lineItems)&&row.lineItems.length?row.lineItems.length:1});
    }
    const add=(a,b)=>{const n=a+b;if(!Number.isSafeInteger(n))throw Error('통계 금액이 정확한 정수 범위를 넘었습니다. 조회 조건을 줄이세요.');return n;};
    const sum=list=>list.reduce((a,r)=>({documents:a.documents+1,usage:a.usage+r.usage,amount:add(a.amount,r.amount)}),{documents:0,usage:0,amount:0});
    function aggregate(keys){
        const groups=new Map();for(const row of rows){if(row.month!==current&&row.month!==comparison)continue;const key=JSON.stringify(keys.map(k=>row[k]));if(!groups.has(key))groups.set(key,{...Object.fromEntries(keys.map(k=>[k,row[k]])),current:{documents:0,usage:0,amount:0},comparison:{documents:0,usage:0,amount:0}});
            const result=groups.get(key);for(const [month,field] of [[current,'current'],[comparison,'comparison']])if(row.month===month){result[field].documents++;result[field].usage+=row.usage;result[field].amount=add(result[field].amount,row.amount);}
        }
        return [...groups.values()].sort((a,b)=>b.current.amount-a.current.amount||keys.map(k=>a[k]).join(' ').localeCompare(keys.map(k=>b[k]).join(' '),'ko'));
    }
    return {rows,invalid,current:sum(rows.filter(x=>x.month===current)),comparison:sum(rows.filter(x=>x.month===comparison)),tables:{branch:aggregate(['group']),dept:aggregate(['group','dept']),user:aggregate(['group','dept','user']),purpose:aggregate(['purpose']),overall:aggregate(dimensions)}};
}
root.YbyStats=Object.freeze({build,purpose});if(typeof module==='object'&&module.exports)module.exports=root.YbyStats;
})(globalThis);

let currentStatsExport=null;
const statsDimensionLabels={group:'지점',dept:'부서',user:'사용자',purpose:'사용 목적'};
function statsTableHTML(rows,keys,compact=false){
    const heading=keys.map(k=>'<th>'+statsDimensionLabels[k]+'</th>').join('');
    const metrics=compact?'<th>사용 횟수</th><th>사용금액</th>':'<th>기준월 정산 문서</th><th>기준월 사용 횟수</th><th>기준월 사용금액</th><th>비교월 정산 문서</th><th>비교월 사용금액</th><th>증감액</th>';
    const body=rows.map(r=>'<tr>'+keys.map(k=>'<td>'+escapeHtml(r[k])+'</td>').join('')+(compact?'<td>'+r.current.usage+'회</td><td class="num-right">'+r.current.amount.toLocaleString()+'원</td>':'<td>'+r.current.documents+'건</td><td>'+r.current.usage+'회</td><td class="num-right">'+r.current.amount.toLocaleString()+'원</td><td>'+r.comparison.documents+'건</td><td class="num-right">'+r.comparison.amount.toLocaleString()+'원</td><td class="num-right">'+(r.current.amount-r.comparison.amount).toLocaleString()+'원</td>')+'</tr>').join('');
    return '<div class="stats-scroll"><table><thead><tr>'+heading+metrics+'</tr></thead><tbody>'+body+(rows.length?'':'<tr><td colspan="'+(keys.length+(compact?2:6))+'" class="ledger-empty">조회 조건에 해당하는 승인 자료가 없습니다.</td></tr>')+'</tbody></table></div>';
}
function renderStats(){
    try{
        const currentInput=document.getElementById('statsMonth'),compareInput=document.getElementById('statsCompareMonth');if(!currentInput.value)currentInput.value=localDate().slice(0,7);if(!compareInput.value){const [year,month]=currentInput.value.split('-').map(Number);compareInput.value=new Date(Date.UTC(year,month-2,1)).toISOString().slice(0,7);}
        const mode=document.getElementById('statsModeSelect').value,current=currentInput.value,comparison=compareInput.value;
        const companyOf=row=>row.cardCompany||cardsData.find(c=>c.group===row.group&&c.num===row.cardNum)?.company||'';
        const enrich=rows=>(rows||[]).map(r=>({...r,cardCompany:companyOf(r)}));
        const pending=enrich(expenseData),history=enrich(expenseHistoryData),all=[...pending,...history].filter(r=>userScope==='ALL'||r.group===userScope);
        const company=document.getElementById('statsCompanyFilter')?.value||'';setHistorySelectOptions('statsCompanyFilter',all.filter(r=>r.status==='승인완료').map(r=>r.cardCompany),'전체 카드사');setHistorySelectOptions('statsCardFilter',all.filter(r=>r.status==='승인완료'&&(!company||r.cardCompany===company)).map(r=>r.cardNum),'전체 카드');
        const filters={company:document.getElementById('statsCompanyFilter').value,card:document.getElementById('statsCardFilter').value},model=YbyStats.build(pending,history,userScope,current,comparison,filters);
        currentStatsExport={model,mode,current,comparison,scope:userScope};
        document.getElementById('reportDocTitle').textContent=(mode==='overall'?'전체 통합 통계':'법인카드 사용 통계')+' · '+current;
        document.getElementById('reportDocSubtitle').textContent='기준월 '+current+' / 비교월 '+comparison+' · '+(userScope==='ALL'?'전체 지점':userScope+' 지점')+' · '+(filters.company||'전체 카드사')+' · '+(filters.card||'전체 카드');
        document.getElementById('reportSummaryText').innerHTML='<div class="stats-overview">'+[['승인 정산 문서',model.current.documents+'건'],['사용 횟수',model.current.usage+'회'],['승인 사용금액',model.current.amount.toLocaleString()+'원'],['비교월 대비',(model.current.amount-model.comparison.amount).toLocaleString()+'원']].map(([label,value])=>'<div><small>'+label+'</small><strong>'+value+'</strong></div>').join('')+'</div><p class="ledger-help">유효 승인 자료만 집계합니다. 승인취소·이전 정정·재보고로 대체된 자료는 제외하며, 이력대장 자료를 우선합니다. 월은 정산 문서의 사용일 기준, 사용 횟수는 건별 명세 수입니다.'+(model.invalid?' 금액 확인이 필요한 '+model.invalid+'건은 합계에서 제외했습니다.':'')+'</p>';
        const config={branch:{title:'지점별 통계',keys:['group']},dept:{title:'지점·부서별 통계',keys:['group','dept']},user:{title:'지점·부서·개인별 통계',keys:['group','dept','user']},purpose:{title:'목적별 통계',keys:['purpose']},overall:{title:'전체 통합 비교표',keys:['group','dept','user','purpose']}}[mode];
        document.getElementById('statsTableTitle').textContent=config.title;const oldTable=document.getElementById('statsTableBody').closest('table');oldTable.hidden=true;
        const target=document.getElementById('statsUnifiedTables');target.innerHTML=mode==='overall'?'<div class="stats-dimension-grid">'+['branch','dept','user','purpose'].map(key=>{const labels={branch:['group'],dept:['group','dept'],user:['group','dept','user'],purpose:['purpose']};return '<section><h3>'+({branch:'지점별',dept:'부서별',user:'개인별',purpose:'목적별'})[key]+' 요약</h3>'+statsTableHTML(model.tables[key],labels[key],true)+'</section>';}).join('')+'</div><section class="stats-combined"><h3>지점 → 부서 → 개인 → 목적 통합 비교</h3>'+statsTableHTML(model.tables.overall,config.keys)+'</section>':statsTableHTML(model.tables[mode],config.keys);
        const graph=model.tables[mode==='overall'?'branch':mode],labelKeys=mode==='overall'?['group']:config.keys,labels=graph.map(r=>labelKeys.map(k=>r[k]).join(' / '));
        document.getElementById('chart1Title').textContent=mode==='overall'?'지점별 승인 사용금액 비중':config.title+' · 승인 금액 비중';document.getElementById('chart2Title').textContent='기준월 / 비교월 승인 금액';
        if(typeof Chart!=='undefined'){
            if(chartInstance1)chartInstance1.destroy();if(chartInstance2)chartInstance2.destroy();
            chartInstance1=new Chart(document.getElementById('chart1').getContext('2d'),{type:'doughnut',data:{labels,datasets:[{data:graph.map(r=>r.current.amount),backgroundColor:['#466d91','#6c9b87','#bc985a','#8d82ac','#799caf','#a8b2be']}]},options:{animation:false,responsive:true,maintainAspectRatio:false}});
            chartInstance2=new Chart(document.getElementById('chart2').getContext('2d'),{type:'bar',data:{labels,datasets:[{label:current,data:graph.map(r=>r.current.amount),backgroundColor:'#466d91'},{label:comparison,data:graph.map(r=>r.comparison.amount),backgroundColor:'#bbc9d7'}]},options:{animation:false,responsive:true,maintainAspectRatio:false}});
        }
    }catch(error){document.getElementById('reportSummaryText').textContent='통계를 표시할 수 없습니다: '+error.message;currentStatsExport=null;}
}
function exportToExcel(){
    if(!currentStatsExport){alert('통계를 먼저 조회하세요.');return;}
    const {model,mode,current,comparison}=currentStatsExport,all=mode==='overall',keys=all?['group','dept','user','purpose']:({branch:['group'],dept:['group','dept'],user:['group','dept','user'],purpose:['purpose']})[mode];
    const headers=['통계 구분',...keys.map(k=>statsDimensionLabels[k]),'기준월 정산 문서','기준월 사용 횟수','기준월 사용금액','비교월 정산 문서','비교월 사용금액','증감액'];
    const rows=[],sections=all?['branch','dept','user','purpose','overall']:[mode];for(const section of sections)for(const row of model.tables[section])rows.push([({branch:'지점',dept:'부서',user:'개인',purpose:'목적',overall:'통합'})[section],...keys.map(k=>row[k]||''),row.current.documents,row.current.usage,row.current.amount,row.comparison.documents,row.comparison.amount,row.current.amount-row.comparison.amount]);
    downloadExcelReport('법인카드_전체통계_'+current+'.xlsx','통계 '+current+' / '+comparison,headers,rows);
}
function printReportView(){renderStats();const title=document.title;document.title='법인카드_'+(currentStatsExport?.mode==='overall'?'전체통합':'사용')+'_통계';requestAnimationFrame(()=>{window.print();setTimeout(()=>{document.title=title;},1000);});}

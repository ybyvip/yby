"""Cross-process data lock. Windows uses kernel handles, not buffered CRT locking."""
import ctypes
import errno
import os
from pathlib import Path
import sys

class DatabaseBusyError(RuntimeError):
    """Another process holds the kernel lock; the lock file itself is harmless."""

class _WindowsLock:
    def __init__(self,path):
        from ctypes import wintypes
        class Overlapped(ctypes.Structure):
            _fields_=[('Internal',ctypes.c_size_t),('InternalHigh',ctypes.c_size_t),('Offset',wintypes.DWORD),('OffsetHigh',wintypes.DWORD),('hEvent',wintypes.HANDLE)]
        self.path=path;self.handle=None;self.overlap=Overlapped()
        self.api=ctypes.WinDLL('kernel32',use_last_error=True)
        self.api.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
        self.api.CreateFileW.restype=wintypes.HANDLE
        self.api.LockFileEx.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,wintypes.DWORD,ctypes.POINTER(Overlapped)]
        self.api.LockFileEx.restype=wintypes.BOOL
        self.api.CloseHandle.argtypes=[wintypes.HANDLE];self.api.CloseHandle.restype=wintypes.BOOL
    def acquire(self):
        handle=self.api.CreateFileW(str(self.path),0xC0000000,3,None,4,0x80,None)
        if handle==ctypes.c_void_p(-1).value:
            code=ctypes.get_last_error()
            raise OSError(13 if code==5 else 5,f'Windows CreateFileW 오류 {code}: '+ctypes.FormatError(code),str(self.path))
        self.handle=handle
        if not self.api.LockFileEx(handle,3,0,1,0,ctypes.byref(self.overlap)):
            code=ctypes.get_last_error();self.close()
            if code in (32,33):raise DatabaseBusyError('같은 자료 폴더의 서버 또는 유지보수 작업이 실행 중입니다: '+str(self.path))
            raise OSError(13 if code==5 else 5,f'Windows LockFileEx 오류 {code}: '+ctypes.FormatError(code),str(self.path))
    def close(self):
        if self.handle is not None:
            self.api.CloseHandle(self.handle);self.handle=None

class DatabaseLock:
    def __init__(self,data_dir):
        data=Path(data_dir).resolve();self.path=data.parent/(data.name+'.runtime.lock');self.stream=None;self.windows=None
    def __enter__(self):
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            if sys.platform=='win32':
                self.windows=_WindowsLock(self.path);self.windows.acquire()
            else:
                import fcntl
                descriptor=os.open(self.path,os.O_RDWR|os.O_CREAT,0o600)
                self.stream=os.fdopen(descriptor,'r+b',buffering=0)
                try:fcntl.flock(self.stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                except OSError as error:
                    self.stream.close();self.stream=None
                    if error.errno in (errno.EACCES,errno.EAGAIN):raise DatabaseBusyError('같은 자료 폴더의 서버 또는 유지보수 작업이 실행 중입니다: '+str(self.path)) from error
                    raise
        except OSError as error:
            if self.windows:self.windows.close()
            raise OSError(error.errno,'자료 잠금 파일을 열거나 잠글 수 없습니다. 실행 폴더의 쓰기 권한·보안 프로그램 정책을 확인하세요. '+str(error),str(self.path)) from error
        return self
    def __exit__(self,*args):
        if self.windows:self.windows.close()
        if self.stream is not None:self.stream.close();self.stream=None

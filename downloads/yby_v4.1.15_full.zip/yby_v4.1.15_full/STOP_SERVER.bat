@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
set "YBY_RUN_DIR=%~dp0"
if exist "%LOCALAPPDATA%\YBY\app\app.py" set "YBY_RUN_DIR=%LOCALAPPDATA%\YBY\app\"
where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3 "%~dp0stop_server.py" --root "%YBY_RUN_DIR%."
goto finished
:use_python
python "%~dp0stop_server.py" --root "%YBY_RUN_DIR%."
:finished
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%

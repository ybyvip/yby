V3.2.1 로그인 화면 수정판

주요 수정:
1. 로그인 초기화를 window.onload에서 DOMContentLoaded 기반으로 변경.
2. Chart.js/XLSX 외부 CDN이 지연되거나 차단되어도 로그인 화면이 먼저 표시되도록 수정.
3. 서버 bootstrap 전에 admin / 1234 로그인 계정 표시를 보장.
4. 서버 DB 인증은 기존대로 SQLite를 기준으로 유지.
5. 기존 카드/하이패스 데이터는 삭제하지 않음.

실행: START_V3.bat
관리자: admin / 1234

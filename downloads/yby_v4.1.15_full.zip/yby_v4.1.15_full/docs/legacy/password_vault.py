"""Authenticated encryption for the administrator's latest-password display."""
import hashlib
import json
import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken


def _fernet(key_path, create=False):
    key_path = Path(key_path)
    if create and not key_path.exists():
        key_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            descriptor = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            pass
        else:
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(Fernet.generate_key())
    return Fernet(key_path.read_bytes())


def store_password(conn, key_path, username, password, actor, timestamp):
    if not Path(key_path).exists() and conn.execute('SELECT COUNT(*) FROM password_display').fetchone()[0]:
        raise ValueError('비밀번호 표시용 키 파일이 없습니다. data/password_display.key 백업을 복원하세요.')
    row = conn.execute('SELECT password_hash FROM users WHERE username=?', (username,)).fetchone()
    payload = json.dumps({'username': username, 'password': password,
                          'fingerprint': hashlib.sha256(row['password_hash'].encode()).hexdigest()}, ensure_ascii=False).encode()
    token = _fernet(key_path, True).encrypt(payload).decode('ascii')
    conn.execute('''INSERT INTO password_display(username,ciphertext,updated_at,updated_by)
                    VALUES(?,?,?,?) ON CONFLICT(username) DO UPDATE SET
                    ciphertext=excluded.ciphertext,updated_at=excluded.updated_at,updated_by=excluded.updated_by''',
                 (username, token, timestamp, actor))


def read_password(conn, key_path, username):
    row = conn.execute('''SELECT p.*,u.password_hash FROM password_display p
                          JOIN users u ON u.username=p.username WHERE p.username=?''', (username,)).fetchone()
    if not row:
        return {'latestPassword': None, 'passwordDisplayStatus': 'legacy',
                'passwordUpdatedAt': None, 'passwordUpdatedBy': None}
    try:
        payload = json.loads(_fernet(key_path).decrypt(row['ciphertext'].encode()))
        fingerprint = hashlib.sha256(row['password_hash'].encode()).hexdigest()
        if payload.get('username') != username or payload.get('fingerprint') != fingerprint:
            raise InvalidToken
        return {'latestPassword': payload['password'], 'passwordDisplayStatus': 'available',
                'passwordUpdatedAt': row['updated_at'], 'passwordUpdatedBy': row['updated_by']}
    except (OSError, ValueError, InvalidToken, KeyError):
        return {'latestPassword': None, 'passwordDisplayStatus': 'unavailable',
                'passwordUpdatedAt': None, 'passwordUpdatedBy': None}

# V3.9.8 검증 기록

## 통과한 검증

- 전체 Python 소스 AST 문법 검사, HTML 내부 JavaScript Node.js 문법 검사.
- `python -m unittest discover -s tests -v`: **34개 테스트 실행, 34개 통과**, 실패·건너뜀 없음.
- 임시 DB, 로컬 Chromium/Playwright의 실제 화면 흐름:
  - 정상 로그인과 초기 화면, 로컬 차트·엑셀 스크립트 로딩.
  - 카드 이력에 저장한 img/onerror·svg/onload 문자열이 HTML로 실행되지 않고 텍스트로 출력됨.
  - 작은따옴표·HTML 특수문자가 들어간 계정 이름의 생성과 권한 저장 버튼 동작.
  - 최초 임시 비밀번호 변경, 변경 후 재로그인.
  - 메신저 보호 화면의 오답 비밀번호 거부·정상 비밀번호 해제.
  - 카드 불출·미사용 반납, 사용 반납·정산 신청의 DB 반영.
  - 로그아웃 시 업무 상태 정리 및 localStorage 업무 캐시 부재.
  - 위 흐름에서 브라우저 JavaScript 런타임 오류 없음.
- `tests/tls_smoke.py`: 임시 인증서로 실제 서버 프로세스의 HTTPS 기동, CA 및 hostname 검증, 로그인, Secure/SameSite=Strict 쿠키 확인. 인증서 검증을 해제하지 않음.
- SQLite 백업 `PRAGMA integrity_check` 정상.

서버 테스트는 권한 없는 카드 저장·지점 밖 변경·담당자 승인·감사 기록 접근 차단, 세션 만료, 삭제 계정과 이전 상태의 재활성화 방지, 비밀번호 초기화 후 세션 폐기와 필수 변경, 저장 충돌, 메시지 ID 덮어쓰기 차단, 첨부 수신자 접근, 정산 신청 권한, 이전 비밀번호 해시 및 완료 정산 이력 이전, 지점별 카드 삭제를 포함합니다.

## 이번 수정의 추가 검증

- 실제 화면에서 담당자 비밀번호와 권한을 함께 수정한 뒤, 최종 비밀번호·수정 시각·수정자와 이력 행이 즉시 갱신되는 것을 확인했습니다.
- 변경 이력에 권한 추가 내역이 나오고, 비밀번호 원문은 들어가지 않는 것을 확인했습니다.
- 이력 검색, 페이지 새로고침·재로그인 후 최신 비밀번호와 이력 유지가 통과했습니다.
- 본인 비밀번호 변경 시 표시 값과 PASSWORD_CHANGE 이력이 함께 갱신됩니다.
- 일반 계정과 미로그인 사용자의 비밀번호 표시·변경 이력 API 접근을 거부합니다.
- 암호화된 비밀번호는 DB에 원문으로 저장되지 않고, 일반 상태와 JSON에 포함되지 않습니다.
- 권한만 수정할 때 최신 비밀번호가 사라지지 않으며, 실패한 저장·암호화 키 누락은 비밀번호와 이력을 부분 변경하지 않습니다.
- 기존 서버의 ACCOUNT_UPDATE 기록을 새 이력대장에서도 확인합니다.

## 검증 환경과 실행 방법

Python 3.12, Node.js 24, Linux Chromium에서 임시 자료로 검증했습니다. 실제 업무 DB나 사용자의 비밀번호를 사용하지 않았습니다.

서버 테스트와 프로그램에는 cryptography 라이브러리가 필요합니다. cryptography 46.0.5와 50.0.0에서 서버 테스트 및 주요 화면 흐름을 검증했습니다. 프로그램 폴더의 INSTALL_DEPENDENCIES.bat 또는 requirements.txt로 설치할 수 있습니다.

```sh
python -m unittest discover -s tests -v
```

추가 화면 검증에는 Playwright와 Chromium이 필요합니다. Linux 테스트의 기본 Chromium 경로는 `/usr/bin/chromium`입니다. 다른 경로는 `V3_TEST_CHROMIUM` 환경 변수에 지정할 수 있습니다.

```sh
python tests/browser_smoke.py
```

추가 HTTPS 테스트에는 OpenSSL 명령이 필요합니다. 테스트가 만드는 인증서와 개인키는 임시 폴더에 생성하고 제거합니다.

```sh
python tests/tls_smoke.py
```

## 검증하지 않은 항목

- 실제 Windows에서 BAT 실행·방화벽 설정·Edge 동작.
- 사용자의 기존 업무 DB 및 첨부파일로 하는 이전 검증.
- 실제 사내 인증서와 다른 PC에서의 HTTPS 접속.
- 전체 인쇄·엑셀 보고서 및 장시간 다중 사용자 부하 시험.

기본 실행은 HTTP입니다. 네트워크 통신이 자동으로 암호화된다고 가정하지 마세요. HTTPS 설정은 `README_V3_9_7.md`를 확인하세요.

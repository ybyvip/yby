"""Scoped Hi-pass/fuel bundles, immutable change documents and confirmation."""
from copy import deepcopy
import re
import uuid
import domain

STATUSES=('대기중','불출중','회수중','회수완료')
CLASSES=('임원','직원','직영승무원','업무용차량','기타')
COMMON=('hipassUser','car','issueArea','route','reason','classification','returnDate','distributionStatus')
HIPASS=('type','company','num','issueDate','expiryDate')
FUEL=('company','num','paymentType','usageScope','userType','assignedUser','issueDate','expiryDate','cardAlias')

def enum(value,choices,label,optional=False):
    if optional and value in (None,''):return
    if value not in choices:raise ValueError(label+'을 선택하세요.')

def text(value,label,required=False,limit=200):
    if not isinstance(value,str) or len(value)>limit or (required and not value.strip()):raise ValueError(label+' 형식 오류')
    return value.strip()

def validate(row):
    partial=row.get('draftType')=='temporary' and row.get('reviewStatus')=='draft'
    enabled=row.get('hipassEnabled',True);fuel=row.get('fuelEnabled',False)
    if type(enabled)!=bool or type(fuel)!=bool or not (enabled or fuel):raise ValueError('하이패스 또는 유류대카드를 선택하세요.')
    text(row.get('hipassUser',''),'실사용자',not partial)
    enum(row.get('classification'),CLASSES,'사용 분류',optional=True)
    if row.get('reviewStatus') not in (None,'draft','confirmed'):raise ValueError('확인 상태 오류')
    enum(row.get('distributionStatus'),STATUSES,'배부 상태',optional=True)
    domain.date_value(row.get('returnDate'),'회수일')
    if row.get('distributionStatus')=='회수완료' and not row.get('returnDate'):raise ValueError('회수완료는 실제 회수일이 필요합니다.')
    if enabled:
        enum(row.get('type'),('선불형','후불형'),'하이패스 구분',optional=partial)
        text(row.get('company',''),'하이패스 발급사',not partial);text(row.get('num',''),'하이패스 번호',not partial,80)
        for f in ('issueDate','expiryDate','returnDate'):domain.date_value(row.get(f),f,not partial and f!='returnDate')
        if row.get('expiryDate') and row.get('issueDate') and row['expiryDate']<row['issueDate']:raise ValueError('하이패스 만료일이 발급일보다 빠릅니다.')
        if row.get('returnDate') and row.get('issueDate') and row['returnDate']<row['issueDate']:raise ValueError('회수일이 발급일보다 빠릅니다.')
    if fuel:
        card=row.get('fuelCard')
        if not isinstance(card,dict):raise ValueError('유류대카드 정보가 필요합니다.')
        for f in ('company','num'):text(card.get(f,''),'유류대 '+f,not partial,80 if f=='num' else 200)
        enum(card.get('paymentType'),('신용','체크'),'유류대 신용/체크',optional=partial)
        enum(card.get('usageScope'),('국내전용','해외겸용'),'유류대 사용 범위',optional=partial)
        enum(card.get('userType'),('지정','비지정'),'유류대 사용자 구분',optional=partial)
        if card.get('userType')=='지정':text(card.get('assignedUser',''),'유류대 지정 사용자',not partial)
        for f in ('issueDate','expiryDate'):domain.date_value(card.get(f),f,not partial)
        if card.get('expiryDate') and card.get('issueDate') and card['expiryDate']<card['issueDate']:raise ValueError('유류대 만료일이 발급일보다 빠릅니다.')
        if row.get('returnDate') and card.get('issueDate') and row['returnDate']<card['issueDate']:raise ValueError('유류대 회수일이 발급일보다 빠릅니다.')

def normalize(data,group,partial=False):
    modern='hipassEnabled' in data or 'fuelEnabled' in data
    row={f:text(data.get(f,''),f,limit=2000 if f=='reason' else 200) for f in COMMON+HIPASS}
    row.update(group=group,hipassEnabled=data.get('hipassEnabled',True),fuelEnabled=data.get('fuelEnabled',False))
    if modern:enum(row['classification'],CLASSES,'사용 분류',optional=partial)
    if row['fuelEnabled']:
        if not isinstance(data.get('fuelCard'),dict):raise ValueError('유류대카드 정보가 필요합니다.')
        row['fuelCard']={f:text(data['fuelCard'].get(f,''),'유류대 '+f) for f in FUEL}
    if not row['hipassEnabled']:
        for f in HIPASS:row[f]=''
    if 'distributionStatus' not in data:row.pop('distributionStatus',None)
    if partial:row.update(draftType='temporary',reviewStatus='draft')
    validate(row);return row

def numbers(row):
    values=[]
    if row.get('hipassEnabled',True):values.append(row.get('num',''))
    if row.get('fuelEnabled'):values.append(row.get('fuelCard',{}).get('num',''))
    return [re.sub(r'[\s-]','',x).casefold() for x in values]

def unique(rows):
    seen=set()
    for row in rows:
        for num in numbers(row):
            if not num:continue
            if num in seen:raise ValueError('하이패스·유류대 카드번호가 중복됩니다.')
            seen.add(num)

def change(a,conn,state,data,user,scope,path):
    a.require_permission(user,'v_hipass_reg')
    rows=state.setdefault('hipass',[]);events=state.setdefault('hipassBox',[]);today=a.business_date()
    mode=data.get('mode','ready')
    if mode not in ('ready','temporary'):raise ValueError('저장 방식 오류')
    partial=mode=='temporary'
    def log(before,after,action,reason):
        start=len(events);event(events,before,after,action,user,a.now(),reason)
        sequence=max([int(e.get('sequence') or 0) for e in events[:start]]+[start,int(state.get('_next_hipass_event_no') or 0)])
        for e in events[start:]:sequence+=1;e['sequence']=sequence
        state['_next_hipass_event_no']=sequence
    def completion_date(row):
        if row.get('distributionStatus')=='회수완료':
            domain.date_value(row.get('returnDate'),'실제 회수일',True)
            if row['returnDate']>today:raise ValueError('실제 회수일은 오늘 이후일 수 없습니다.')
    def authenticate():
        reason=text(data.get('changeReason',''),'수정·삭제·회수 사유',True,1000)
        auth=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
        if not auth or not a.verify_password(auth[0],data.get('password','')):raise PermissionError('현재 로그인 계정의 비밀번호를 확인하세요.')
        return reason
    if path.endswith('/register'):
        group=data.get('group') if scope=='ALL' else scope
        if group not in domain.BRANCHES:raise ValueError('지점 오류')
        values={**data,'distributionStatus':data.get('distributionStatus') or '대기중'}
        if values['distributionStatus'] not in ('대기중','불출중'):raise ValueError('새 등록은 대기중 또는 불출중만 선택할 수 있습니다.')
        row=normalize(values,group,partial)
        if partial and not any(row.get(k) for k in ('hipassUser','car','issueArea','route','reason','company','num')) and not any((row.get('fuelCard') or {}).get(k) for k in ('company','num','assignedUser','cardAlias')):raise ValueError('임시저장할 사용자·차량·카드 정보 중 하나 이상 입력하세요.')
        row.update(id=max([int(x['id']) for x in rows if str(x.get('id','')).isdigit()]+[int(state.get('_next_hipass_id') or 100)])+1,
                   reviewStatus='draft',draftType=mode,recordVersion=uuid.uuid4().hex,date=today,createdBy=user,createdAt=a.now())
        state['_next_hipass_id']=row['id'];rows.append(row);unique(rows)
        log(None,row,'임시저장' if partial else '최초등록','임시 작성 · 하단 보관' if partial else '입력 저장 · 불출 전 확인 대기');return {'hipass':row}
    targets=[x for x in rows if str(x.get('id'))==str(data.get('id')) and x.get('group')==data.get('recordGroup')]
    if len(targets)!=1:raise ValueError('대상 묶음을 찾을 수 없습니다.')
    old=targets[0]
    if scope not in ('ALL',old['group']):raise PermissionError('다른 지점 자료입니다.')
    if data.get('expectedVersion')!=old.get('recordVersion'):raise a.StateConflict('자료가 변경되었습니다. 다시 열어 확인하세요.')
    if path.endswith('/confirm'):
        if old.get('reviewStatus')=='confirmed':raise ValueError('이미 확인된 자료입니다.')
        if old.get('draftType')=='temporary':raise ValueError('임시저장 자료입니다. 이어서 작성한 뒤 변경 저장으로 입력을 완료하세요.')
        if distribution_status(old,today)!='불출중':raise ValueError('대기중 자료는 하단에 보관합니다. 불출중으로 변경한 뒤 확인하세요.')
        validate(old)
        source=linked_update(old,events)
        before=deepcopy(old);old.update(reviewStatus='confirmed',draftType='ready',confirmedBy=user,confirmedAt=a.now(),recordVersion=uuid.uuid4().hex)
        log(before,old,'정보확인','입력 확인 · 불출 확정 및 리스트 반영')
        if source:events[-1]['documentChangeId']=source['id']
        return {'hipass':old}
    reason=authenticate()
    if path.endswith('/delete'):
        rows.remove(old);log(old,None,'카드삭제',reason);return {'deleted':old['id']}
    if path.endswith('/complete-return'):
        if distribution_status(old,today) not in ('회수중','회수예정'):raise ValueError('회수중인 자료만 최종 회수할 수 있습니다.')
        before=deepcopy(old);new=deepcopy(old)
        new.update(distributionStatus='회수완료',returnDate=data.get('returnDate',''),reviewStatus='confirmed',draftType='ready',recordVersion=uuid.uuid4().hex)
        completion_date(new);validate(new);rows[rows.index(old)]=new;log(before,new,'회수완료',reason);return {'hipass':new}
    group=data.get('group') if scope=='ALL' else scope
    if group not in domain.BRANCHES:raise ValueError('지점 오류')
    previous=distribution_status(old,today);previous='회수중' if previous=='회수예정' else previous
    was_issued=old.get('reviewStatus')!='draft' and previous in ('불출중','회수중','회수완료') or any(
        str(e.get('recordId'))==str(old['id']) and e.get('group')==old['group'] and e.get('after',{} ) and e['after'].get('reviewStatus')=='confirmed' and distribution_status(e['after'],today)=='불출중' for e in events)
    if not was_issued:previous='대기중'
    values={**data,'distributionStatus':data.get('distributionStatus') or old.get('distributionStatus') or previous}
    next_status=values['distributionStatus']
    allowed={'대기중':('대기중','불출중'),'불출중':('불출중','회수중','회수완료'),'회수중':('회수중','회수완료'),'회수완료':STATUSES[:2]+('회수완료',)}
    if next_status not in allowed.get(previous,()):raise ValueError(previous+'에서 '+str(next_status)+'으로 변경할 수 없습니다.')
    if partial and (was_issued or next_status not in ('대기중','불출중')):raise ValueError('이미 불출한 자료는 임시저장할 수 없습니다. 변경 저장을 이용하세요.')
    if previous=='회수완료' and next_status in ('대기중','불출중') and values.get('returnDate'):raise ValueError('다시 배부하려면 이전 회수일을 비우세요.')
    new=normalize(values,group,partial);new.update(id=old['id'],date=old.get('date',today),createdAt=old.get('createdAt'),createdBy=old.get('createdBy'),
        reviewStatus='confirmed' if next_status in ('회수중','회수완료') else 'draft',draftType=mode,recordVersion=uuid.uuid4().hex)
    if new['reviewStatus']=='confirmed':
        for key in ('confirmedBy','confirmedAt'):
            if key in old:new[key]=old[key]
    completion_date(new)
    if all(new.get(k)==old.get(k) for k in COMMON+HIPASS+('group','hipassEnabled','fuelEnabled','fuelCard','draftType')):raise ValueError('변경한 내용이 없습니다.')
    rows[rows.index(old)]=new;unique(rows)
    action='회수완료' if next_status=='회수완료' and previous!='회수완료' else '정보수정'
    log(old,new,action,reason);return {'hipass':new}


def linked_update(row,events):
    version=row.get('recordVersion')
    if not version:return None
    return next((e for e in reversed(events) if e.get('recordId')==row.get('id') and e.get('group')==row.get('group')
                 and e.get('action')=='정보수정' and (e.get('after') or {}).get('recordVersion')==version),None)


def event(events,before,after,action,user,at,reason):
    groups={x['group'] for x in (before,after) if x};change_id=uuid.uuid4().hex
    for group in groups:
        visible_before=deepcopy(before) if before and before['group']==group else None
        visible_after=deepcopy(after) if after and after['group']==group else None
        row=visible_after or visible_before
        events.append({**deepcopy(row),'id':uuid.uuid4().hex,'recordId':row['id'],'action':action,'handler':user,'time':at,
                       'changeReason':reason,'changeId':change_id,'before':visible_before,'after':visible_after})

def selected(rows,scope,params):
    q=params.get('q',[''])[0][:200].casefold();group=params.get('group',[''])[0];category=params.get('classification',[''])[0]
    return [r for r in rows if scope in ('ALL',r.get('group')) and (not group or r.get('group')==group)
            and (not category or r.get('classification','')==category)
            and (not q or q in str(r).casefold())]

def workbook_rows(rows):
    headers=['묶음ID','소속지점','사용분류','실사용자','차량번호','카드종류','발급사','카드번호','선불/후불·신용/체크','사용범위','지정구분','지정사용자','발급일','만료일','회수일','불출지역','운행노선','등록사유','확인상태','확인자','확인일시']
    result=[]
    for r in rows:
        common=[r['id'],r['group'],r.get('classification') or '미분류',r.get('hipassUser',''),r.get('car','')]
        tail=[r.get('returnDate',''),r.get('issueArea',''),r.get('route',''),r.get('reason',''),{'draft':'확인대기','confirmed':'확인완료'}.get(r.get('reviewStatus'),'기존자료·확인미기록'),r.get('confirmedBy',''),r.get('confirmedAt','')]
        if r.get('hipassEnabled',True):result.append(common+['하이패스',r.get('company',''),r.get('num',''),r.get('type',''),'','','',r.get('issueDate',''),r.get('expiryDate','')]+tail)
        if r.get('fuelEnabled'):
            f=r['fuelCard'];result.append(common+['유류대',f['company'],f['num'],f['paymentType'],f['usageScope'],f['userType'],f.get('assignedUser',''),f['issueDate'],f['expiryDate']]+tail)
    return headers,result


def distribution_status(row,today):
    """Legacy inference is display-only; review and physical distribution are separate."""
    if row.get('distributionStatus') in STATUSES:return row['distributionStatus']
    if row.get('returnDate'):return '회수완료' if row['returnDate']<=today else '회수예정'
    if row.get('reviewStatus')=='draft':return '대기중'
    return '불출중' if row.get('hipassUser') else '대기중'

def history_context(event,records,events,today):
    """Resolve only stable scoped IDs, or one unambiguous legacy card number."""
    snap=event.get('after') or event.get('before') or event
    rid=event.get('recordId')
    if rid is not None:
        matches=[r for r in records if str(r.get('id'))==str(rid) and r.get('group')==event.get('group')]
        related=[e for e in events if str(e.get('recordId'))==str(rid) and e.get('group')==event.get('group')]
    else:
        nums=set(numbers(snap));nums.discard('')
        matches=[r for r in records if r.get('group')==event.get('group') and nums.intersection(numbers(r))] if nums else []
        related=related_history(event,events)
    current=matches[0] if len(matches)==1 else None
    created=(current or {}).get('createdAt') or snap.get('createdAt') or (current or {}).get('date') or snap.get('date')
    if not created:
        original=next((e for e in related if e.get('action')=='최초등록'),None)
        created=original.get('time') if original else None
    if current:status=distribution_status(current,today)
    elif any(e.get('action')=='카드삭제' for e in related):status='삭제됨'
    elif any(e.get('action')=='정보수정' and e.get('before') and e.get('after') is None for e in related):status='이관됨'
    else:status='현재자료 없음' if rid is not None else '확인불가'
    return created or '미기록',status


def in_worklist(row,today):
    return row.get('reviewStatus')=='draft' or distribution_status(row,today) in ('대기중','회수중','회수예정')

def in_list(row,today):return not in_worklist(row,today)

def metric_rows(rows,metric,today):
    predicates={
        'issued':lambda r:r.get('reviewStatus')!='draft' and distribution_status(r,today)=='불출중',
        'registered':lambda r:True,
        'review':lambda r:r.get('reviewStatus')=='draft',
        'recovery':lambda r:distribution_status(r,today) in ('회수중','회수예정','회수완료'),
        'hipass':lambda r:r.get('hipassEnabled',True) and bool(r.get('num','').strip()),
        'fuel':lambda r:r.get('fuelEnabled') and bool(r.get('fuelCard',{}).get('num','').strip())}
    if metric not in predicates:raise ValueError('현황 지표 오류')
    return [r for r in rows if predicates[metric](r)]

def related_history(event,events):
    rid=event.get('recordId')
    if rid is not None:return [e for e in events if str(e.get('recordId'))==str(rid) and e.get('group')==event.get('group')]
    nums=set(numbers(event.get('after') or event.get('before') or event));nums.discard('')
    return [e for e in events if e.get('group')==event.get('group') and (bool(nums.intersection(numbers(e.get('after') or e.get('before') or e))) if nums else e.get('id')==event.get('id'))]

def history_presentation(event,records,events,today):
    related=related_history(event,events)
    latest=bool(related) and related[-1].get('id')==event.get('id')
    created,current=history_context(event,records,events,today)
    messages={'최초등록':'등록 완료','임시저장':'임시저장 완료','정보수정':'변경 완료','정보확인':'확인 완료','회수완료':'회수처리 완료','카드삭제':'삭제처리 완료'}
    sequence=event.get('sequence') or next((i+1 for i,e in enumerate(events) if e.get('id')==event.get('id')),0)
    return {'created':created,'status':current if latest else messages.get(event.get('action'),'처리 완료'),'latest':latest,'sequence':sequence}

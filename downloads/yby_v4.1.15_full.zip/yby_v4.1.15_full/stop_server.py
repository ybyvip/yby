"""Stop only the verified server owned by this application directory."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import process_identity
import argparse

ROOT=Path(__file__).resolve().parent


def main(root=ROOT):
    root=Path(root).resolve()
    marker=root/'server.pid'
    if not marker.exists():print('이 폴더에서 시작한 서버 기록이 없습니다.');return
    meta=json.loads(marker.read_text());pid=int(meta['pid']);app=root/'app.py'
    if Path(meta['app']).resolve()!=app:raise RuntimeError('서버 경로가 다릅니다.')
    arguments=process_identity.arguments(pid)
    if not arguments:
        marker.unlink(missing_ok=True);print('서버가 이미 종료되었습니다.');return
    if not process_identity.owns_app(pid,app):raise RuntimeError('해당 PID가 다른 프로그램입니다. 종료하지 않았습니다.')
    os.kill(pid,signal.SIGTERM)
    for _ in range(40):
        if not process_identity.owns_app(pid,app):break
        time.sleep(.1)
    else:raise RuntimeError('서버 종료를 기다리고 있습니다. 실행 창을 확인한 뒤 다시 시작하세요.')
    # Do not erase a new server's record if a concurrent launch already replaced it.
    if marker.exists() and int(json.loads(marker.read_text())['pid'])==pid:marker.unlink(missing_ok=True)
    print('이 폴더의 서버 종료를 확인했습니다. RUN_LAN_WINDOWS.bat로 다시 시작할 수 있습니다.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=ROOT)
    try:main(parser.parse_args().root)
    except Exception as e:print('오류:',e,file=sys.stderr);raise SystemExit(1)

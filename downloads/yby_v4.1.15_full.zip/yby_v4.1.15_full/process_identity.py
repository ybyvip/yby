"""Read process arguments without trusting a stale PID file or a substring match."""
import os
from pathlib import Path
import subprocess


def arguments(pid):
    pid = int(pid)
    if pid <= 0:
        return []
    if os.name != 'nt':
        try:
            return [os.fsdecode(v) for v in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if v]
        except FileNotFoundError:
            return []
    script = ("$OutputEncoding=[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new(); "
              f"$p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if($p){{$p.CommandLine}}")
    command = subprocess.check_output(
        ['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
        text=True, encoding='utf-8', timeout=15).strip()
    if not command:
        return []
    import ctypes
    from ctypes import wintypes
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
    count = ctypes.c_int()
    argv = shell.CommandLineToArgvW(command, ctypes.byref(count))
    if not argv:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return [argv[i] for i in range(count.value)]
    finally:
        kernel = ctypes.WinDLL('kernel32')
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree.restype = ctypes.c_void_p
        kernel.LocalFree(argv)


def owns_app(pid, app):
    expected = Path(app).resolve()
    return any(Path(value).resolve() == expected for value in arguments(pid)[1:] if value and not value.startswith('-'))

@echo off
setlocal
chcp 65001 >nul
set "YBY_RUN_DIR=%LOCALAPPDATA%\YBY\app"
if exist "%YBY_RUN_DIR%\LAN_CLIENT.zip" goto show_zip
if exist "%~dp0LAN_CLIENT.zip" set "YBY_RUN_DIR=%~dp0."
if exist "%YBY_RUN_DIR%\LAN_CLIENT.zip" goto show_zip
echo 먼저 RUN_LAN_WINDOWS.bat로 서버를 시작하세요. 시작 완료 후 LAN_CLIENT.zip이 생성됩니다.
pause
exit /b 1
:show_zip
explorer.exe /select,"%YBY_RUN_DIR%\LAN_CLIENT.zip"

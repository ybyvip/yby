@echo off
echo V4 runtime requires Python 3.11+ only. No pip packages are required.
pause

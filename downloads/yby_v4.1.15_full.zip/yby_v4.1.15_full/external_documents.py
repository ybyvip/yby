"""Normalized Oracle inbox boundary. No Oracle connection or source SQL yet.

Only a trusted future server adapter calls stage(); browsers cannot insert source
documents. Bindings use the SAME transaction as the business operation.
"""
import hashlib
import json
import re
from datetime import datetime, timezone
import domain

def initialize(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS external_documents(document_key TEXT PRIMARY KEY,kind TEXT NOT NULL,branch TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,received_at TEXT NOT NULL)')
    conn.execute('CREATE INDEX IF NOT EXISTS ix_external_branch ON external_documents(branch,kind)')
    conn.execute('CREATE TABLE IF NOT EXISTS external_document_bindings(document_key TEXT PRIMARY KEY,use_kind TEXT NOT NULL,target_ref TEXT NOT NULL,actor TEXT NOT NULL,bound_at TEXT NOT NULL)')

def short(value,label,required=False,limit=200):
    if not isinstance(value,str) or len(value)>limit or (required and not value.strip()):raise ValueError(label+' 형식 오류')
    return value.strip()

def stage(conn,document):
    """Internal adapter contract, deliberately not an HTTP/upload endpoint."""
    if not isinstance(document,dict):raise ValueError('외부 문서 형식 오류')
    kind=document.get('kind');branch=document.get('group');revision=document.get('revision')
    if kind not in ('application','settlement') or branch not in domain.BRANCHES:raise ValueError('문서 종류·지점 매핑 확인 필요')
    if type(revision)!=int or revision<1:raise ValueError('외부 문서 버전이 필요합니다.')
    source_id=short(document.get('documentId'),'외부 문서 고유키',True)
    row={'kind':kind,'group':branch,'documentId':source_id,'revision':revision,'source':'ORACLE'}
    for field in ('documentNo','applicantName','user','dept','purpose','approvalStatus','cardLast4','attendees','note'):
        row[field]=short(document.get(field,''),field,field in ('documentNo','applicantName','purpose'),2000 if field in ('purpose','note','attendees') else 200)
    if type(document.get('withdrawn',False))!=bool:raise ValueError('외부 회수 여부는 참/거짓으로 매핑하세요.')
    row['withdrawn']=document.get('withdrawn',False)
    if row['cardLast4'] and not re.fullmatch(r'\d{4}',row['cardLast4']):raise ValueError('카드 끝자리는 4자리여야 합니다.')
    if kind=='application':
        for field in ('applicationDate','dueDate'):
            row[field]=document.get(field);domain.date_value(row[field],field,True)
        if row['dueDate']<row['applicationDate']:raise ValueError('신청일 이후 반납예정일이 필요합니다.')
    else:
        if not row['cardLast4']:raise ValueError('정산서 카드 끝자리가 필요합니다.')
        items,total=domain.expense_lines(document.get('lineItems'))
        if 'amount' in document and (type(document['amount'])!=int or document['amount']!=total):raise ValueError('외부 정산 합계 불일치')
        row.update(lineItems=items,amount=total,date=min(x['date'] for x in items))
    key=hashlib.sha256(json.dumps(['ORACLE',kind,source_id],ensure_ascii=False).encode()).hexdigest()
    row['key']=key
    old=conn.execute('SELECT revision,payload FROM external_documents WHERE document_key=?',(key,)).fetchone()
    payload=json.dumps(row,ensure_ascii=False,sort_keys=True)
    if old:
        if revision<old[0]:raise ValueError('이전 외부 문서 버전은 반영하지 않습니다.')
        if revision==old[0]:
            if payload!=old[1]:raise ValueError('동일 외부 버전의 내용이 다릅니다.')
            return key
        previous=json.loads(old[1])
        if previous['group']!=branch:raise ValueError('외부 문서 지점 변경은 관리자 확인이 필요합니다.')
    conn.execute('INSERT INTO external_documents VALUES(?,?,?,?,?,?) ON CONFLICT(document_key) DO UPDATE SET revision=excluded.revision,payload=excluded.payload,received_at=excluded.received_at',
        (key,kind,branch,revision,payload,datetime.now(timezone.utc).isoformat()))
    return key

def card_matches(document,card):
    suffix=document.get('cardLast4')
    return document['group']==card['group'] and (not suffix or re.sub(r'\D','',card['num'])[-4:]==suffix)

def load(conn,key):
    if not isinstance(key,str) or not re.fullmatch('[0-9a-f]{64}',key):raise ValueError('외부 문서 식별자 오류')
    row=conn.execute('SELECT payload FROM external_documents WHERE document_key=?',(key,)).fetchone()
    if not row:raise ValueError('수신된 외부 문서를 찾을 수 없습니다.')
    return json.loads(row[0])

def resolve(conn,data,kind,card):
    key=data.get('externalDocumentId')
    if not key:
        if data.get('entrySource') not in (None,'','YBY'):raise ValueError('외부 자료는 수신 문서를 선택하여 확인해야 합니다.')
        return None
    if data.get('externalConfirmed') is not True:raise ValueError('외부 문서 내용을 확인해 주세요.')
    row=load(conn,key)
    if row['kind']!=kind or not card_matches(row,card):raise PermissionError('선택한 외부 문서의 종류·지점·카드가 다릅니다.')
    if type(data.get('externalRevision'))!=int or row['revision']!=data['externalRevision']:raise ValueError('외부 문서가 갱신되었습니다. 다시 열어 확인하세요.')
    if row['withdrawn']:raise ValueError('회수·삭제된 외부 문서는 새 처리에 연결할 수 없습니다.')
    if conn.execute('SELECT 1 FROM external_document_bindings WHERE document_key=?',(key,)).fetchone():raise ValueError('이미 YBY 업무에 연결한 외부 문서입니다.')
    return row

def source_fields(document):
    if document is None:return {'entrySource':'YBY'}
    return {'entrySource':'ORACLE','sourceRef':{name:document[name] for name in ('key','documentId','documentNo','kind','group','revision','approvalStatus','applicantName')}}

def bind(conn,document,target,user,at):
    if document is None:return
    cursor=conn.execute('INSERT INTO external_document_bindings SELECT document_key,?,?,?,? FROM external_documents WHERE document_key=? AND revision=? AND payload=?',
        (document['kind'],json.dumps({'target':target,'sourceSnapshot':document},ensure_ascii=False),user,at,document['key'],document['revision'],json.dumps(document,ensure_ascii=False,sort_keys=True)))
    if cursor.rowcount!=1:raise ValueError('외부 문서가 변경되었습니다. 다시 확인하세요.')

def listing(conn,scope,kind,card=None,query='',offset=0,status='all'):
    if status not in ('all','unapplied','applied','withdrawn'):raise ValueError('적용 상태 필터 오류')
    clauses=['d.kind=?'];args=[kind]
    if scope!='ALL':clauses.append('d.branch=?');args.append(scope)
    if card:clauses.append('d.branch=?');args.append(card['group'])
    # Scope in SQL before content/search/count. Local normalized inbox only.
    rows=conn.execute('SELECT d.payload,d.received_at,b.document_key,b.bound_at FROM external_documents d LEFT JOIN external_document_bindings b ON d.document_key=b.document_key WHERE '+' AND '.join(clauses)+' ORDER BY d.received_at DESC,d.document_key',args)
    items=[];counts={'unapplied':0,'applied':0,'withdrawn':0}
    for payload,received,bound,bound_at in rows:
        doc=json.loads(payload)
        if card and not card_matches(doc,card):continue
        if query and query.casefold() not in ' '.join(str(doc.get(k,'')) for k in ('documentNo','applicantName','user','dept','purpose')).casefold():continue
        application_status='applied' if bound else 'withdrawn' if doc['withdrawn'] else 'unapplied'
        counts[application_status]+=1
        if status!='all' and status!=application_status:continue
        items.append({**{k:doc.get(k) for k in ('key','kind','group','revision','documentNo','applicantName','user','dept','purpose','approvalStatus','cardLast4','amount','applicationDate','date','withdrawn')},'bound':bool(bound),'receivedAt':received,'applicationStatus':application_status,'appliedAt':bound_at})
    return {'total':len(items),'items':items[offset:offset+50],'counts':counts}

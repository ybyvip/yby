@echo off
call "%~dp0tools\certificate_recovery\REPAIR_CERTIFICATE_OWNER.bat"

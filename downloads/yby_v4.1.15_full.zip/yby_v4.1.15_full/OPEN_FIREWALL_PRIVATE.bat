@echo off
call "%~dp0SETUP_SERVER_FIREWALL.bat" %*

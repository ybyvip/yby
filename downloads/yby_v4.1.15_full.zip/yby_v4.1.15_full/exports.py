"""Dependency-free OOXML workbook writer; strings never become formulas."""
from datetime import date
import io
from xml.sax.saxutils import escape
from zipfile import ZipFile,ZIP_DEFLATED


def make_xlsx(title,headers,rows):
    if not isinstance(headers,list) or not 1<=len(headers)<=50 or not isinstance(rows,list) or len(rows)>10000:raise ValueError('표는 1~50열, 최대 10,000행까지 내보낼 수 있습니다.')
    def column(n):
        text=''
        while n:n,r=divmod(n-1,26);text=chr(65+r)+text
        return text
    def cell(value,reference):
        if isinstance(value,(int,float)) and not isinstance(value,bool):
            import math
            if not math.isfinite(value):raise ValueError('유한한 숫자가 필요합니다.')
            return f'<c r="{reference}"><v>{value}</v></c>'
        value=str(value if value is not None else '')
        if len(value)>32767:raise ValueError('엑셀 셀 문자열은 최대 32,767자입니다.')
        if any(ord(c)<32 and c not in '\t\n\r' for c in value):raise ValueError('엑셀에 저장할 수 없는 제어문자입니다.')
        return f'<c r="{reference}" t="inlineStr"><is><t xml:space="preserve">{escape(value)}</t></is></c>'
    xml_rows=[]
    for index,row in enumerate([headers]+rows,1):
        if not isinstance(row,list) or len(row)!=len(headers):raise ValueError('엑셀 행의 열 수가 다릅니다.')
        xml_rows.append(f'<row r="{index}">'+''.join(cell(v,column(c)+str(index)) for c,v in enumerate(row,1))+'</row>')
    title=''.join(c for c in str(title) if c not in '[]:*?/\\' and ord(c)>=32)[:31] or 'Report'
    buffer=io.BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml','<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="'+escape(title,{'"':'&quot;'})+'" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr('xl/worksheets/sheet1.xml','<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'+''.join(xml_rows)+'</sheetData></worksheet>')
    return buffer.getvalue()

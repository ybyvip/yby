@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상을 찾을 수 없습니다.
pause
exit /b 1
:use_py
py -3 "%~dp0certificate_permissions.py"
goto finished
:use_python
python "%~dp0certificate_permissions.py"
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo PASS가 표시되면 기존 RUN_LAN_WINDOWS.bat를 다시 실행하세요.
echo 새 인증서를 만드는 것이 아니라 기존 인증서의 접근권한만 복구합니다.
pause
exit /b %RESULT%

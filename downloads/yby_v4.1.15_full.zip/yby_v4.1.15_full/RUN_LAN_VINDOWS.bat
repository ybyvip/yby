@echo off
call "%~dp0RUN_LAN_WINDOWS.bat" %*

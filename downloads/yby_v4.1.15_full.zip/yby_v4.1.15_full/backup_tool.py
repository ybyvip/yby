"""Offline full backup/verification/restore; never overwrite existing data blindly."""
import argparse
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import backup_manager
from db_lock import DatabaseLock

ROOT=Path(__file__).resolve().parent


def ensure_stopped():
    marker=ROOT/'server.pid'
    if marker.exists():
        meta=json.loads(marker.read_text())
        with socket.socket() as s:
            s.settimeout(1)
            if s.connect_ex(('127.0.0.1' if meta['host']=='0.0.0.0' else meta['host'],int(meta['port'])))==0:raise RuntimeError('서버를 먼저 종료하세요.')
    # Also guard the documented port if an older launcher has no marker.
    with socket.socket() as s:
        s.settimeout(1)
        if s.connect_ex(('127.0.0.1',int(os.environ.get('V3_PORT','5000'))))==0:raise RuntimeError('서버를 먼저 종료하세요.')


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser(description='V4 전체 백업·검증·복원 도구')
    p.add_argument('action',choices=['create','verify','restore'])
    p.add_argument('archive',type=Path)
    p.add_argument('--data-dir',type=Path,default=Path(os.environ.get('V3_DATA_DIR',str(ROOT/'data'))))
    args=p.parse_args()
    if args.action=='verify':
        with tempfile.TemporaryDirectory() as t:manifest=backup_manager.verify(args.archive,t)
        print('백업 검증 완료:',manifest['version'],len(manifest['files']),'files');return
    ensure_stopped()
    with DatabaseLock(args.data_dir):
        run_maintenance(args)

def run_maintenance(args):
    if args.action=='create':
        db=args.data_dir/'corporate_card_system.db'
        if not db.is_file():raise ValueError('업무 DB가 없습니다.')
        print('전체 백업 완료:',backup_manager.create(db,args.data_dir/'attachments',args.archive))
    else:print(json.dumps(backup_manager.restore(args.archive,args.data_dir),ensure_ascii=False,indent=2))


if __name__=='__main__':
    try:main()
    except Exception as e:print('오류:',e,file=sys.stderr);raise SystemExit(1)

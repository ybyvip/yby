"""Real UI: notice upload retry/download; own cancellation -> revision -> rejection/re-report -> approval."""
import base64
from pathlib import Path
import importlib.util
import json
import sys
import time
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests()
try:
 c.setUp();a=f.app
 with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_dashboard','v_expense','v_expense_history','v_card_rent']),));conn.commit()
 c.save({'cards':[{'id':1,'num':'REVISION-UI','group':'서울','status':'available','company':'fixture'}]},c.admin)
 def operation(path,data,cookie=c.admin):
  status,body,_=c.request(path,{**data,'revision':c.state(cookie)['revision'],'requestId':str(time.time_ns())},cookie)
  assert status==200,(status,body);return body
 def approved(cookie):
  row=operation('/api/expenses/submit',{'expense':{'date':'2026-10-16','cardNum':'REVISION-UI','group':'서울','user':'시험 사용자','merchant':'가맹점','purpose':'최초 정산','amount':100,'category':'일반'}},cookie)['expense']
  operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':row['requester'],'decision':'approve'})
  return row
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
  errors=[]
  def login(name,password):
   page=browser.new_page();page.on('pageerror',lambda error:errors.append(str(error)));page.on('dialog',lambda dialog:dialog.accept('증빙 사용일을 보완하세요') if dialog.type=='prompt' else dialog.accept())
   page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'");page.evaluate('stopLiveSync()');return page
  admin=login('admin','Admin-test-pass!');branch=login('branch','Branch-test-pass!')
  uploaded=[];admin.on('request',lambda request:uploaded.append(request.url) if request.url.endswith('/api/attachments') else None)
  admin.evaluate('openNoticeManageModal()');admin.fill('#newNoticeTitle','한글 첨부 <&> 공지');admin.fill('#newNoticeInput','공지 본문과 파일을 확인하세요.')
  content=b'%PDF-1.4\nYBY notice binary fixture\x00\xff'
  admin.set_input_files('#newNoticeFile',{'name':'한글 공지파일.pdf','mimeType':'application/pdf','buffer':content})
  admin.route('**/api/notices/create',lambda route:route.fulfill(status=500,content_type='application/json',body='{"ok":false,"message":"SIMULATED_NOTICE_FAILURE"}'))
  admin.evaluate('async()=>await addNewNotice()')
  assert admin.input_value('#newNoticeTitle')=='한글 첨부 <&> 공지';assert admin.input_value('#newNoticeInput')=='공지 본문과 파일을 확인하세요.'
  assert admin.evaluate("document.getElementById('newNoticeFile').files.length")==1
  assert a.get_state().get('notices',[])==[]
  admin.unroute('**/api/notices/create');admin.evaluate('async()=>await addNewNotice()');assert len(uploaded)==1
  assert len(a.get_state()['notices'])==1
  branch.evaluate('async()=>await pollServerState()');branch.locator('#dashboardNoticeList button').filter(has_text='한글 첨부 <&> 공지').click()
  assert branch.locator('#modalBody a').count()==2
  link=branch.locator('#modalBody a[download]')
  with branch.expect_download() as downloaded:link.click()
  assert Path(downloaded.value.path()).read_bytes()==content;assert '한글' in downloaded.value.suggested_filename
  print('PASS: notice real file upload; failed publish preserves title/body/file; retry avoids duplicate upload; branch sees clickable open/download links and exact bytes/Korean filename',flush=True)
  branch.evaluate('closeModal()');admin.evaluate('closeModal()')
  original=approved(c.admin)
  admin.evaluate('async()=>await pollServerState()');admin.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
  admin.locator('#expenseHistoryTable button').filter(has_text='승인 취소·정정').click()
  admin.fill('#correctionReason','영수증 금액을 <정정>하여 재보고하세요.');admin.fill('#correctionPassword','Admin-test-pass!')
  admin.locator('#modalFooter button').filter(has_text='승인취소 후 재보고 요청').click()
  admin.wait_for_function("() => expenseData.some(x=>x.status==='재보고대기')")
  assert admin.locator('#v_expense').is_visible();assert '영수증 금액을 <정정>' in admin.locator('#expenseTable').inner_text()
  assert admin.locator('#expenseTable button').filter(has_text='승인').count()==0
  admin.locator('#expenseTable button').filter(has_text='정정 작성·재보고').click()
  admin.locator('#returnExpenseLines .line-price').fill('45000');admin.fill('#resubmissionMessage','45,000원으로 정정하여 재보고합니다.')
  admin.click('#resubmitExpenseButton');admin.wait_for_function("() => expenseData.some(x=>x.status==='승인대기')")
  assert '45,000원으로 정정하여 재보고' in admin.locator('#expenseTable').inner_text()
  admin.locator('#expenseTable button').filter(has_text='반려').click();admin.wait_for_function('() => expenseData.length===0')
  admin.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
  admin.locator('#expenseHistoryTable button').filter(has_text='수정 후 재보고').click();admin.wait_for_selector('#resubmissionMessage')
  admin.locator('#returnExpenseLines .line-price').fill('47000');admin.fill('#resubmissionMessage','증빙 사용일을 확인하여 재보고합니다.')
  admin.click('#resubmitExpenseButton');admin.wait_for_function("() => expenseData.some(x=>x.status==='승인대기')")
  admin.evaluate("switchView('v_expense',document.getElementById('nav_v_expense'))")
  admin.locator('#expenseTable button').filter(has_text='승인').click();admin.wait_for_function('() => expenseData.length===0')
  ledger=a.get_state()['expenseHistory'];assert [row['status'] for row in ledger]==['승인취소','반려됨','승인완료'];assert [row['amount'] for row in ledger]==[100,45000,47000]
  assert ledger[-1]['selfDecision'];assert len(ledger[-1]['reviewMessages'])==7
  admin.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
  admin.locator('#expenseHistoryTable tr').filter(has_text='승인완료').locator('button').filter(has_text='상세 보기').click()
  detail=admin.inner_text('#expenseDetailPrintArea');assert '재보고·결재 메시지' in detail and '45,000원으로 정정' in detail and '증빙 사용일을 확인' in detail
  admin.evaluate('closeModal()');admin.evaluate("switchView('v_stats',document.getElementById('nav_v_stats'));document.getElementById('statsMonth').value='2026-10';renderStats()")
  assert '47,000원' in admin.inner_text('#reportSummaryText');assert '총 1건' in admin.inner_text('#reportSummaryText')
  print('PASS: top-admin own cancellation, mandatory draft/re-report, edited amount, reason/message column, reject/reopen/re-report/approve, preserved originals/full timeline and approved-only statistics',flush=True)
  another=approved(c.branch)
  operation('/api/expenses/correct',{'id':another['id'],'group':'서울','requester':'branch','reason':'지점 사용자 보완 요청','password':'Admin-test-pass!'})
  branch.evaluate('async()=>await pollServerState()');branch.evaluate("switchView('v_expense',document.getElementById('nav_v_expense'))")
  branch.locator('#expenseTable button').filter(has_text='정정 작성·재보고').click();branch.locator('#returnExpenseLines .line-price').fill('300');branch.fill('#resubmissionMessage','지점에서 수정하여 재보고합니다.');branch.click('#resubmitExpenseButton')
  branch.wait_for_function("() => expenseData.some(x=>x.status==='승인대기')")
  assert a.get_state()['expense'][0]['requester']=='branch';assert a.get_state()['expense'][0]['resubmittedBy']=='branch'
  assert not errors,errors
  print('PASS: original branch owner can revise/resubmit while remaining logged in; no JavaScript errors',flush=True)
  browser.close()
finally:f.SecurityTests.tearDownClass()

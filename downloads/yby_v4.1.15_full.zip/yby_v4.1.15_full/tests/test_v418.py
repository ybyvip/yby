"""Server-owned rental/return/settlement links and their preservation boundaries."""
import copy
import unittest
from unittest import mock
import sqlite3
import test_security as fixture
import test_v4 as workflow

class LedgerLinkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixture.SecurityTests.setUpClass()
    @classmethod
    def tearDownClass(cls):fixture.SecurityTests.tearDownClass()
    def setUp(self):
        self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
    def op(self,path,data,cookie=None):return self.w.operation(path,data,cookie or self.c.branch)
    def ref(self,row):return {key:row[key] for key in ('id','group','requester')}
    def returned(self):
        self.assertEqual(self.w.rent()[0],200)
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft()})[0],200)
        return self.a.get_state()['expense'][0]
    def test_used_return_links_exact_event_and_expense_in_same_commit(self):
        row=self.returned();state=self.a.get_state();issue,returned=state['history']
        self.assertEqual(issue['rentalEventId'],issue['id'])
        self.assertEqual(returned['rentalEventId'],issue['id'])
        self.assertEqual(returned['expenseRef'],self.ref(row));self.assertEqual(row['returnEventId'],returned['id'])
        self.assertEqual(row['rentalEventId'],issue['id']);self.assertNotIn('rentalEventId',state['cards'][0])
    def test_repeat_same_day_uses_distinct_event_ids_and_unused_has_no_expense(self):
        self.returned();self.w.rent();self.op('/api/cards/return',{'cardId':1,'used':False})
        state=self.a.get_state();events=state['history']
        self.assertEqual(events[-1]['rentalEventId'],events[-2]['id']);self.assertNotEqual(events[0]['id'],events[-2]['id'])
        self.assertNotIn('expenseRef',events[-1]);self.assertEqual(len(state['expense']),1)
    def test_state_save_cannot_forge_card_or_expense_links(self):
        self.w.rent();cards=copy.deepcopy(self.a.get_state()['cards']);cards[0]['rentalEventId']=999
        self.assertEqual(self.c.save({'cards':cards},self.c.admin)[0],403)
        self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft()})
        for field,value in [('rentalEventId',999),('returnEventId',999),('returnSource',False)]:
            changed=copy.deepcopy(self.a.get_state()['expense']);changed[0][field]=value
            self.assertEqual(self.c.save({'expense':changed},self.c.branch)[0],403,field)
    def test_manual_submission_does_not_accept_forged_return_links(self):
        value=self.w.draft();value.update(rentalEventId=999,returnEventId=999,returnSource=True)
        status,body,_=self.op('/api/expenses/submit',{'expense':value});self.assertEqual(status,200)
        self.assertNotIn('rentalEventId',body['expense']);self.assertNotIn('returnEventId',body['expense']);self.assertFalse(body['expense']['returnSource'])
    def test_linkage_survives_cancellation_resubmission_and_approval(self):
        row=self.returned()
        self.op('/api/expenses/decision',{**self.ref(row),'decision':'approve'},self.c.admin)
        status,body,_=self.op('/api/expenses/correct',{**self.ref(row),'reason':'연결 보존 검사','password':'Admin-test-pass!'},self.c.admin)
        self.assertEqual(status,200,body);draft=body['expense']
        self.assertEqual(draft['rentalEventId'],row['rentalEventId']);self.assertEqual(draft['returnEventId'],row['returnEventId'])
        status,body,_=self.op('/api/expenses/resubmit',{**self.ref(draft),'message':'수정했습니다','expense':{'amount':250,'returnEventId':999,'rentalEventId':999}})
        self.assertEqual(status,200,body);self.assertEqual(body['expense']['returnEventId'],row['returnEventId'])
        self.assertEqual(self.op('/api/expenses/decision',{**self.ref(draft),'decision':'approve'},self.c.admin)[0],200)
        self.assertEqual(self.a.get_state()['history'][1]['expenseRef'],self.ref(row))
    def test_failed_return_does_not_orphan_links(self):
        self.w.rent();before=copy.deepcopy(self.a.get_state())
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated disk failure')):
            self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft()})[0],500)
        state=self.a.get_state();self.assertEqual(state['cards'],before['cards']);self.assertEqual(state['history'],before['history']);self.assertEqual(state['expense'],[])
    def test_legacy_open_rental_is_not_assigned_an_invented_event_reference(self):
        self.w.rent();state=self.a.get_state();state['cards'][0].pop('rentalEventId');state['history'][0].pop('rentalEventId')
        with self.a.db() as c:self.a.persist_state(c,state,'admin')
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft()})[0],200)
        state=self.a.get_state();self.assertNotIn('rentalEventId',state['history'][-1]);self.assertIn('expenseRef',state['history'][-1])
    def test_ledger_module_has_exact_public_mime_and_no_path_fallback(self):
        status,raw,headers=self.c.request('/static/history-ledger-v418.js');self.assertEqual(status,200)
        self.assertEqual(headers.get_content_type(),'application/javascript');self.assertIn(b'YbyLedger',raw)
        self.assertEqual(self.c.request('/static/history-ledger-v418.js.bak')[0],404)

if __name__=='__main__':unittest.main()

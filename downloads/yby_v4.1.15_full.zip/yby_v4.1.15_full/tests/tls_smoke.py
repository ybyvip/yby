from pathlib import Path
import tempfile,subprocess,shutil,os,ssl,time,urllib.request,json,socket,sys
source=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as t:
 root=Path(t)
 for name in ['app.py','settlement_workflow.py','password_vault.py','security.py','launcher.py','operations.py','db_lock.py','exports.py','domain.py','storage.py','backup_manager.py','templates','static']:
  if (source/name).is_dir():shutil.copytree(source/name,root/name)
  else:shutil.copy2(source/name,root/name)
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1','-keyout',str(root/'key.pem'),'-out',str(root/'cert.pem')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
 env=dict(os.environ,V3_TLS_CERT=str(root/'cert.pem'),V3_TLS_KEY=str(root/'key.pem'),V3_HOST='127.0.0.1',V3_PORT=str(port))
 process=subprocess.Popen([sys.executable,str(root/'app.py')],env=env,cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 context=ssl.create_default_context(cafile=str(root/'cert.pem'))
 try:
  for _ in range(50):
   try:
    with urllib.request.urlopen(f'https://localhost:{port}/health',context=context,timeout=2) as r:body=json.load(r)
    if body.get('ok') and body.get('database'):break
   except Exception:
    if process.poll() is not None:raise RuntimeError('TLS server exited')
    time.sleep(.15)
  else:raise RuntimeError('TLS readiness timeout')
  # Seed the test account without printing any generated initial credentials.
  subprocess.run([sys.executable,'-c',"import app; c=app.db(); c.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(app.phash('TLS-test-pass!'),'admin'));c.commit();c.close()"],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
  request=urllib.request.Request(f'https://localhost:{port}/api/login',data=json.dumps({'username':'admin','password':'TLS-test-pass!'}).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(request,context=context,timeout=5) as response:
   cookie=response.headers['Set-Cookie'];assert '; Secure' in cookie;assert '; SameSite=Strict' in cookie;assert json.load(response)['ok']
  print('HTTPS startup, trusted certificate/hostname validation, login and Secure cookie PASS')
 finally:
  process.terminate();process.wait(timeout=5)

"""Live normalized inbox and independent settlement-to-report drafts."""
import copy,json,unittest
from urllib.parse import urlencode
import test_v419 as intake

class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):intake.IntakeTests.setUpClass()
    @classmethod
    def tearDownClass(cls):intake.IntakeTests.tearDownClass()
    def setUp(self):
        self.t=intake.IntakeTests();self.t.setUp();self.c=self.t.c;self.a=self.t.a
    def get(self,path,params=None,cookie=None):
        return self.c.request(path+('?' + urlencode(params) if params else ''),cookie=cookie or self.c.branch)
    def returned(self):
        self.assertEqual(self.t.rent()[0],200)
        status,value,_=self.t.op('/api/cards/return',{'cardId':1,'used':True,'expense':{**self.t.w.draft(),'cardNum':'TEST-5545','lineItems':self.t.source('settlement')['lineItems'],'amount':18000}})
        self.assertEqual(status,200,value);return value['expenseRef']
    def test_unapplied_to_applied_only_on_committed_issue(self):
        key=self.t.stage(self.t.source())
        first=self.get('/api/external-documents',{'kind':'application'})[1]
        self.assertEqual(first['counts'],{'unapplied':1,'applied':0,'withdrawn':0});self.assertEqual(first['pollSeconds'],10)
        self.assertFalse(first['oracleConnected']);self.assertIn('checkedAt',first)
        self.assertEqual(self.get('/api/external-document',{'key':key,'kind':'application'})[0],200)
        self.assertEqual(self.get('/api/external-documents',{'kind':'application'})[1]['items'][0]['applicationStatus'],'unapplied')
        self.assertEqual(self.t.rent(**self.t.selected(key))[0],200)
        row=self.get('/api/external-documents',{'kind':'application','status':'applied'})[1]['items'][0]
        self.assertEqual(row['applicationStatus'],'applied');self.assertTrue(row['bound']);self.assertTrue(row['appliedAt'])
        self.assertEqual(self.get('/api/external-documents',{'kind':'application','status':'unapplied'})[1]['total'],0)
    def test_status_counts_respect_branch_search_card_and_withdrawal(self):
        self.t.stage(self.t.source())
        self.t.stage(self.t.source(documentId='W',withdrawn=True))
        self.t.stage(self.t.source(documentId='X',group='인천',applicantName='foreign-private'))
        value=self.get('/api/external-documents',{'kind':'application','status':'withdrawn'})[1]
        self.assertEqual(value['counts'],{'unapplied':1,'applied':0,'withdrawn':1});self.assertEqual(value['total'],1)
        self.assertNotIn('foreign-private',json.dumps(value))
        self.assertEqual(self.get('/api/external-documents',{'kind':'application','q':'foreign-private'})[1]['counts'],{'unapplied':0,'applied':0,'withdrawn':0})
        self.assertEqual(self.get('/api/external-documents',{'status':'forged'})[0],400)
    def test_updated_source_visible_without_changing_business_state(self):
        doc=self.t.source();key=self.t.stage(doc);before=self.a.get_state()
        self.t.stage({**doc,'revision':2,'approvalStatus':'승인완료'})
        value=self.get('/api/external-documents',{'kind':'application'})[1]['items'][0]
        self.assertEqual(value['revision'],2);self.assertEqual(value['approvalStatus'],'승인완료');self.assertEqual(self.a.get_state(),before)
        self.assertEqual(self.t.rent(**self.t.selected(key))[0],400)
    def test_applied_document_retains_applied_state_after_source_withdrawal(self):
        doc=self.t.source();key=self.t.stage(doc);self.t.rent(**self.t.selected(key));self.t.stage({**doc,'revision':2,'withdrawn':True})
        value=self.get('/api/external-documents',{'kind':'application','status':'applied'})[1]
        self.assertEqual(value['total'],1);self.assertTrue(value['items'][0]['withdrawn']);self.assertTrue(value['items'][0]['bound'])
    def test_return_reference_and_preview_copy_detail_total_without_auto_submission(self):
        ref=self.returned();before=self.a.get_state();status,value,_=self.get('/api/report-prefill',ref)
        self.assertEqual(status,200,value);draft=value['draft'];self.assertEqual(draft['sourceExpenseRef'],ref)
        self.assertIn('18,000원',draft['content']);self.assertIn('다른 신청자',draft['content']);self.assertIn('회의 식사',draft['content'])
        self.assertIn('승인대기',draft['content']);self.assertIn('별도 기안',draft['content']);self.assertNotIn('sourceSnapshot',draft)
        self.assertEqual(self.a.get_state(),before)
    def test_preview_denies_missing_foreign_and_permissionless_sources(self):
        ref=self.returned();self.assertEqual(self.get('/api/report-prefill',{**ref,'requester':'missing'})[0],400)
        readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get('/api/report-prefill',ref,readonly)[0],403)
        with self.a.db() as conn:
            conn.execute("UPDATE users SET scope='인천' WHERE username='branch'");conn.commit()
        self.assertNotEqual(self.get('/api/report-prefill',ref)[0],200)
        self.assertEqual(self.c.request('/api/report-prefill?'+urlencode(ref))[0],401)
    def test_report_submission_is_independent_editable_and_server_links_true_source(self):
        ref=self.returned();draft=self.get('/api/report-prefill',ref)[1]['draft']
        payload={**draft,'title':'수정한 업무 결과 보고','content':draft['content']+'\n검토 후 추가 의견','approver':'admin','sourceExpenseSnapshot':{'amount':1}}
        status,value,_=self.t.op('/api/documents/submit',payload)
        self.assertEqual(status,200,value);report=value['document'];self.assertEqual(report['sourceExpenseRef'],ref)
        self.assertEqual(report['sourceExpenseSnapshot']['amount'],18000);self.assertEqual(report['status'],'pending');self.assertEqual(report['title'],payload['title'])
        before=copy.deepcopy(report['sourceExpenseSnapshot']);self.assertEqual(self.t.op('/api/documents/decision',{'id':report['id'],'decision':'approve'},self.c.admin)[0],200)
        state=self.a.get_state();self.assertEqual(state['expense'][0]['status'],'승인대기');self.assertEqual(state['reports'][0]['sourceExpenseSnapshot'],before)
    def test_linked_report_rejects_invalid_or_cross_branch_reference_atomically(self):
        ref=self.returned();payload={'title':'보고','content':'본문','group':'서울','approver':'admin','sourceExpenseRef':{**ref,'id':'bad'}}
        self.assertEqual(self.t.op('/api/documents/submit',payload)[0],400);self.assertFalse(self.a.get_state().get('reports'))
        with self.a.db() as conn:
            conn.execute("UPDATE users SET scope='인천' WHERE username='branch'");conn.commit()
        payload['sourceExpenseRef']=ref;self.assertEqual(self.t.op('/api/documents/submit',payload)[0],403);self.assertFalse(self.a.get_state().get('reports'))
    def test_unused_return_produces_no_settlement_reference_or_report(self):
        self.t.rent();status,value,_=self.t.op('/api/cards/return',{'cardId':1,'used':False})
        self.assertEqual(status,200);self.assertNotIn('expenseRef',value);self.assertFalse(self.a.get_state().get('reports'));self.assertFalse(self.a.get_state().get('expense'))
    def test_snapshot_copy_after_approval_and_generic_save_cannot_forge_report(self):
        ref=self.returned();self.t.op('/api/expenses/decision',{**ref,'decision':'approve'},self.c.admin)
        self.assertEqual(self.get('/api/report-prefill',ref)[1]['draft']['sourceStatus'],'승인완료')
        draft=self.get('/api/report-prefill',ref)[1]['draft'];status,value,_=self.t.op('/api/documents/submit',{**draft,'approver':'admin'})
        self.assertEqual(status,200,value);reports=copy.deepcopy(self.a.get_state()['reports']);reports[0]['sourceExpenseSnapshot']['amount']=1
        self.assertEqual(self.c.save({'reports':reports},self.c.admin)[0],403)

if __name__=='__main__':unittest.main()

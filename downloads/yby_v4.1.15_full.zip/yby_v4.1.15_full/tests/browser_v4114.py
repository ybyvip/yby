"""Actual temporary-save, issue, recovery, metric drilldowns and linked change documents."""
from pathlib import Path
import importlib.util,json,os,sys,time
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4114-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=f.app
    with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg']),));conn.commit()
    def operation(action,payload):
        status,value,_=c.request('/api/hipass/'+action,{**payload,'requestId':str(time.time_ns()),'revision':c.state(c.admin)['revision']},cookie=c.admin);assert status==200,(status,value);return value
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);errors=[];dialogs=[]
        def login(name,password):
            page=browser.new_page(viewport={'width':1600,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
            def dialog(d):dialogs.append(d.message);d.accept()
            page.on('dialog',dialog);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function('(name)=>currentUser===name&&!loginInFlight',arg=name);page.evaluate('stopLiveSync()');return page
        def nav(page,name):page.click('#nav_'+name)
        def row_for(page,body,bundle):return page.locator('#'+body+' tr[data-fleet-id="'+str(bundle)+'"]')
        page=login('admin','Admin-test-pass!');nav(page,'v_hipass_reg');assert page.locator('#regHipassDistributionStatus option').all_text_contents()==['대기중','불출중']
        page.select_option('#regHipassGroup','서울');page.check('#regHipassFuelEnabled');page.fill('#regHipassCar','임시 차량');page.locator('#fleetRegisterForm button[data-save-mode=temporary]').click();page.wait_for_function('()=>hipassData.length===1')
        row=a.get_state()['hipass'][0];bundle=row['id'];assert row['draftType']=='temporary' and row['distributionStatus']=='대기중';expect(page.locator('#commonModal')).not_to_be_visible();expect(row_for(page,'registeredHiPassTable',bundle)).to_contain_text('임시저장');assert row_for(page,'hipassBoxTable',bundle).count()==0
        # New browser login reads the draft from the server, not a form cache.
        page.close();page=login('admin','Admin-test-pass!');nav(page,'v_hipass_reg');row_for(page,'registeredHiPassTable',bundle).get_by_role('button',name='이어서 작성').click();assert page.input_value('#editHipassCar')=='임시 차량';assert page.locator('#editHipassDistributionStatus option').all_text_contents()==['대기중','불출중']
        page.select_option('#editHipassClassification','직원');page.select_option('#editFuelPaymentType','신용');page.select_option('#editFuelUsageScope','국내전용');page.select_option('#editFuelUserType','지정')
        fields={'editHipassCompany':'시험 도로공사','editHipassNum':'HP-4114','editHipassUser':'묶음 사용자','editHipassCar':'차량-변경전','editHipassIssueDate':'2026-01-01','editHipassExpiryDate':'2099-01-01','editHipassIssueArea':'서울','editHipassRoute':'서울-청주','editHipassReason':'업무 배부','editFuelCompany':'변경전 유류사','editFuelNum':'FUEL-4114','editFuelAssignedUser':'묶음 사용자','editFuelIssueDate':'2026-01-01','editFuelExpiryDate':'2099-01-01','editFuelCardAlias':'노선 주유카드','fleetChangeReason':'임시 작성 완료','fleetPassword':'Admin-test-pass!'}
        for key,value in fields.items():page.fill('#'+key,value)
        page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.wait_for_function('()=>hipassData[0].draftType==="ready"');expect(page.locator('#modalBody')).to_contain_text('대기중 자료');assert page.locator('#modalFooter button').filter(has_text='불출 확정').count()==0;assert row_for(page,'hipassBoxTable',bundle).count()==0
        page.evaluate('closeModal()');row_for(page,'registeredHiPassTable',bundle).get_by_role('button',name='이어서 작성').click();page.select_option('#editHipassDistributionStatus','불출중');page.fill('#fleetChangeReason','실제 배부 준비');page.fill('#fleetPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.locator('#modalFooter button').filter(has_text='불출 확정').click();page.wait_for_function('()=>hipassData[0].reviewStatus==="confirmed"')
        expect(page.locator('#v_hipass_box')).to_have_class('view-panel active');assert row_for(page,'registeredHiPassTable',bundle).count()==0;expect(row_for(page,'hipassBoxTable',bundle)).to_contain_text('불출중')
        # Three logical bundles: one paired, one Hi-pass-only, one fuel-only.
        base={k:v for k,v in a.get_state()['hipass'][0].items() if k not in ('id','recordVersion','reviewStatus','draftType','date','createdAt','createdBy','confirmedAt','confirmedBy')}
        operation('register',{**base,'group':'인천','hipassUser':'다른 지점 사용자','num':'HP-ONLY-4114','fuelEnabled':False,'distributionStatus':'대기중'})
        operation('register',{**base,'hipassEnabled':False,'fuelCard':{**base['fuelCard'],'num':'FUEL-ONLY-4114'},'distributionStatus':'대기중'})
        page.evaluate('async()=>{await loadServerState();initApp();}');nav(page,'v_hipass_status')
        keys=['issued','registered','review','recovery','hipass','fuel'];expected=[1,3,2,0,2,2]
        assert page.locator('.fleet-status-metrics button').first.get_attribute('data-fleet-metric')=='issued'
        assert [int(page.locator('[data-fleet-metric='+key+'] strong').inner_text()) for key in keys]==expected
        for key,count in zip(keys,expected):
            page.locator('[data-fleet-metric='+key+']').click();assert page.locator('.fleet-metric-table tbody tr:not(:has(td[colspan]))').count()==count
            if key=='registered':
                expect(page.locator('#modalBody')).to_contain_text('하이패스 단독 1 + 유류대 단독 1 + 두 카드 동시 등록 1 = 전체 3묶음');page.locator('.modal-card').screenshot(path=str(screens/'metric_detail.png'))
            if key=='hipass':
                with page.expect_download() as d:page.locator('#modalFooter button').filter(has_text='엑셀').click()
                with ZipFile(d.value.path()) as z:
                    xml=z.read('xl/worksheets/sheet1.xml').decode();assert 'HP-ONLY-4114' in xml and 'FUEL-4114' not in xml
            page.evaluate('closeModal()')
        page.select_option('#fleetstatusGroup','서울');expect(page.locator('[data-fleet-metric=registered] strong')).to_have_text('2');page.select_option('#fleetstatusGroup','')
        page.locator('.fleet-branch-toggle').filter(has_text='서울').click();page.evaluate('fleetRenderAll()');assert page.locator('.fleet-branch-toggle').filter(has_text='서울').get_attribute('aria-expanded')=='true';page.locator('#v_hipass_status').screenshot(path=str(screens/'status.png'))
        # Save a genuine business edit, confirm, then open newest confirmation document.
        nav(page,'v_hipass_box');row_for(page,'hipassBoxTable',bundle).get_by_role('button',name='수정',exact=True).click();assert page.locator('#editHipassDistributionStatus option').all_text_contents()==['불출중','회수중','회수완료']
        page.fill('#editHipassCar','차량-변경후');page.fill('#editFuelCompany','변경후 유류사');page.fill('#fleetChangeReason','차량 및 유류사 정정');page.fill('#fleetPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.locator('#modalFooter button').filter(has_text='불출 확정').click();page.wait_for_selector('#commonModal',state='hidden')
        nav(page,'v_hipass_history');latest=a.get_state()['hipassBox'][-1];assert latest['action']=='정보확인' and latest['documentChangeId'];assert page.evaluate('()=>{const event={...hipassBoxLogs.at(-1)};delete event.documentChangeId;return fleetComparisonEvent(event).id===hipassBoxLogs.at(-1).documentChangeId;}');page.locator('[data-fleet-event="'+latest['id']+'"]').get_by_role('button').click()
        expect(page.locator('#modalBody')).to_contain_text('연결된 정보수정');car=page.locator('.fleet-comparison tbody tr').filter(has=page.locator('th',has_text='차량번호'));assert car.locator('td').nth(0).inner_text()=='차량-변경전';assert '차량-변경후' in car.locator('td').nth(1).inner_text()
        colors=car.locator('td').evaluate_all('(els)=>els.map(x=>getComputedStyle(x).backgroundColor)');assert colors[0]!=colors[1] and 'rgba(0, 0, 0, 0)' not in colors
        expect(page.locator('.fleet-comparison')).to_contain_text('변경전 유류사');expect(page.locator('.fleet-comparison')).to_contain_text('변경후 유류사');page.locator('.modal-card').screenshot(path=str(screens/'comparison.png'))
        page.evaluate('document.body.classList.add("print-expense-detail")');page.emulate_media(media='print');page.pdf(path=str(screens/'comparison.pdf'),format='A4',print_background=True);page.emulate_media(media='screen');page.evaluate('document.body.classList.remove("print-expense-detail");closeModal()')
        # Recovery routes back to the worklist; final physical return is password protected.
        nav(page,'v_hipass_box');row_for(page,'hipassBoxTable',bundle).get_by_role('button',name='수정',exact=True).click();page.select_option('#editHipassDistributionStatus','회수중');page.fill('#fleetChangeReason','회수 요청');page.fill('#fleetPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.wait_for_selector('#commonModal',state='hidden')
        expect(page.locator('#v_hipass_reg')).to_have_class('view-panel active');assert row_for(page,'hipassBoxTable',bundle).count()==0;expect(row_for(page,'registeredHiPassTable',bundle)).to_contain_text('회수중');page.locator('#v_hipass_reg').screenshot(path=str(screens/'worklist.png'))
        row_for(page,'registeredHiPassTable',bundle).get_by_role('button',name='최종 회수').click();page.fill('#fleetReturnReason','실물 회수 확인');page.fill('#fleetReturnPassword','wrong');page.locator('#modalFooter button').filter(has_text='회수완료 처리').click();page.wait_for_function('()=>document.getElementById("fleetReturnPassword").value===""');assert a.get_state()['hipass'][0]['distributionStatus']=='회수중'
        page.fill('#fleetReturnPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='회수완료 처리').click();page.wait_for_selector('#commonModal',state='hidden');expect(page.locator('#v_hipass_box')).to_have_class('view-panel active');expect(row_for(page,'hipassBoxTable',bundle)).to_contain_text('회수완료');assert row_for(page,'registeredHiPassTable',bundle).count()==0
        nav(page,'v_hipass_history');events=[e for e in a.get_state()['hipassBox'] if e.get('recordId')==bundle];ids=[e['id'] for e in events]
        for event in events:
            item=page.locator('[data-fleet-event="'+event['id']+'"]');expect(item).to_contain_text('회수완료' if event is events[-1] else '과거 작업 완료')
            assert item.get_attribute('data-latest')==str(event is events[-1]).lower()
        assert page.locator('#fleetHistoryTable tr[data-latest=true]').count()==3
        sequence=page.locator('#fleetHistoryTable tr').locator('td:first-child').all_text_contents();assert len(sequence)==len(set(sequence));page.locator('#v_hipass_history').screenshot(path=str(screens/'history.png'))
        with page.expect_download() as d:page.evaluate("fleetExport('history')")
        with ZipFile(d.value.path()) as z:assert '일련번호' in z.read('xl/worksheets/sheet1.xml').decode()
        branch=login('branch','Branch-test-pass!');nav(branch,'v_hipass_status');expect(branch.locator('[data-fleet-metric=registered] strong')).to_have_text('2');branch.locator('[data-fleet-metric=registered]').click();assert '다른 지점 사용자' not in branch.inner_text('#modalBody');branch.evaluate('closeModal()')
        for width in [1600,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});nav(page,'v_hipass_reg');measure=page.locator('#fleetRegisterFields').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
            nav(page,'v_hipass_status');measure=page.locator('#fleetStatusContent').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
            if width>=768:assert len(set(page.locator('.fleet-status-metrics .ledger-metric').evaluate_all('(els)=>els.map(x=>x.getBoundingClientRect().top)')))==1
        assert not errors,errors
        print('PASS: partial temporary save survives new login; waiting remains in bottom worklist; issue selection and explicit confirmation required; new form excludes recovery states')
        print('PASS: issued metric first; six metric drilldowns match counts; 3 bundles = HP-only 1 + fuel-only 1 + paired 1, 2 cards of each type; filters, actual metric XLSX, branch scope')
        print('PASS: latest confirmation opens actual linked input change; old/new car and fuel issuer visible, both columns shaded distinctly; actual comparison PDF generated')
        print('PASS: list edit -> recovering worklist -> wrong password blocked -> final return -> completed list; serials unique, only final event current, past rows completed; 1600/1024/768/390/320px fit; no JS runtime errors')
        browser.close()
finally:f.SecurityTests.tearDownClass()

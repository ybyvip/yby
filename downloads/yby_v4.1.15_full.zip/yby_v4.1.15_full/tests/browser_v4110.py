"""Actual Chromium: 10s polling, apply status, return inbox and report draft.
Only disposable fixture documents are staged; no Oracle database is contacted.
"""
from pathlib import Path
import importlib.util,json,os,sys
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import external_documents as inbox
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4110-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    assert c.save({'cards':[{'id':1,'num':'TEST-5545','group':'서울','company':'시험 카드사','status':'available'},{'id':2,'num':'TEST-7777','group':'인천','company':'시험 카드사','status':'available'}]},c.admin)[0]==200
    def source(kind,**extra):
        doc={'documentId':kind+'-INDEPENDENT','documentNo':'시험-신청-001' if kind=='application' else '시험-정산-099','kind':kind,'group':'서울','revision':1,'applicationDate':'2026-10-01','dueDate':'2099-01-01','applicantName':'신청 담당자','user':'실제 사용자','dept':'총무팀','purpose':'거래처 협의 및 출장','approvalStatus':'결재중','cardLast4':'5545'}
        if kind=='settlement':doc['lineItems']=[{'date':'2026-10-01','category':'식대','merchant':'식당','description':'회의 식사','quantity':2,'unitPrice':9000,'amount':18000},{'date':'2026-10-02','category':'교통','merchant':'택시','description':'거래처 이동','quantity':1,'unitPrice':5000,'amount':5000}]
        return {**doc,**extra}
    def stage(doc):
        with a.db() as conn:key=inbox.stage(conn,doc);conn.commit()
        return key
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        page=browser.new_page(viewport={'width':1440,'height':1100});errors=[];dialogs=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        def dialog(d):dialogs.append(d.message);d.accept()
        page.on('dialog',dialog)
        page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
        page.goto(f'http://127.0.0.1:{c.server.server_port}/')
        page.fill('#loginUserSelect','branch');page.fill('#loginPasswordInput','Branch-test-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>currentUser==='branch'&&!loginInFlight");page.evaluate('stopLiveSync()');page.click('#nav_v_card_rent')
        expect(page.locator('#applicationLiveContent .live-health')).to_contain_text('Oracle 연결 대기')
        page.fill('#rentUser','작성 중인 사용자');page.fill('#rentDept','작성 중인 부서')
        key=stage(source('application'))
        stage(source('application',documentId='FOREIGN',documentNo='숨겨진-다른지점',group='인천',cardLast4='7777'))
        # Wait for the REAL timer, not a direct refresh call or a document click.
        expect(page.locator('#applicationLiveContent .live-list')).to_contain_text('시험-신청-001',timeout=15000)
        assert '숨겨진' not in page.inner_text('#applicationLiveContent')
        assert page.input_value('#rentUser')=='작성 중인 사용자' and page.input_value('#rentDept')=='작성 중인 부서'
        expect(page.locator('#applicationLiveContent .live-badge')).to_have_text('미적용')
        for width in [1440,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100})
            metric=page.locator('#applicationLiveContent').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert metric['sw']<=metric['w']+1,(width,metric)
        page.set_viewport_size({'width':1440,'height':1100});page.locator('#applicationLiveContent').screenshot(path=str(screens/'application_inbox.png'))
        page.locator('#applicationLiveContent .live-document button').click();page.wait_for_selector('#applyExternalDocument')
        assert page.locator('#applyExternalDocument').is_disabled()
        page.check('#externalDocumentConfirmed');stage(source('application',revision=2,approvalStatus='승인완료'))
        page.click('#applyExternalDocument');expect(page.locator('#applyExternalDocument')).to_be_enabled();expect(page.locator('#externalPicker')).to_be_visible()
        assert any('변경' in message for message in dialogs);assert page.input_value('#rentUser')=='작성 중인 사용자'
        page.click('#externalPickerClose');page.locator('#applicationLiveContent .live-refresh').click()
        expect(page.locator('#applicationLiveContent')).to_contain_text('승인완료')
        page.locator('#applicationLiveContent .live-document button').click();page.wait_for_selector('#applyExternalDocument')
        page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached')
        assert page.input_value('#rentUser')=='실제 사용자' and page.input_value('#rentApplicant')=='신청 담당자'
        assert a.get_state()['cards'][0]['status']=='available'
        page.click('#rentalApplyButton');page.wait_for_function('()=>cardsData.find(x=>x.id===1).status==="rented"')
        expect(page.locator('#applicationLiveContent .live-badge')).to_have_text('적용',timeout=15000)
        assert '실제 사용자' in page.inner_text('#returnTable')
        page.locator('#applicationLiveContent .live-filter summary').click();page.locator('#applicationLiveContent .live-status').select_option('unapplied')
        expect(page.locator('#applicationLiveContent .live-list')).to_contain_text('수신 자료 없음')
        page.locator('#returnTable button').click()
        expect(page.locator('#settlementLiveContent')).to_be_visible()
        page.check('#returnUsedCheckbox');page.fill('#returnExpensePurpose','입력 중인 정산')
        settlement_key=stage(source('settlement'))
        stage(source('settlement',documentId='WRONGCARD',documentNo='다른카드-정산',cardLast4='9999'))
        expect(page.locator('#settlementLiveContent .live-list')).to_contain_text('시험-정산-099',timeout=15000)
        assert '다른카드' not in page.inner_text('#settlementLiveContent');assert page.input_value('#returnExpensePurpose')=='입력 중인 정산'
        for width in [768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});metric=page.locator('#settlementLiveContent').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert metric['sw']<=metric['w']+1,(width,metric)
        page.set_viewport_size({'width':1440,'height':1100});page.locator('#settlementLiveContent').screenshot(path=str(screens/'return_inbox.png'))
        page.locator('#settlementLiveContent .live-document button').click();page.wait_for_selector('#applyExternalDocument')
        page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached')
        assert page.is_checked('#returnUsedCheckbox') and page.inner_text('#returnExpenseTotal')=='23,000'
        page.check('#returnCopyReport');page.click('#returnCardSubmitButton')
        page.wait_for_function('()=>document.getElementById("v_report_write").classList.contains("active")')
        assert len(a.get_state()['reports'])==0 and a.get_state()['cards'][0]['status']=='available'
        content=page.input_value('#repContent');assert '23,000원' in content and '회의 식사' in content and '取引' not in content
        assert '승인대기' in page.inner_text('#reportCopyBanner') and '별도 기안' in content
        assert page.input_value('#approver1')=='branch' and page.input_value('#approver2')=='admin'
        page.locator('#v_report_write').screenshot(path=str(screens/'report_draft.png'))
        page.fill('#repTitle','검토 후 작성한 출장 보고');page.fill('#repContent',content+'\n추가 업무 결과: 협의 완료');page.select_option('#approver2','admin')
        page.locator('#reportWriteForm button[type=submit]').click();page.wait_for_function('()=>reportList.length===1')
        state=a.get_state();report=state['reports'][0];expense=state['expense'][0]
        assert report['sourceExpenseRef']['id']==expense['id'] and report['sourceExpenseSnapshot']['amount']==23000
        assert report['status']=='pending' and expense['status']=='승인대기'
        assert page.locator('#reportCopyBanner').is_hidden()
        # Applied settlement stays visible for reference but cannot be applied twice.
        data=c.request('/api/external-documents?kind=settlement&cardId=1',cookie=c.branch)[1]
        assert data['total']==1 and data['items'][0]['applicationStatus']=='applied'
        # A saved settlement can reopen the draft later; cancellation preserves an existing report.
        page.click('#nav_v_expense');page.get_by_role('button',name='명세 보기',exact=True).click();page.get_by_role('button',name='관련 보고서 초안 작성',exact=True).click()
        page.wait_for_function('()=>document.getElementById("v_report_write").classList.contains("active")')
        assert '23,000원' in page.input_value('#repContent')
        await_count=[];page.on('request',lambda r:await_count.append(r.url) if '/api/external-documents?' in r.url else None)
        page.evaluate('handleLogout()');page.wait_for_function('()=>currentUser===null')
        count=len(await_count);page.wait_for_timeout(11000);assert len(await_count)==count
        assert page.locator('#applicationLiveInbox').inner_text()=='' and page.evaluate('workflowLive.reportRef') is None
        assert not errors,errors
        print('PASS: real 10s application/settlement polling without clicks; branch/card filtering; form preservation; applied/unapplied filters; 1440/768/390/320px fit')
        print('PASS: source version changed after review rejected; explicit issue/return required; original settlement detail rows and total fill correctly')
        print('PASS: return -> editable report draft, no automatic submission; independent report/settlement approvals; authoritative source trace; later reopening; logout stops polling and clears data; no JS errors')
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

"""Request parties and review-first source inbox; no live Oracle or company data."""
import copy,json,sqlite3,unittest
from unittest import mock
from urllib.parse import urlencode
import test_security as fixture
import test_v4 as workflow
import external_documents as inbox

class IntakeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixture.SecurityTests.setUpClass()
    @classmethod
    def tearDownClass(cls):fixture.SecurityTests.tearDownClass()
    def setUp(self):
        self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
        with self.a.db() as conn:
            conn.execute('DELETE FROM external_document_bindings');conn.execute('DELETE FROM external_documents');conn.commit()
        self.cards=[{'id':1,'num':'TEST-5545','group':'서울','status':'available','company':'시험'},{'id':2,'num':'TEST-7777','group':'인천','status':'available','company':'시험'}]
        self.assertEqual(self.c.save({'cards':self.cards},self.c.admin)[0],200)
    def op(self,path,data,cookie=None):return self.w.operation(path,data,cookie or self.c.branch)
    def rent(self,**extra):return self.op('/api/cards/rent',{'cardId':1,'dept':'총무팀','user':'실제 사용자','applicantName':'다른 신청자','applicationDate':'2026-10-01','purpose':'거래처 협의','dueDate':'2099-01-01',**extra})
    def source(self,kind='application',**extra):
        doc={'documentId':'DOC-1','documentNo':'26-10-TEST','kind':kind,'group':'서울','revision':1,'applicationDate':'2026-10-01','dueDate':'2099-01-01','applicantName':'외부 신청자','user':'실제 사용자','dept':'총무팀','purpose':'외부 업무 목적','approvalStatus':'결재중','cardLast4':'5545'}
        if kind=='settlement':doc.update(lineItems=[{'date':'2026-10-01','category':'식대','merchant':'식당','description':'회의 식사','quantity':2,'unitPrice':9000,'amount':18000}])
        doc.update(extra);return doc
    def stage(self,doc):
        with self.a.db() as conn:key=inbox.stage(conn,doc);conn.commit()
        return key
    def selected(self,key,revision=1):return {'externalDocumentId':key,'externalRevision':revision,'externalConfirmed':True}
    def test_manual_today_default_and_independent_parties_persist_through_return(self):
        status,_,_=self.rent(applicationDate=self.a.business_date());self.assertEqual(status,200)
        card=self.a.get_state()['cards'][0];self.assertEqual(card['applicationDate'],self.a.business_date());self.assertEqual(card['applicantName'],'다른 신청자');self.assertEqual(card['user'],'실제 사용자');self.assertEqual(card['entrySource'],'YBY')
        self.op('/api/cards/return',{'cardId':1,'used':True,'expense':{**self.w.draft(),'cardNum':'TEST-5545'}})
        state=self.a.get_state();self.assertEqual(state['history'][-1]['applicantName'],'다른 신청자');self.assertEqual(state['expense'][0]['rentalEntrySource'],'YBY');self.assertNotIn('applicantName',state['cards'][0])
    def test_legacy_api_defaults_today_and_user_but_invalid_dates_or_empty_applicant_fail(self):
        self.assertEqual(self.w.rent()[0],200)
        card=self.a.get_state()['cards'][0];self.assertEqual(card['applicationDate'],self.a.business_date());self.assertEqual(card['applicantName'],'staff')
        self.op('/api/cards/return',{'cardId':1,'used':False})
        for extra in ({'applicationDate':'invalid'},{'applicationDate':'2026-02-30'},{'applicationDate':'2099-02-01'},{'applicantName':''}):self.assertEqual(self.rent(**extra)[0],400,extra)
    def test_source_identity_not_forgeable_by_generic_state_or_manual_post(self):
        self.assertEqual(self.rent(entrySource='ORACLE')[0],400)
        self.assertEqual(self.rent(sourceRef={'documentNo':'fake'})[0],200)
        card=self.a.get_state()['cards'][0];self.assertEqual(card['entrySource'],'YBY');self.assertNotIn('sourceRef',card)
        for field,value in [('applicantName','forged'),('applicationDate','2020-01-01'),('entrySource','ORACLE'),('sourceRef',{'documentNo':'fake'})]:
            cards=copy.deepcopy(self.a.get_state()['cards']);cards[0][field]=value;self.assertEqual(self.c.save({'cards':cards},self.c.admin)[0],403,field)
    def test_empty_inbox_is_honest_and_requires_rental_permission(self):
        status,data,_=self.c.request('/api/external-documents',cookie=self.c.branch);self.assertEqual(status,200);self.assertEqual(data['total'],0);self.assertFalse(data['oracleConnected'])
        readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.c.request('/api/external-documents',cookie=readonly)[0],403)
        self.assertEqual(self.c.request('/api/external-documents')[0],401)
    def test_application_selection_requires_confirmation_version_branch_kind_and_single_binding(self):
        key=self.stage(self.source());selected=self.selected(key)
        self.assertEqual(self.rent(**{**selected,'externalConfirmed':False})[0],400)
        self.assertEqual(self.rent(**{**selected,'externalRevision':2})[0],400)
        self.assertEqual(self.rent(**selected)[0],200)
        self.assertEqual(self.a.get_state()['cards'][0]['sourceRef']['documentNo'],'26-10-TEST')
        self.op('/api/cards/return',{'cardId':1,'used':False})
        self.assertEqual(self.rent(**selected)[0],400)
        foreign=self.stage(self.source(documentId='foreign',group='인천'));self.assertEqual(self.rent(**self.selected(foreign))[0],403)
        settlement=self.stage(self.source('settlement'));self.assertEqual(self.rent(**self.selected(settlement))[0],403)
    def test_application_and_settlement_have_independent_ids_and_source_status_does_not_block_yby(self):
        app_key=self.stage(self.source());settle_key=self.stage(self.source('settlement'));self.assertNotEqual(app_key,settle_key)
        self.assertEqual(self.rent(**self.selected(app_key))[0],200)
        expense={**self.w.draft(),'cardNum':'TEST-5545','amount':18000,'lineItems':self.source('settlement')['lineItems']}
        status,_,_=self.op('/api/cards/return',{'cardId':1,'used':True,'expense':expense,**self.selected(settle_key)});self.assertEqual(status,200)
        state=self.a.get_state();row=state['expense'][0]
        self.assertEqual(row['entrySource'],'ORACLE');self.assertEqual(row['rentalEntrySource'],'ORACLE');self.assertNotEqual(row['sourceRef']['key'],row['rentalSourceRef']['key']);self.assertEqual(row['sourceRef']['approvalStatus'],'결재중')
        self.assertEqual(self.op('/api/expenses/decision',{**{k:row[k] for k in ('id','group','requester')},'decision':'approve'},self.c.admin)[0],200)
    def test_settlement_can_attach_to_manual_rental_and_does_not_release_card_on_bad_source(self):
        self.rent();key=self.stage(self.source('settlement',cardLast4='9999'))
        payload={'cardId':1,'used':True,'expense':{**self.w.draft(),'cardNum':'TEST-5545'},**self.selected(key)}
        self.assertEqual(self.op('/api/cards/return',payload)[0],403);self.assertEqual(self.a.get_state()['cards'][0]['status'],'rented')
        key=self.stage(self.source('settlement',documentId='valid'));payload.update(self.selected(key));self.assertEqual(self.op('/api/cards/return',payload)[0],200)
        row=self.a.get_state()['expense'][0];self.assertEqual(row['entrySource'],'ORACLE');self.assertEqual(row['rentalEntrySource'],'YBY')
    def test_staging_duplicate_old_revision_and_changed_used_document_snapshot(self):
        doc=self.source();key=self.stage(doc);self.assertEqual(self.stage(doc),key)
        self.assertEqual(self.rent(**self.selected(key))[0],200)
        self.stage({**doc,'revision':2,'approvalStatus':'승인완료'})
        with self.a.db() as conn:
            bound=json.loads(conn.execute('SELECT target_ref FROM external_document_bindings').fetchone()[0]);self.assertEqual(bound['sourceSnapshot']['revision'],1);self.assertEqual(bound['sourceSnapshot']['approvalStatus'],'결재중')
        with self.assertRaises(ValueError):self.stage(doc)
        with self.assertRaises(ValueError):self.stage({**doc,'revision':2,'purpose':'same version changed'})
    def test_scope_applies_before_list_search_count_and_detail_and_card_filter(self):
        own=self.stage(self.source('settlement'));foreign=self.stage(self.source('settlement',documentId='foreign',group='인천',cardLast4='7777',applicantName='숨긴 신청자'))
        status,data,_=self.c.request('/api/external-documents?'+urlencode({'kind':'settlement'}),cookie=self.c.branch);self.assertEqual(status,200);self.assertEqual(data['total'],1);self.assertNotIn('숨긴 신청자',json.dumps(data,ensure_ascii=False))
        self.assertEqual(self.c.request('/api/external-document?'+urlencode({'key':foreign,'kind':'settlement'}),cookie=self.c.branch)[0],403)
        self.assertEqual(self.c.request('/api/external-documents?cardId=2',cookie=self.c.branch)[0],403)
        self.assertEqual(self.c.request('/api/external-document?'+urlencode({'key':own,'kind':'settlement','cardId':1}),cookie=self.c.branch)[0],200)
    def test_failed_save_rolls_back_source_binding_as_well_as_card(self):
        key=self.stage(self.source())
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated save failure')):self.assertEqual(self.rent(**self.selected(key))[0],500)
        with self.a.db() as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],0)
        self.assertEqual(self.a.get_state()['cards'][0]['status'],'available')
    def test_withdrawn_source_and_bad_totals_are_rejected(self):
        key=self.stage(self.source(withdrawn=True));self.assertEqual(self.rent(**self.selected(key))[0],400)
        with self.assertRaises(ValueError):self.stage(self.source('settlement',amount=1))
    def test_source_snapshots_are_included_in_full_database_backup(self):
        import tempfile,backup_manager
        from pathlib import Path
        key=self.stage(self.source());self.rent(**self.selected(key))
        with tempfile.TemporaryDirectory() as folder:
            archive=Path(folder)/'full.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive)
            restored=Path(folder)/'restore';backup_manager.restore(archive,restored)
            with sqlite3.connect(restored/self.a.DB_PATH.name) as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],1)
    def test_edited_external_settlement_and_resubmission_keep_provenance(self):
        self.rent();key=self.stage(self.source('settlement'))
        self.op('/api/cards/return',{'cardId':1,'used':True,'expense':{**self.w.draft(),'cardNum':'TEST-5545'},**self.selected(key)})
        row=self.a.get_state()['expense'][0];self.assertTrue(row['sourceAdjusted'])
        ref=lambda r:{k:r[k] for k in ('id','group','requester')}
        self.op('/api/expenses/decision',{**ref(row),'decision':'approve'},self.c.admin)
        draft=self.op('/api/expenses/correct',{**ref(row),'reason':'내용 보완','password':'Admin-test-pass!'},self.c.admin)[1]['expense']
        status,body,_=self.op('/api/expenses/resubmit',{**ref(draft),'message':'보완 후 재보고','expense':{'amount':250,'entrySource':'YBY','sourceAdjusted':False}})
        self.assertEqual(status,200);self.assertEqual(body['expense']['entrySource'],'ORACLE');self.assertTrue(body['expense']['sourceAdjusted']);self.assertEqual(body['expense']['sourceRef']['key'],key)
    def test_binding_rechecks_revision_and_rolls_back_a_document_changed_after_review(self):
        key=self.stage(self.source());original=inbox.bind
        def changed(conn,doc,target,user,at):
            conn.execute('UPDATE external_documents SET revision=revision+1 WHERE document_key=?',(key,))
            return original(conn,doc,target,user,at)
        with mock.patch.object(inbox,'bind',changed):self.assertEqual(self.rent(**self.selected(key))[0],400)
        self.assertEqual(self.a.get_state()['cards'][0]['status'],'available')
        with self.a.db() as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],0)

if __name__=='__main__':unittest.main()

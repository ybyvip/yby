"""Real multi-user UI: live account editing, reauthenticated vault, detailed return/self approval."""
from pathlib import Path
import importlib.util
import sys
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests()
try:
 c.setUp();a=f.app
 c.save({'cards':[{'id':1,'num':'UI-MULTI-TEST','group':'서울','status':'available','company':'fixture'}]},c.admin)
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
  errors=[]
  def login(name,password):
   page=browser.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
   page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter')
   page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'");page.evaluate('stopLiveSync()');return page
  admin=login('admin','Admin-test-pass!');branch=login('branch','Branch-test-pass!')
  admin.evaluate("switchView('v_admin',document.getElementById('nav_v_admin'))")
  admin.wait_for_selector('#permissionTable tr')
  row=admin.locator('#permissionTable tr').filter(has=admin.locator('td b',has_text='branch'))
  row.locator('input[value=v_report_write]').uncheck();row.locator('button').filter(has_text='저장').click()
  branch.evaluate('async()=>await pollServerState()')
  assert branch.evaluate('currentUser')=='branch'
  assert branch.locator('#appContainer').is_visible()
  assert branch.locator('#nav_v_report_write').is_hidden()
  row=admin.locator('#permissionTable tr').filter(has=admin.locator('td b',has_text='branch'))
  row.locator('.account-password').fill('UI-reset-current-pass!');row.locator('button').filter(has_text='저장').click()
  admin.wait_for_function("() => accountHistoryRows.some(x=>x.action==='ACCOUNT_PASSWORD_RESET')")
  branch.evaluate('async()=>await pollServerState()');assert branch.evaluate('currentUser')=='branch';assert branch.locator('#appContainer').is_visible()
  assert 'branch' in admin.locator('#passwordHistoryTable').inner_text()
  print('PASS: live branch remains logged in across permission change/password reset; removed menu hidden; separate password history',flush=True)
  row=admin.locator('#permissionTable tr').filter(has=admin.locator('td b',has_text='branch'));row.locator('button').filter(has_text='현재 비밀번호 보기').click()
  admin.fill('#passwordRevealAdmin','Admin-test-pass!');admin.locator('#modalFooter button').filter(has_text='재인증하고 보기').click()
  admin.wait_for_selector('#revealedAccountPassword');assert admin.input_value('#revealedAccountPassword')=='UI-reset-current-pass!'
  assert not admin.evaluate("JSON.stringify(accountsData).includes('UI-reset-current-pass!')")
  admin.evaluate("window.dispatchEvent(new Event('blur'))");assert admin.input_value('#revealedAccountPassword')=='';admin.evaluate('closeModal()')
  print('PASS: top admin reauthentication reveals only requested current password, clears on blur, no general state leakage',flush=True)
  waiting=[]
  admin.route('**/api/admin/password-reveal',lambda route:waiting.append(route))
  admin.evaluate("openPasswordReveal('branch')");admin.fill('#passwordRevealAdmin','Admin-test-pass!');admin.locator('#modalFooter button').filter(has_text='재인증하고 보기').click()
  admin.wait_for_timeout(100);assert waiting
  admin.evaluate('closeModal()');waiting[0].fulfill(status=200,content_type='application/json',body='{"ok":true,"password":"must-not-appear-after-close"}')
  admin.wait_for_timeout(100);assert admin.locator('#revealedAccountPassword').count()==0
  admin.unroute('**/api/admin/password-reveal')
  print('PASS: delayed credential response after closing dialog is discarded',flush=True)
  def detailed_return(page):
   page.evaluate("async()=>{await businessOperation('/api/cards/rent',{cardId:1,dept:'UI 검증',user:'시험 사용자',purpose:'출장',dueDate:'2099-01-01'});openReturnModal(1)}")
   page.check('#returnUsedCheckbox');page.select_option('#returnExpenseCategory','식대');page.fill('#returnExpensePurpose','두 건의 상세 정산')
   rows=page.locator('#returnExpenseLines tr')
   rows.nth(0).locator('.line-merchant').fill('가맹점 <&>');rows.nth(0).locator('.line-description').fill('점심 <script>검증</script>');rows.nth(0).locator('.line-quantity').fill('2');rows.nth(0).locator('.line-price').fill('9000')
   page.locator('button').filter(has_text='+ 사용 건 추가').click()
   rows.nth(1).locator('.line-merchant').fill('택시');rows.nth(1).locator('.line-description').fill('외근 이동');rows.nth(1).locator('.line-category').fill('교통');rows.nth(1).locator('.line-price').fill('5000')
   assert page.input_value('#returnExpenseAmount')=='23000';assert page.inner_text('#returnExpenseTotal')=='23,000'
   page.click('#returnCardSubmitButton');page.wait_for_selector('#commonModal',state='hidden')
  detailed_return(branch)
  assert a.get_state()['cards'][0]['status']=='available';assert a.get_state()['expense'][0]['amount']==23000
  admin.evaluate('async()=>await pollServerState()')
  admin.evaluate("switchView('v_expense',document.getElementById('nav_v_expense'))")
  admin.locator('#expenseTable button').filter(has_text='명세 보기').click();assert '23,000' in admin.inner_text('#expenseDetailPrintArea');assert '점심 <script>검증</script>' in admin.inner_text('#expenseDetailPrintArea');admin.evaluate('closeModal()')
  admin.locator('#expenseTable button').filter(has_text='승인').click();admin.wait_for_function('() => expenseData.length===0')
  detailed_return(admin)
  admin.evaluate("switchView('v_expense',document.getElementById('nav_v_expense'))")
  admin.locator('#expenseTable button').filter(has_text='승인').click();admin.wait_for_function('() => expenseData.length===0')
  records=a.get_state()['expenseHistory'];own=next(x for x in records if x['requester']=='admin');assert own['selfDecision'] and len(own['lineItems'])==2
  admin.evaluate("switchView('v_expense_history',document.getElementById('nav_v_expense_history'))")
  exported=admin.evaluate('expenseHistoryExportRows()');assert len(exported)==4 and sum(row[12] for row in exported)==46000
  assert not errors,errors
  print('PASS: two-line return editor, automatic quantities/amounts/total, immutable saved detail, escaped text, admin self approval and itemized exports',flush=True)
  browser.close()
finally:f.SecurityTests.tearDownClass()

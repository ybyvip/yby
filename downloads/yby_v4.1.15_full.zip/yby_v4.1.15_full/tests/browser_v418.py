"""Real API data -> branch-scoped ledger, live summary, snapshot report and PDF."""
from pathlib import Path
import importlib.util, json, os, sys, time, xml.etree.ElementTree as ET
from zipfile import ZipFile
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v418-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    with a.db() as conn:
        conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_dashboard','v_card_status','v_card_history','v_card_rent','v_expense','v_expense_history']),'branch'));conn.commit()
    assert c.save({'cards':[{'id':1,'group':'서울','num':'TEST-SEOUL-5545','company':'시험 카드사','status':'available'}, {'id':2,'group':'인천','num':'TEST-INCHEON-5545','company':'시험 카드사','status':'available'}]},c.admin)[0]==200
    def op(path,payload,cookie=None):
        cookie=cookie or c.branch
        status,data,_=c.request(path,{**payload,'requestId':str(time.time_ns()),'revision':c.state(cookie)['revision']},cookie)
        assert status==200,(path,status,data)
        return data
    def ref(row):return {k:row[k] for k in ('id','group','requester')}
    def rent():return op('/api/cards/rent',{'cardId':1,'user':'사용자 <&>','dept':'총무팀','purpose':'업무 협의','dueDate':'2099-01-01'})
    def draft(amount=5000,**extra):return {'date':'2026-10-19','cardNum':'TEST-SEOUL-5545','group':'서울','user':'사용자 <&>','dept':'총무팀','merchant':'업무 협의처','category':'식대','purpose':'거래처 협의 <img src=x onerror="window.pwned=1">','amount':amount,**extra}
    rent()
    detailed=draft(23000,lineItems=[{'date':'2026-10-19','category':'식대','merchant':'식당','description':'회의 식사','quantity':2,'unitPrice':9000,'amount':18000},{'date':'2026-10-19','category':'교통','merchant':'택시','description':'거래처 이동','quantity':1,'unitPrice':5000,'amount':5000}])
    op('/api/cards/return',{'cardId':1,'used':True,'expense':detailed});first=a.get_state()['expense'][0]
    op('/api/expenses/decision',{**ref(first),'decision':'approve'},c.admin)
    rent();op('/api/cards/return',{'cardId':1,'used':True,'expense':draft()});second=a.get_state()['expense'][0]
    op('/api/expenses/decision',{**ref(second),'decision':'approve'},c.admin)
    correction=op('/api/expenses/correct',{**ref(second),'reason':'금액 정정','password':'Admin-test-pass!'},c.admin)['expense']
    rent();op('/api/cards/return',{'cardId':1,'used':False});rent()
    legacy=op('/api/expenses/submit',{'expense':draft(1700,user='별도 사용자',category='일반')})['expense']
    op('/api/expenses/decision',{**ref(legacy),'decision':'approve'},c.admin)
    foreign=op('/api/expenses/submit',{'expense':draft(990000,cardNum='TEST-INCHEON-5545',group='인천',user='다른 지점 사용자')},c.admin)['expense']
    op('/api/expenses/decision',{**ref(foreign),'decision':'approve'},c.admin)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        errors=[]
        def login(user,password):
            page=browser.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
            page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/')
            page.fill('#loginUserSelect',user);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter')
            page.wait_for_function('(user)=>currentUser===user&&!loginInFlight',arg=user)
            page.evaluate('stopLiveSync()');return page
        page=login('admin','Admin-test-pass!')
        assert page.locator('.node-header').count()==6
        assert page.locator('.node-header').evaluate_all(r'(els)=>els.every(e=>/\p{Extended_Pictographic}/u.test(e.textContent))')
        assert page.locator('.sub-item,.page-title,h1,h2,h3,h4').evaluate_all(r'(els)=>els.every(e=>!/\p{Extended_Pictographic}/u.test(e.textContent))')
        assert '지역별 배부현황 및 대여현황' in page.inner_text('#nav_v_card_status')
        assert page.locator('#nav_v_expense').evaluate('(e)=>e.nextElementSibling.id')=='nav_v_expense_history'
        page.locator('#nav_v_card_history').click()
        ids=page.locator('#cardHistoryTable tr td:first-child').all_text_contents()
        assert ids==['7','6','5','4','3','2','1'],ids
        assert '누적 불출 4회' in page.locator('#cardHistoryTable tr').first.inner_text()
        assert '대여중 · 반납대기' in page.locator('#cardHistoryTable tr').first.inner_text()
        assert '반납완료 · 재보고대기' in page.locator('#cardHistoryTable tr').nth(3).inner_text()
        page.select_option('#historyTypeFilter','불출')
        assert page.locator('#cardHistoryTable tr').count()==4
        assert all('누적 불출 4회' in text for text in page.locator('#cardHistoryTable tr').all_text_contents())
        page.evaluate('resetCardHistoryFilters()')
        page.locator('#v_card_history').screenshot(path=str(screens/'card_history.png'))
        with page.expect_download() as download:page.evaluate('exportHistoryExcel()')
        with ZipFile(download.value.path()) as z:
            xml=ET.fromstring(z.read('xl/worksheets/sheet1.xml'));ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            sheet=xml.findall('.//s:row',ns);assert len(sheet)==8
            texts=lambda row:[''.join(cell.itertext()) for cell in row.findall('s:c',ns)]
            assert texts(sheet[1])[0]=='7' and texts(sheet[1])[11]=='4'
            assert texts(sheet[1])[12]=='대여중 · 반납대기'
        page.locator('#nav_v_expense_history').click()
        def metrics(scope='#expenseHistorySummary'):
            return page.locator(scope+' [data-metric]').evaluate_all('(els)=>Object.fromEntries(els.map(e=>[e.dataset.metric,e.querySelector("strong").textContent]))')
        total=metrics();assert total['documents']=='4건' and total['amount']=='1,014,700원' and total['usageCount']=='4회',total
        page.select_option('#expenseHistoryGroupFilter','서울')
        scoped=metrics();assert scoped['documents']=='3건' and scoped['amount']=='24,700원' and scoped['usageCount']=='3회' and scoped['cancelled']=='1건',scoped
        page.locator('#v_expense_history').screenshot(path=str(screens/'expense_summary.png'))
        page.select_option('#expenseHistoryCategoryFilter','복수 항목');assert metrics()['amount']=='23,000원' and metrics()['usageCount']=='2회'
        page.select_option('#expenseHistoryCategoryFilter','')
        page.click('#expenseSummaryReportButton')
        assert metrics('#expenseDetailPrintArea')==scoped
        assert '서울' in page.inner_text('.report-filter-list')
        assert '다른 지점 사용자' not in page.inner_text('#expenseDetailPrintArea')
        assert page.locator('#expenseDetailPrintArea img,#expenseDetailPrintArea script').count()==0
        assert not page.evaluate('window.pwned')
        for width in [1440,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1000})
            fit=page.locator('#modalBody').evaluate('(e)=>({w:e.clientWidth,scroll:e.scrollWidth})')
            assert fit['scroll']<=fit['w']+1,(width,fit)
        page.set_viewport_size({'width':1440,'height':1000})
        page.locator('.modal-card').screenshot(path=str(screens/'summary_report.png'))
        page.evaluate('window.__printed=0;window.print=()=>window.__printed++')
        page.click('#expenseSummaryPrintButton')
        try:
            page.wait_for_function('()=>window.__printed>=1')
        except Exception:
            print('Print diagnostics',errors,page.evaluate('({count:window.__printed,classes:document.body.className,visible:document.visibilityState,onclick:document.getElementById("expenseSummaryPrintButton")?.getAttribute("onclick")})'),flush=True)
            raise
        page.evaluate('document.body.classList.add("print-expense-detail")')
        page.emulate_media(media='print')
        assert page.locator('#expenseDetailPrintArea').is_visible()
        assert page.locator('#expenseDetailPrintArea').evaluate('(e)=>e.getBoundingClientRect().top')<10
        assert page.locator('#expenseDetailPrintArea table').evaluate_all('(els)=>els.every(e=>getComputedStyle(e).display==="table")')
        page.pdf(path=str(screens/'summary_report.pdf'),format='A4',print_background=True)
        page.emulate_media(media='screen');page.evaluate('document.body.classList.remove("print-expense-detail")')
        # Snapshot report remains fixed while a linked re-report is actually approved.
        op('/api/expenses/resubmit',{**ref(correction),'message':'금액 보완 후 재보고','expense':{'amount':7000}})
        op('/api/expenses/decision',{**ref(correction),'decision':'approve'},c.admin)
        page.evaluate('async()=>{await loadServerState();initApp()}')
        assert metrics('#expenseDetailPrintArea')==scoped
        assert metrics()['amount']=='31,700원'
        page.evaluate('closeModal()');page.click('#expenseSummaryReportButton')
        assert metrics('#expenseDetailPrintArea')['amount']=='31,700원'
        page.evaluate('closeModal()');page.locator('#nav_v_card_history').click()
        assert '반납완료 · 승인완료' in page.locator('#cardHistoryTable tr').nth(3).inner_text()
        page.locator('#nav_v_expense_history').click();page.fill('#expenseHistorySearch','없는검색어-418')
        assert metrics()['documents']=='0건' and metrics()['amount']=='0원'
        page.click('#expenseSummaryReportButton');assert metrics('#expenseDetailPrintArea')['documents']=='0건'
        assert '조회 결과가 없습니다' in page.inner_text('#expenseDetailPrintArea');page.evaluate('closeModal()')
        branch=login('branch','Branch-test-pass!')
        branch.locator('#nav_v_expense_history').click()
        assert branch.locator('#expenseHistorySummary [data-metric=amount] strong').inner_text()=='31,700원'
        assert branch.locator('#expenseHistoryGroupFilter option[value="인천"]').count()==0
        with branch.expect_response(lambda r:'/api/state' in r.url) as state_response:branch.evaluate('async()=>await loadServerState()')
        assert '다른 지점 사용자' not in json.dumps(state_response.value.json(),ensure_ascii=False)
        branch.click('#expenseSummaryReportButton');assert '다른 지점 사용자' not in branch.inner_text('#expenseDetailPrintArea')
        assert branch.locator('#adminTreeNode').is_hidden()
        assert not errors,errors
        # Preview images use plain fictional labels; the XSS probe remains tested above.
        page.evaluate('''()=>{
            resetExpenseHistoryFilters();
            expenseHistoryData=expenseHistoryData.map(e=>({...e,user:'시험 사용자',purpose:'거래처 업무 협의 및 출장 정산'}));
            cardHistoryData=cardHistoryData.map(e=>({...e,user:'시험 사용자',purpose:'거래처 업무 협의 및 출장'}));
            cardsData=cardsData.map(e=>({...e,user:e.user?'시험 사용자':''}));
            switchView('v_expense_history',document.getElementById('nav_v_expense_history'));
            document.getElementById('expenseHistoryGroupFilter').value='서울';renderExpenseHistory();
            document.getElementById('mainContentArea').scrollTop=0;
        }''')
        page.screenshot(path=str(screens/'preview_summary.png'))
        page.click('#expenseSummaryReportButton')
        page.locator('.modal-card').screenshot(path=str(screens/'preview_report.png'))
        page.evaluate('closeModal();switchView("v_card_history",document.getElementById("nav_v_card_history"))')
        page.screenshot(path=str(screens/'preview_history.png'))
        print('PASS: real API records, six retained group icons, no other heading icons, renamed view, newest first, cumulative counts and same-card occurrence progress')
        print('PASS: actual Excel newest order/count/progress; scope/category/search metrics; cancelled originals excluded; line-count vs quantity and category totals')
        print('PASS: summary report snapshot, conditions, HTML escaping, print/PDF and 1440/1024/768/390/320px fit; actual re-report approval updates links/summary')
        print('PASS: branch-only state/list/report, no foreign options/data and no JavaScript errors')
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

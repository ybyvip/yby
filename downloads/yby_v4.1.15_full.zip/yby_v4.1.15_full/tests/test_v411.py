"""Cancellation/re-reporting financial invariants and real notice attachment transport."""
import base64
import copy
import json
from pathlib import Path
import sqlite3
import unittest
from unittest import mock
import test_security as fixture
import test_v4 as workflow

class RevisionTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):fixture.SecurityTests.setUpClass()
 @classmethod
 def tearDownClass(cls):fixture.SecurityTests.tearDownClass()
 def setUp(self):
  self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
 def op(self,path,data,cookie=None):return self.w.operation(path,data,cookie or self.c.admin)
 def ref(self,row):return {key:row[key] for key in ('id','group','requester')}
 def approved(self,cookie=None):
  row=self.w.operation('/api/expenses/submit',{'expense':self.w.draft()},cookie or self.c.branch)[1]['expense']
  status,body,_=self.op('/api/expenses/decision',{**self.ref(row),'decision':'approve'})
  self.assertEqual(status,200,body);return body['expense']
 def cancel(self,row,**override):return self.op('/api/expenses/correct',{**self.ref(row),'reason':'명세 보완 요청','password':'Admin-test-pass!',**override})
 def resubmit(self,row,cookie=None,**override):return self.op('/api/expenses/resubmit',{**self.ref(row),'expense':{'amount':250,'merchant':'보완된 가맹점','purpose':'수정된 목적'},'message':'세부 명세를 보완하여 재보고합니다.',**override},cookie or self.c.branch)
 def test_cancellation_preserves_values_and_creates_no_negative_approval(self):
  original=self.approved();status,body,_=self.cancel(original);self.assertEqual(status,200,body)
  state=self.a.get_state();self.assertEqual(len(state['expenseHistory']),1);old=state['expenseHistory'][0]
  self.assertEqual(old['status'],'승인취소');self.assertEqual(old['amount'],100);self.assertEqual(old['approvedAt'],original['approvedAt'])
  self.assertEqual(state['expense'][0]['status'],'재보고대기');self.assertEqual(body['expense']['requester'],'branch')
  self.assertFalse(any(row['amount']<0 for row in state['expenseHistory']));self.assertEqual(old['cancelReason'],'명세 보완 요청')
 def test_resubmission_requires_message_then_reapproval_counts_only_new_amount(self):
  original=self.approved();draft=self.cancel(original)[1]['expense']
  self.assertEqual(self.op('/api/expenses/decision',{**self.ref(draft),'decision':'approve'})[0],400)
  self.assertEqual(self.resubmit(draft,message='')[0],400)
  status,body,_=self.resubmit(draft);self.assertEqual(status,200,body);self.assertEqual(body['expense']['amount'],250)
  self.assertEqual(self.op('/api/expenses/decision',{**self.ref(draft),'decision':'approve'})[0],200)
  ledger=self.a.get_state()['expenseHistory'];self.assertEqual(sum(row['amount'] for row in ledger if row['status']=='승인완료'),250)
  self.assertEqual([x['type'] for x in ledger[-1]['reviewMessages']],['approve','cancel','resubmit','approve'])
  self.assertEqual([x['type'] for x in ledger[0]['reviewMessages']],['approve','cancel'])
 def test_top_admin_can_cancel_edit_and_reapprove_own(self):
  row=self.approved(self.c.admin);draft=self.cancel(row)[1]['expense']
  self.assertEqual(self.resubmit(draft,self.c.admin)[0],200)
  status,body,_=self.op('/api/expenses/decision',{**self.ref(draft),'decision':'approve'})
  self.assertEqual(status,200);self.assertTrue(body['expense']['selfDecision'])
 def test_rejection_can_be_corrected_and_reported_again_with_all_messages(self):
  draft=self.cancel(self.approved())[1]['expense'];self.resubmit(draft)
  self.assertEqual(self.op('/api/expenses/decision',{**self.ref(draft),'decision':'reject','reason':''})[0],400)
  rejected=self.op('/api/expenses/decision',{**self.ref(draft),'decision':'reject','reason':'증빙을 다시 확인하세요'})[1]['expense']
  status,body,_=self.op('/api/expenses/reopen-rejected',{**self.ref(rejected),'reason':'증빙 추가 후 재보고'},self.c.branch)
  self.assertEqual(status,200,body);next_draft=body['expense'];self.assertEqual(next_draft['correctionCycle'],2)
  self.assertEqual(self.resubmit(next_draft)[0],200)
  self.assertEqual(self.op('/api/expenses/decision',{**self.ref(next_draft),'decision':'approve'})[0],200)
  ledger=self.a.get_state()['expenseHistory'];self.assertEqual(len(ledger),3)
  self.assertEqual(sum(row['amount'] for row in ledger if row['status']=='승인완료'),250)
  self.assertIn('reject',[x['type'] for x in ledger[-1]['reviewMessages']])
 def test_repeated_or_concurrent_cancellation_cannot_make_two_drafts(self):
  row=self.approved();data={**self.ref(row),'reason':'정정','password':'Admin-test-pass!'}
  revision=self.c.state(self.c.admin)['revision'];payload={**data,'requestId':'same-cancel-request','revision':revision}
  self.assertEqual(self.c.request('/api/expenses/correct',payload,self.c.admin)[0],200)
  self.assertEqual(self.c.request('/api/expenses/correct',payload,self.c.admin)[0],200)
  self.assertEqual(self.cancel(row)[0],400);self.assertEqual(len(self.a.get_state()['expense']),1)
 def test_nonadmin_cannot_cancel_and_other_user_cannot_resubmit(self):
  row=self.approved()
  self.assertEqual(self.op('/api/expenses/correct',{**self.ref(row),'reason':'취소','password':'Admin-test-pass!'},self.c.branch)[0],403)
  draft=self.cancel(row)[1]['expense']
  with self.a.db() as conn:
   conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_expense']),));conn.commit()
  other=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.resubmit(draft,other)[0],403)
 def test_two_parallel_cancellations_commit_only_one_draft(self):
  from concurrent.futures import ThreadPoolExecutor
  row=self.approved();revision=self.c.state(self.c.admin)['revision']
  def cancel(index):
   data={**self.ref(row),'reason':'동시 정정','password':'Admin-test-pass!','requestId':'parallel-cancel-'+str(index),'revision':revision}
   return self.c.request('/api/expenses/correct',data,self.c.admin)[0]
  with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(cancel,range(2)))
  self.assertEqual(sorted(results),[200,409]);self.assertEqual(len(self.a.get_state()['expense']),1)
 def test_wrong_password_or_empty_reason_never_cancels(self):
  row=self.approved()
  self.assertEqual(self.cancel(row,password='wrong')[0],403);self.assertEqual(self.cancel(row,reason='')[0],400)
  self.assertEqual(self.a.get_state()['expenseHistory'][0]['status'],'승인완료')
 def test_database_failure_rolls_back_cancellation_and_queue(self):
  row=self.approved()
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated transaction failure')):self.assertEqual(self.cancel(row)[0],500)
  state=self.a.get_state();self.assertEqual(state['expense'],[]);self.assertEqual(state['expenseHistory'][0]['status'],'승인완료')
 def test_generic_save_cannot_forge_workflow_messages_or_edit_draft(self):
  draft=self.cancel(self.approved())[1]['expense'];changed=copy.deepcopy(draft);changed['purpose']='우회 수정'
  self.assertEqual(self.c.save({'expense':[changed]},self.c.admin)[0],403)
  self.assertEqual(self.a.get_state()['expense'][0]['purpose'],draft['purpose'])
 def test_new_submission_ignores_forged_workflow_metadata(self):
  value=self.w.draft();value.update(replaces={'id':'forged'},reviewMessages=[{'text':'forged'}],isCorrection=True)
  row=self.w.operation('/api/expenses/submit',{'expense':value})[1]['expense']
  self.assertNotIn('replaces',row);self.assertNotIn('reviewMessages',row);self.assertNotIn('isCorrection',row)
 def upload(self,content,cookie=None,purpose='settlement',**extra):
  data={'name':'한글 증빙.pdf','content':base64.b64encode(content).decode(),'purpose':purpose,'group':'서울',**extra}
  return self.c.request('/api/attachments',data,cookie or self.c.branch)
 def test_admin_resubmission_retains_original_users_receipt(self):
  upload=self.upload(b'%PDF-original');ref={'id':upload[1]['attachment_id'],'name':upload[1]['name']}
  value=self.w.draft();value['attachments']=[ref]
  row=self.w.operation('/api/expenses/submit',{'expense':value})[1]['expense']
  self.op('/api/expenses/decision',{**self.ref(row),'decision':'approve'});draft=self.cancel(row)[1]['expense']
  status,body,_=self.resubmit(draft,self.c.admin,expense={'amount':250,'attachments':[ref]})
  self.assertEqual(status,200,body);self.assertEqual(body['expense']['attachments'],[ref])
 def test_failed_resubmission_keeps_draft_and_approved_statistics_zero(self):
  draft=self.cancel(self.approved())[1]['expense']
  self.assertEqual(self.resubmit(draft,expense={'amount':-1})[0],400)
  state=self.a.get_state();self.assertEqual(state['expense'][0]['status'],'재보고대기');self.assertEqual(sum(x['amount'] for x in state['expenseHistory'] if x['status']=='승인완료'),0)
 def test_legacy_negative_corrections_are_preserved_and_not_reopened(self):
  row=self.approved()
  state=self.a.get_state();state['expenseHistory'][0]['correctionId']='legacy-credit'
  state['expenseHistory'].append({**row,'id':'legacy-credit','amount':-100,'isCorrection':True,'correctsId':row['id']})
  with self.a.db() as conn:self.a.persist_state(conn,state,'admin')
  self.assertEqual(self.cancel(row)[0],400);self.assertEqual(self.a.get_state()['expenseHistory'][-1]['amount'],-100)

class NoticeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):fixture.SecurityTests.setUpClass()
 @classmethod
 def tearDownClass(cls):fixture.SecurityTests.tearDownClass()
 def setUp(self):
  self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
 def upload(self,body=b'%PDF-1.7\nfixture\x00\xff',cookie=None,purpose='notice'):
  return self.c.request('/api/attachments',{'name':'공지 <&> 한글.pdf','purpose':purpose,'broadcast':True,'content':base64.b64encode(body).decode()},cookie or self.c.admin)
 def publish(self,upload):
  return self.w.operation('/api/notices/create',{'title':'첨부 공지 <&>','text':'공지 본문','attachment':{'id':upload['attachment_id'],'name':'not trusted name'}},self.c.admin)
 def test_published_notice_download_has_exact_bytes_and_korean_filename(self):
  content=b'%PDF-1.7\nfixture\x00\xff';value=self.upload(content)[1]
  self.assertEqual(self.c.request('/api/attachments/'+value['attachment_id'],cookie=self.c.branch)[0],403)
  status,body,_=self.publish(value);self.assertEqual(status,200,body);self.assertEqual(body['notice']['attachment']['name'],'공지 <&> 한글.pdf')
  status,opened,headers=self.c.request('/api/attachments/'+value['attachment_id'],cookie=self.c.branch)
  self.assertEqual(status,200);self.assertEqual(opened,content);self.assertEqual(headers['Content-Type'],'application/pdf');self.assertTrue(headers['Content-Disposition'].startswith('inline;'))
  status,raw,headers=self.c.request('/api/attachments/'+value['attachment_id']+'?download=1',cookie=self.c.branch)
  self.assertEqual(status,200);self.assertEqual(raw,content);self.assertTrue(headers['Content-Disposition'].startswith('attachment;'));self.assertIn("filename*=UTF-8''",headers['Content-Disposition'])
  self.assertEqual(self.c.request('/api/attachments/'+value['attachment_id'])[0],401)
 def test_deleted_notice_no_longer_exposes_notice_attachment(self):
  value=self.upload()[1];row=self.publish(value)[1]['notice']
  self.assertEqual(self.w.operation('/api/notices/delete',{'id':row['id']},self.c.admin)[0],200)
  self.assertEqual(self.c.request('/api/attachments/'+value['attachment_id'],cookie=self.c.branch)[0],403)
 def test_nonadmin_cannot_upload_publish_or_delete_notice(self):
  self.assertEqual(self.upload(cookie=self.c.branch)[0],403)
  self.assertEqual(self.w.operation('/api/notices/create',{'title':'x','text':'x'},self.c.branch)[0],403)
  self.assertEqual(self.w.operation('/api/notices/delete',{'id':1},self.c.branch)[0],403)
 def test_chat_file_cannot_be_published_as_notice_attachment(self):
  value=self.upload(purpose='chat')[1];self.assertEqual(self.publish(value)[0],403)
 def test_missing_attachment_or_invalid_body_does_not_create_notice(self):
  self.assertEqual(self.publish({'attachment_id':'0'*32})[0],400)
  self.assertEqual(self.w.operation('/api/notices/create',{'title':'','text':'x'},self.c.admin)[0],400)
  self.assertEqual(self.a.get_state().get('notices',[]),[])
 def test_database_failure_then_retry_reuses_uploaded_file(self):
  value=self.upload()[1]
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated notice save failure')):self.assertEqual(self.publish(value)[0],500)
  self.assertEqual(self.a.get_state().get('notices',[]),[]);self.assertEqual(self.publish(value)[0],200)
  self.assertEqual(len(self.a.get_state()['notices']),1)

if __name__=='__main__':unittest.main()

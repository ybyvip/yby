"""State gates, partial draft persistence, metric reconciliation and immutable history."""
import copy,json,unittest,sqlite3
from unittest import mock
from zipfile import ZipFile
from io import BytesIO
from urllib.parse import urlencode
import test_v4112 as fixtures
import fleet_cards

class WorkflowFixture(fixtures.FleetTests):
    pass
for name in dir(fixtures.FleetTests):
    if name.startswith('test_'):setattr(WorkflowFixture,name,None)

class StateWorkflowTests(WorkflowFixture):
    def issue(self):
        row=self.register();return self.confirm(row)[1]['hipass']
    def recover(self):
        row=self.issue();status,value,_=self.update(row,distributionStatus='회수중');self.assertEqual(status,200,value);return value['hipass']
    def complete(self,row,**extra):return self.op('complete-return',{**self.ref(row),'returnDate':self.a.business_date(),'password':'Branch-test-pass!','changeReason':'회수 확인',**extra})
    def test_partial_temporary_save_reload_is_in_worklist_not_list_or_card_count(self):
        status,value,_=self.op('register',{'group':'인천','hipassEnabled':True,'fuelEnabled':True,'fuelCard':{},'car':'작성 중 차량','mode':'temporary'})
        self.assertEqual(status,200,value);row=value['hipass'];self.assertEqual(row['group'],'서울');self.assertEqual(row['draftType'],'temporary');self.assertEqual(row['distributionStatus'],'대기중')
        state=self.c.state(self.c.branch)['state'];self.assertEqual(state['hipass'][0],row)
        self.assertTrue(fleet_cards.in_worklist(row,self.a.business_date()));self.assertFalse(fleet_cards.in_list(row,self.a.business_date()))
        self.assertEqual(fleet_cards.metric_rows([row],'registered',self.a.business_date()),[row]);self.assertEqual(fleet_cards.metric_rows([row],'hipass',self.a.business_date()),[])
        self.assertEqual(self.confirm(row)[0],400)
        status,value,_=self.update(row,distributionStatus='불출중');self.assertEqual(status,200,value);row=value['hipass'];self.assertEqual(row['draftType'],'ready')
        self.assertEqual(self.confirm(row)[0],200)
    def test_ready_waiting_cannot_advance_even_via_direct_api(self):
        row=self.register(distributionStatus='대기중');before=copy.deepcopy(self.a.get_state());self.assertEqual(self.confirm(row)[0],400);self.assertEqual(self.a.get_state(),before)
        with ZipFile(BytesIO(self.export('list')[1])) as z:self.assertNotIn('HP-001',z.read('xl/worksheets/sheet1.xml').decode())
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertIn('HP-001',z.read('xl/worksheets/sheet1.xml').decode())
        row=self.update(row,distributionStatus='불출중')[1]['hipass'];row=self.confirm(row)[1]['hipass'];self.assertTrue(fleet_cards.in_list(row,self.a.business_date()))
    def test_new_registration_cannot_start_in_recovery_or_return_complete(self):
        for state in ('회수중','회수완료'):
            for mode in ('ready','temporary'):self.assertEqual(self.op('register',self.payload(distributionStatus=state,mode=mode,returnDate=self.a.business_date()))[0],400)
        self.assertFalse(self.a.get_state()['hipass'])
    def test_full_temporary_issue_selected_still_requires_completed_input_save(self):
        row=self.register(mode='temporary',distributionStatus='불출중');self.assertEqual(self.confirm(row)[0],400)
        self.assertFalse(fleet_cards.metric_rows([row],'issued',self.a.business_date()))
        row=self.update(row,distributionStatus='불출중')[1]['hipass'];self.assertEqual(self.confirm(row)[0],200)
    def test_invalid_partial_dates_enums_duplicate_numbers_are_rejected(self):
        self.assertEqual(self.op('register',{'group':'서울','mode':'temporary','hipassEnabled':True})[0],400)
        self.assertEqual(self.op('register',{'group':'서울','mode':'temporary','hipassEnabled':True,'expiryDate':'bad'})[0],400)
        self.register();self.assertEqual(self.op('register',{'group':'서울','mode':'temporary','num':'H P-001','hipassEnabled':True})[0],400)
        self.assertEqual(self.op('register',{'group':'서울','mode':'temporary','classification':'가짜','hipassEnabled':True})[0],400)
    def test_recovery_moves_out_of_list_into_worklist_then_final_return_moves_back(self):
        row=self.recover();self.assertEqual(row['reviewStatus'],'confirmed');self.assertTrue(fleet_cards.in_worklist(row,self.a.business_date()))
        self.assertEqual(self.confirm(row)[0],400)
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertIn('HP-001',z.read('xl/worksheets/sheet1.xml').decode())
        with ZipFile(BytesIO(self.export('list')[1])) as z:self.assertNotIn('HP-001',z.read('xl/worksheets/sheet1.xml').decode())
        status,value,_=self.complete(row);self.assertEqual(status,200,value);done=value['hipass'];self.assertEqual(done['distributionStatus'],'회수완료');self.assertTrue(fleet_cards.in_list(done,self.a.business_date()))
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertNotIn('HP-001',z.read('xl/worksheets/sheet1.xml').decode())
        with ZipFile(BytesIO(self.export('list')[1])) as z:self.assertIn('회수완료',z.read('xl/worksheets/sheet1.xml').decode())
    def test_return_authentication_reason_date_stale_and_repeat_are_guarded(self):
        row=self.recover();before=copy.deepcopy(self.a.get_state())
        for change,expected in [({'password':'bad'},403),({'changeReason':''},400),({'returnDate':''},400),({'returnDate':'2099-01-01'},400),({'expectedVersion':'old'},409)]:self.assertEqual(self.complete(row,**change)[0],expected)
        self.assertEqual(self.a.get_state(),before);status,value,_=self.complete(row);self.assertEqual(status,200,value)
        self.assertEqual(self.complete(row)[0],409);self.assertEqual(self.complete(value['hipass'])[0],400)
    def test_illegal_transition_waiting_to_recovery_and_issued_to_waiting_blocked(self):
        row=self.register(distributionStatus='대기중');self.assertEqual(self.update(row,distributionStatus='회수중')[0],400);self.assertEqual(self.complete(row)[0],400)
        row=self.update(row,distributionStatus='불출중')[1]['hipass'];row=self.confirm(row)[1]['hipass'];self.assertEqual(self.update(row,distributionStatus='대기중')[0],400)
        self.assertEqual(self.update(row,mode='temporary',car='새차')[0],400)
        row=self.update(row,distributionStatus='회수중')[1]['hipass'];self.assertEqual(self.update(row,distributionStatus='불출중')[0],400)
    def test_completed_card_can_be_prepared_again_only_after_clearing_old_return_date(self):
        row=self.complete(self.recover())[1]['hipass'];self.assertEqual(self.update(row,distributionStatus='대기중',returnDate=self.a.business_date())[0],400)
        status,value,_=self.update(row,distributionStatus='대기중',returnDate='');self.assertEqual(status,200,value);self.assertEqual(self.confirm(value['hipass'])[0],400)
    def test_recovery_password_and_foreign_branch_permissions_are_enforced(self):
        row=self.recover()
        with self.a.db() as conn:conn.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_reg']),));conn.commit()
        cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.op('complete-return',{**self.ref(row),'password':'Branch-test-pass!','changeReason':'시도','returnDate':self.a.business_date()},cookie)[0],403)
    def test_recovery_failure_is_atomic_and_does_not_add_event_or_change_status(self):
        row=self.recover();before=copy.deepcopy(self.a.get_state())
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated save failure')):self.assertEqual(self.complete(row)[0],500)
        self.assertEqual(self.a.get_state(),before)
    def test_metrics_reconcile_single_and_paired_bundles_and_filtered_exports(self):
        row=self.issue();hp=self.register(num='HP-ONLY',fuelEnabled=False);fuel=self.register(hipassEnabled=False,fuelCard={**self.payload()['fuelCard'],'num':'FUEL-ONLY'})
        rows=self.a.get_state()['hipass'];today=self.a.business_date()
        self.assertEqual([len(fleet_cards.metric_rows(rows,k,today)) for k in ('issued','registered','review','recovery','hipass','fuel')],[1,3,2,0,2,2])
        status,raw,_=self.c.request('/api/hipass/export?'+urlencode({'mode':'status','metric':'hipass'}),cookie=self.c.branch);self.assertEqual(status,200)
        with ZipFile(BytesIO(raw)) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('HP-ONLY',xml);self.assertNotIn('FUEL-ONLY',xml)
        self.assertEqual(self.c.request('/api/hipass/export?mode=status&metric=invalid',cookie=self.c.branch)[0],400)
    def test_confirmation_links_actual_input_change_and_preserves_before_after(self):
        row=self.issue();old=copy.deepcopy(row);status,value,_=self.update(row,car='변경 차량',fuelCard={**self.payload()['fuelCard'],'company':'변경 유류사'});self.assertEqual(status,200,value)
        edit=self.a.get_state()['hipassBox'][-1];row=self.confirm(value['hipass'])[1]['hipass'];events=self.a.get_state()['hipassBox'];confirm=events[-1]
        self.assertEqual(confirm['documentChangeId'],edit['id']);self.assertEqual(edit['before']['car'],old['car']);self.assertEqual(edit['after']['car'],'변경 차량')
        self.assertNotEqual(edit['before']['fuelCard']['company'],edit['after']['fuelCard']['company']);self.assertEqual(confirm['before']['car'],confirm['after']['car'])
        self.assertEqual(self.a.get_state()['hipassBox'][-2],edit)
    def test_only_latest_event_has_current_status_and_sequences_survive_filter_and_delete(self):
        row=self.recover();state=self.a.get_state();events=state['hipassBox'];view=[fleet_cards.history_presentation(e,state['hipass'],events,self.a.business_date()) for e in events]
        self.assertEqual(sum(v['latest'] for v in view),1);self.assertEqual(view[-1]['status'],'회수중');self.assertTrue(all(v['status'].endswith('완료') for v in view[:-1]));self.assertEqual(len(set(v['sequence'] for v in view)),len(view))
        row=self.complete(row)[1]['hipass'];state=self.a.get_state();self.assertEqual(fleet_cards.history_presentation(events[-1],state['hipass'],state['hipassBox'],self.a.business_date())['status'],'변경 완료')
        with ZipFile(BytesIO(self.export('history')[1])) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('일련번호',xml);self.assertIn('회수완료',xml);self.assertIn('변경 완료',xml)
    def test_legacy_history_same_card_only_last_row_is_current_without_rewriting_snapshots(self):
        row={'id':101,'group':'서울','hipassUser':'기존','num':'OLD-NO'}
        events=[{'id':1,'group':'서울','num':'OLD-NO','action':'최초등록','time':'2026-01-01 09:00'},{'id':2,'group':'서울','num':'OLD-NO','action':'정보수정','time':'2026-01-02 09:00'}]
        before=copy.deepcopy(events);result=[fleet_cards.history_presentation(e,[row],events,self.a.business_date()) for e in events]
        self.assertFalse(result[0]['latest']);self.assertEqual(result[0]['status'],'등록 완료');self.assertTrue(result[-1]['latest']);self.assertEqual(events,before)

if __name__=='__main__':unittest.main()

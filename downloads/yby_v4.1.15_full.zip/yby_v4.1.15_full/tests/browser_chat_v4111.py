"""Direct messenger blur, live density, detached window, and preserved password lock."""
from pathlib import Path
import importlib.util,os,sys
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-chat-v4111-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('dialog',lambda d:d.accept());page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
        page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>currentUser==='admin'&&!loginInFlight");page.evaluate('stopLiveSync()');page.click('#chatPanelToggle')
        page.evaluate('''()=>{chatMessagesList=[{id:'preview-all',sender:'branch',text:'메신저 표시 시험 메시지',dm:false,recipient:'ALL',time:'2026-10-19 16:00:00'},{id:'preview-private',sender:'branch',text:'별도 창 표시 시험 메시지',dm:true,recipient:'admin',recipients:['admin'],time:'2026-10-19 16:00:01'}];setActiveChatThread('ALL');}''')
        page.fill('#chatInput','작성 중인 메시지 유지');before=page.locator('.chat-area').bounding_box()
        original=page.evaluate('JSON.stringify(chatMessagesList)')
        page.click('#chatBlurToggle');expect(page.locator('#chatPrivacyCover')).to_be_hidden();expect(page.locator('#commonModal')).to_be_hidden()
        expect(page.locator('#chatBlurOptions')).to_be_visible();expect(page.locator('#chatBlurToggle')).to_have_attribute('aria-pressed','true')
        filters=lambda:page.locator('#chatMessages').evaluate('(e)=>getComputedStyle(e).filter')
        assert filters().startswith('blur('),filters()
        for selector in ['.main-content','#chatBlurOptions','.chat-format-toolbar']:
            assert page.locator(selector).evaluate('(e)=>getComputedStyle(e).filter')=='none',selector
        page.locator('#chatBlurLevel').focus();page.locator('#chatBlurLevel').press('Home');low=filters();assert page.inner_text('#chatBlurLevelValue')=='20%'
        page.locator('#chatBlurLevel').press('End');high=filters();assert page.inner_text('#chatBlurLevelValue')=='100%' and low!=high
        assert page.locator('#chatConversationTitle').evaluate('(e)=>getComputedStyle(e).filter')==high
        assert page.locator('#chatInput').evaluate('(e)=>getComputedStyle(e).filter')==high
        page.evaluate('renderChatMessages()');assert filters()==high
        assert page.input_value('#chatInput')=='작성 중인 메시지 유지' and page.evaluate('JSON.stringify(chatMessagesList)')==original
        after=page.locator('.chat-area').bounding_box();assert before['width']==after['width'] and before['height']==after['height']
        page.locator('.chat-area').screenshot(path=str(screens/'messenger_direct_blur.png'))
        page.click('#chatBlurToggle');assert filters()=='none';expect(page.locator('#chatBlurOptions')).to_be_hidden();assert page.input_value('#chatInput')=='작성 중인 메시지 유지'
        # Existing lock mode still covers the messenger and requires password verification.
        page.click('#chatBoldToggle');expect(page.locator('#chatPrivacyCover')).to_be_visible()
        page.fill('#chatPrivacyPassword','incorrect-password');page.locator('#chatPrivacyCover button').click();expect(page.locator('#chatPrivacyError')).not_to_be_empty();expect(page.locator('#chatPrivacyCover')).to_be_visible()
        page.fill('#chatPrivacyPassword','Admin-test-pass!');page.locator('#chatPrivacyCover button').click();expect(page.locator('#chatPrivacyCover')).to_be_hidden()
        page.evaluate("setActiveChatThread('DM|admin|branch')")
        with page.expect_popup() as info:page.locator('.chat-header button[title="별도 창으로 열기"]').click()
        popup=info.value;popup.on('pageerror',lambda e:errors.append(str(e)));popup.wait_for_selector('#popBlur')
        expect(popup.locator('#detachedChatMessages')).to_contain_text('별도 창 표시 시험 메시지')
        popup.fill('#detachedChatInput','별도 창 작성 중');popup.click('#popBlur');expect(popup.locator('#detachedPrivacyCover')).to_be_hidden()
        assert popup.locator('body').evaluate('(e)=>getComputedStyle(e,"::after").content') in ('none','normal')
        popup.locator('#popBlurLevel').focus();popup.locator('#popBlurLevel').press('Home');low=popup.locator('#detachedChatMessages').evaluate('(e)=>getComputedStyle(e).filter')
        popup.locator('#popBlurLevel').press('End');high=popup.locator('#detachedChatMessages').evaluate('(e)=>getComputedStyle(e).filter')
        assert low!=high and 'blur(' in high and popup.inner_text('#popBlurValue')=='100%'
        assert popup.locator('.toolbar').evaluate('(e)=>getComputedStyle(e).filter')=='none'
        popup.wait_for_timeout(1200);assert popup.locator('#detachedChatMessages').evaluate('(e)=>getComputedStyle(e).filter')==high
        assert popup.input_value('#detachedChatInput')=='별도 창 작성 중'
        popup.screenshot(path=str(screens/'messenger_detached_blur.png'))
        popup.click('#popBlur');assert popup.locator('#detachedChatMessages').evaluate('(e)=>getComputedStyle(e).filter')=='none'
        popup.click('#popBold');expect(popup.locator('#detachedPrivacyCover')).to_be_visible()
        popup.fill('#popPrivacyPassword','incorrect-password');popup.click('#popReveal');expect(popup.locator('#popPrivacyError')).not_to_be_empty();popup.wait_for_timeout(1200);expect(popup.locator('#popPrivacyError')).not_to_be_empty();expect(popup.locator('#detachedPrivacyCover')).to_be_visible()
        popup.fill('#popPrivacyPassword','Admin-test-pass!');popup.click('#popReveal');expect(popup.locator('#detachedPrivacyCover')).to_be_hidden()
        assert popup.input_value('#detachedChatInput')=='별도 창 작성 중'
        popup.close();assert not errors,errors
        print('PASS: sidebar and detached messenger blur content directly without overlay/dialog; actual range keyboard input 20% -> 100% changes filter immediately; toolbar and business view stay sharp')
        print('PASS: layout, draft text and message data preserved; rerender/periodic popup refresh retains chosen density; toggle restores normal; no JS errors')
        print('PASS: existing sidebar and detached password lock still requires correct password; wrong password cannot unlock')
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

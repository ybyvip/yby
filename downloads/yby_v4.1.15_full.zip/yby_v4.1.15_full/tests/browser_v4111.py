"""Actual compact UI, self-review/self-approval, and independent issue completion."""
from pathlib import Path
import importlib.util,json,os,sys,time
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import external_documents as inbox
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4111-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    with a.db() as conn:
        conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_dashboard','v_card_rent','v_card_history','v_expense','v_expense_history','v_report_write','v_report_box']),'branch'));conn.commit()
    assert c.save({'cards':[{'id':1,'num':'TEST-5545','group':'서울','company':'시험 카드사','status':'available'}]},c.admin)[0]==200
    def source(kind):
        d={'documentId':kind+'-INDEPENDENT','documentNo':'시험-신청-001' if kind=='application' else '시험-정산-009','kind':kind,'group':'서울','revision':1,'applicationDate':'2026-10-19','dueDate':'2099-01-01','applicantName':'신청 담당자','user':'실제 사용자','dept':'총무팀','purpose':'업무 협의 출장','approvalStatus':'결재중','cardLast4':'5545'}
        if kind=='settlement':d['lineItems']=[{'date':'2026-10-19','category':'식대','merchant':'업무 식당','description':'업무 협의 식사','quantity':1,'unitPrice':27000,'amount':27000}]
        return d
    def stage(kind):
        with a.db() as conn:key=inbox.stage(conn,source(kind));conn.commit()
        return key
    def pick(page,area):
        page.locator(area+' .live-document button').click();page.wait_for_selector('#applyExternalDocument')
        page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached')
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        errors=[];dialogs=[]
        def login(user,password):
            page=browser.new_page(viewport={'width':1920,'height':1080});page.on('pageerror',lambda e:errors.append(str(e)))
            def dialog(d):dialogs.append(d.message);d.accept()
            page.on('dialog',dialog);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',user);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter')
            page.wait_for_function('(user)=>currentUser===user&&!loginInFlight',arg=user);page.evaluate('stopLiveSync()');return page
        page=login('admin','Admin-test-pass!');page.click('#nav_v_card_rent')
        expect(page.locator('#applicationLiveContent .live-health')).to_contain_text('Oracle 연결 대기')
        assert page.locator('#pickExternalApplication,#rentalSourceLabel').count()==0
        assert '신청 자료 출처' not in page.inner_text('#v_card_rent')
        height=page.locator('#applicationLiveContent').evaluate('(e)=>e.getBoundingClientRect().height');assert height<190,height
        assert not page.locator('#applicationLiveContent .live-filter').get_attribute('open')
        assert page.locator('#applicationLiveContent footer').is_hidden()
        tops=page.locator('#rentApplicationDate,#rentCardSelect,#rentDept,#rentUser,#rentApplicant,#rentDueDate').evaluate_all('(els)=>els.map(e=>e.getBoundingClientRect().top)')
        assert max(tops)-min(tops)<3,tops
        for width in [1440,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1080})
            for selector in ['#applicationLiveContent','.rental-request-grid']:
                metric=page.locator(selector).evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert metric['sw']<=metric['w']+1,(width,selector,metric)
        page.set_viewport_size({'width':1920,'height':1080});page.locator('#v_card_rent').screenshot(path=str(screens/'compact_empty_rental.png'))
        stage('application');page.locator('#applicationLiveContent .live-refresh').click();expect(page.locator('#applicationLiveContent .live-list')).to_contain_text('시험-신청-001')
        pick(page,'#applicationLiveContent');expect(page.locator('#applicationLiveContent .live-selected')).to_contain_text('시험-신청-001')
        page.locator('#applicationLiveContent .live-selected button').click();assert page.evaluate('rentalIntake.application') is None
        pick(page,'#applicationLiveContent');page.click('#rentalApplyButton');page.wait_for_function('()=>cardsData[0].status==="rented"')
        page.click('#nav_v_card_history');assert '반납대기' in page.inner_text('#cardHistoryTable');assert '불출완료' not in page.inner_text('#cardHistoryTable')
        page.click('#nav_v_card_rent');page.locator('#returnTable button').click()
        assert page.locator('#pickExternalSettlement,#returnSettlementSource').count()==0
        assert '정산 자료 출처' not in page.inner_text('#modalBody')
        expect(page.locator('#settlementLiveContent .live-health')).to_contain_text('Oracle 연결 대기')
        assert page.locator('#settlementLiveContent').evaluate('(e)=>e.getBoundingClientRect().height')<190
        stage('settlement');page.locator('#settlementLiveContent .live-refresh').click();expect(page.locator('#settlementLiveContent .live-list')).to_contain_text('시험-정산-009')
        pick(page,'#settlementLiveContent');assert page.inner_text('#returnExpenseTotal')=='27,000'
        assert page.is_checked('#returnUsedCheckbox');page.locator('#modalBody').evaluate('(e)=>e.scrollTop=0')
        page.locator('.modal-card').screenshot(path=str(screens/'compact_return.png'))
        page.check('#returnCopyReport');page.click('#returnCardSubmitButton');page.wait_for_function('()=>document.getElementById("v_report_write").classList.contains("active")')
        assert page.input_value('#approver1')=='admin' and page.input_value('#approver2')=='admin'
        assert '27,000원' in page.input_value('#repContent');page.locator('#v_report_write').screenshot(path=str(screens/'self_approval_draft.png'))
        page.locator('#reportWriteForm button[type=submit]').click();page.wait_for_function('()=>reportList.length===1')
        report=a.get_state()['reports'][0];assert report['status']=='pending' and report['selfReviewed']
        assert report['decisions'][0]['actor']=='admin' and report['decisions'][0]['selfDecision']
        assert not any('본인 외 최고관리자' in d for d in dialogs)
        # Receipt returned already: issue is complete even though settlement awaits approval.
        page.click('#nav_v_card_history')
        issue=page.locator('#cardHistoryTable tr').filter(has_text='불출완료');assert issue.count()==1 and '승인대기' not in issue.inner_text()
        assert '반납완료 · 승인대기' in page.inner_text('#cardHistoryTable')
        page.locator('#v_card_history').screenshot(path=str(screens/'issue_complete_history.png'))
        with page.expect_download() as download:page.evaluate('exportHistoryExcel()')
        from zipfile import ZipFile
        with ZipFile(download.value.path()) as z:
            sheet=z.read('xl/worksheets/sheet1.xml').decode();assert '불출완료' in sheet and '반납완료 · 승인대기' in sheet
        page.click('#nav_v_report_box');page.get_by_role('button',name='최종 승인',exact=True).click();page.wait_for_function('()=>reportList[0].status==="approved"')
        final=a.get_state()['reports'][0];assert final['selfApproved'] and len(final['decisions'])==2
        assert a.get_state()['expense'][0]['status']=='승인대기'
        page.get_by_role('button',name='보기',exact=True).click();expect(page.locator('.report-decisions')).to_contain_text('기안 상신 시 본인 검토 완료');expect(page.locator('.report-decisions')).to_contain_text('최종 결재')
        page.locator('.modal-card').screenshot(path=str(screens/'self_approved_detail.png'));page.evaluate('closeModal()')
        # Branch default self review, admin final; branch cannot final-approve itself.
        branch=login('branch','Branch-test-pass!');branch.click('#nav_v_report_write')
        assert branch.input_value('#approver1')=='branch' and branch.input_value('#approver2')=='admin'
        branch.fill('#repTitle','지점 업무 결과 보고');branch.fill('#repContent','확인 후 상신합니다.');branch.locator('#reportWriteForm button[type=submit]').click()
        branch.wait_for_function('()=>reportList.some(r=>r.author==="branch")');assert branch.get_by_role('button',name='최종 승인',exact=True).count()==0
        row=next(r for r in a.get_state()['reports'] if r['author']=='branch');assert row['status']=='pending' and row['selfReviewed']
        page.evaluate('async()=>{await loadServerState();initApp()}');page.get_by_role('button',name='최종 승인',exact=True).click()
        page.wait_for_function('()=>reportList.find(r=>r.author==="branch").status==="approved"')
        assert a.get_state()['expense'][0]['status']=='승인대기'
        assert not errors,errors
        print('PASS: duplicate source panels removed; single compact inbox, collapsed filters/pagination; empty inbox <190px; six desktop fields one row; 1920/1440/1024/768/390/320px fit')
        print('PASS: select/clear/reselect source, issue and return via live inbox; one-line settlement and report copied with defaults self-review/admin final')
        print('PASS: actual own admin report submit -> self-review audit -> own final approval; branch defaults -> admin final; settlement still pending; no JS errors')
        print('PASS: issue immediately 불출완료 after return, pending settlement stays on return row; screen and real Excel export agree')
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

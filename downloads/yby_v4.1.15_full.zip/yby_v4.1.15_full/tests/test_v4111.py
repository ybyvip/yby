"""Explicit self-review and assigned highest-administrator final approval."""
import copy,json,unittest
from unittest import mock
import sqlite3
import test_v4 as workflow

class ReportApprovalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):workflow.V4Tests.setUpClass()
    @classmethod
    def tearDownClass(cls):workflow.V4Tests.tearDownClass()
    def setUp(self):
        self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
    def submit(self,cookie=None,**extra):
        return self.w.operation('/api/documents/submit',{'group':'서울','title':'업무 결과 보고','content':'실제 업무 결과','reviewer':'branch','approver':'admin',**extra},cookie)
    def decide(self,row,cookie=None,decision='approve',request_id=None):
        return self.w.operation('/api/documents/decision',{'id':row['id'],'decision':decision},cookie,request_id)
    def test_branch_self_review_is_completed_on_submit_but_final_requires_admin(self):
        status,value,_=self.submit();self.assertEqual(status,200,value);row=value['document']
        self.assertEqual(row['status'],'pending');self.assertTrue(row['selfReviewed']);self.assertEqual(row['reviewer'],'branch')
        self.assertEqual(len(row['decisions']),1);self.assertEqual(row['decisions'][0]['actor'],'branch');self.assertTrue(row['decisions'][0]['selfDecision'])
        self.assertEqual(self.decide(row)[0],403);self.assertEqual(self.a.get_state()['reports'][0]['status'],'pending')
        self.assertEqual(self.decide(row,self.c.admin)[0],200)
        final=self.a.get_state()['reports'][0];self.assertEqual(final['status'],'approved');self.assertFalse(final['selfApproved']);self.assertEqual(len(final['decisions']),2)
    def test_admin_can_submit_self_review_and_final_approve_own_report_exactly_once(self):
        status,value,_=self.submit(self.c.admin,reviewer='admin');self.assertEqual(status,200,value);row=value['document']
        self.assertEqual(row['author'],'admin');self.assertEqual(row['status'],'pending')
        payload={'id':row['id'],'decision':'approve','requestId':'own-final','revision':self.c.state(self.c.admin)['revision']}
        first=self.c.request('/api/documents/decision',payload,self.c.admin);self.assertEqual(first[0],200,first[1])
        again=self.c.request('/api/documents/decision',payload,self.c.admin);self.assertEqual(again[0],200)
        final=self.a.get_state()['reports'][0];self.assertTrue(final['selfApproved']);self.assertTrue(final['selfDecision']);self.assertEqual(final['status'],'approved')
        self.assertEqual([d['stage'] for d in final['decisions']],['pending_review','pending']);self.assertEqual(len(final['decisions']),2)
        self.assertEqual(self.decide(row,self.c.admin)[0],403)
    def test_admin_own_rejection_is_logged_as_final_self_decision(self):
        row=self.submit(self.c.admin,reviewer='admin')[1]['document'];self.assertEqual(self.decide(row,self.c.admin,'reject')[0],200)
        final=self.a.get_state()['reports'][0];self.assertEqual(final['status'],'rejected');self.assertTrue(final['selfDecision']);self.assertFalse(final['selfApproved'])
    def test_final_assignee_cannot_skip_another_reviewers_pending_stage(self):
        row=self.submit(self.c.admin,reviewer='branch')[1]['document'];self.assertEqual(row['status'],'pending_review')
        self.assertEqual(self.decide(row,self.c.admin)[0],403);self.assertEqual(self.decide(row)[0],200)
        self.assertEqual(self.decide(row,self.c.admin)[0],200);self.assertTrue(self.a.get_state()['reports'][0]['selfApproved'])
    def test_nonadmin_final_assignment_and_foreign_reviewers_are_rejected(self):
        self.assertEqual(self.submit(approver='branch')[0],400)
        with self.a.db() as conn:conn.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_report_box']),));conn.commit()
        self.assertEqual(self.submit(reviewer='readonly')[0],400)
        self.assertFalse(self.a.get_state().get('reports'))
    def test_demoted_final_assignee_cannot_use_old_assignment_to_approve(self):
        row=self.submit()[1]['document']
        with self.a.db() as conn:conn.execute("UPDATE users SET scope='서울',permissions_json=? WHERE username='admin'",(json.dumps(['v_report_box']),));conn.commit()
        try:
            cookie=self.c.login('admin','Admin-test-pass!');self.assertEqual(self.decide(row,cookie)[0],403)
            self.assertEqual(self.a.get_state()['reports'][0]['status'],'pending')
        finally:
            with self.a.db() as conn:conn.execute("UPDATE users SET scope='ALL' WHERE username='admin'");conn.commit()
    def test_self_review_failure_is_atomic_and_generic_state_cannot_forge_decisions(self):
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated report save failure')):
            self.assertEqual(self.submit(self.c.admin,reviewer='admin')[0],500)
        self.assertFalse(self.a.get_state().get('reports'))
        row=self.submit(self.c.admin,reviewer='admin')[1]['document'];reports=copy.deepcopy(self.a.get_state()['reports']);reports[0]['status']='approved'
        self.assertEqual(self.c.save({'reports':reports},self.c.admin)[0],403);self.assertEqual(self.a.get_state()['reports'][0]['status'],'pending')
    def test_self_review_is_available_with_write_permission_without_other_reviewer_permission(self):
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_report_write']),));conn.commit()
        status,value,_=self.submit();self.assertEqual(status,200,value);self.assertEqual(value['document']['status'],'pending')
    def test_other_highest_admin_is_not_allowed_to_take_assigned_final_approval(self):
        with self.a.db() as conn:conn.execute("UPDATE users SET scope='ALL' WHERE username='readonly'");conn.commit()
        other=self.c.login('readonly','Branch-test-pass!');row=self.submit()[1]['document']
        self.assertEqual(self.decide(row,other)[0],403);self.assertEqual(self.decide(row,self.c.admin)[0],200)

if __name__=='__main__':unittest.main()

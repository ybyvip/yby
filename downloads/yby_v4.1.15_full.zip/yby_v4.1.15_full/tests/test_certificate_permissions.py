import contextlib
import io
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import certificate_permissions as permissions
import lan_setup


class CertificatePermissionTests(unittest.TestCase):
    def test_windows_files_receive_effective_file_rights_without_folder_inheritance_flags(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'root-ca.cer').write_bytes(b'public');(root/'server-key.pem').write_bytes(b'private')
            calls=[]
            with patch.object(permissions,'is_windows',return_value=True),patch.object(permissions,'windows_sid',return_value='S-1-5-21-100'),patch.object(permissions,'run',side_effect=lambda args:calls.append(args)):
                permissions.protect(root)
            self.assertEqual(len(calls),3)
            for args in calls:
                self.assertNotIn('/T',args)
                rights=[arg for arg in args if arg.startswith('*')]
                if Path(args[1])==root:self.assertTrue(all(right.endswith(':(OI)(CI)F') for right in rights))
                else:
                    self.assertTrue(all(right.endswith(':F') and '(OI)' not in right and '(CI)' not in right for right in rights))
                    self.assertIn('*S-1-5-21-100:F',rights)

    def test_nested_folder_and_files_have_separate_acl_kinds(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'nested').mkdir();(root/'nested/file.pem').write_bytes(b'dummy')
            calls=[]
            with patch.object(permissions,'is_windows',return_value=True),patch.object(permissions,'windows_sid',return_value='S-1-5-21-100'),patch.object(permissions,'run',side_effect=lambda args:calls.append(args)):
                permissions.protect(root)
            self.assertEqual(len(calls),3)
            self.assertIn('*S-1-5-21-100:F',calls[-1])

    def test_failed_acl_command_stops_instead_of_claiming_repair(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(permissions,'is_windows',return_value=True),patch.object(permissions,'windows_sid',return_value='S-1-5-21-100'),patch.object(permissions,'run',side_effect=RuntimeError('ACL blocked')):
            with self.assertRaisesRegex(RuntimeError,'ACL blocked'):permissions.protect(folder)

    def test_existing_acl_is_repaired_before_the_first_certificate_load(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'certificates').mkdir()
            with patch.object(permissions,'is_windows',return_value=True),patch.object(lan_setup,'protect_certificate_directory') as repair:
                self.assertIsNone(lan_setup.load_settings(root))
                repair.assert_called_once_with(root/'certificates')

    def test_readability_probe_does_not_print_private_bytes(self):
        with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()) as output:
            root=Path(folder)
            for name in permissions.REQUIRED:(root/name).write_bytes(b'NEVER-PRINT-PRIVATE-KEY')
            permissions.check_readable(root)
            self.assertNotIn('NEVER-PRINT-PRIVATE-KEY',output.getvalue())

    def test_empty_key_is_rejected_by_the_readability_probe(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            for name in permissions.REQUIRED:(root/name).write_bytes(b'x')
            (root/'server-key.pem').write_bytes(b'')
            with self.assertRaisesRegex(RuntimeError,'빈 인증서'):permissions.check_readable(root)

    def test_repair_preserves_all_certificate_bytes(self):
        import hashlib,ssl,subprocess
        with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()):
            root=Path(folder)
            lan_setup.create_certificates(ROOT,root,'10.10.0.121','test-server',None)
            before={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in root.iterdir() if path.is_file()}
            first=permissions.repair(root);second=permissions.repair(root)
            after={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in root.iterdir() if path.is_file()}
            self.assertEqual(first,second);self.assertEqual(before,after)


if __name__=='__main__':unittest.main()

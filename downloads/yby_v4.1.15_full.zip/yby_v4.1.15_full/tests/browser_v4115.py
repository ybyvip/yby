"""Real matching editor -> external expense inbox -> one return/expense, all-statistics and colors."""
from pathlib import Path
from zipfile import ZipFile
import importlib.util,json,os,sys,time,subprocess
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import external_documents
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4115-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=f.app
    with a.db() as conn:
        conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_rent','v_expense','v_stats','v_hipass_reg','v_hipass_box']),));conn.commit()
    assert c.save({'cards':[{'id':1,'num':'TEST-5545','group':'서울','status':'available','company':'시험사'}]},c.admin)[0]==200
    def source(kind,identity,number,**extra):
        doc={'kind':kind,'documentId':identity,'documentNo':number,'group':'서울','revision':1,'applicantName':'신청 담당자','user':'사용 담당자','dept':'총무팀','purpose':'[출장] 외부 업무','approvalStatus':'결재중','cardLast4':'5545','applicationDate':'2026-10-01','dueDate':'2099-01-01'}
        if kind=='settlement':doc['lineItems']=[{'date':'2026-10-01','category':'식대','merchant':'시험 식당','description':'업무 식사','quantity':2,'unitPrice':1000,'amount':2000}]
        doc.update(extra)
        with a.db() as conn:key=external_documents.stage(conn,doc);conn.commit()
        return key
    appkey=source('application','A1','신청-001');wrong=source('settlement','S1','정산-잘못선택');correct=source('settlement','S2','정산-정정선택');source('application','FOREIGN','다른지점-자료',group='인천')
    def operation(path,payload,cookie=None):
        actor=cookie or c.admin;status,value,_=c.request(path,{**payload,'requestId':str(time.time_ns()),'revision':c.state(actor)['revision']},cookie=actor);assert status==200,(status,value);return value
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);errors=[];dialogs=[]
        def login(name,password):
            page=browser.new_page(viewport={'width':1600,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
            def dialog(d):dialogs.append(d.message);d.accept()
            page.on('dialog',dialog);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function('(name)=>currentUser===name&&!loginInFlight',arg=name);page.evaluate('stopLiveSync()');return page
        page=login('admin','Admin-test-pass!');page.click('#nav_v_expense');assert page.locator('#expCardSelect').count()==0;page.locator('#expenseSettlementLiveContent .live-refresh').click();expect(page.locator('#expenseSettlementLiveContent')).to_contain_text('정산-정정선택')
        page.click('#nav_v_external_match');page.locator('#matchCandidatesapplication input[value="'+appkey+'"]').check();page.wait_for_function('(key)=>matchUI.application?.key===key',arg=appkey)
        page.locator('#matchCandidatessettlement input[value="'+wrong+'"]').check();page.wait_for_function('(key)=>matchUI.settlement?.key===key',arg=wrong);page.check('#matchConfirmed');page.fill('#matchReason','처음 연결');page.click('#matchSaveButton');page.wait_for_selector('#matchResultBody tr[data-match-id]')
        page.locator('#matchResultBody button').filter(has_text='불출 준비').click();page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached');page.click('#rentalApplyButton');page.wait_for_function('()=>cardsData[0].status==="rented"')
        # Correct a wrong settlement selection while the card is issued, before financial processing.
        page.click('#nav_v_external_match');page.locator('#matchResultBody button').filter(has_text='매칭 수정').click();page.locator('#matchCandidatessettlement input[value="'+correct+'"]').check();page.wait_for_function('(key)=>matchUI.settlement?.key===key',arg=correct)
        page.check('#matchConfirmed');page.fill('#matchReason','잘못 선택한 정산서 연결 정정');page.fill('#matchPassword','bad');page.click('#matchSaveButton');expect(page.locator('#matchEditorError')).to_contain_text('비밀번호');page.fill('#matchPassword','Admin-test-pass!');page.click('#matchSaveButton');page.wait_for_function('()=>matchUI.editing===null');expect(page.locator('#matchResultBody')).to_contain_text('정산-정정선택');page.locator('#v_external_match').screenshot(path=str(screens/'matching.png'))
        page.locator('#matchResultBody button').filter(has_text='이력').click();expect(page.locator('#modalBody')).to_contain_text('정산-잘못선택');expect(page.locator('#modalBody')).to_contain_text('정산-정정선택');page.locator('.modal-card').screenshot(path=str(screens/'matching_history.png'));page.evaluate('closeModal()')
        # The settlement screen has the same live inbox and routes the matched source to its exact active rental.
        page.click('#nav_v_expense');page.locator('#expenseSettlementLiveContent .live-refresh').click();page.locator('#expenseSettlementLiveContent article[data-key="'+correct+'"] button').click();expect(page.locator('#returnUsedCheckbox')).to_be_checked();assert page.input_value('#returnExpenseAmount')=='2000';assert page.evaluate('rentalIntake.settlement.key')==correct
        page.locator('.modal-card').screenshot(path=str(screens/'matched_return.png'));page.click('#returnCardSubmitButton');page.wait_for_selector('#commonModal',state='hidden');assert len(a.get_state()['expense'])==1;expense=a.get_state()['expense'][0];assert expense['externalMatchRef']['applicationKey']==appkey and expense['sourceRef']['key']==correct
        page.click('#nav_v_external_match');page.evaluate('loadExternalMatches()');expect(page.locator('#matchResultBody')).to_contain_text('저장완료');assert page.locator('#matchResultBody button').filter(has_text='매칭 수정').count()==0
        page.click('#nav_v_expense');page.locator('#expenseTable button').filter(has_text='승인').first.click();page.wait_for_function('()=>expenseHistoryData.some(e=>e.status==="승인완료")')
        # Add other approved/cancelled/legacy-credit fixtures to verify all-statistic totals and branch restrictions.
        state=a.get_state();base={**state['expenseHistory'][0]};base.pop('lineItems',None);base.pop('externalMatchRef',None)
        state['expenseHistory'] += [{**base,'id':'OWN-SECOND','user':'다른 사용자','dept':'영업팀','amount':3000,'purpose':'[복지] 행사'}, {**base,'id':'CANCELLED','status':'승인취소','amount':9000}, {**base,'id':'CREDIT','isCorrection':True,'amount':-2000}, {**base,'id':'FOREIGN-STAT','group':'인천','user':'다른지점통계','amount':7000}]
        with a.db() as conn:a.persist_state(conn,state,'fixture')
        page.evaluate('async()=>{await loadServerState();initApp();}');page.click('#nav_v_stats');expect(page.locator('#statsModeSelect')).to_have_value('overall');page.fill('#statsMonth','2026-10');page.fill('#statsCompareMonth','2026-09');page.evaluate('renderStats()')
        assert page.evaluate('currentStatsExport.model.current.amount')==12000;assert page.locator('.stats-dimension-grid>section').count()==4;assert page.locator('.stats-combined table tbody tr').count()==3;assert page.locator('.stats-dimension-grid section').evaluate_all('(items)=>items.every(e=>{const t=e.querySelector("table");return t.scrollWidth<=e.clientWidth})')
        capture_style=page.add_style_tag(content='#appContainer{height:auto!important;overflow:visible!important}#mainContentArea{height:auto!important;overflow:visible!important}');page.locator('#reportPrintArea').screenshot(path=str(screens/'overall_stats.png'));capture_style.evaluate('(e)=>e.remove()')
        with page.expect_download() as d:page.evaluate('exportToExcel()')
        with ZipFile(d.value.path()) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();assert all(x in xml for x in ['통합','부서','개인','목적','다른 사용자'])
        page.emulate_media(media='print');page.pdf(path=str(screens/'overall_stats.pdf'),format='A4',landscape=True,print_background=True);page.emulate_media(media='screen')
        subprocess.run(['pdftotext','-layout',str(screens/'overall_stats.pdf'),str(screens/'overall_stats.txt')],check=True);pdf=(screens/'overall_stats.txt').read_text();assert all(text in pdf for text in ['전체 통합 통계','지점별 요약','부서별 요약','개인별 요약','목적별 요약','지점 → 부서 → 개인 → 목적 통합 비교','다른 사용자','12,000원'])
        # Actual latest Hi-pass rows use distinct waiting / issued backgrounds.
        hp={'group':'서울','hipassEnabled':True,'fuelEnabled':False,'classification':'직원','hipassUser':'색상 사용자','type':'선불형','company':'시험 도로공사','num':'HP-WAIT','issueDate':'2026-01-01','expiryDate':'2099-01-01','distributionStatus':'대기중'}
        operation('/api/hipass/register',hp);issued=operation('/api/hipass/register',{**hp,'num':'HP-ISSUE','distributionStatus':'불출중'})['hipass'];operation('/api/hipass/confirm',{'id':issued['id'],'recordGroup':issued['group'],'expectedVersion':issued['recordVersion']})
        page.evaluate('async()=>{await loadServerState();initApp();}');page.click('#nav_v_hipass_history');wait=page.locator('.ledger-progress.fleet-waiting');issued=page.locator('.ledger-progress.fleet-issued');expect(wait).to_have_text('대기중');expect(issued).to_have_text('불출중');assert wait.evaluate('(e)=>getComputedStyle(e).backgroundColor')!=issued.evaluate('(e)=>getComputedStyle(e).backgroundColor');page.locator('#v_hipass_history').screenshot(path=str(screens/'status_colors.png'))
        branch=login('branch','Branch-test-pass!');branch.click('#nav_v_external_match');assert '다른지점-자료' not in branch.inner_text('#v_external_match');branch.click('#nav_v_stats');branch.fill('#statsMonth','2026-10');branch.evaluate('renderStats()');assert branch.evaluate('currentStatsExport.model.current.amount')==5000;assert '다른지점통계' not in branch.inner_text('#statsUnifiedTables')
        for width in [1600,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});page.click('#nav_v_external_match');measure=page.locator('#externalMatchingWorkspace').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
            page.click('#nav_v_stats');measure=page.locator('#statsUnifiedTables').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
        assert not errors,errors
        print('PASS: manual expense form removed; same live external settlement inbox visible; explicit wrong match -> issue -> password-protected rematch/history before processing')
        print('PASS: settlement inbox opens exact matched active rental -> one return and expense with application/settlement snapshots -> processed mapping locked; approval remains separate')
        print('PASS: integrated statistics four dimension summaries + joint table, no cancellation/credit double count, 12000 admin versus 5000 own branch; actual full XLSX and PDF; latest waiting/issued colors differ')
        print('PASS: matching and integrated-statistics layout at1600/1024/768/390/320px; branch document/statistics restriction; no JS runtime errors')
        browser.close()
finally:f.SecurityTests.tearDownClass()

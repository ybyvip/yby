"""Weather transport, asynchronous cache and safe public login assets."""
from datetime import datetime,timezone
from pathlib import Path
import io,json,sys,threading,time,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import login_weather as weather
import test_security as fixture


def document(now,symbol='clearsky_day',temperature=18.5):
    return {'properties':{'timeseries':[{'time':datetime.fromtimestamp(now,timezone.utc).isoformat(),
        'data':{'instant':{'details':{'air_temperature':temperature}},'next_1_hours':{'summary':{'symbol_code':symbol}}}}]}}


def settled(cache):
    deadline=time.monotonic()+2
    while time.monotonic()<deadline:
        value=cache.snapshot()
        if not value['loading']:return value
        time.sleep(.005)
    raise AssertionError('Weather worker did not settle')


class WeatherTests(unittest.TestCase):
    def test_selects_recent_forecast_and_normalizes_conditions(self):
        now=time.time()
        for symbol,condition in [('clearsky_day','clear'),('fair_night','clear'),('cloudy','cloudy'),('fog','cloudy'),('lightrainshowersandthunder_day','rain'),('heavysnow','snow'),('sleet','snow')]:
            with self.subTest(symbol=symbol):
                source=document(now,symbol);source['properties']['timeseries'].insert(0,document(now-20000)['properties']['timeseries'][0])
                value=weather.parse_forecast(source,now)
                self.assertEqual(value['condition'],condition);self.assertEqual(value['temperatureC'],18.5)
                self.assertNotIn('symbol_code',value)

    def test_rejects_stale_invalid_and_nonfinite_weather(self):
        now=time.time()
        for payload in [document(now-10801),document(now+3601),document(now,'<script>'),document(now,'unknown'),document(now,temperature=True),document(now,temperature=float('nan')),document(now,temperature=100)]:
            with self.subTest(payload=repr(payload)):
                with self.assertRaises(ValueError):weather.parse_forecast(payload,now)

    def test_next_six_hour_summary_is_supported(self):
        now=time.time();source=document(now,'snow');data=source['properties']['timeseries'][0]['data']
        data['next_6_hours']=data.pop('next_1_hours')
        self.assertEqual(weather.parse_forecast(source,now)['condition'],'snow')

    def test_concurrent_requests_share_one_nonblocking_fetch(self):
        now=time.time();release=threading.Event();started=threading.Event();calls=[]
        def load():
            calls.append(1);started.set();release.wait(2);return document(now),3600
        cache=weather.WeatherCache(load,lambda:now)
        try:
            begin=time.monotonic();first=cache.snapshot();self.assertLess(time.monotonic()-begin,.3)
            self.assertFalse(first['ready']);self.assertTrue(started.wait(1))
            workers=[threading.Thread(target=cache.snapshot) for _ in range(12)]
            for worker in workers:worker.start()
            for worker in workers:worker.join()
            self.assertEqual(len(calls),1)
        finally:release.set()
        value=settled(cache);self.assertTrue(value['ready']);self.assertEqual(value['city'],'청주시')
        for _ in range(10):self.assertTrue(cache.snapshot()['ready'])
        self.assertEqual(len(calls),1)

    def test_failure_is_cached_and_returns_time_only_fallback(self):
        clock=[time.time()];calls=[]
        def load():calls.append(1);raise OSError('private proxy details must not be returned')
        cache=weather.WeatherCache(load,lambda:clock[0]);value=settled(cache)
        self.assertFalse(value['ready']);self.assertNotIn('proxy',json.dumps(value))
        for _ in range(8):cache.snapshot()
        self.assertEqual(len(calls),1)
        clock[0]+=901;settled(cache);self.assertEqual(len(calls),2)

    def test_expired_cache_keeps_recent_forecast_then_drops_old_weather(self):
        clock=[time.time()];calls=[]
        def load():
            calls.append(1)
            if len(calls)>1:raise OSError('offline')
            return document(clock[0],'rain'),600
        cache=weather.WeatherCache(load,lambda:clock[0]);self.assertTrue(settled(cache)['ready'])
        clock[0]+=601;value=settled(cache);self.assertTrue(value['ready']);self.assertTrue(value['stale'])
        clock[0]+=10800;value=settled(cache);self.assertFalse(value['ready']);self.assertNotIn('temperatureC',value)

    def test_https_transport_has_timeout_identification_and_no_business_headers(self):
        class Response(io.BytesIO):headers={'Expires':'Sat, 17 Oct 2026 07:00:00 GMT'}
        source=document(time.time())
        with patch.object(weather.urllib.request,'urlopen',return_value=Response(json.dumps(source).encode())) as fetch:
            result,ttl=weather.fetch_forecast()
        request=fetch.call_args.args[0]
        self.assertEqual(request.full_url,weather.URL);self.assertIn('https://api.met.no/',request.full_url)
        self.assertIn('YBY/',request.get_header('User-agent'));self.assertEqual(fetch.call_args.kwargs,{'timeout':5})
        self.assertIsNone(request.get_header('Cookie'));self.assertIsNone(request.get_header('Authorization'))
        self.assertEqual(result,source);self.assertGreaterEqual(ttl,600)

    def test_oversized_response_is_rejected(self):
        class Response(io.BytesIO):headers={}
        with patch.object(weather.urllib.request,'urlopen',return_value=Response(b' '*(2*1024*1024+1))):
            with self.assertRaises(ValueError):weather.fetch_forecast()


class LoginPublicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixture.SecurityTests.setUpClass();cls.client=fixture.SecurityTests()
    @classmethod
    def tearDownClass(cls):fixture.SecurityTests.tearDownClass()
    def setUp(self):self.client.setUp()

    def test_weather_is_public_nonblocking_and_does_not_stop_login(self):
        release=threading.Event()
        def blocked():release.wait(2);raise OSError('offline')
        cache=weather.WeatherCache(blocked)
        try:
            with patch.object(fixture.app,'LOGIN_WEATHER',cache):
                begin=time.monotonic();status,value,headers=self.client.request('/api/login-weather?url=http://example.invalid&lat=0')
                self.assertEqual(status,200);self.assertLess(time.monotonic()-begin,.5)
                self.assertFalse(value['ready']);self.assertEqual(value['city'],'청주시');self.assertEqual(headers['Cache-Control'],'no-store')
                self.assertIsNone(headers.get('Set-Cookie'))
                self.assertEqual(self.client.request('/api/login',{'username':'admin','password':'Admin-test-pass!'})[0],200)
                self.assertTrue(self.client.request('/health')[1]['database'])
        finally:release.set();settled(cache)

    def test_all_scenic_assets_have_exact_public_bytes_and_traversal_is_denied(self):
        for key in ('day','sunrise','sunset','night','rain','snow','classic'):
            path=f'/static/login-{key}-v416.jpg'
            status,raw,headers=self.client.request(path)
            self.assertEqual(status,200);self.assertEqual(raw,(ROOT/path.lstrip('/')).read_bytes())
            self.assertEqual(headers['Content-Type'],'image/jpeg');self.assertEqual(int(headers['Content-Length']),len(raw));self.assertEqual(headers['X-Content-Type-Options'],'nosniff')
        for path in ('/static/login-day-v416.jpg.bak','/static/unknown.jpg','/static/login-day-v416.jpg/../../data/corporate_card_system.db'):
            self.assertEqual(self.client.request(path)[0],404)


if __name__=='__main__':unittest.main()

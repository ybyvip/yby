"""Representative local load; not a capacity certification or long soak test."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import threading
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();case=f.SecurityTests()
try:
    case.setUp();a=f.app
    history=[{'id':i+1,'group':'서울','handler':'branch','type':'불출','cardNum':'LOAD-TEST','user':'fixture','time':'2026-10-15T00:00:00+00:00'} for i in range(5000)]
    with a.db() as c:a.persist_state(c,{'cards':[{'id':1,'num':'LOAD-TEST','group':'서울','status':'available'}],'history':history},'fixture')
    server=a.operations.BoundedHTTPServer(('127.0.0.1',0),a.Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        revision=case.state(case.branch)['revision']
        def request(index):
            start=time.perf_counter()
            headers={'Cookie':case.branch}
            if index%2:headers['If-None-Match']=revision
            req=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/state',headers=headers)
            with urllib.request.urlopen(req,timeout=20) as r:
                raw=r.read();data=json.loads(raw)
                assert r.status==200
                if index%2:assert data['unchanged'] and len(raw)<500
                else:assert len(data['state']['history'])==5000
            return time.perf_counter()-start,len(raw)
        with ThreadPoolExecutor(max_workers=10) as pool:results=list(pool.map(request,range(60)))
        durations=sorted(t for t,_ in results)
        output={'records':5000,'requests':60,'concurrent_clients':10,'successful':len(results),'p50_ms':round(statistics.median(durations)*1000,2),'p95_ms':round(durations[int(len(durations)*.95)-1]*1000,2),'max_ms':round(max(durations)*1000,2),'max_body_bytes':max(n for _,n in results),'unchanged_max_body_bytes':max(n for _,n in results if n<500),'limitations':'Local temporary data and short run; no Windows/real-network/long-soak capacity claim'}
        print(json.dumps(output,ensure_ascii=False))
    finally:server.shutdown();server.server_close();thread.join()
finally:f.SecurityTests.tearDownClass()

"""Independent source matching, atomic episode routing, corrections and scoped history."""
import copy,json,sqlite3,tempfile,unittest
from pathlib import Path
from unittest import mock
from urllib.parse import urlencode
import test_v419 as fixtures
import external_matching as matching

class MatchingFixture(fixtures.IntakeTests):pass
for name in dir(fixtures.IntakeTests):
    if name.startswith('test_'):setattr(MatchingFixture,name,None)
class MatchingTests(MatchingFixture):
    def setUp(self):
        super().setUp()
        with self.a.db() as conn:conn.execute('DELETE FROM external_document_matches');conn.execute('DELETE FROM external_match_events');conn.commit()
        self.appkey=self.stage(self.source(documentId='APP-1',documentNo='신청-001'));self.setkey=self.stage(self.source('settlement',documentId='SET-1',documentNo='정산-001'))
    def match(self,**extra):return self.op('/api/external-matches/create',{'applicationKey':self.appkey,'settlementKey':self.setkey,'applicationRevision':1,'settlementRevision':1,'confirmed':True,**extra})
    def pair(self):
        status,value,_=self.match();self.assertEqual(status,200,value);return value['match']
    def list(self,cookie=None):return self.c.request('/api/external-matches',cookie=cookie or self.c.branch)
    def update(self,pair,**extra):return self.op('/api/external-matches/update',{'id':pair['id'],'expectedVersion':pair['version'],'applicationKey':pair['applicationKey'],'settlementKey':pair['settlementKey'],'applicationRevision':1,'settlementRevision':1,'confirmed':True,'reason':'매칭 확인 정정','password':'Branch-test-pass!',**extra})
    def returned(self,pair):
        return self.op('/api/cards/return',{'cardId':1,'used':True,'expense':{**self.w.draft(),'cardNum':'TEST-5545','amount':18000,'lineItems':self.source('settlement')['lineItems']},**self.selected(pair['settlementKey']),'externalMatchVersion':pair['version']})
    def test_create_is_one_to_one_explicit_and_keeps_original_documents_independent(self):
        pair=self.pair();status,data,_=self.list();self.assertEqual(status,200);self.assertEqual(data['items'][0]['target']['phase'],'awaiting_issue')
        self.assertNotEqual(pair['applicationKey'],pair['settlementKey']);self.assertEqual(pair['applicationSnapshot']['documentNo'],'신청-001')
        self.assertEqual(self.match()[0],400)
        with self.a.db() as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],0)
    def test_match_requires_confirmation_correct_kind_revision_branch_and_last_four(self):
        self.assertEqual(self.match(confirmed=False)[0],400);self.assertEqual(self.match(applicationRevision=2)[0],409)
        self.assertEqual(self.match(applicationKey=self.setkey)[0],400)
        foreign=self.stage(self.source('settlement',documentId='FOREIGN',group='인천'))
        self.assertEqual(self.match(settlementKey=foreign)[0],403)
        other=self.stage(self.source('settlement',documentId='OTHER',cardLast4='9999'))
        self.assertEqual(self.match(settlementKey=other)[0],400)
    def test_before_financial_processing_edit_requires_password_reason_and_version(self):
        pair=self.pair();other=self.stage(self.source('settlement',documentId='SET-2',documentNo='정산-002'))
        self.assertEqual(self.update(pair,password='bad',settlementKey=other)[0],403);self.assertEqual(self.update(pair,reason='')[0],400);self.assertEqual(self.update(pair,expectedVersion='stale')[0],409)
        status,data,_=self.update(pair,settlementKey=other);self.assertEqual(status,200,data);self.assertNotEqual(data['match']['version'],pair['version'])
        status,data,_=self.c.request('/api/external-match-history?id='+pair['id'],cookie=self.c.branch);self.assertEqual(data['total'],2);self.assertEqual(data['items'][0]['before']['settlementKey'],self.setkey);self.assertEqual(data['items'][0]['after']['settlementKey'],other)
    def test_exact_rental_episode_drives_one_return_and_expense_with_snapshot_link(self):
        pair=self.pair();self.assertEqual(self.rent(**self.selected(self.appkey))[0],200)
        item=self.list()[1]['items'][0];self.assertEqual(item['target']['phase'],'rented');self.assertEqual(item['target']['cardId'],1)
        status,value,_=self.returned(pair);self.assertEqual(status,200,value);state=self.a.get_state();self.assertEqual(len(state['expense']),1);expense=state['expense'][0]
        self.assertEqual(expense['externalMatchRef']['id'],pair['id']);self.assertEqual(expense['rentalSourceRef']['key'],self.appkey);self.assertEqual(expense['sourceRef']['key'],self.setkey)
        self.assertEqual(state['history'][-1]['externalMatchRef'],expense['externalMatchRef']);self.assertTrue(self.list()[1]['items'][0]['locked']);self.assertNotEqual(self.returned(pair)[0],200)
    def test_after_return_and_settlement_mapping_is_locked_and_uses_existing_correction(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));self.assertEqual(self.returned(pair)[0],200)
        self.assertEqual(self.update(pair)[0],400);self.assertEqual(self.op('/api/external-matches/delete',{'id':pair['id'],'expectedVersion':pair['version'],'reason':'변경','password':'Branch-test-pass!'})[0],400)
        row=self.a.get_state()['expense'][0];ref={k:row[k] for k in ('id','group','requester')};self.assertEqual(self.op('/api/expenses/decision',{**ref,'decision':'approve'},self.c.admin)[0],200)
        status,value,_=self.op('/api/expenses/correct',{**ref,'reason':'잘못된 자료 보완','password':'Admin-test-pass!'},self.c.admin);self.assertEqual(status,200,value);self.assertEqual(value['expense']['externalMatchRef']['id'],pair['id'])
    def test_mapping_can_change_after_issue_before_return_without_rewriting_issue_snapshot(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));before=copy.deepcopy(self.a.get_state()['history'][0]);other=self.stage(self.source('settlement',documentId='SET-NEW',documentNo='정산-새문서'))
        status,value,_=self.update(pair,settlementKey=other);self.assertEqual(status,200,value);new=value['match'];self.assertEqual(self.a.get_state()['history'][0],before)
        self.assertEqual(self.returned(pair)[0],400);self.assertEqual(self.returned(new)[0],200)
    def test_stale_or_withdrawn_source_prevents_processing_and_same_pair_can_be_reconfirmed(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));self.stage(self.source('settlement',documentId='SET-1',documentNo='정산-001',revision=2,approvalStatus='승인완료'))
        self.assertTrue(self.list()[1]['items'][0]['stale']);self.assertEqual(self.returned(pair)[0],400)
        status,value,_=self.update(pair,settlementRevision=2);self.assertEqual(status,200,value)
        self.stage(self.source('settlement',documentId='SET-1',documentNo='정산-001',revision=3,withdrawn=True));self.assertEqual(self.returned(value['match'])[0],400)
    def test_matched_application_cannot_return_with_other_document_or_manual_used_bypass(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));other=self.stage(self.source('settlement',documentId='UNMATCHED'))
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft(),**self.selected(other)})[0],400)
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':True,'expense':self.w.draft()})[0],400)
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':False})[0],200)
    def test_matching_never_selects_by_ambiguous_suffix_or_wrong_episode(self):
        pair=self.pair();self.rent()  # same physical card, but manual rental is not this application.
        self.assertEqual(self.returned(pair)[0],400)
        self.assertEqual(self.a.get_state()['cards'][0]['status'],'rented')
    def test_missing_or_stale_match_version_cannot_apply_after_match_review_changed(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));status,value,_=self.update(pair);self.assertEqual(status,200,value)
        self.assertEqual(self.returned(pair)[0],400);self.assertEqual(self.returned(value['match'])[0],200)
    def test_delete_releases_document_pair_keeps_scoped_audit_and_no_business_data_changes(self):
        pair=self.pair();before=copy.deepcopy(self.a.get_state());status,value,_=self.op('/api/external-matches/delete',{'id':pair['id'],'expectedVersion':pair['version'],'reason':'잘못 연결','password':'Branch-test-pass!'});self.assertEqual(status,200,value)
        self.assertEqual(self.list()[1]['total'],0);self.assertEqual(self.c.request('/api/external-match-history',cookie=self.c.branch)[1]['total'],2);self.assertEqual(self.a.get_state(),before);self.assertEqual(self.match()[0],200)
    def test_scope_is_applied_before_candidates_matches_history_and_counts(self):
        pair=self.pair()
        with self.a.db() as conn:conn.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_external_match']),));conn.commit()
        foreign=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.list(foreign)[1]['total'],0)
        self.assertEqual(self.c.request('/api/external-match-history?id='+pair['id'],cookie=foreign)[1]['total'],0)
        status,value,_=self.op('/api/external-matches/delete',{'id':pair['id'],'expectedVersion':pair['version'],'reason':'시도','password':'Branch-test-pass!'},foreign);self.assertEqual(status,403,value)
    def test_expense_only_can_receive_sources_and_match_but_cannot_return_cards(self):
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_expense']),));conn.commit()
        cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.c.request('/api/external-documents?kind=settlement',cookie=cookie)[0],200)
        self.assertEqual(self.c.request('/api/external-document?'+urlencode({'kind':'settlement','key':self.setkey}),cookie=cookie)[0],200)
        self.assertEqual(self.op('/api/cards/return',{'cardId':1,'used':False},cookie)[0],403)
    def test_readonly_and_anonymous_cannot_match_or_list(self):
        cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.list(cookie)[0],403);self.assertEqual(self.c.request('/api/external-matches')[0],401)
    def test_database_failure_rolls_back_matching_and_event_and_binding(self):
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated failure')):self.assertEqual(self.match()[0],500)
        with self.a.db() as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_matches').fetchone()[0],0);self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_match_events').fetchone()[0],0)
    def test_source_versions_and_financial_link_cannot_be_forged_through_generic_save(self):
        pair=self.pair();self.rent(**self.selected(self.appkey));self.returned(pair);rows=copy.deepcopy(self.a.get_state()['expense']);rows[0]['externalMatchRef']['id']='forged';self.assertEqual(self.c.save({'expense':rows},self.c.admin)[0],403)
    def test_upgrade_backup_failure_stops_schema_change(self):
        with self.a.db() as conn:conn.execute("INSERT OR IGNORE INTO schema_versions VALUES(6,'fixture')");conn.execute('DELETE FROM schema_versions WHERE version=7');conn.commit()
        try:
            with mock.patch.object(self.a,'backup',side_effect=OSError('fixture backup unavailable')) as backup:
                with self.assertRaises(OSError):self.a.prepare_db()
                backup.assert_called_once_with('before_upgrade')
            with self.a.db() as conn:self.assertEqual(conn.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],6)
        finally:
            with self.a.db() as conn:self.a.storage.initialize(conn);conn.commit()
    def test_full_backup_restores_matches_and_change_history(self):
        import backup_manager
        self.pair()
        with tempfile.TemporaryDirectory() as folder:
            archive=Path(folder)/'full.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive);restored=Path(folder)/'restored';backup_manager.restore(archive,restored)
            with sqlite3.connect(restored/self.a.DB_PATH.name) as conn:self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_matches').fetchone()[0],1);self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_match_events').fetchone()[0],1);self.assertEqual(conn.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],7)

if __name__=='__main__':unittest.main()

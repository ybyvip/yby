"""Private certificate ACLs: inheritable rules for folders, direct rules for files."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import ssl
import subprocess
import sys

REQUIRED=('server.pem','server-key.pem','root-ca.pem','root-ca.cer')

def is_windows():return os.name=='nt'

def run(arguments):
    result=subprocess.run(arguments,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
    if result.returncode:
        raise RuntimeError('인증서 권한 설정 실패: '+result.stderr[-1200:]+'\n'+result.stdout[-1200:])
    return result

def windows_sid():
    sid=run(['powershell.exe','-NoProfile','-NonInteractive','-Command','[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value']).stdout.strip()
    if not re.fullmatch(r'S-\d-\d+(?:-\d+)+',sid):raise RuntimeError('현재 Windows 사용자 SID를 확인할 수 없습니다.')
    return sid

def acl_arguments(path,sid,is_directory):
    # Do not propagate a folder-only ACE onto a file or combine it with /T.
    access='(OI)(CI)F' if is_directory else 'F'
    return ['icacls.exe',str(path),'/inheritance:r','/grant:r','*'+sid+':'+access,
            '*S-1-5-18:'+access,'*S-1-5-32-544:'+access]

def protect(directory):
    directory=Path(directory)
    if directory.is_symlink():raise RuntimeError('인증서 폴더의 심볼릭 링크는 지원하지 않습니다.')
    if not is_windows():
        directory.chmod(0o700)
        for entry in os.scandir(directory):
            if entry.is_symlink():raise RuntimeError('인증서 경로의 심볼릭 링크는 지원하지 않습니다.')
            if entry.is_dir(follow_symlinks=False):protect(entry.path)
            else:Path(entry.path).chmod(0o600)
        return
    sid=windows_sid()
    def apply(path):
        run(acl_arguments(path,sid,True))
        # scandir uses directory metadata; it does not open the currently unreadable file.
        for entry in os.scandir(path):
            if entry.is_symlink():raise RuntimeError('인증서 경로의 심볼릭 링크는 지원하지 않습니다.')
            if entry.is_dir(follow_symlinks=False):apply(Path(entry.path))
            else:run(acl_arguments(entry.path,sid,False))
    apply(directory)

def check_readable(directory):
    for name in REQUIRED:
        path=Path(directory)/name
        # Probe actual Python access, not only icacls' exit code. Never print key bytes.
        with path.open('rb') as stream:
            if not stream.read(1):raise RuntimeError('빈 인증서 또는 키 파일입니다: '+str(path))

def repair(directory):
    directory=Path(directory)
    if not directory.is_dir():raise RuntimeError('인증서 폴더가 없습니다: '+str(directory))
    protect(directory)
    check_readable(directory)
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(directory/'server.pem'),str(directory/'server-key.pem'))
    ssl.create_default_context(cafile=str(directory/'root-ca.pem'))
    fingerprint=hashlib.sha256((directory/'root-ca.cer').read_bytes()).hexdigest().upper()
    print('PASS: Python에서 인증서 4개 읽기 및 서버 인증서/개인키 로드 확인')
    print('CA SHA-256: '+fingerprint)
    print('DB와 인증서를 삭제하거나 새로 생성하지 않았습니다.')
    return fingerprint

def main():
    parser=argparse.ArgumentParser(description='YBY 인증서 접근권한 복구(기존 인증서 보존)')
    parser.add_argument('--directory',type=Path)
    args=parser.parse_args()
    if args.directory is None:
        local=os.environ.get('LOCALAPPDATA')
        if not local:raise RuntimeError('LOCALAPPDATA 경로가 없습니다.')
        directory=Path(local)/'YBY/app/certificates'
    else:directory=args.directory
    print('복구 대상: '+str(directory))
    repair(directory)

if __name__=='__main__':
    try:main()
    except Exception as error:print('복구 실패: '+str(error),file=sys.stderr);raise SystemExit(1)

"""Compatibility entry point: all launchers use the same V4 startup policy."""
import os
if os.name=='nt':
    from windows_bootstrap import main
else:
    from run_ready import main
if __name__=='__main__':
    raise SystemExit(main())

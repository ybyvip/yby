@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3 "%~dp0verify_windows.py"
goto finished
:use_python
python "%~dp0verify_windows.py"
:finished
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%

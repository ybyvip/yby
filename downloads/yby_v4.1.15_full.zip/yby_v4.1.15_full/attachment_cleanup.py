"""Conservative offline orphan cleanup; dry-run unless --apply is explicit."""
import argparse
import json
import time
from pathlib import Path
import app
from backup_tool import ensure_stopped
from db_lock import DatabaseLock


def candidates(state,directory,age_days=7):
    serialized=json.dumps(state,ensure_ascii=False)
    cutoff=time.time()-age_days*86400
    result=[]
    for metadata in Path(directory).glob('*.json'):
        identity=metadata.stem
        if len(identity)!=32 or any(c not in '0123456789abcdef' for c in identity):continue
        if identity in serialized or metadata.stat().st_mtime>cutoff:continue
        result.append(metadata)
    return result


def main():
    parser=argparse.ArgumentParser(description='미사용 첨부파일 정리 (기본: 삭제하지 않고 목록만 표시)')
    parser.add_argument('--apply',action='store_true');parser.add_argument('--older-than-days',type=int,default=7)
    args=parser.parse_args()
    if args.older_than_days<7:raise ValueError('안전한 정리를 위해 최소 7일을 지정하세요.')
    ensure_stopped()
    if not app.DB_PATH.is_file():raise ValueError('업무 DB가 없습니다.')
    with DatabaseLock(app.DB_DIR):
        cleanup(args)

def cleanup(args):
    rows=candidates(app.get_state() or {},app.ATTACHMENT_DIR,args.older_than_days)
    print('정리 대상:',len(rows),'개')
    for p in rows:print(p.stem)
    if args.apply and rows:
        app.backup('manual')
        for p in rows:
            p.with_suffix('.bin').unlink(missing_ok=True);p.unlink()
        print('전체 백업 후 미사용 첨부파일 정리 완료')


if __name__=='__main__':
    try:main()
    except Exception as e:print('오류:',e);raise SystemExit(1)

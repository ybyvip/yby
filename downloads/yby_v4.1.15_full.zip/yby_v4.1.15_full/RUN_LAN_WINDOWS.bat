@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상을 설치하고 PATH에 추가하세요.
pause
exit /b 1
:use_py
py -3 "%~dp0windows_bootstrap.py" --lan %*
goto finished
:use_python
python "%~dp0windows_bootstrap.py" --lan %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo 실행 안내가 끝났습니다. 이미 실행 중인 서버는 기존 창에서 계속 동작합니다. 오류가 있으면 위의 안내를 확인하세요.
pause
exit /b %RESULT%

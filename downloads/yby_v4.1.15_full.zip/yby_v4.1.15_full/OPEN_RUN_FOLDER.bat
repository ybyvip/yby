@echo off
start "" "%LOCALAPPDATA%\YBY\app"

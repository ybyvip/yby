"""Authenticated credential storage: Windows DPAPI; Fernet on non-Windows hosts."""
import base64
import ctypes
import json
import os
from pathlib import Path


def _dpapi(raw, decrypt=False):
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buffer=ctypes.create_string_buffer(raw)
    source=Blob(len(raw),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    api=ctypes.WinDLL('crypt32',use_last_error=True)
    function=api.CryptUnprotectData if decrypt else api.CryptProtectData
    function.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    function.restype=wintypes.BOOL
    if not function(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target)):
        raise RuntimeError('Windows 사용자 암호화 저장소에 접근하지 못했습니다.')
    try:return ctypes.string_at(target.data,target.size)
    finally:
        kernel=ctypes.WinDLL('kernel32');kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
        kernel.LocalFree(target.data)


def _fernet(directory, create=False):
    from cryptography.fernet import Fernet
    key=Path(directory)/'admin_password_vault.key'
    if key.is_symlink():raise ValueError('비밀번호 키의 심볼릭 링크는 지원하지 않습니다.')
    if create and not key.exists():
        try:
            fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        except FileExistsError:pass
        else:
            with os.fdopen(fd,'wb') as output:output.write(Fernet.generate_key())
    key.chmod(0o600)
    return Fernet(key.read_bytes())


def seal(directory, username, password, credential_hash):
    raw=json.dumps({'user':username,'password':password,'hash':credential_hash},ensure_ascii=False).encode('utf-8')
    if os.name=='nt':return 'dpapi1:'+base64.b64encode(_dpapi(raw)).decode('ascii')
    return 'fernet1:'+_fernet(directory,True).encrypt(raw).decode('ascii')


def reveal(directory, username, ciphertext, credential_hash):
    kind,encoded=ciphertext.split(':',1)
    if kind=='dpapi1' and os.name=='nt':raw=_dpapi(base64.b64decode(encoded,validate=True),True)
    elif kind=='fernet1' and os.name!='nt':raw=_fernet(directory).decrypt(encoded.encode('ascii'))
    else:raise ValueError('이 서버 사용자의 암호화 저장소와 다릅니다. 해당 계정으로 다시 로그인하거나 비밀번호를 재설정하세요.')
    value=json.loads(raw)
    if value.get('user')!=username or value.get('hash')!=credential_hash:raise ValueError('현재 비밀번호와 표시 기록이 다릅니다.')
    return value['password']

@echo off
setlocal
chcp 65001 >nul
set "YBY_RUN_DIR=%~dp0"
if exist "%LOCALAPPDATA%\YBY\app\lan_settings.json" set "YBY_RUN_DIR=%LOCALAPPDATA%\YBY\app\"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\client_templates\client_connect.ps1" -ServerRoot "%YBY_RUN_DIR%."
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%

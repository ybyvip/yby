"""Password storage and authorization helpers; Python standard library only."""
import hashlib
import json
import re
import secrets

ITERATIONS = 600000


def legacy_hash(password):
    return hashlib.sha256(str(password).encode('utf-8')).hexdigest()


def encode_hash(digest):
    if not re.fullmatch(r'[0-9a-f]{64}', digest):
        raise ValueError('잘못된 비밀번호 해시입니다.')
    salt = secrets.token_hex(16)
    value = hashlib.pbkdf2_hmac('sha256', digest.encode(), bytes.fromhex(salt), ITERATIONS).hex()
    return f'pbkdf2_sha256${ITERATIONS}${salt}${value}'


def password_hash(password):
    return encode_hash(legacy_hash(password))


def verify_password(stored, password):
    if not isinstance(stored, str):
        return False
    if re.fullmatch(r'[0-9a-f]{64}', stored):
        return secrets.compare_digest(stored, legacy_hash(password))
    try:
        algorithm, rounds, salt, expected = stored.split('$')
        if algorithm != 'pbkdf2_sha256' or not 100000 <= int(rounds) <= 2000000:
            return False
        actual = hashlib.pbkdf2_hmac('sha256', legacy_hash(password).encode(), bytes.fromhex(salt), int(rounds)).hex()
        return secrets.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def validate_password(password):
    if not isinstance(password, str) or not 10 <= len(password) <= 128 or password.isspace():
        raise ValueError('비밀번호는 공백만으로 구성하지 말고 10~128자로 입력하세요.')


def clean_accounts(state):
    if not isinstance(state, dict):
        return {}
    accounts = state.get('accounts')
    if isinstance(accounts, dict):
        state['accounts'] = {name: {k: v for k, v in info.items() if k not in ('pw', 'passwordHash', 'password', 'latestPassword', 'ciphertext', 'passwordUpdatedAt', 'passwordUpdatedBy', 'passwordDisplayStatus')}
                             for name, info in accounts.items() if isinstance(info, dict)}
    return state


def normalize_expenses(state):
    """Keep old completed expenses in the same ledger used by the browser."""
    if not isinstance(state, dict) or not isinstance(state.get('expense'), list):
        return state
    history = state.get('expenseHistory')
    history = list(history) if isinstance(history, list) else []
    def key(item):
        return (str(item.get('group', '')), str(item.get('id', '')),
                str(item.get('requester', '')), str(item.get('requestedAt') or item.get('date') or ''))
    known = {key(item) for item in history if isinstance(item, dict)}
    active = []
    for item in state['expense']:
        if isinstance(item, dict) and item.get('status') in ('승인완료', '반려됨'):
            if key(item) not in known:
                history.append(item); known.add(key(item))
        else:
            active.append(item)
    state['expense'] = active
    state['expenseHistory'] = history
    return state


READ_VIEWS = {
    'cards': {'v_card_status', 'v_card_rent', 'v_card_reg', 'v_expense', 'v_stats'},
    'history': {'v_card_history', 'v_card_rent', 'v_stats'},
    'hipass': {'v_hipass_reg', 'v_hipass_box', 'v_hipass_status', 'v_hipass_history', 'v_stats'},
    'hipassBox': {'v_hipass_box', 'v_hipass_reg', 'v_hipass_history', 'v_stats'},
    'expense': {'v_expense', 'v_stats'},
    'expenseHistory': {'v_expense_history', 'v_expense', 'v_stats'},
    'complaint': {'v_complaint'},
    'reports': {'v_report_box', 'v_report_write'},
}
WRITE_VIEWS = {
    'cards': {'v_card_reg', 'v_card_rent'}, 'history': {'v_card_rent'},
    'hipass': {'v_hipass_reg'}, 'hipassBox': {'v_hipass_reg'},
    'expense': {'v_expense'}, 'expenseHistory': set(), 'complaint': {'v_complaint'},
    'reports': {'v_report_write'},
}
RENT_FIELDS = {'status', 'dept', 'user', 'purpose', 'rentDate', 'dueDate'}


def record_key(item):
    actor = item.get('requester') or item.get('author') or item.get('handler') or item.get('created_by') or ''
    return str(item.get('group')), str(actor), str(item.get('id'))


def validate_branch_changes(incoming, current, scope, permissions, username):
    """Only permit authorized changes; visible unchanged data is safe to echo."""
    permissions = set(permissions)
    for field, allowed in WRITE_VIEWS.items():
        records = incoming.get(field, [])
        if not isinstance(records, list):
            raise ValueError(f'{field}: 목록 형식이 필요합니다.')
        old = {record_key(x): x for x in current.get(field, []) if isinstance(x, dict)}
        for item in records:
            if not isinstance(item, dict) or item.get('group') != scope:
                raise PermissionError(f'{field}: 담당 지점만 변경할 수 있습니다.')
            previous = old.get(record_key(item))
            # cardKey is deliberately omitted from non-administrator responses.
            compare = dict(previous) if previous else None
            if field == 'cards' and compare:
                compare.pop('cardKey', None)
            if item == compare or item == previous:
                continue
            if not permissions.intersection(allowed):
                raise PermissionError(f'{field}: 변경 권한이 없습니다.')
            if field == 'cards' and 'v_card_reg' not in permissions:
                if not previous or any(item.get(k) != compare.get(k) for k in set(item) | set(compare) if k not in RENT_FIELDS):
                    raise PermissionError('카드 등록 정보 변경 권한이 없습니다.')
            if field == 'history':
                if previous or item.get('handler') != username or item.get('type') not in ('불출', '반납'):
                    raise PermissionError('카드 이력은 본인의 불출·반납 기록만 추가할 수 있습니다.')
            if field == 'expense':
                if previous and previous.get('requester') != username:
                    raise PermissionError('다른 사용자의 정산 내역은 변경할 수 없습니다.')
                if item.get('status') != '승인대기' or any(item.get(k) for k in ('approvedBy', 'approvedAt', 'rejectedBy', 'rejectedAt')):
                    raise PermissionError('정산 승인·반려는 최고관리자만 할 수 있습니다.')
                if item.get('requester') != username:
                    raise PermissionError('정산 신청자는 현재 사용자여야 합니다.')
            if field == 'reports':
                if (previous and previous.get('author') != username) or item.get('author') != username or item.get('status') != 'pending':
                    raise PermissionError('본인의 결재 대기 문서만 작성·수정할 수 있습니다.')


class StateConflict(Exception):
    pass

"""Public Cheongju forecast for the login backdrop; never reads business data.
MET Norway Locationforecast, CC BY 4.0. HTTPS stays verified. Network work is
shared, cached and asynchronous so a blocked weather service cannot block login.
"""
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import json
import math
import re
import threading
import time
import urllib.request

URL='https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=36.64&lon=127.49'
PROVIDER_URL='https://www.met.no/en/free-meteorological-data'
MAX_STALE=3*60*60
BASE={'city':'청주시','timezone':'Asia/Seoul','provider':'MET Norway','attributionUrl':PROVIDER_URL}


def parse_forecast(document, now):
    candidates=[]
    for item in document.get('properties',{}).get('timeseries',[])[:1000]:
        try:
            timestamp=datetime.fromisoformat(item['time'].replace('Z','+00:00'))
            if timestamp.tzinfo is None:continue
            age=now-timestamp.timestamp()
            if -3600<=age<=MAX_STALE:candidates.append((abs(age),timestamp,item['data']))
        except (ValueError,TypeError,KeyError,AttributeError):continue
    if not candidates:raise ValueError('No recent forecast')
    _,timestamp,data=min(candidates,key=lambda item:item[0])
    temperature=data['instant']['details']['air_temperature']
    if isinstance(temperature,bool) or not isinstance(temperature,(int,float)) or not math.isfinite(temperature) or not -80<=temperature<=60:
        raise ValueError('Invalid temperature')
    symbol=''
    for interval in ('next_1_hours','next_6_hours','next_12_hours'):
        symbol=data.get(interval,{}).get('summary',{}).get('symbol_code','')
        if symbol:break
    if not isinstance(symbol,str) or not re.fullmatch('[a-z_]{1,80}',symbol):raise ValueError('Invalid weather symbol')
    if 'sleet' in symbol:condition,label='snow','진눈깨비'
    elif 'snow' in symbol:condition,label='snow','눈'
    elif 'thunder' in symbol:condition,label='rain','천둥·비'
    elif 'rain' in symbol:condition,label='rain','비'
    elif 'fog' in symbol:condition,label='cloudy','안개'
    elif 'cloud' in symbol:condition,label='cloudy','구름 많음'
    elif symbol.split('_')[0] in ('clearsky','fair'):condition,label='clear','맑음'
    else:raise ValueError('Unknown weather symbol')
    return {'condition':condition,'description':label,'temperatureC':round(temperature,1),
            'forecastAt':timestamp.astimezone(timezone.utc).isoformat()}


def fetch_forecast():
    request=urllib.request.Request(URL,headers={
        'User-Agent':'YBY/4.1.14 https://github.com/ybyvip/yby',
        'Accept':'application/json'})
    with urllib.request.urlopen(request,timeout=5) as response:
        raw=response.read(2*1024*1024+1)
        if len(raw)>2*1024*1024:raise ValueError('Weather response too large')
        ttl=3600
        if response.headers.get('Expires'):
            try:ttl=max(600,min(86400,parsedate_to_datetime(response.headers['Expires']).timestamp()-time.time()))
            except (ValueError,TypeError,OverflowError):pass
        return json.loads(raw),ttl


class WeatherCache:
    def __init__(self,loader=None,clock=None):
        self.loader=loader or fetch_forecast
        self.clock=clock or time.time
        self._lock=threading.Lock()
        self._value=None
        self._updated=0
        self._expires=0
        self._next_attempt=0
        self._fetching=False

    def snapshot(self):
        now=self.clock()
        with self._lock:
            if now>=self._next_attempt and not self._fetching:
                self._fetching=True
                try:threading.Thread(target=self._refresh,name='YBY-login-weather',daemon=True).start()
                except Exception:
                    self._fetching=False;self._next_attempt=now+900
            result={**BASE,'ready':False,'loading':self._fetching,'stale':False}
            if self._value and now-self._updated<=MAX_STALE:
                # Expired forecast timestamps are never presented as current weather.
                forecast_time=datetime.fromisoformat(self._value['forecastAt']).timestamp()
                if -3600<=now-forecast_time<=MAX_STALE:
                    result.update(self._value,ready=True,stale=now>=self._expires,
                                  updatedAt=datetime.fromtimestamp(self._updated,timezone.utc).isoformat())
            return result

    def _refresh(self):
        try:
            document,ttl=self.loader()
            now=self.clock();value=parse_forecast(document,now)
            ttl=float(ttl)
            if not math.isfinite(ttl):raise ValueError('Invalid cache lifetime')
            with self._lock:
                self._value=value;self._updated=now;self._expires=now+max(600,min(86400,ttl));self._next_attempt=self._expires
        except Exception:
            with self._lock:self._next_attempt=self.clock()+900
        finally:
            with self._lock:self._fetching=False

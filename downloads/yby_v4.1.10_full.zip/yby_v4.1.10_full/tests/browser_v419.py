"""Actual new request form and review/apply/return workflow using an isolated inbox.
The source inbox is populated by fixture code, NEVER a live Oracle connection.
"""
from pathlib import Path
import importlib.util,json,os,sys
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import external_documents as inbox
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v419-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    assert c.save({'cards':[{'id':1,'num':'TEST-5545','group':'서울','company':'시험 카드사','status':'available'},{'id':2,'num':'TEST-7777','group':'인천','company':'시험 카드사','status':'available'}]},c.admin)[0]==200
    def source(kind,**extra):
        doc={'documentId':'APPLICATION-ONLY' if kind=='application' else 'SETTLEMENT-ONLY','documentNo':'시험-신청-001' if kind=='application' else '시험-정산-099','kind':kind,'group':'서울','revision':1,'applicationDate':'2026-10-01','dueDate':'2099-01-01','applicantName':'외부 신청 담당자' if kind=='application' else '외부 정산 기안자','user':'실제 사용자','dept':'총무팀','purpose':'거래처 협의 및 출장','approvalStatus':'결재중','cardLast4':'5545'}
        if kind=='settlement':doc['lineItems']=[{'date':'2026-10-01','category':'식대','merchant':'식당','description':'회의 식사','quantity':2,'unitPrice':9000,'amount':18000},{'date':'2026-10-02','category':'교통','merchant':'택시','description':'거래처 이동','quantity':1,'unitPrice':5000,'amount':5000}]
        return {**doc,**extra}
    def stage(doc):
        with a.db() as conn:key=inbox.stage(conn,doc);conn.commit()
        return key
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        page=browser.new_page(viewport={'width':1440,'height':1000});errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
        page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
        page.goto(f'http://127.0.0.1:{c.server.server_port}/')
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>currentUser==='admin'&&!loginInFlight");page.evaluate('stopLiveSync()')
        page.click('#nav_v_card_rent')
        assert page.input_value('#rentApplicationDate')==page.evaluate('localDate()')
        page.fill('#rentUser','실제 사용자');assert page.input_value('#rentApplicant')=='실제 사용자'
        assert page.locator('#rentApplicant').get_attribute('readonly') is not None
        page.uncheck('#rentApplicantSame');page.fill('#rentApplicant','신청 담당자');page.fill('#rentApplicationDate','2026-10-01')
        page.fill('#rentDept','총무팀');page.fill('#rentDueDate','2099-01-01');page.check('input[name=purposeChk][value=출장]');page.fill('#rentDetailPurpose','거래처 협의 및 출장')
        page.select_option('#rentCardSelect','1');page.evaluate('renderRentDropdowns()')
        assert page.input_value('#rentApplicationDate')=='2026-10-01' and page.input_value('#rentApplicant')=='신청 담당자'
        page.screenshot(path=str(screens/'request_form.png'))
        page.locator('#v_card_rent button[type=submit]').click()
        page.wait_for_function('()=>cardsData.find(c=>c.id===1).status==="rented"')
        card=a.get_state()['cards'][0];assert card['applicantName']=='신청 담당자' and card['user']=='실제 사용자' and card['applicationDate']=='2026-10-01'
        assert card['rentDate']==a.business_date() and card['entrySource']=='YBY'
        assert '신청 담당자' in page.inner_text('#returnTable') and 'YBY 직접 입력' in page.inner_text('#returnTable')
        assert page.input_value('#rentApplicationDate')==page.evaluate('localDate()')
        page.evaluate('openReturnModal(1)');page.check('#returnUsedCheckbox');page.fill('#returnExpensePurpose','입력 중인 내용 보존')
        page.click('#pickExternalSettlement');page.wait_for_function('()=>document.getElementById("externalInboxList").textContent.includes("아직 선택할")')
        assert 'Oracle' in page.inner_text('#externalInboxStatus');page.keyboard.press('Escape')
        assert page.locator('#externalPicker').count()==0 and page.locator('#commonModal').is_visible()
        assert page.input_value('#returnExpensePurpose')=='입력 중인 내용 보존'
        settlement=stage(source('settlement'))
        stage(source('settlement',documentId='FOREIGN',documentNo='다른지점-문서',group='인천',cardLast4='7777'))
        page.click('#pickExternalSettlement');page.wait_for_selector('.intake-document-row')
        assert page.locator('.intake-document-row').count()==1
        assert '다른지점-문서' not in page.inner_text('#externalInboxList')
        page.get_by_role('button',name='내용 확인',exact=True).click();page.wait_for_selector('#applyExternalDocument')
        assert page.locator('#applyExternalDocument').is_disabled()
        assert '외부 정산 기안자' in page.inner_text('#externalDocumentReview')
        assert a.get_state()['cards'][0]['status']=='rented' and a.get_state().get('expense',[])==[]
        for width in [1440,768,390,320]:
            page.set_viewport_size({'width':width,'height':1000})
            metrics=page.locator('.intake-picker-body').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})')
            assert metrics['sw']<=metrics['w']+1,(width,metrics)
        page.set_viewport_size({'width':1440,'height':1000})
        page.locator('.intake-picker-card').screenshot(path=str(screens/'external_review.png'))
        page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached');assert page.locator('#externalPicker').count()==0
        assert page.input_value('#returnExpenseUser')=='실제 사용자' and page.inner_text('#returnExpenseTotal')=='23,000'
        assert page.locator('#returnExpenseLines tr').count()==2 and page.is_checked('#returnUsedCheckbox')
        assert '시험-정산-099' in page.inner_text('#returnSettlementSource')
        assert a.get_state()['cards'][0]['status']=='rented'
        page.locator('.modal-card').screenshot(path=str(screens/'return_from_external.png'))
        page.click('#returnCardSubmitButton');page.wait_for_selector('#commonModal',state='hidden')
        row=a.get_state()['expense'][0];assert row['amount']==23000 and row['entrySource']=='ORACLE' and row['rentalEntrySource']=='YBY'
        assert row['applicantName']=='신청 담당자' and row['externalApplicantName']=='외부 정산 기안자'
        with a.db() as conn:assert conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0]==1
        application=stage(source('application'))
        page.click('#pickExternalApplication');page.wait_for_selector('.intake-document-row')
        page.get_by_role('button',name='내용 확인',exact=True).click();page.check('#externalDocumentConfirmed');page.click('#applyExternalDocument');page.wait_for_selector('#externalPicker',state='detached')
        assert page.input_value('#rentApplicant')=='외부 신청 담당자' and page.input_value('#rentUser')=='실제 사용자'
        assert not page.is_checked('#rentApplicantSame') and page.input_value('#rentApplicationDate')=='2026-10-01'
        assert page.locator('#rentCardSelect option').count()==1
        assert a.get_state()['cards'][0]['status']=='available'
        page.locator('#v_card_rent button[type=submit]').click()
        page.wait_for_function('()=>cardsData.find(c=>c.id===1).entrySource==="ORACLE"')
        card=a.get_state()['cards'][0];assert card['sourceRef']['key']==application and card['sourceRef']['key']!=row['sourceRef']['key']
        page.click('#nav_v_card_history');assert '外部' not in page.inner_text('#cardHistoryTable')
        assert '외부 Oracle 자료' in page.inner_text('#cardHistoryTable') and '외부 신청 담당자' in page.inner_text('#cardHistoryTable')
        stage(source('settlement',documentId='ESCAPE-PROBE',documentNo='외부입력-검사',purpose='외부 입력값 <img src=x onerror="window.__externalProbe=1">'))
        page.evaluate('openReturnModal(1)');page.click('#pickExternalSettlement')
        page.fill('#externalInboxQuery','외부 입력값');page.click('#externalInboxSearch')
        page.wait_for_function('()=>document.querySelectorAll(".intake-document-row").length===1')
        page.get_by_role('button',name='내용 확인',exact=True).click();page.wait_for_selector('#applyExternalDocument')
        assert page.locator('#externalDocumentReview img,#externalDocumentReview script').count()==0
        assert not page.evaluate('window.__externalProbe')
        page.click('#externalPickerClose');page.evaluate('closeModal()')
        assert not errors,errors
        print('PASS: KST today default, independent applicant/user, refresh preserves draft, actual rental/return date and provenance persisted')
        print('PASS: empty inbox honest; source picker preserves return form; card/branch filter; disabled until review confirmed; 1440/768/390/320px fit')
        print('PASS: preview/apply does not issue/return; two lines fill existing form; external settlement on manual rental; independent external application then real issue; source/history/snapshot preserved; external text escaped; no JS errors')
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

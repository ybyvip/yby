@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if errorlevel 1 (python "%~dp0network_diagnose.py") else (py -3 "%~dp0network_diagnose.py")
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%

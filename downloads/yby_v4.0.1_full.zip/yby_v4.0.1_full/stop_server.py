"""Stop only the verified server owned by this application directory."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
    marker=ROOT/'server.pid'
    if not marker.exists():print('이 폴더에서 시작한 서버 기록이 없습니다.');return
    meta=json.loads(marker.read_text());pid=int(meta['pid']);app=ROOT/'app.py'
    if Path(meta['app']).resolve()!=app:raise RuntimeError('서버 경로가 다릅니다.')
    if os.name=='nt':
        # PID alone can be reused; require an exact path argument in process metadata.
        script=f"$OutputEncoding=[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new(); $p=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}'; if($p){{$p.CommandLine}}"
        command=subprocess.check_output(['powershell','-NoProfile','-Command',script],text=True,encoding='utf-8').strip()
    else:
        proc=Path(f'/proc/{pid}/cmdline')
        if not proc.exists():marker.unlink();print('서버가 이미 종료되었습니다.');return
        command=proc.read_bytes().replace(b'\0',b' ').decode()
    import shlex
    arguments=shlex.split(command,posix=os.name!='nt')
    if str(app) not in [x.strip('"') for x in arguments]:raise RuntimeError('해당 PID가 다른 프로그램입니다. 종료하지 않았습니다.')
    os.kill(pid,signal.SIGTERM);marker.unlink(missing_ok=True);print('이 폴더의 서버만 종료 요청했습니다.')


if __name__=='__main__':
    try:main()
    except Exception as e:print('오류:',e,file=sys.stderr);raise SystemExit(1)

@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\setup_firewall.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo 이 도구는 서버에서 관리자 권한으로 실행합니다. 회사 보안 정책이 차단하면 IT 관리자에게 문의하세요.
pause
exit /b %RESULT%

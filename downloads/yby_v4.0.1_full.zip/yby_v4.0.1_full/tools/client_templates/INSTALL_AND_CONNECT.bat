@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0client_connect.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo If connection failed, check the server console and company network policy.
pause
exit /b %RESULT%

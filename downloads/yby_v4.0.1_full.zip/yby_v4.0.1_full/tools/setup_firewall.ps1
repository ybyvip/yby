$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$settingsPath=Join-Path $root 'lan_settings.json'
if (-not (Test-Path -LiteralPath $settingsPath)) { throw 'Run RUN_LAN_WINDOWS.bat first to create server settings.' }
$settings=Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
$port=[int]$settings.port
if ($port -lt 1 -or $port -gt 65535) { throw 'Invalid server port' }
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Right-click SETUP_SERVER_FIREWALL.bat and choose Run as administrator.' }
$python=[string]$settings.python_executable
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw 'Configured Python was moved. Run RUN_LAN_WINDOWS.bat again.' }
$name='YBY-V4-LAN-HTTPS-'+$port
$existing=Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue
if ($existing) { $existing | Remove-NetFirewallRule }
New-NetFirewallRule -Name $name -DisplayName ('YBY V4 LAN HTTPS TCP '+$port) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -RemoteAddress @('LocalSubnet','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16') -Profile Domain,Private -Program $python | Out-Null
Write-Host ('PASS: TCP '+$port+'; Domain/Private profiles; local/private IPv4 sources; configured Python only.')
Get-NetConnectionProfile | Select-Object InterfaceAlias,NetworkCategory | Format-Table
Write-Host 'Public profile is intentionally excluded. Company VPN must route to the server; company network ACLs still apply.'

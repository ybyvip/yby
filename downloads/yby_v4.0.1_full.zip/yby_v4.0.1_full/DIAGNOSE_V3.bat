@echo off
setlocal
cd /d "%~dp0"
title YBY V4.0.1 Diagnostics
echo ============================================================
echo YBY V4.0.1 Diagnostics
echo ============================================================
echo.

echo [1] Python launcher:
where py.exe
if errorlevel 1 echo py.exe not found
echo.
echo [2] Python:
where python.exe
if errorlevel 1 echo python.exe not found
echo.
echo [3] Required files:
if exist "%~dp0app.py" (echo app.py OK) else (echo app.py MISSING)
if exist "%~dp0launcher.py" (echo launcher.py OK) else (echo launcher.py MISSING)
if exist "%~dp0templates\index.html" (echo index.html OK) else (echo index.html MISSING)
if exist "%~dp0data\corporate_card_system.db" (echo database file exists) else (echo database file missing; it will be created)
echo.
echo [4] Launch test:
where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 --version >nul 2>&1
    if not errorlevel 1 (
        py -3 "%~dp0launcher.py"
        goto :finished
    )
)
where python.exe >nul 2>&1
if not errorlevel 1 (
    python "%~dp0launcher.py"
    goto :finished
)
echo Python 3 was not found.
:finished
echo.
pause

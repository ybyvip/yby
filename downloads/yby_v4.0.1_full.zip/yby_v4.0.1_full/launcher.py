"""Compatibility entry point: all launchers use the same V4 startup policy."""
from run_ready import main
if __name__=='__main__':
    raise SystemExit(main())

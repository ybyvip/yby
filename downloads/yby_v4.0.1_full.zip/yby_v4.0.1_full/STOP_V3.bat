@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py.exe >nul 2>&1
if errorlevel 1 (python "%~dp0stop_server.py") else (py -3 "%~dp0stop_server.py")
pause

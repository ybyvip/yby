@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상이 필요합니다. 설치 시 "Add Python to PATH"를 선택하세요.
pause
exit /b 1
:use_py
py -3 "%~dp0run_ready.py" %*
goto finished
:use_python
python "%~dp0run_ready.py" %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo 서버가 종료되었습니다. 위의 오류 안내를 확인하세요.
pause
exit /b %RESULT%

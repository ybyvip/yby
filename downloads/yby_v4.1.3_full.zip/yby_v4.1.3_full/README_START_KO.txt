﻿V4.1.3 실행 오류 수정 안내: CHANGES_V4_1_3_KO.md — Windows PowerShell 한글 인코딩(BOM) 복구 및 설치 전 구문 검사.

V4.1.2 최신 안내: CHANGES_V4_1_2_KO.md — 반납/재보고 공통 양식, 창에 맞는 건별 명세, 승인취소 음영 및 신청·결재 날짜 배치 개선.

기존 정산 취소·재보고/공지 첨부 안내: CHANGES_V4_1_1_KO.md

YBY V4.1.3 전체 수정본

기존 사용자: 새 폴더에 전체 압축 해제 → STOP_SERVER.bat → RUN_LAN_WINDOWS.bat.
기존 실제 AppData 업무 자료·계정·비밀번호·인증서는 유지합니다. data를 지우지 마세요.

첫 실행 후 바탕화면의 YBY 로그인 아이콘을 사용하세요.
HTTP 주소로 들어가도 HTTPS 로그인 화면으로 이동합니다.
서버 실행 창은 계속 열어 두어야 합니다.

다른 PC: 서버 OPEN_LAN_CLIENT.bat → 새 LAN_CLIENT.zip 복사 → 압축 해제 → INSTALL_AND_CONNECT.bat.
현재 비밀번호: 최고관리자 화면의 보기 → 관리자 재인증 → 30초 표시.
기존 해시만 남은 계정은 새 버전 로그인/변경 후 표시할 수 있습니다.
정산: 반납 회수 → 사용함 → 건별 행 추가 → 합계 확인 → 반납 처리.
최고관리자는 자신의 정산을 승인/반려할 수 있습니다.

자세한 변경/사용법: CHANGES_V4_1_KO.md
접속/방화벽/인증서: README_LAN_KO.md
검증 결과/한계: VALIDATION_V4.md
실제 Windows 검사: 서버 VERIFY_WINDOWS.bat / 다른 PC CHECK_CONNECTION.bat

V4.1.3 실행 오류 수정 안내: CHANGES_V4_1_3_KO.md — Windows PowerShell 한글 인코딩(BOM) 복구 및 설치 전 구문 검사.

V4.1.2 최신 안내: CHANGES_V4_1_2_KO.md — 반납/재보고 공통 양식, 창에 맞는 건별 명세, 승인취소 음영 및 신청·결재 날짜 배치 개선.

**V4.1.1 정산 취소·재보고/공지 첨부 변경은 [CHANGES_V4_1_1_KO.md](CHANGES_V4_1_1_KO.md)를 먼저 확인하세요. 기존 V4.1.0은 새 폴더에서 STOP_SERVER.bat → RUN_LAN_WINDOWS.bat 순서로 업데이트합니다.**

# V4.1.1 먼저 확인할 내용

새 로그인 바로가기·HTTP 자동 HTTPS 이동·관리자 비밀번호 표시·접속 유지·건별 정산·최고관리자 본인 결재는 **[CHANGES_V4_1_KO.md](CHANGES_V4_1_KO.md)**를 확인하세요. 기존 V4.0.4 사용자는 새 폴더에서 STOP_SERVER.bat → RUN_LAN_WINDOWS.bat 순서입니다. 다른 PC에도 새 LAN_CLIENT.zip을 배포하세요.

# YBY V4.1.1 사내망 실행 안내

V4.0.3의 업무 기능·자료·계정을 유지하면서 중복 실행 처리와 인증서 등록·배포 절차를 개선한 전체 패키지입니다. 서버: Windows 10/11, Python 3.11 이상, 기본 Windows PowerShell 5.1. 다른 PC: Windows 10/11, PowerShell, Edge/Chrome. 다른 PC에는 Python이 필요하지 않습니다.

## 기존 V4.0.3을 쓰고 있다면

1. 이 ZIP을 새 폴더에 전체 압축 해제하세요.
2. **새 폴더의 STOP_SERVER.bat**를 일반 더블클릭하여 기존 서버를 종료하세요. 다른 사용자들의 작업을 먼저 마무리하세요.
3. **RUN_LAN_WINDOWS.bat**를 일반 더블클릭하세요. 이미 `%LOCALAPPDATA%\YBY\app`에 있는 실제 업무 자료·비밀번호·인증서를 유지하면서 프로그램을 업데이트합니다. 기존 파일은 program_backups에 보존합니다.
4. 최초 인증서 등록 안내가 나오면 SHA-256을 확인하고 **예**를 누르세요. Windows 인증서 등록 확인창도 승인하세요. 이미 등록된 인증서에는 이 질문이 반복되지 않습니다.
5. 브라우저에서 로그인하세요. 실제 버전은 서버 창의 **READY V4.1.1**와 로그인 화면에서 확인하세요.

기존 AppData의 data를 지우거나, 바탕화면의 오래된 data로 덮어쓰지 마세요. 기존 실행 창을 열어 둔 채 새 버전을 실행하면 **실행 중인 버전**으로 연결하고 업데이트를 위해 종료가 필요함을 알립니다. 실행 중인 프로그램 파일을 교체하거나 자료 잠금을 우회하지 않습니다.

## 새 서버 PC라면

1. ZIP 전체 압축 해제 → RUN_LAN_WINDOWS.bat 일반 더블클릭.
2. IP 후보가 여러 개면 회사 PC들이 접근할 수 있는 서버의 실제 사내망 IPv4를 선택하세요. 고정 IP 또는 DHCP 예약을 권장합니다.
3. 최초 1회 인증서 등록 안내에서 예 → Windows 확인창 승인 → 로그인.
4. SETUP_SERVER_FIREWALL.bat를 일반 더블클릭 → 이때 요청하는 관리자 승인(UAC)을 진행하세요. 원래 사용자의 설정 경로를 유지하므로 다른 관리자 계정으로 승인해도 올바른 서버 설정을 사용합니다.
5. 서버 창을 열어 두세요. 창을 닫거나 PC를 끄면 다른 PC도 접속할 수 없습니다.

초기 관리자 ID는 admin입니다. 신규 설치의 무작위 임시 비밀번호는 최초 실행 창에만 표시하며 최초 로그인 후 변경해야 합니다. 놓쳤다면 서버 종료 → RESET_ADMIN_V3.bat → 새 비밀번호 10~128자 두 번 입력 → RUN_LAN_WINDOWS.bat. 비밀번호 입력 중 화면에 글자가 나타나지 않는 것은 정상입니다.

## 다른 PC에서는

1. 서버 PC에서 **OPEN_LAN_CLIENT.bat**를 더블클릭하세요. 전달할 **LAN_CLIENT.zip**이 선택된 탐색기가 열립니다.
2. 이 ZIP만 USB 등 회사에서 허용한 방법으로 다른 PC에 복사하세요.
3. 다른 PC에서 ZIP 전체 압축 해제 → **INSTALL_AND_CONNECT.bat**를 일반 더블클릭하세요.
4. 최초 1회 서버 창의 CA SHA-256과 등록 창의 값을 비교해 같으면 **예**를 누르세요. 인증서는 현재 Windows 사용자에게만 등록됩니다. 회사 정책이 사용자 루트 등록을 막는다면 IT 담당자의 조직 인증서 배포가 필요합니다.
5. HTTPS·인증서·DB 확인이 통과하면 브라우저가 열립니다. 이후 같은 BAT를 실행하면 이미 등록된 인증서로 바로 접속합니다.

서버 PC의 재접속은 **CONNECT_SERVER.bat**를 사용하세요. RUN_LAN_WINDOWS.bat를 다시 실행해도 동일한 정상 서버로 연결하며 두 번째 서버를 만들지 않습니다. 실행 방식이나 포트/IP 변경은 STOP_SERVER.bat로 종료 후 진행하세요.

## 폴더 위치

- 실제 실행 폴더: `%LOCALAPPDATA%\YBY\app`
- 실제 업무 자료: `%LOCALAPPDATA%\YBY\app\data`
- 전달할 ZIP: `%LOCALAPPDATA%\YBY\app\LAN_CLIENT.zip`
- 풀린 접속용 폴더: `%LOCALAPPDATA%\YBY\app\LAN_CLIENT`

AppData는 숨김 폴더입니다. Windows 키+R에 위 경로를 붙여 넣으면 바로 열립니다. OPEN_RUN_FOLDER.bat도 제공합니다. 접속 ZIP에는 공개 인증서·주소·접속 도구·안내만 들어갑니다. data, certificates, 서버 개인키, 전체 프로그램 폴더를 다른 PC에 전달하지 마세요.

## 보안·진단

- HTTP 탐색은 같은 포트의 HTTPS로 이동합니다. 사내망 로그인과 업무 통신은 HTTPS, TLS 1.2 이상입니다. 인증서 체인·주소·유효기간·정확한 CA를 검증합니다. HTTPS 검증을 끄거나 브라우저 경고를 우회하지 않습니다.
- 최초 1회 공개 루트를 신뢰 등록합니다. 이 작업은 해당 CA가 발급하는 인증서를 Windows 사용자에게 신뢰시키므로 서버 CA/개인키를 보호하고 전달 지문을 확인하세요.
- Windows CA 개인키는 발급한 사용자의 개인 인증서 저장소에 있습니다. server-key.pem은 서버 certificates 폴더에만 둡니다. 인증서 만료·IP 변경 시 서버 종료 후 RUN_LAN_WINDOWS.bat로 갱신하고 새 LAN_CLIENT.zip을 배포하세요. CA가 유지되면 다시 신뢰 등록할 필요가 없습니다.
- 방화벽은 지정 Python, 지정 TCP 포트, Domain/Private 프로필, 사내 IPv4/로컬 서브넷에만 허용합니다. Public 프로필·방화벽 전체 해제·인터넷 포트포워딩으로 우회하지 않습니다.
- 기존 비밀번호 해시·권한·강제 최초 변경·로그인 제한·보안 쿠키·세션 만료·백업/복구·자료 충돌 보호를 유지합니다.
- 서버 검증: 서버를 켠 상태에서 **VERIFY_WINDOWS.bat**를 일반 더블클릭하세요. 실제 Windows 사용자 신뢰 저장소·HTTPS 로그인 HTML·CA·프로세스·네이티브 자료 잠금·재실행을 검사하고 diagnostics에 JSON을 남깁니다. 업무 자료나 비밀번호를 변경하지 않습니다.
- 다른 PC 검증: LAN_CLIENT의 **CHECK_CONNECTION.bat**. 이 결과가 통과해야 해당 PC의 실제 회사망 접속이 확인됩니다. 브라우저를 재시작해야 새 신뢰 설정이 반영되는 경우가 있습니다.
- 자료 사용 중: 정상 서버이면 재접속합니다. 유지보수/시작 작업이라면 끝날 때까지 기다리세요. `.runtime.lock` 파일을 수동 삭제하지 마세요. 프로세스 종료 시 OS 잠금은 해제됩니다.
- 인증서 파일 Access denied: 기존 인증서를 지우지 말고 **REPAIR_CERTIFICATE_OWNER.bat**를 일반 더블클릭하고 도구가 요청할 때 관리자 승인하세요. 원래 Windows 사용자의 인증서 경로만 복구하고 일반 권한 읽기/키 로드를 확인합니다.
- 정책·프록시·VPN·사내 방화벽/망 ACL 차단은 프로그램만으로 해제할 수 없습니다. 서버/클라이언트 검증 결과를 IT에 전달하세요. 조직 CA를 쓰는 회사는 IT가 발급·관리한 인증서를 사용할 수 있습니다.

업무 전체 백업은 data 기준입니다. 새 PC 이전 시 lan_settings.json, certificates, Windows 사용자 인증서 저장소는 별도 운영 백업/이전이 필요합니다. 서버를 단순히 다른 Windows 계정으로 옮기면 CA 개인키가 따라가지 않습니다.

## 검증 범위

실행 결과와 한계는 VALIDATION_V4.md를 확인하세요. 이 배포의 클라우드 검증은 Linux에서 수행하며 실제 Windows/Edge/회사 VPN의 검증을 완료했다고 표시하지 않습니다. VERIFY_WINDOWS와 CHECK_CONNECTION은 해당 PC에서 실제 확인하기 위한 도구입니다.

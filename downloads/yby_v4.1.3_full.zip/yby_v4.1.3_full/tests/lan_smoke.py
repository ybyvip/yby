"""Actual private-interface TLS/startup/persistence acceptance. Uses disposable data only."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SOURCE))
import lan_setup


def main():
    candidates=lan_setup.local_ips()
    if not candidates:raise RuntimeError('No RFC1918 interface available; this is not a passing/skipped test.')
    ip=candidates[0]
    with tempfile.TemporaryDirectory(prefix='yby-lan-') as folder:
        root=Path(folder)/'application'
        shutil.copytree(SOURCE,root,ignore=shutil.ignore_patterns('__pycache__','data','backups','logs','certificates','LAN_CLIENT','lan_settings.json','*.runtime.lock','server.pid'))
        with socket.socket() as probe:probe.bind(('0.0.0.0',0));port=probe.getsockname()[1]
        env={k:v for k,v in os.environ.items() if not k.startswith(('V3_','V4_'))}
        # Direct shared HTTP must still fail before creating a business DB.
        denied=subprocess.run([sys.executable,str(root/'app.py')],cwd=root,env=dict(env,V3_HOST='0.0.0.0',V3_PORT=str(port)),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert denied.returncode!=0 and not (root/'data/corporate_card_system.db').exists()
        print('PASS: shared plaintext HTTP remains blocked; no business DB created',flush=True)
        process=None
        log=Path(folder)/'private-console.log'
        def start(arguments):
            with log.open('ab') as output:
                child=subprocess.Popen([sys.executable,str(root/'run_ready.py'),*arguments,'--no-browser'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
            for _ in range(720):
                if child.poll() is not None:raise RuntimeError('LAN runner exited. Private console not printed.')
                try:
                    context=ssl.create_default_context(cafile=str(root/'certificates/root-ca.pem'))
                    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
                    with opener.open(f'https://{ip}:{port}/health',timeout=2) as r:health=json.load(r)
                    if health.get('version')=='4.1.3' and health['database'] and 'LAN HTTPS 확인 완료' in log.read_text(errors='replace'):return child,opener
                except (OSError,ValueError):pass
                time.sleep(.25)
            child.terminate();child.wait(timeout=10);raise RuntimeError('LAN runner timed out')
        try:
            process,opener=start(['--lan','--server-ip',ip,'--port',str(port)])
            settings=json.loads((root/'lan_settings.json').read_text())
            assert settings['server_ip']==ip and settings['port']==port
            bundle=root/'LAN_CLIENT';info=json.loads((bundle/'connection.json').read_text())
            assert info['sha256']==hashlib.sha256((bundle/'YBY_LAN_ROOT.cer').read_bytes()).hexdigest().upper()
            assert not any('key' in path.name or path.suffix=='.db' for path in bundle.iterdir())
            context=ssl.create_default_context(cafile=str(root/'certificates/root-ca.pem'))
            local=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
            with local.open(f'https://localhost:{port}/health',timeout=3) as response:assert json.load(response)['version']=='4.1.3'
            print('PASS: first-time OS certificate generation + real RFC1918 IP and localhost trusted TLS + correct client bundle',flush=True)
            credential=re.search(r'\[최초 임시 비밀번호\] admin: (\S+) ',log.read_text(errors='replace')).group(1)
            request=urllib.request.Request(f'https://{ip}:{port}/api/login',data=json.dumps({'username':'admin','password':credential}).encode(),headers={'Content-Type':'application/json'})
            with opener.open(request,timeout=10) as response:
                cookie=response.headers['Set-Cookie'];assert '; Secure' in cookie and '; SameSite=Strict' in cookie
                assert json.load(response)['mustChangePassword']
            request=urllib.request.Request(f'https://{ip}:{port}/api/change-password',data=json.dumps({'currentPassword':credential,'newPassword':'LAN-restart-pass!'}).encode(),headers={'Content-Type':'application/json','Cookie':cookie.split(';')[0]})
            with opener.open(request,timeout=10) as response:assert json.load(response)['ok']
            print('PASS: real HTTPS login, secure session and mandatory password change',flush=True)
            marker=(root/'server.pid').read_bytes()
            ca_before=(root/'certificates/root-ca.cer').read_bytes()
            duplicate=subprocess.run([sys.executable,str(root/'run_ready.py'),'--lan','--no-browser'],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
            assert duplicate.returncode==0,duplicate.stderr
            assert '이미 실행 중인 YBY' in duplicate.stdout
            assert (root/'server.pid').read_bytes()==marker
            assert (root/'certificates/root-ca.cer').read_bytes()==ca_before
            assert process.poll() is None
            import zipfile
            with zipfile.ZipFile(root/'LAN_CLIENT.zip') as archive:
                assert archive.testzip() is None
                assert len(archive.namelist())==6
                assert not any('key' in name or name.endswith('.db') for name in archive.namelist())
            print('PASS: repeated LAN launch reconnects to same PID without configuration/certificate changes; public-only client ZIP',flush=True)
            try:
                untrusted=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=ssl.create_default_context()))
                untrusted.open(f'https://{ip}:{port}/health',timeout=3)
                raise AssertionError('Untrusted certificate was accepted')
            except urllib.error.URLError as error:assert isinstance(error.reason,ssl.SSLCertVerificationError)
            with socket.create_connection((ip,port),timeout=3) as connection:
                try:context.wrap_socket(connection,server_hostname='wrong-host.invalid');raise AssertionError('Wrong hostname accepted')
                except ssl.SSLCertVerificationError:pass
            before=(root/'lan_settings.json').read_bytes()
            busy=subprocess.run([sys.executable,str(root/'lan_setup.py'),'--server-ip',ip],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            assert busy.returncode!=0 and (root/'lan_settings.json').read_bytes()==before
            diagnose=subprocess.run([sys.executable,str(root/'network_diagnose.py')],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            assert diagnose.returncode==0 and 'HTTPS' in diagnose.stdout
            print('PASS: untrusted CA/wrong hostname rejected, active-server reconfiguration blocked, network diagnosis succeeds',flush=True)
            cert_hash=hashlib.sha256((root/'certificates/server.pem').read_bytes()).hexdigest()
            subprocess.run([sys.executable,str(root/'stop_server.py')],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
            process.wait(timeout=10);process=None
            process,opener=start([])  # Ordinary RUN_WINDOWS uses this same saved-config path.
            request=urllib.request.Request(f'https://{ip}:{port}/api/login',data=json.dumps({'username':'admin','password':'LAN-restart-pass!'}).encode(),headers={'Content-Type':'application/json'})
            with opener.open(request,timeout=10) as response:assert not json.load(response)['mustChangePassword']
            assert hashlib.sha256((root/'certificates/server.pem').read_bytes()).hexdigest()==cert_hash
            print('PASS: saved LAN settings loaded by ordinary runner, same-port restart, certificate/password persistence',flush=True)
            subprocess.run([sys.executable,str(root/'stop_server.py')],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
            process.wait(timeout=10);process=None
        finally:
            if process is not None:
                if (root/'server.pid').exists():subprocess.run([sys.executable,str(root/'stop_server.py')],cwd=root,env=env,stdout=subprocess.DEVNULL)
                process.wait(timeout=10)


if __name__=='__main__':main()

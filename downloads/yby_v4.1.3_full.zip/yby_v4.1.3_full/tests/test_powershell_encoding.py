"""Distribution encoding must work with Windows PowerShell 5.1 -File."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import lan_setup
import windows_bootstrap


class PowerShellEncodingTests(unittest.TestCase):
    def test_every_distributed_powershell_file_is_utf8_with_bom(self):
        scripts=list((ROOT/'tools').rglob('*.ps1'))
        self.assertGreaterEqual(len(scripts),4)
        for path in scripts:
            with self.subTest(path=str(path.relative_to(ROOT))):
                raw=path.read_bytes()
                self.assertTrue(raw.startswith(b'\xef\xbb\xbf'))
                text=raw.decode('utf-8-sig')
                self.assertNotIn('\ufffd',text)
                self.assertNotIn('\ufeff',text)
        client=(ROOT/'tools/client_templates/client_connect.ps1').read_text(encoding='utf-8-sig')
        self.assertIn('바탕화면에 YBY 로그인 바로가기를 만들었습니다.',client)

    def test_exported_public_client_folder_and_zip_preserve_identical_bom_bytes(self):
        with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()):
            root=Path(folder)
            (root/'certificates').mkdir()
            (root/'certificates/root-ca.cer').write_bytes(b'public fixture certificate')
            shutil.copytree(ROOT/'tools',root/'tools')
            lan_setup.export_client(root,{'server_ip':'10.10.0.121','port':5000})
            expected=(ROOT/'tools/client_templates/client_connect.ps1').read_bytes()
            self.assertEqual((root/'LAN_CLIENT/client_connect.ps1').read_bytes(),expected)
            with zipfile.ZipFile(root/'LAN_CLIENT.zip') as archive:
                self.assertEqual(archive.read('LAN_CLIENT/client_connect.ps1'),expected)

    def source(self,folder,raw):
        source=Path(folder);script=source/'test.ps1';script.write_bytes(raw)
        (source/'MANIFEST.json').write_text(json.dumps({'files':{'test.ps1':hashlib.sha256(raw).hexdigest()}}))
        return source

    def test_bootstrap_rejects_bomless_script_even_when_manifest_hash_matches(self):
        with tempfile.TemporaryDirectory() as folder:
            source=self.source(folder,"Write-Host '한글 안내'\n".encode('utf-8'))
            with self.assertRaisesRegex(RuntimeError,'UTF-8 BOM'):
                windows_bootstrap.source_files(source)

    def test_bootstrap_copies_bom_script_without_changing_encoding(self):
        with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()):
            source=Path(folder)/'source';source.mkdir()
            raw="Write-Host '한글 안내'\n".encode('utf-8-sig')
            self.source(source,raw);target=Path(folder)/'runtime'
            windows_bootstrap.prepare_runtime(source,target)
            self.assertEqual((target/'test.ps1').read_bytes(),raw)

    def test_native_parser_uses_file_decoding_and_quotes_paths_as_literals(self):
        with patch.object(windows_bootstrap.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='')) as run:
            windows_bootstrap.check_native_powershell(Path("folder's 한글"),['tools/client.ps1'])
        args=run.call_args.args[0]
        self.assertEqual(args[0],'powershell.exe')
        self.assertIn('::ParseFile(',args[-1])
        self.assertIn("folder''s 한글",args[-1])
        self.assertNotIn('-File',args)

    def test_native_parser_failure_blocks_installation(self):
        with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()):
            source=Path(folder)/'source';source.mkdir()
            self.source(source,"Write-Host '한글 안내'\n".encode('utf-8-sig'))
            target=Path(folder)/'runtime'
            with patch.object(windows_bootstrap.sys,'platform','win32'),patch.object(windows_bootstrap.subprocess,'run',return_value=SimpleNamespace(returncode=1,stdout='parser fixture failure')),patch.object(windows_bootstrap,'prepare_runtime') as install:
                with self.assertRaisesRegex(RuntimeError,'구문 검사 실패'):
                    windows_bootstrap.run_windows(source,target,['--lan','--no-browser'])
                install.assert_not_called()
            self.assertFalse(target.exists())


if __name__=='__main__':unittest.main()

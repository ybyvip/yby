"""Manual dedicated login: typed credentials, lifecycle, errors, layout and auth."""
from pathlib import Path
import importlib.util
import json
import os
import sys
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
fixture.SecurityTests.setUpClass();c=fixture.SecurityTests()
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v414-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=fixture.app
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'])
        context=browser.new_context(viewport={'width':480,'height':780})
        context.add_init_script("window.__resizeCalls=[];window.resizeTo=(w,h)=>window.__resizeCalls.push([w,h]);window.moveTo=()=>{}")
        page=context.new_page();errors=[];dialogs=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('dialog',lambda dialog:(dialogs.append(dialog.message),dialog.accept()))
        pending=[]
        page.route('**/api/bootstrap?*',lambda route:pending.append(route))
        base=f'http://127.0.0.1:{c.server.server_port}/'
        page.goto(base+'?desktop=1')
        page.wait_for_function("()=>document.getElementById('loginAccountStatus').textContent.includes('확인 중')")
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!')
        bootstrap=c.request('/api/bootstrap')[1]
        assert pending;pending[0].fulfill(status=200,content_type='application/json',body=json.dumps(bootstrap))
        page.wait_for_function("()=>document.getElementById('loginAccountStatus').textContent.includes('활성 계정')")
        assert page.input_value('#loginUserSelect')=='admin'
        assert page.input_value('#loginPasswordInput')=='Admin-test-pass!'
        page.unroute('**/api/bootstrap?*')
        assert page.locator('#loginUserSelect').evaluate('(x)=>x.tagName')=='INPUT'
        assert page.locator('#loginPasswordInput').get_attribute('type')=='password'
        assert page.locator('#loginPasswordInput').get_attribute('autocomplete')=='current-password'
        assert page.locator('#loginAccounts option').count()>=2
        page.fill('#loginUserSelect','');page.fill('#loginPasswordInput','')
        for width,height in [(480,780),(390,844),(320,740),(1366,900)]:
            page.set_viewport_size({'width':width,'height':height})
            metrics=page.evaluate("""()=>{const overlay=document.getElementById('loginModal'),r=overlay.getBoundingClientRect();return {width:overlay.clientWidth,scroll:overlay.scrollWidth,outside:Array.from(overlay.querySelectorAll('input,button')).filter(x=>x.offsetParent!==null).filter(x=>{const q=x.getBoundingClientRect();return q.left<r.left-1||q.right>r.right+1}).map(x=>x.id)}}""")
            assert metrics['scroll']<=metrics['width']+1,(width,metrics)
            assert not metrics['outside'],(width,metrics)
        page.set_viewport_size({'width':440,'height':720})
        page.screenshot(path=str(screens/'yby_v4.1.7_login.png'))
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','wrong-password')
        page.press('#loginPasswordInput','Enter')
        page.wait_for_selector('#loginError:not([hidden])')
        assert page.locator('#loginModal').is_visible();assert page.locator('#appContainer').is_hidden()
        assert not page.locator('#loginSubmitButton').is_disabled();assert not dialogs
        page.fill('#loginPasswordInput','Admin-test-pass!')
        login_requests=[]
        page.route('**/api/login',lambda route:login_requests.append(route))
        page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>document.getElementById('loginSubmitButton').disabled")
        page.evaluate('handleLogin({preventDefault(){}})')
        assert len(login_requests)==1
        login_requests[0].continue_()
        page.wait_for_function("()=>currentUser==='admin'&&document.getElementById('appContainer').style.display==='flex'")
        page.unroute('**/api/login')
        assert page.input_value('#loginPasswordInput')==''
        assert page.evaluate('document.documentElement.dataset.ybyScreen')=='app'
        assert page.evaluate('window.__resizeCalls.length')>=2
        assert page.title()=='YBY 법인카드 · 하이패스'
        page.set_viewport_size({'width':1366,'height':900})
        page.evaluate('async()=>await handleLogout()')
        page.wait_for_function("()=>currentUser===null&&document.documentElement.dataset.ybyScreen==='login'")
        assert page.title()=='YBY 로그인'
        assert page.input_value('#loginPasswordInput')==''
        assert page.locator('#loginError').is_hidden()
        assert page.evaluate("JSON.stringify(localStorage).includes('Admin-test-pass!')")==False
        page.route('**/api/login',lambda route:route.fulfill(status=503,content_type='application/json',body='{"ok":false,"message":"회사 서버가 준비 중입니다."}'))
        page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.click('#loginSubmitButton')
        page.wait_for_selector('#loginError:not([hidden])');assert '준비 중' in page.inner_text('#loginError')
        assert not page.locator('#loginSubmitButton').is_disabled()
        page.unroute('**/api/login')
        page.close()
        # A reopened desktop client asks for credentials rather than silently logging in.
        page=context.new_page();page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(base+'?desktop=1');assert page.locator('#loginModal').is_visible()
        assert page.input_value('#loginPasswordInput')==''
        with a.db() as conn:conn.execute("UPDATE users SET must_change_password=1 WHERE username='branch'");conn.commit()
        page.fill('#loginUserSelect','branch');page.fill('#loginPasswordInput','Branch-test-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_selector('#ownNewPassword',state='visible')
        assert page.input_value('#loginPasswordInput')==''
        page.on('dialog',lambda dialog:dialog.accept())
        page.fill('#ownNewPassword','Changed-v414-pass!');page.fill('#ownConfirmPassword','Changed-v414-pass!');page.click('#ownPasswordSave')
        page.wait_for_selector('#commonModal',state='hidden')
        page.fill('#loginUserSelect','branch');page.fill('#loginPasswordInput','Changed-v414-pass!');page.press('#loginPasswordInput','Enter')
        page.wait_for_function("()=>currentUser==='branch'")
        assert page.locator('#appContainer').is_visible()
        page.close()
        normal=context.new_page();normal.goto(base)
        assert not normal.evaluate("document.documentElement.classList.contains('desktop-client')")
        assert normal.evaluate('window.__resizeCalls.length')==0
        assert c.request('/health')[1]['database']
        assert not errors,errors
        print('PASS: reference-style typed-ID login; initial/bootstrap typing preserved; 480/390/320/1366 widths; inline auth/server errors; single request while busy; Enter login; no password cache; logout/reopen; mandatory password change; branch/admin auth',flush=True)
        print('PASS: dedicated mode requests login/workspace window sizes and titles; ordinary browser unaffected; closing client keeps server alive; no JavaScript errors. Native Windows window sizing/Start menu registration not executed here.',flush=True)
        browser.close()
finally:fixture.SecurityTests.tearDownClass()

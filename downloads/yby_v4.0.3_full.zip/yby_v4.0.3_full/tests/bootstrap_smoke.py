"""Install from a read-only source, start relocated app and preserve original DB."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SOURCE))
import windows_bootstrap

def main():
    with tempfile.TemporaryDirectory(prefix='yby-permission-') as folder:
        source=Path(folder)/'바탕화면 원본';target=Path(folder)/'사용자 실행 폴더'
        shutil.copytree(SOURCE,source,ignore=shutil.ignore_patterns('__pycache__','data','logs','backups','certificates','LAN_CLIENT','lan_settings.json','*.runtime.lock','server.pid'))
        env={k:v for k,v in os.environ.items() if not k.startswith(('V3_','V4_'))}
        seed="import app; app.prepare_db(); c=app.db(); c.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(app.phash('Bootstrap-test-pass!'),'admin')); c.commit(); c.close()"
        subprocess.run([sys.executable,'-c',seed],cwd=source,env=env,check=True,stdout=subprocess.DEVNULL)
        database=source/'data/corporate_card_system.db';before=hashlib.sha256(database.read_bytes()).hexdigest()
        for path in source.rglob('*'):path.chmod(0o555 if path.is_dir() else 0o444)
        source.chmod(0o555)
        process=None
        try:
            windows_bootstrap.prepare_runtime(source,target)
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
            log=Path(folder)/'private-console.log'
            with log.open('ab') as output:
                process=subprocess.Popen([sys.executable,str(target/'run_ready.py'),'--local','--port',str(port),'--no-browser'],cwd=target,env=env,stdout=output,stderr=subprocess.STDOUT)
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            url=f'http://127.0.0.1:{port}'
            for _ in range(100):
                if process.poll() is not None:raise RuntimeError('Relocated startup failed; private console not printed')
                try:
                    with opener.open(url+'/health',timeout=2) as response:
                        if json.load(response)['version']=='4.0.3':break
                except OSError:pass
                time.sleep(.1)
            else:raise RuntimeError('Relocated readiness timeout')
            request=urllib.request.Request(url+'/api/login',data=json.dumps({'username':'admin','password':'Bootstrap-test-pass!'}).encode(),headers={'Content-Type':'application/json'})
            with opener.open(request,timeout=10) as response:cookie=response.headers['Set-Cookie'].split(';')[0];assert json.load(response)['ok']
            request=urllib.request.Request(url+'/api/state',headers={'Cookie':cookie})
            with opener.open(request,timeout=10) as response:revision=json.load(response)['revision']
            payload={'num':'RELOCATED-TEST','group':'서울','company':'test','revision':revision,'requestId':'relocated-startup-register'}
            request=urllib.request.Request(url+'/api/cards/register',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Cookie':cookie})
            with opener.open(request,timeout=10) as response:assert json.load(response)['card']['num']=='RELOCATED-TEST'
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            subprocess.run([sys.executable,str(target/'stop_server.py')],cwd=target,env=env,check=True,stdout=subprocess.DEVNULL)
            process.wait(timeout=10);process=None
            windows_bootstrap.prepare_runtime(source,target)
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            print('PASS: read-only Korean-path source -> writable runtime; original DB unchanged; actual startup/login/business save; repeated install keeps runtime data',flush=True)
        finally:
            if process is not None:
                if (target/'server.pid').exists():subprocess.run([sys.executable,str(target/'stop_server.py')],cwd=target,env=env,stdout=subprocess.DEVNULL)
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10)
            source.chmod(0o700)
            for path in source.rglob('*'):path.chmod(0o700 if path.is_dir() else 0o600)

if __name__=='__main__':main()

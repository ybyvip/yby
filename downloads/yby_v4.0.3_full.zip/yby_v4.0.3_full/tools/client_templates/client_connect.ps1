param([switch]$CheckOnly)
$ErrorActionPreference='Stop'
$info=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'connection.json') -Raw | ConvertFrom-Json
$ip=[System.Net.IPAddress]::Parse($info.server_ip)
$port=[int]$info.port
if ($port -lt 1 -or $port -gt 65535) { throw 'Invalid port' }
$url='https://' + $ip.ToString() + ':' + $port
$certificate=Join-Path $PSScriptRoot 'YBY_LAN_ROOT.cer'
$actual=(Get-FileHash -LiteralPath $certificate -Algorithm SHA256).Hash
if ($actual -ne $info.sha256) { throw 'Certificate SHA-256 mismatch. Get a fresh LAN_CLIENT folder from the server.' }
Write-Host ('Server URL: ' + $url)
Write-Host ('CA SHA-256: ' + $actual)
if (-not $CheckOnly) {
    Write-Host 'Compare this SHA-256 with the server console. This trusts the YBY private certificate authority for your Windows user.'
    $answer=Read-Host 'Type YES to install this certificate and connect; anything else cancels'
    if ($answer -cne 'YES') { Write-Host 'Cancelled; no certificate installed.'; exit 1 }
    & certutil.exe -user -addstore Root $certificate
    if ($LASTEXITCODE -ne 0) { throw 'Certificate installation failed. Ask company IT about certificate policy.' }
}
Write-Host 'Checking TCP connection...'
if (-not (Test-NetConnection -ComputerName $ip.ToString() -Port $port -InformationLevel Quiet -WarningAction SilentlyContinue)) {
    throw 'TCP connection failed. Keep RUN_LAN_WINDOWS open on the server; check server IPv4, Private/Domain firewall, VPN routing and company network policy.'
}
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$health=Invoke-RestMethod -Uri ($url+'/health') -TimeoutSec 10
if (-not $health.ok -or -not $health.database -or $health.version -ne '4.0.3') { throw 'YBY V4.0.3 health check failed or another server is using this port.' }
Write-Host 'PASS: TCP, trusted HTTPS certificate, hostname/IP, YBY version and database.'
if (-not $CheckOnly) { Start-Process $url }

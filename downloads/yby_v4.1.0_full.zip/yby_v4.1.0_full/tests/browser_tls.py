"""Real Chromium HTTPS login using an isolated, explicitly trusted NSS root CA."""
import json
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.request
from playwright.sync_api import sync_playwright

SOURCE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SOURCE))
import lan_setup


def main():
    if sys.platform!='linux' or not shutil.which('certutil'):
        raise RuntimeError('This acceptance requires Linux Chromium/NSS tools; not a Windows verification.')
    ip=lan_setup.local_ips()[0]
    with tempfile.TemporaryDirectory(prefix='yby-browser-https-') as folder:
        root=Path(folder)/'app';home=Path(folder)/'browser-home'
        shutil.copytree(SOURCE,root,ignore=shutil.ignore_patterns('__pycache__','data','backups','logs','certificates','LAN_CLIENT','lan_settings.json','*.runtime.lock','server.pid'))
        nss=home/'.pki/nssdb';nss.mkdir(parents=True)
        with socket.socket() as probe:probe.bind(('0.0.0.0',0));port=probe.getsockname()[1]
        env={k:v for k,v in os.environ.items() if not k.startswith(('V3_','V4_'))}
        log=Path(folder)/'private-console.log'
        with log.open('wb') as output:
            process=subprocess.Popen([sys.executable,str(root/'run_ready.py'),'--lan','--server-ip',ip,'--port',str(port),'--no-browser'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
        try:
            for _ in range(200):
                if process.poll() is not None:raise RuntimeError('Private HTTPS test server exited')
                if 'LAN HTTPS 확인 완료' in log.read_text(errors='replace'):break
                time.sleep(.1)
            else:raise RuntimeError('Private HTTPS server readiness timeout')
            password=re.search(r'\[최초 임시 비밀번호\] admin: (\S+) ',log.read_text()).group(1)
            subprocess.run(['certutil','-N','--empty-password','-d','sql:'+str(nss)],check=True,stdout=subprocess.DEVNULL)
            subprocess.run(['certutil','-A','-d','sql:'+str(nss),'-n','YBY isolated acceptance CA','-t','C,,','-i',str(root/'certificates/root-ca.pem')],check=True,stdout=subprocess.DEVNULL)
            with sync_playwright() as p:
                browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server'],env=dict(os.environ,HOME=str(home)))
                try:
                    context=browser.new_context()  # ignore_https_errors remains False.
                    page=context.new_page();page.on('dialog',lambda dialog:dialog.accept());page.goto(f'http://localhost:{port}/');assert page.url==f'https://localhost:{port}/'
                    page.select_option('#loginUserSelect','admin');page.fill('#loginPasswordInput',password)
                    with page.expect_response(lambda r:'/api/login' in r.url) as initial:
                        page.press('#loginPasswordInput','Enter')
                    assert initial.value.json()['mustChangePassword']
                    page.fill('#ownNewPassword','Browser-HTTPS-pass!');page.fill('#ownConfirmPassword','Browser-HTTPS-pass!')
                    with page.expect_response(lambda r:'/api/change-password' in r.url) as changed:
                        page.click('#ownPasswordSave')
                    assert changed.value.json()['ok']
                    page.wait_for_selector('#commonModal',state='hidden')
                    password='Browser-HTTPS-pass!'
                    page.select_option('#loginUserSelect','admin');page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter')
                    page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'")
                    print('PASS: Chromium HTTPS localhost login with NSS-trusted CA and no certificate bypass',flush=True)
                    other=browser.new_context();remote=other.new_page();remote.goto(f'http://{ip}:{port}/');assert remote.url==f'https://{ip}:{port}/'
                    remote.select_option('#loginUserSelect','admin');remote.fill('#loginPasswordInput',password)
                    with remote.expect_response(lambda r:'/api/login' in r.url) as response:
                        remote.press('#loginPasswordInput','Enter')
                    body=response.value.json();assert body['ok'] and not body['mustChangePassword']
                    cookies=other.cookies();session=[c for c in cookies if c['httpOnly']]
                    assert session and all(c['secure'] and c['sameSite']=='Strict' for c in session)
                    print('PASS: Chromium HTTP navigation redirects to trusted HTTPS on localhost and RFC1918 IP; secure login cookie',flush=True)
                    page.evaluate('async()=>await handleLogout()');page.close()
                    reopened=context.new_page();reopened.goto(f'http://localhost:{port}/')
                    assert reopened.url==f'https://localhost:{port}/'
                    reopened.select_option('#loginUserSelect','admin');reopened.fill('#loginPasswordInput',password);reopened.press('#loginPasswordInput','Enter')
                    reopened.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'")
                    print('PASS: logout, close login window, reopen using HTTP bookmark, trusted HTTPS login succeeds',flush=True)
                finally:browser.close()
        finally:
            if (root/'server.pid').exists():subprocess.run([sys.executable,str(root/'stop_server.py')],cwd=root,env=env,stdout=subprocess.DEVNULL)
            process.wait(timeout=15)


if __name__=='__main__':main()

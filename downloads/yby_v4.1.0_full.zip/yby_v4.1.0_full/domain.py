"""Server-owned business validation shared by every write route."""
from datetime import date
import json
import re

BRANCHES={'본사','서울','인천','정봉','임원실'}


def date_value(value,label,required=False):
    if not value and not required:return
    try:
        if not isinstance(value,str) or date.fromisoformat(value).isoformat()!=value:raise ValueError
    except (TypeError,ValueError):raise ValueError(label+': YYYY-MM-DD 날짜가 필요합니다.')


def expense_lines(items):
    if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('세부 정산은 1~100건으로 작성하세요.')
    result=[];total=0
    for item in items:
        if not isinstance(item,dict):raise ValueError('세부 정산 항목 형식 오류')
        entry={}
        for name in ('date','category','merchant','description','note'):
            value=item.get(name,'')
            if not isinstance(value,str) or len(value)>1000 or (name!='note' and not value.strip()):raise ValueError('건별 사용일·구분·사용처·상세내역을 입력하세요.')
            entry[name]=value.strip()
        date_value(entry['date'],'건별 사용일',True)
        quantity=item.get('quantity',1);price=item.get('unitPrice')
        if type(quantity)!=int or not 1<=quantity<=1000000 or type(price)!=int or not 1<=price<=10**12:raise ValueError('수량과 단가는 양의 정수로 입력하세요.')
        amount=quantity*price;total+=amount
        if total>10**12:raise ValueError('정산 합계는 1조원을 넘을 수 없습니다.')
        if 'amount' in item and (type(item['amount'])!=int or item['amount']!=amount):raise ValueError('건별 금액이 수량×단가와 다릅니다.')
        entry.update(quantity=quantity,unitPrice=price,amount=amount);result.append(entry)
    return result,total


def prepare_expense(row):
    if 'lineItems' not in row:return
    items,total=expense_lines(row['lineItems'])
    if 'amount' in row and (type(row['amount'])!=int or row['amount']!=total):raise ValueError('정산 합계가 건별 금액 합계와 다릅니다.')
    merchants=list(dict.fromkeys(item['merchant'] for item in items))
    categories=list(dict.fromkeys(item['category'] for item in items))
    row.update(lineItems=items,amount=total,date=min(item['date'] for item in items),
               merchant=merchants[0] if len(merchants)==1 else f'{merchants[0]} 외 {len(merchants)-1}곳',
               category=categories[0] if len(categories)==1 else '복수 항목')


def expense(item,cards,require_card=True):
    if 'lineItems' in item:
        _,total=expense_lines(item['lineItems'])
        if item.get('amount')!=total:raise ValueError('건별 정산 합계 불일치')
    for field in ('date','cardNum','user','merchant','purpose'):
        if not isinstance(item.get(field),str) or not item[field].strip():raise ValueError('정산 필수 항목 누락: '+field)
    date_value(item['date'],'사용일',True)
    amount=item.get('amount')
    if isinstance(amount,bool) or not isinstance(amount,int) or not 1<=amount<=10**12:raise ValueError('정산 금액은 1~1조원의 정수여야 합니다.')
    if item.get('group') not in BRANCHES:raise ValueError('정산 지점이 올바르지 않습니다.')
    if require_card and not any(c.get('num')==item['cardNum'] and c.get('group')==item['group'] for c in cards):raise ValueError('해당 지점에 등록된 카드가 아닙니다.')
    if item.get('status') not in ('승인대기','승인완료','반려됨'):raise ValueError('정산 상태가 올바르지 않습니다.')
    if not isinstance(item.get('attachments',[]),list) or len(item.get('attachments',[]))>5:raise ValueError('정산 첨부는 최대 5개입니다.')


def identity(item):
    return (str(item.get('group','')),str(item.get('requester') or item.get('author') or item.get('handler') or ''),str(item.get('id','')))


def validate(state,current,user,admin=False,trusted=False):
    cards=state.get('cards',current.get('cards',[]));numbers=set();ids=set()
    old_cards={str(c.get('id')):c for c in current.get('cards',[])}
    for card in cards:
        if not isinstance(card,dict):raise ValueError('카드 형식이 올바르지 않습니다.')
        num=card.get('num');group=card.get('group')
        if not isinstance(num,str) or not num.strip() or len(num)>80 or group not in BRANCHES:raise ValueError('카드 번호와 지점이 필요합니다.')
        canonical=re.sub(r'[\s-]','',num).casefold()
        if canonical in numbers or str(card.get('id')) in ids:raise ValueError('카드 번호 또는 ID가 중복됩니다.')
        numbers.add(canonical);ids.add(str(card.get('id')))
        card.setdefault('status','available')
        if card['status'] not in ('available','rented'):raise ValueError('카드 상태가 올바르지 않습니다.')
        old=old_cards.get(str(card.get('id')))
        if old==card:continue
        if isinstance(card.get('id'),bool) or not str(card.get('id','')).isdigit() or int(card['id'])<1:raise ValueError('카드 ID가 올바르지 않습니다.')
        if card.get('userType') not in (None,'','지정','비지정'):raise ValueError('사용자 구분 오류')
        if card.get('userType')=='지정' and not str(card.get('assignedUser','')).strip():raise ValueError('지정 사용자 이름이 필요합니다.')
        for field in ('issueDate','expiryDate','rentDate','dueDate'):date_value(card.get(field),field)
        if card.get('expiryDate') and card.get('issueDate') and card['expiryDate']<card['issueDate']:raise ValueError('카드 만료일이 발급일보다 빠릅니다.')
        if card.get('status')=='rented':
            if not all(card.get(f) for f in ('dept','user','purpose','rentDate','dueDate')):raise ValueError('불출 필수 정보가 누락되었습니다.')
            if card['dueDate']<card['rentDate']:raise ValueError('반납 예정일이 불출일보다 빠릅니다.')
        if old and old.get('status')!=card.get('status') and not trusted:
            raise PermissionError('카드 불출·반납은 전용 업무 API를 사용하세요.')
    if any(c.get('status')=='rented' and str(c.get('id')) not in ids for c in current.get('cards',[])):raise ValueError('불출 중인 카드는 먼저 반납해야 삭제할 수 있습니다.')
    for pending in current.get('expense',[]):
        existed=any(c.get('num')==pending.get('cardNum') and c.get('group')==pending.get('group') for c in current.get('cards',[]))
        if existed and not any(c.get('num')==pending.get('cardNum') and c.get('group')==pending.get('group') for c in cards):raise ValueError('미결 정산과 연결된 카드는 삭제·번호 변경 전에 정산을 처리하세요.')
    for field in ('history','expenseHistory'):
        if field not in state:continue
        old={identity(x):x for x in current.get(field,[])}
        new={identity(x):x for x in state[field]}
        if not trusted and any(new.get(k)!=v for k,v in old.items()):raise PermissionError('확정 이력은 수정·삭제할 수 없습니다. 정정 업무를 사용하세요.')
        if not trusted and any(k not in old for k in new):raise PermissionError('정산 승인은 전용 업무 API를 사용하세요.')
    old_expenses={identity(x):x for x in current.get('expense',[])}
    if not trusted and any(identity(x) not in {identity(v) for v in state.get('expense',[])} for x in current.get('expense',[])):raise PermissionError('정산 삭제는 전용 업무 절차를 사용하세요.')
    for item in state.get('expense',[]):
        previous=old_expenses.get(identity(item))
        if previous==item:continue
        expense(item,cards)
        if not trusted and previous is None:raise PermissionError('새 정산은 전용 신청 API를 사용하세요.')
        if not trusted:
            if item.get('status')!='승인대기' or any(item.get(f) for f in ('approvedBy','approvedAt','rejectedBy','rejectedAt')):raise PermissionError('정산 승인은 전용 업무 API를 사용하세요.')
            if item.get('requester')!=user:raise PermissionError('정산 신청자는 현재 사용자여야 합니다.')
    if not trusted:
        old_docs={identity(x):x for x in current.get('reports',[])}
        if set(old_docs)!={identity(x) for x in state.get('reports',[])} or any(old_docs.get(identity(x))!=x for x in state.get('reports',[])):raise PermissionError('보고서 작성·결재는 전용 업무 API를 사용하세요.')
    for field in ('chat','inbox'):
        old={str(x.get('id')):x for x in current.get(field,[])}
        for item in state.get(field,[]):
            previous=old.get(str(item.get('id')))
            if previous==item:continue
            if field=='inbox' and previous and previous.get('recipient')==user and all(item.get(k)==v for k,v in previous.items() if k!='read'):continue
            if item.get('sender')!=user:raise PermissionError('다른 사용자의 메시지를 생성·변경할 수 없습니다.')
    hipass_numbers=set()
    for item in state.get('hipass',[]):
        num=item.get('num','');key=re.sub(r'[\s-]','',str(num)).casefold()
        if not key or key in hipass_numbers:raise ValueError('하이패스 번호 누락 또는 중복')
        hipass_numbers.add(key)
        previous=next((x for x in current.get('hipass',[]) if identity(x)==identity(item)),None)
        if previous==item:continue
        if previous is None and not trusted:raise PermissionError('하이패스 등록은 전용 API를 사용하세요.')
        if item.get('type') not in ('선불형','후불형') or not item.get('company') or not item.get('hipassUser'):raise ValueError('하이패스 종류·발급사·사용자가 필요합니다.')
        date_value(item.get('issueDate'),'발급일',True);date_value(item.get('expiryDate'),'만료일',True);date_value(item.get('returnDate'),'반납일')
        if item['expiryDate']<item['issueDate']:raise ValueError('하이패스 만료일이 발급일보다 빠릅니다.')
    for field in ('hipass','complaint','reports'):
        for item in state.get(field,[]):
            if not isinstance(item,dict):raise ValueError(field+': 잘못된 형식입니다.')
            previous=next((x for x in current.get(field,[]) if identity(x)==identity(item)),None)
            if previous==item:continue
            if item.get('group') not in BRANCHES:raise ValueError(field+': 지점이 필요합니다.')
            if field=='complaint' and (not item.get('title') or not item.get('content')):raise ValueError('민원 제목과 내용이 필요합니다.')
    def strings(value):
        if isinstance(value,str) and len(value)>200000:raise ValueError('항목의 문자열이 너무 깁니다.')
        if isinstance(value,dict):
            for v in value.values():strings(v)
        if isinstance(value,list):
            for v in value:strings(v)
    strings(state)

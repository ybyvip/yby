"""Configure private-network HTTPS using OS certificate tools, without pip packages."""
import argparse
import base64
from datetime import datetime, timezone, timedelta
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import uuid
import zipfile
import startup_diagnostics as diagnostics
import certificate_permissions

ROOT = Path(__file__).resolve().parent
SETTINGS = 'lan_settings.json'
PRIVATE_NETWORKS = tuple(ipaddress.ip_network(x) for x in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'))


def private_ip(value):
    address = ipaddress.IPv4Address(value)
    if not any(address in network for network in PRIVATE_NETWORKS):
        raise ValueError('사내망 IPv4 주소(10.x, 172.16~31.x, 192.168.x)를 지정하세요.')
    return str(address)


def local_ips():
    addresses = set()
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            try: addresses.add(private_ip(item[4][0]))
            except ValueError: pass
    except OSError:
        pass
    return sorted(addresses, key=lambda x: int(ipaddress.ip_address(x)))


def assigned_ip(value):
    value = private_ip(value)
    with socket.socket() as probe:
        probe.bind((value, 0))
    return value


def load_settings(root=ROOT):
    diagnostics.stage('기존 사내망 설정 확인',Path(root)/SETTINGS)
    certificates=Path(root)/'certificates'
    if certificate_permissions.is_windows() and certificates.is_dir():
        # Repair V4.1.0 file ACLs before opening any existing certificate.
        protect_certificate_directory(certificates)
    path = Path(root) / SETTINGS
    if not path.exists(): return None
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('format') != 1 or data.get('mode') != 'lan-https':
        raise ValueError('lan_settings.json 형식이 잘못되었습니다. RUN_LAN_WINDOWS.bat로 다시 설정하세요.')
    private_ip(data['server_ip'])
    if type(data['port']) is not int or not 1 <= data['port'] <= 65535:
        raise ValueError('접속 포트는 1~65535여야 합니다.')
    if not re.fullmatch(r'[A-Za-z0-9.-]{1,253}', data['hostname']):
        raise ValueError('서버 이름 형식이 잘못되었습니다.')
    for name in ('server.pem', 'server-key.pem', 'root-ca.pem', 'root-ca.cer'):
        if not (Path(root)/'certificates'/name).is_file():
            raise ValueError('HTTPS 인증서가 없습니다. RUN_LAN_WINDOWS.bat로 설정하세요.')
    ssl.create_default_context(cafile=str(Path(root)/'certificates/root-ca.pem'))
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(str(Path(root)/'certificates/server.pem'), str(Path(root)/'certificates/server-key.pem'))
    return data


def configured_env(root, env, settings):
    result = dict(env)
    result.update(V3_HOST='0.0.0.0', V3_PORT=str(settings['port']), V4_LAN_SERVER_IP=settings['server_ip'],
                  V3_TLS_CERT=str(Path(root)/'certificates/server.pem'),
                  V3_TLS_KEY=str(Path(root)/'certificates/server-key.pem'),
                  V3_TLS_CA=str(Path(root)/'certificates/root-ca.pem'))
    return result


def pem(label, raw):
    encoded = base64.b64encode(raw).decode('ascii')
    return ('-----BEGIN '+label+'-----\n'+'\n'.join(encoded[i:i+64] for i in range(0,len(encoded),64))+'\n-----END '+label+'-----\n').encode('ascii')


def der_length(size):
    if size < 128: return bytes([size])
    raw = size.to_bytes((size.bit_length()+7)//8, 'big')
    return bytes([0x80 | len(raw)]) + raw


def rsa_private_pem(parameters):
    # Serialize OS-generated RSA parameters as standard PKCS#1; no key generation here.
    integers = [b'\0']
    for name in ('Modulus','Exponent','D','P','Q','DP','DQ','InverseQ'):
        raw = base64.b64decode(parameters[name], validate=True).lstrip(b'\0') or b'\0'
        if raw[0] & 128: raw = b'\0'+raw
        integers.append(raw)
    body = b''.join(b'\x02'+der_length(len(raw))+raw for raw in integers)
    return pem('RSA PRIVATE KEY', b'\x30'+der_length(len(body))+body)


def run_tool(arguments):
    result = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace')
    if result.returncode:
        # Never print private parameters or tool stdout. Errors from these fixed tools contain diagnostics only.
        raise RuntimeError('인증서 도구 실행 실패: '+result.stderr[-1600:])
    return result


def protect_certificate_directory(directory):
    diagnostics.stage('인증서 폴더 접근권한 설정',directory)
    certificate_permissions.protect(directory)


def create_certificates(root, target, server_ip, hostname, previous):
    diagnostics.stage('HTTPS 인증서 생성',target)
    previous_dir = Path(root)/'certificates'
    if os.name == 'nt':
        request = {'server_ip':server_ip, 'hostname':hostname, 'id':uuid.uuid4().hex[:12],
                   'root_thumbprint':previous.get('root_thumbprint','') if previous else ''}
        request_path=target/'request.json'; output_path=target/'parameters.json'
        request_path.write_text(json.dumps(request),encoding='utf-8')
        run_tool(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(Path(root)/'tools/create_lan_certificate.ps1'),'-RequestPath',str(request_path),'-OutputPath',str(output_path)])
        result=json.loads(output_path.read_text(encoding='utf-8-sig'))
        leaf=base64.b64decode(result['certificate'],validate=True)
        ca=base64.b64decode(result['root_certificate'],validate=True)
        (target/'server.pem').write_bytes(pem('CERTIFICATE',leaf)+pem('CERTIFICATE',ca))
        (target/'server-key.pem').write_bytes(rsa_private_pem(result['parameters']))
        (target/'root-ca.pem').write_bytes(pem('CERTIFICATE',ca))
        (target/'root-ca.cer').write_bytes(ca)
        return {'root_thumbprint':result['root_thumbprint'],'expires_utc':result['expires_utc']}
    openssl=shutil.which('openssl')
    if not openssl: raise RuntimeError('Linux 사내망 인증서 생성에는 openssl 명령이 필요합니다.')
    if previous:
        for name in ('root-ca.pem','root-ca.cer','root-ca-key.pem'):
            if not (previous_dir/name).is_file():raise RuntimeError('기존 CA 개인키가 없습니다. 원본 certificates 폴더를 복원하세요.')
            shutil.copy2(previous_dir/name,target/name)
    else:
        run_tool([openssl,'req','-x509','-newkey','rsa:3072','-nodes','-sha256','-days','1825','-subj','/CN=YBY LAN Root '+uuid.uuid4().hex[:12],'-addext','basicConstraints=critical,CA:TRUE,pathlen:0','-addext','keyUsage=critical,keyCertSign,cRLSign','-keyout',str(target/'root-ca-key.pem'),'-out',str(target/'root-ca.pem')])
        run_tool([openssl,'x509','-in',str(target/'root-ca.pem'),'-outform','DER','-out',str(target/'root-ca.cer')])
    extension=target/'extension.cnf'
    extension.write_text('basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\nsubjectAltName=DNS:localhost,DNS:'+hostname+',IP:127.0.0.1,IP:'+server_ip+'\n',encoding='ascii')
    run_tool([openssl,'req','-new','-newkey','rsa:3072','-nodes','-sha256','-subj','/CN='+hostname,'-keyout',str(target/'server-key.pem'),'-out',str(target/'server.csr')])
    run_tool([openssl,'x509','-req','-sha256','-days','365','-in',str(target/'server.csr'),'-CA',str(target/'root-ca.pem'),'-CAkey',str(target/'root-ca-key.pem'),'-set_serial',str(uuid.uuid4().int),'-extfile',str(extension),'-out',str(target/'server.pem')])
    (target/'server.pem').write_bytes((target/'server.pem').read_bytes()+(target/'root-ca.pem').read_bytes())
    return {'root_thumbprint':'','expires_utc':(datetime.now(timezone.utc)+timedelta(days=365)).isoformat()}


def export_client(root, settings):
    client=Path(root)/'LAN_CLIENT';client.mkdir(exist_ok=True)
    diagnostics.stage('다른 PC용 공개 인증서 읽기',Path(root)/'certificates/root-ca.cer')
    ca=(Path(root)/'certificates/root-ca.cer').read_bytes()
    (client/'YBY_LAN_ROOT.cer').write_bytes(ca)
    info={'url':f"https://{settings['server_ip']}:{settings['port']}", 'server_ip':settings['server_ip'],
          'port':settings['port'], 'sha256':hashlib.sha256(ca).hexdigest().upper()}
    (client/'connection.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
    for name in ('INSTALL_AND_CONNECT.bat','CHECK_CONNECTION.bat','client_connect.ps1'):
        shutil.copy2(Path(root)/'tools/client_templates'/name, client/name)
    text='''YBY 사내망 접속용 폴더 — 개인키/업무 자료 없음

1. 이 LAN_CLIENT 폴더만 다른 PC로 복사합니다. 프로그램 전체/certificates 폴더는 공유하지 마세요.
2. INSTALL_AND_CONNECT.bat를 일반 더블클릭합니다. 서버 화면과 아래 인증서 SHA-256을 비교하고 등록 창에서 예를 누릅니다.
3. 현재 Windows 사용자에게 이 YBY 서버 전용 CA를 최초 1회 등록한 뒤 브라우저를 엽니다. 이후에는 등록 질문 없이 연결합니다.
4. CHECK_CONNECTION.bat는 서버 포트/HTTPS/인증서 연결을 검사합니다.
5. 인증서 경고를 무시하지 마세요. 회사 정책상 인증서 설치가 차단되면 IT 관리자에게 문의하세요.

접속 주소: {url}
CA 인증서 SHA-256: {sha256}

같은 사내망 또는 해당 주소로 연결 가능한 회사 VPN에서만 사용합니다.
서버 PC가 꺼졌거나 실행 창을 닫으면 접속할 수 없습니다.
서버 IP가 바뀌면 서버에서 RUN_LAN_WINDOWS.bat를 다시 실행하고 이 폴더를 다시 받으세요.
CA 신뢰 해제: certmgr.msc > 신뢰할 수 있는 루트 인증 기관 > 인증서에서
해당 YBY LAN Root 인증서를 지문으로 확인하여 삭제합니다. 다른 인증서는 삭제하지 마세요.
'''.format(**info)
    (client/'접속안내.txt').write_text(text,encoding='utf-8-sig')
    # Include only public, known files, even if unrelated files exist in LAN_CLIENT.
    bundle=root/'LAN_CLIENT.zip';temporary=bundle.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for name in ('YBY_LAN_ROOT.cer','connection.json','INSTALL_AND_CONNECT.bat','CHECK_CONNECTION.bat','client_connect.ps1','접속안내.txt'):
            archive.write(client/name,'LAN_CLIENT/'+name)
    os.replace(temporary,bundle)
    return info


def ensure_configuration(root=ROOT, server_ip=None, port=None, interactive=True):
    root=Path(root)
    previous=load_settings(root)
    candidates=local_ips()
    if server_ip is None:
        if previous:
            try: server_ip=assigned_ip(previous['server_ip'])
            except OSError: pass
        if server_ip is None and len(candidates)==1:server_ip=candidates[0]
        if server_ip is None:
            if not interactive:raise RuntimeError('서버 IP를 --server-ip로 지정하세요. 후보: '+', '.join(candidates))
            print('사내망 IP 후보: '+(', '.join(candidates) or '자동 확인 실패'))
            server_ip=input('다른 PC에서 사용할 이 서버 PC의 사내망 IPv4 주소: ').strip()
    try: server_ip=assigned_ip(server_ip)
    except OSError as error:raise RuntimeError('지정한 IP가 이 서버 PC에 없습니다. ipconfig의 IPv4 주소를 확인하세요.') from error
    hostname=socket.gethostname().rstrip('.')
    if not re.fullmatch(r'[A-Za-z0-9.-]{1,253}',hostname):hostname='yby-server'
    port=port if port is not None else (previous['port'] if previous else 5000)
    if type(port) is not int or not 1<=port<=65535:raise ValueError('포트 범위는 1~65535입니다.')
    renew=not previous or previous['server_ip']!=server_ip or previous['hostname']!=hostname
    if previous:
        renew=renew or datetime.fromisoformat(previous['expires_utc'])<=datetime.now(timezone.utc)+timedelta(days=30)
    settings=dict(previous or {},format=1,mode='lan-https',server_ip=server_ip,hostname=hostname,port=port,python_executable=sys.executable)
    if renew:
        print('이 PC의 사내망 HTTPS 인증서를 준비합니다. 개인키는 서버에만 보관합니다.',flush=True)
        with tempfile.TemporaryDirectory(prefix='.yby-cert-',dir=root) as temp:
            target=Path(temp)
            protect_certificate_directory(target)
            settings.update(create_certificates(root,target,server_ip,hostname,previous))
            context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(str(target/'server.pem'),str(target/'server-key.pem'))
            ssl.create_default_context(cafile=str(target/'root-ca.pem'))
            certificates=root/'certificates';certificates.mkdir(exist_ok=True)
            protect_certificate_directory(certificates)
            for name in ('server.pem','server-key.pem','root-ca.pem','root-ca.cer','root-ca-key.pem'):
                path=target/name
                if path.exists():
                    path.chmod(0o600)
                    os.replace(path,certificates/name)
            protect_certificate_directory(certificates)
            certificate_permissions.check_readable(certificates)
    temp_settings=root/(SETTINGS+'.tmp')
    diagnostics.stage('사내망 설정 저장',root/SETTINGS)
    # ASCII JSON is also read correctly by Windows PowerShell 5.1 with Korean user paths.
    temp_settings.write_text(json.dumps(settings,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
    os.replace(temp_settings,root/SETTINGS)
    info=export_client(root,settings)
    print('다른 PC 접속 주소: '+info['url'])
    print('CA 인증서 SHA-256: '+info['sha256'])
    print('다른 PC 전달 파일: '+str(root/'LAN_CLIENT.zip'))
    print('OPEN_LAN_CLIENT.bat로 전달 ZIP 위치를 열 수 있습니다.')
    print('다른 PC: LAN_CLIENT.zip 압축 해제 → INSTALL_AND_CONNECT.bat 일반 더블클릭')
    print('서버 인증서: 첫 접속 시 등록 창에서 예를 누르세요. 재접속은 CONNECT_SERVER.bat')
    print('서버 방화벽: SETUP_SERVER_FIREWALL.bat를 1회 실행하고 관리자 승인하세요.')
    return settings


def main():
    parser=argparse.ArgumentParser(description='YBY 사내망 HTTPS 설정')
    parser.add_argument('--server-ip');parser.add_argument('--port',type=int)
    args=parser.parse_args()
    from db_lock import DatabaseLock
    data=Path(os.environ.get('V3_DATA_DIR',str(ROOT/'data')))
    with DatabaseLock(data):ensure_configuration(ROOT,args.server_ip,args.port,sys.stdin.isatty())


if __name__=='__main__':
    os.umask(0o077)
    try:main()
    except Exception as error:diagnostics.report(error,ROOT);raise SystemExit(1)

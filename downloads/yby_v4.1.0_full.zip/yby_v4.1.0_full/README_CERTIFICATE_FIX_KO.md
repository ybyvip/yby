# 기존 인증서 접근권한 복구

V4.1.0은 폴더의 상속 권한과 파일의 직접 권한을 분리합니다. 기존 V4.0.2/4.0.3의 인증서 소유권이 이미 손상되어 일반 권한으로 변경할 수 없다면 서버를 종료하고 REPAIR_CERTIFICATE_OWNER.bat를 **일반 더블클릭**하세요. 도구가 원래 사용자를 확인한 후 요청하는 UAC를 승인합니다. 도구를 처음부터 다른 관리자로 실행하지 마세요.

이 도구는 원래 프로필의 certificates 및 정해진 인증서 파일만 처리하고 DB/인증서 내용을 삭제·재생성하지 않습니다. 개인키를 표시하지 않습니다. 마지막 일반 사용자 Python 검사에서 PASS가 나온 뒤 RUN_LAN_WINDOWS.bat를 일반 실행하세요. 관리자 승인이 불가능하면 IT 담당자의 지원이 필요합니다.

브라우저의 ERR_CERT_AUTHORITY_INVALID는 파일 접근권한과 별개입니다. 서버 CONNECT_SERVER.bat 또는 다른 PC INSTALL_AND_CONNECT.bat의 최초 신뢰 등록 절차를 따르세요. 최신 전체 절차는 README_LAN_KO.md를 확인하세요.

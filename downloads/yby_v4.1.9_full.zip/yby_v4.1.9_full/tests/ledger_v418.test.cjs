const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../static/history-ledger-v418.js');
const issue=(id,extra={})=>({id,type:'불출',group:'서울',cardNum:'5545',user:'사용자',dept:'총무',time:`2026-10-19T00:00:0${id}Z`,rentDate:'2026-10-19',...extra});
const ret=(id,extra={})=>({...issue(id),type:'반납',used:false,...extra});
const approved=(id,extra={})=>({id,group:'서울',requester:'branch',cardNum:'5545',status:'승인완료',amount:100,category:'식대',...extra});

test('mixed legacy Korean and UTC dates sort newest, numeric IDs break equal timestamps, source unchanged',()=>{
 const rows=[{id:1,time:'2026-10-19 10:00:00'},{id:2,time:'2026-10-19T01:00:00Z'},{id:3,time:'2026-10-19T00:59:00Z'},{id:9,time:''}];
 assert.deepEqual(L.newest(rows).map(r=>r.id),[2,1,3,9]);assert.deepEqual(rows.map(r=>r.id),[1,2,3,9]);
});
test('each rental occurrence pairs only with its return, current occurrence stays pending',()=>{
 const a=issue(1),b=ret(2,{rentalEventId:1}),c=issue(3);
 const context=L.cardContext([c,b,a],[{group:'서울',num:'5545',status:'rented',user:'사용자',rentalEventId:3}],[],'ALL');
 assert.match(context.progress(a).label,/반납완료.*미사용/);assert.match(context.progress(c).label,/반납대기/);
 assert.equal(context.count(a),2);assert.equal(context.count(b),2);
});
test('counts isolate branches, cards may differ, empty names stay unknown',()=>{
 const a=issue(1),b=issue(2,{group:'인천'}),c=issue(3,{cardNum:'7777'});
 const ctx=L.cardContext([a,b,c,issue(4,{user:''})],[],[],'서울');
 assert.equal(ctx.count(a),2);assert.equal(ctx.count(b),0);assert.equal(ctx.count({user:''}),null);
});
test('unambiguous legacy rentals pair chronologically; legacy settlement is not guessed',()=>{
 const a=issue(1),b=ret(2,{used:true});
 const ctx=L.cardContext([b,a],[],[approved('unrelated')],'ALL');
 assert.equal(ctx.progress(a).label,'반납완료 · 정산 이력 확인');
});
test('conflicting legacy rentals, wrong user and invalid explicit links do not get paired',()=>{
 const a=issue(1),b=issue(2),r=ret(3);
 const ctx=L.cardContext([a,b,r],[],[],'ALL');
 assert.match(ctx.progress(a).label,/확인 필요/);assert.match(ctx.progress(b).label,/확인 필요/);
 for(const extra of [{user:'다른 사람'},{rentalEventId:999}]){
  const other=L.cardContext([a,ret(2,extra)],[],[],'ALL');assert.match(other.progress(a).label,/확인 필요/);
 }
});
test('linked settlement follows rejection, cancellation and multiple resubmission stages',()=>{
 const a=issue(1),ref={id:'root',group:'서울',requester:'branch'},b=ret(2,{rentalEventId:1,used:true,expenseRef:ref});
 const root=approved('root',{status:'승인취소',resubmissionId:'child'});
 for(const status of ['재보고대기','승인대기','반려됨','승인완료']){
  const child=approved('child',{status});const ctx=L.cardContext([a,b],[],[root,child],'ALL');assert.equal(ctx.progress(a).label,'반납완료 · '+status);
 }
 const child=approved('child',{status:'반려됨',resubmissionId:'last'}),last=approved('last');
 assert.match(L.cardContext([a,b],[],[root,child,last],'ALL').progress(b).label,/승인완료/);
});
test('expense refs cannot borrow another card or branch; cyclic legacy chains terminate',()=>{
 const a=issue(1),b=ret(2,{used:true,expenseRef:{group:'인천',requester:'branch',id:'x'}});
 assert.match(L.cardContext([a,b],[],[approved('x',{group:'인천'})],'ALL').progress(b).label,/정산 이력 확인/);
 b.expenseRef={group:'서울',requester:'branch',id:'x'};
 assert.match(L.cardContext([a,b],[],[approved('x',{cardNum:'7777'})],'ALL').progress(b).label,/정산 이력 확인/);
 assert.doesNotThrow(()=>L.cardContext([a,b],[],[approved('x',{resubmissionId:'x'})],'ALL').progress(b));
});
test('summary counts transaction lines, not quantities; categories share document counts without double counting money',()=>{
 const row=approved('a',{amount:23000,category:'복수 항목',lineItems:[{category:'식대',quantity:2,amount:18000},{category:'교통',quantity:1,amount:3000},{category:'교통',quantity:1,amount:2000}]});
 const s=L.summary([row],'서울');
 assert.equal(s.approvedDocuments,1);assert.equal(s.usageCount,3);assert.equal(s.amount,23000);assert.equal(s.invalidAmounts,0);
 assert.deepEqual(s.categories,[{name:'식대',documents:1,count:1,amount:18000},{name:'교통',documents:1,count:2,amount:5000}]);
});
test('cancelled/rejected/replaced originals and legacy credits do not inflate approved metrics',()=>{
 const rows=[approved('cancel',{status:'승인취소'}),approved('reject',{status:'반려됨'}),approved('old',{correctionId:'credit'}),approved('credit',{amount:-100,isCorrection:true}),approved('again',{amount:250})];
 const s=L.summary(rows,'서울');assert.equal(s.documents,5);assert.equal(s.approvedDocuments,1);assert.equal(s.usageCount,1);assert.equal(s.amount,250);assert.equal(s.cancelled,1);assert.equal(s.rejected,1);
});
test('empty/filter/branch summaries do not include unavailable records',()=>{
 const s=L.summary([approved('s'),approved('i',{group:'인천',amount:9000})],'서울');assert.equal(s.documents,1);assert.equal(s.amount,100);
 const empty=L.summary([],'ALL');assert.equal(empty.amount,0);assert.equal(empty.usageCount,0);assert.deepEqual(empty.categories,[]);
});
test('invalid or unsafe amounts and inconsistent detail totals are explicitly flagged',()=>{
 for(const row of [approved('a',{amount:'invalid'}),approved('b',{amount:150,lineItems:[{amount:100}]}),approved('c',{amount:Number.MAX_SAFE_INTEGER+1}),approved('d',{amount:true}),approved('e',{amount:-100})])assert.ok(L.summary([row],'ALL').invalidAmounts>0);
});
test('category and user strings such as __proto__ do not corrupt dictionaries',()=>{
 const s=L.summary([approved('a',{category:'__proto__'})],'ALL');assert.equal(s.categories[0].name,'__proto__');assert.equal(s.amount,100);
 const a=issue(1,{user:'__proto__'});assert.equal(L.cardContext([a],[],[],'ALL').count(a),1);
});

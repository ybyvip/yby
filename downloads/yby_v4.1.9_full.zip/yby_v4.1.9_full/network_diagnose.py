"""Read-only checks of saved LAN configuration, TCP, trusted TLS and app health."""
import json
from pathlib import Path
import socket
import ssl
import sys
import urllib.error
import urllib.request
import lan_setup

ROOT=Path(__file__).resolve().parent


def main():
    print('이 PC의 사내망 IPv4 후보: '+', '.join(lan_setup.local_ips()))
    settings=lan_setup.load_settings(ROOT)
    if not settings:
        raise RuntimeError('현재는 기본 로컬 전용 설정입니다. 서버에서 RUN_LAN_WINDOWS.bat를 실행하세요.')
    ip=settings['server_ip'];port=settings['port'];url=f'https://{ip}:{port}'
    print('설정된 접속 주소: '+url)
    lan_setup.assigned_ip(ip)
    print('PASS: 설정된 IPv4가 이 PC에 할당되어 있습니다.')
    with socket.create_connection((ip,port),timeout=3):pass
    print('PASS: 사내망 주소의 TCP 포트가 열려 있습니다.')
    context=ssl.create_default_context(cafile=str(ROOT/'certificates/root-ca.pem'))
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
    with opener.open(url+'/health',timeout=5) as response:health=json.load(response)
    if health.get('version')!='4.1.9' or not health.get('ok') or not health.get('database'):
        raise RuntimeError('응답이 정상 YBY V4.1.9 서버가 아닙니다.')
    print('PASS: 인증서 체인·IP·HTTPS·버전·DB 상태 확인 완료.')
    print('다른 PC에서는 LAN_CLIENT/CHECK_CONNECTION.bat로 별도 검사하세요.')
    print('이 검사는 다른 PC의 방화벽·VPN 경로까지 확인한 결과는 아닙니다.')


if __name__=='__main__':
    try:main()
    except Exception as error:
        print('진단 실패: '+str(error),file=sys.stderr)
        print('서버 실행 창, 현재 IPv4, Domain/Private 방화벽 및 회사 VPN 경로를 확인하세요.',file=sys.stderr)
        raise SystemExit(1)

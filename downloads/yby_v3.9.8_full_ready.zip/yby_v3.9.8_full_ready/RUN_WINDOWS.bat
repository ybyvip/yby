@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 or later is required. Install it with "Add Python to PATH" enabled.
pause
exit /b 1
:use_py
py -3 "%~dp0run_ready.py" %*
goto finished
:use_python
python "%~dp0run_ready.py" %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo Server stopped. Read any error messages above.
pause
exit /b %RESULT%

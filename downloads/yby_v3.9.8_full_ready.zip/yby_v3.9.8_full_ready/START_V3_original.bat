@echo off
rem Legacy entry point delegates to the current, verified launcher.
call "%~dp0START_V3.bat"

"""Portable setup/start wrapper. Original V3.9.8 application files are unchanged."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import time
import urllib.request
import venv
import webbrowser

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 or later is required.')
    os.umask(0o077)
    python = ROOT / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.is_file():
        print('Preparing the local Python virtual environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(ROOT / '.venv')
    check = subprocess.run(
        [str(python), '-c', 'import cryptography; assert cryptography.__version__ == "46.0.5"'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if check.returncode:
        subprocess.run([str(python), '-m', 'pip', 'install', '--disable-pip-version-check',
                        '--no-cache-dir', '-r', str(ROOT / 'requirements.txt')], check=True)
    env = os.environ.copy()
    env.setdefault('V3_HOST', '127.0.0.1')
    env.setdefault('V3_PORT', '5000')
    env['V3_AUTO_BROWSER'] = '0'
    port = int(env['V3_PORT'])
    if bool(env.get('V3_TLS_CERT')) != bool(env.get('V3_TLS_KEY')):
        raise RuntimeError('Set V3_TLS_CERT and V3_TLS_KEY together.')
    tls = bool(env.get('V3_TLS_CERT'))
    context = ssl.create_default_context(cafile=env.get('V3_TLS_CA')) if tls else None
    url = f'https://localhost:{port}/' if tls else f'http://127.0.0.1:{port}/'
    for attempt in range(150):
        try:
            with socket.socket() as probe:
                probe.bind((env['V3_HOST'], port))
            break
        except OSError as error:
            if error.errno not in (48, 98, 10048):
                raise
            with socket.socket() as listener:
                listener.settimeout(1)
                if listener.connect_ex(('127.0.0.1', port)) == 0:
                    raise RuntimeError(f'Port {port} is in use. Stop your previous server first.')
            if attempt == 0:
                print('Waiting for the recently closed server port to be released...', flush=True)
            time.sleep(0.5)
    else:
        raise RuntimeError(f'Port {port} is still unavailable.')

    process = subprocess.Popen([str(python), '-u', str(ROOT / 'app.py')], cwd=ROOT, env=env)
    try:
        for attempt in range(80):
            if process.poll() is not None:
                raise RuntimeError(f'Server exited with code {process.returncode}; see the output above.')
            try:
                with urllib.request.urlopen(url + 'health', context=context, timeout=2) as response:
                    health = json.load(response)
                if health.get('ok') and health.get('database') and health.get('version') == '3.9.8':
                    break
            except OSError:
                pass
            time.sleep(0.15)
        else:
            raise RuntimeError('Server readiness timed out.')
        with urllib.request.urlopen(url, context=context, timeout=5) as response:
            html = response.read().decode('utf-8')
            if 'value="admin"' not in html or '3.9.8' not in html:
                raise RuntimeError('The V3.9.8 login page did not load correctly.')
        print(f'READY V3.9.8: {url}', flush=True)
        print('Keep this window open. Press Ctrl+C to stop the server.', flush=True)
        if not args.no_browser:
            webbrowser.open(url, new=1)
        return process.wait()
    except KeyboardInterrupt:
        return 0
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def stop_on_signal(signum, frame):
    raise KeyboardInterrupt


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, stop_on_signal)
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f'ERROR: {error}', file=sys.stderr)
        raise SystemExit(1)

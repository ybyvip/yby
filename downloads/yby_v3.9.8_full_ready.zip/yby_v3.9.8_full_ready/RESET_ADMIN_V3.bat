@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo 서버를 먼저 종료한 뒤 새 관리자 비밀번호를 지정하세요.
where py.exe >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0reset_admin.py"
  goto finished
)
where python.exe >nul 2>&1
if not errorlevel 1 (
  python "%~dp0reset_admin.py"
  goto finished
)
echo Python 3.11 이상이 필요합니다.
:finished
pause

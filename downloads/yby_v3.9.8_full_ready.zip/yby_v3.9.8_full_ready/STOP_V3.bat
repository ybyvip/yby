@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo V3 서버 포트(5000~5010)에서 실행 중인 프로그램 서버를 종료합니다...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ports=5000..5010; $ids=@(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $ports -contains $_.LocalPort } | Select-Object -ExpandProperty OwningProcess -Unique); $servers=Get-CimInstance Win32_Process | Where-Object { $ids -contains $_.ProcessId -and $_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -match '(?i)app\.py' }; if($servers){$servers | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Write-Host 'V3 서버 종료를 요청했습니다.'} else {Write-Host '해당 포트에서 종료 대상 V3 서버를 찾지 못했습니다.'}"
echo 서버를 다시 시작하려면 START_V3.bat을 실행하세요.
pause

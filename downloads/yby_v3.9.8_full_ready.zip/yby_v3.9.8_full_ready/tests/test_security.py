"""Run from the program folder: python -m unittest discover -s tests -v."""
import base64
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('reviewed_app', ROOT/'app.py')
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)


class SecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        app.DB_PATH = Path(cls.temp.name)/'test.db'
        app.BACKUP_DIR = Path(cls.temp.name)/'backups'; app.BACKUP_DIR.mkdir()
        app.ATTACHMENT_DIR = Path(cls.temp.name)/'attachments'; app.ATTACHMENT_DIR.mkdir()
        with contextlib.redirect_stdout(io.StringIO()):
            app.prepare_db()
        cls.admin_hash = app.phash('Admin-test-pass!')
        cls.branch_hash = app.phash('Branch-test-pass!')
        cls.server = app.ThreadingHTTPServer(('127.0.0.1',0), app.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True); cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(); cls.temp.cleanup()

    def setUp(self):
        app.SESSIONS.clear(); app.SESSION_ACTIVITY.clear(); app.SESSION_IPS.clear(); app.LOGIN_FAILURES.clear()
        with app.db() as conn:
            conn.execute('DELETE FROM system_state'); conn.execute('DELETE FROM audit_events');conn.execute('DELETE FROM account_change_history');conn.execute('DELETE FROM password_display')
            conn.execute("DELETE FROM users WHERE username NOT IN ('admin')")
            conn.execute('UPDATE users SET password_hash=?,active=1,must_change_password=0 WHERE username=?',(self.admin_hash,'admin'))
            conn.execute('INSERT INTO users(username,password_hash,scope,permissions_json,active,must_change_password) VALUES(?,?,?,?,1,0)',
                         ('branch',self.branch_hash,'서울',json.dumps(['v_card_rent','v_expense','v_report_write','v_report_box'])))
            conn.execute('INSERT INTO users(username,password_hash,scope,permissions_json,active,must_change_password) VALUES(?,?,?,?,1,0)',
                         ('readonly',self.branch_hash,'서울','[]'))
            conn.commit()
        self.admin = self.login('admin','Admin-test-pass!')
        self.branch = self.login('branch','Branch-test-pass!')

    def request(self,path,data=None,cookie=None,headers=None):
        h={'Content-Type':'application/json'}; h.update(headers or {})
        if cookie: h['Cookie']=cookie
        request=urllib.request.Request(f'http://127.0.0.1:{self.server.server_port}'+path,
                                       data=json.dumps(data).encode() if data is not None else None,headers=h)
        try: response=urllib.request.urlopen(request,timeout=15)
        except urllib.error.HTTPError as error: response=error
        body=response.read()
        value=json.loads(body) if response.headers.get_content_type()=='application/json' else body
        return response.status,value,response.headers

    def login(self,username,password):
        status,body,headers=self.request('/api/login',{'username':username,'password':password})
        self.assertEqual(status,200,body)
        return headers['Set-Cookie'].split(';')[0]

    def state(self,cookie):
        status,body,_=self.request('/api/state',cookie=cookie); self.assertEqual(status,200,body)
        return body

    def save(self,state,cookie,revision=None):
        if revision is None: revision=self.state(cookie)['revision']
        return self.request('/api/state',{'state':state,'revision':revision},cookie)

    def test_health_and_local_assets(self):
        self.assertTrue(self.request('/health')[1]['database'])
        for name in ['chart.umd.min.js','xlsx.full.min.js']:
            self.assertEqual(self.request('/static/vendor/'+name)[0],200)
        self.assertEqual(self.request('/static/vendor/unknown.js')[0],404)

    def test_login_and_password_verify(self):
        self.assertEqual(self.request('/api/login',{'username':'admin','password':'wrong'})[0],401)
        self.assertEqual(self.request('/api/verify-current-password',{'password':'Admin-test-pass!'},self.admin)[0],200)
        self.assertEqual(self.request('/api/verify-current-password',{'password':'wrong'},self.admin)[0],403)

    def test_session_expiry(self):
        token=self.branch.split('=',1)[1]; app.SESSION_ACTIVITY[token]=time.time()-100
        self.assertEqual(self.request('/api/verify-current-password',{'password':'Branch-test-pass!'},self.branch)[0],401)
        self.assertNotIn(token,app.SESSIONS)

    def test_deleted_account_old_session_blocked(self):
        self.assertEqual(self.request('/api/admin/account-delete',{'username':'branch'},self.admin)[0],200)
        self.assertEqual(self.request('/api/audit',cookie=self.branch)[0],401)
        self.assertEqual(self.request('/api/login',{'username':'branch','password':'Branch-test-pass!'})[0],401)

    def test_deleted_account_stale_state_and_restart_do_not_restore(self):
        self.request('/api/admin/account-delete',{'username':'branch'},self.admin)
        stale={'accounts':{'branch':{'passwordHash':app.legacy_hash('Branch-test-pass!'),'scope':'ALL','permissions':app.ALL_VIEWS}}}
        self.assertEqual(self.save(stale,self.admin)[0],200)
        # Also verify legacy migration respects explicit deactivation.
        with app.db() as conn:
            conn.execute('UPDATE system_state SET state_json=?',(json.dumps(stale),));conn.commit()
        with contextlib.redirect_stdout(io.StringIO()): app.init_db()
        self.assertEqual(self.request('/api/login',{'username':'branch','password':'Branch-test-pass!'})[0],401)

    def test_readonly_cannot_save_cards(self):
        cookie=self.login('readonly','Branch-test-pass!')
        self.assertEqual(self.save({'cards':[{'id':1,'group':'서울','num':'TEST'}]},cookie)[0],403)
        self.assertEqual(self.state(cookie)['state']['cards'],[])

    def test_renter_cannot_register_card(self):
        self.assertEqual(self.save({'cards':[{'id':1,'group':'서울','num':'TEST'}]},self.branch)[0],403)

    def test_rent_and_history_allowed(self):
        card={'id':1,'group':'서울','num':'TEST','status':'available','cardKey':'private'}
        self.assertEqual(self.save({'cards':[card]},self.admin)[0],200)
        state=self.state(self.branch)['state']; self.assertNotIn('cardKey',state['cards'][0])
        state['cards'][0].update(status='rented',user='staff',dept='dept',purpose='work',rentDate='2026-10-14',dueDate='2026-10-15')
        state['history']=[{'id':1,'group':'서울','type':'불출','handler':'branch'}]
        self.assertEqual(self.save(state,self.branch)[0],200)
        self.assertEqual(app.get_state()['cards'][0]['cardKey'],'private')

    def test_foreign_branch_write_blocked(self):
        self.assertEqual(self.save({'expense':[{'id':1,'group':'인천','status':'승인대기','requester':'branch'}]},self.branch)[0],403)

    def test_branch_approval_blocked(self):
        self.assertEqual(self.save({'expense':[{'id':1,'group':'서울','status':'승인완료','requester':'branch'}]},self.branch)[0],403)
        self.assertEqual(self.save({'expenseHistory':[{'id':1,'group':'서울','status':'승인완료','requester':'branch'}]},self.branch)[0],403)

    def test_audit_admin_only_and_access_scoped(self):
        self.assertEqual(self.request('/api/audit',cookie=self.branch)[0],403)
        self.assertEqual(self.request('/api/audit',cookie=self.admin)[0],200)
        self.assertEqual(self.request('/api/access-status',cookie=self.branch)[0],403)
        with app.db() as conn:
            conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_access_status']),'branch'));conn.commit()
        status,body,_=self.request('/api/access-status',cookie=self.branch)
        self.assertEqual(status,200); self.assertTrue(all(u['scope']=='서울' for u in body['users']))

    def test_credentials_not_returned_or_changed_by_state(self):
        state=self.state(self.admin)['state']; self.assertNotIn('passwordHash',json.dumps(state)); self.assertNotIn('pbkdf2_sha256',json.dumps(state))
        state['accounts']['branch']={'passwordHash':app.legacy_hash('hacked'),'scope':'ALL','permissions':app.ALL_VIEWS}
        self.assertEqual(self.save(state,self.admin)[0],200)
        with app.db() as conn:
            row=conn.execute("SELECT * FROM users WHERE username='branch'").fetchone()
        self.assertEqual(row['scope'],'서울');self.assertTrue(app.verify_password(row['password_hash'],'Branch-test-pass!'))
        self.assertNotIn('passwordHash',json.dumps(self.request('/api/admin/accounts',cookie=self.admin)[1]))

    def test_password_reset_invalidates_and_requires_change(self):
        body={'username':'branch','scope':'서울','permissions':['v_expense'],'password':'Temporary-pass!'}
        self.assertEqual(self.request('/api/admin/account-update',body,self.admin)[0],200)
        self.assertEqual(self.request('/api/state',cookie=self.branch)[0],401)
        cookie=self.login('branch','Temporary-pass!')
        self.assertEqual(self.request('/api/state',cookie=cookie)[0],403)
        self.assertEqual(self.request('/api/change-password',{'currentPassword':'Temporary-pass!','newPassword':'New-strong-pass!'},cookie)[0],200)
        self.assertEqual(self.request('/api/state',cookie=cookie)[0],401)
        self.assertEqual(self.state(self.login('branch','New-strong-pass!'))['state']['cards'],[])

    def test_explicit_restore_only(self):
        self.request('/api/admin/account-delete',{'username':'branch'},self.admin)
        self.assertEqual(self.request('/api/admin/account-restore',{'username':'branch'},self.admin)[0],200)
        self.login('branch','Branch-test-pass!')

    def test_optimistic_conflict(self):
        snapshot=self.state(self.admin)
        self.assertEqual(self.save({'notices':[{'id':1,'text':'first'}]},self.admin)[0],200)
        status,_,_=self.request('/api/state',{'state':{'notices':[]},'revision':snapshot['revision']},self.admin)
        self.assertEqual(status,409); self.assertEqual(app.get_state()['notices'][0]['text'],'first')

    def test_backup_integrity(self):
        app.backup('test'); paths=list(app.BACKUP_DIR.glob('*_test.db'));self.assertTrue(paths)
        with sqlite3.connect(paths[-1]) as conn:self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0],'ok')

    def test_attachment_recipient_access(self):
        status,body,_=self.request('/api/attachments',{'name':'test.txt','content':base64.b64encode(b'hello').decode(),'recipients':['branch']},self.admin)
        self.assertEqual(status,200)
        path='/api/attachments/'+body['attachment_id'];self.assertEqual(self.request(path,cookie=self.branch)[1],b'hello')
        cookie=self.login('readonly','Branch-test-pass!');self.assertEqual(self.request(path,cookie=cookie)[0],403)

    def test_settlement_permission_and_success(self):
        data={'expense':{'date':'2026-10-14','group':'서울','cardNum':'TEST','user':'staff','merchant':'shop','purpose':'work','category':'food','amount':100}}
        cookie=self.login('readonly','Branch-test-pass!');self.assertEqual(self.request('/api/expense-submit',data,cookie)[0],403)
        status,body,_=self.request('/api/expense-submit',data,self.branch)
        self.assertEqual(status,200);self.assertEqual(body['expense']['status'],'승인대기');self.assertEqual(body['expense']['requester'],'branch')

    def test_cross_origin_rejected_and_json_list_rejected(self):
        self.assertEqual(self.request('/api/logout',{},self.admin,{'Origin':'https://evil.invalid'})[0],403)
        self.assertEqual(self.request('/api/login',[])[0],400)

    def test_rate_limit(self):
        for _ in range(10):self.assertEqual(self.request('/api/login',{'username':'admin','password':'bad'})[0],401)
        self.assertEqual(self.request('/api/login',{'username':'admin','password':'bad'})[0],429)

    def test_sha256_migration_and_default_password_requirement(self):
        with app.db() as conn:
            conn.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(app.legacy_hash('1234'),'branch'));conn.commit()
        with contextlib.redirect_stdout(io.StringIO()):app.init_db()
        with app.db() as conn:row=conn.execute("SELECT * FROM users WHERE username='branch'").fetchone()
        self.assertTrue(row['password_hash'].startswith('pbkdf2_sha256$'))
        self.assertTrue(app.verify_password(row['password_hash'],'1234'));self.assertEqual(row['must_change_password'],1)

    def test_new_account_secure_initial_password(self):
        with contextlib.redirect_stdout(io.StringIO()):app.init_db()
        with app.db() as conn:row=conn.execute("SELECT * FROM users WHERE username='서울 담당자'").fetchone()
        self.assertFalse(app.verify_password(row['password_hash'],'1234'));self.assertEqual(row['must_change_password'],1)

    def test_another_authors_report_is_not_rewritten_on_save(self):
        report={'id':'R1','group':'서울','author':'readonly','status':'pending','title':'original'}
        self.assertEqual(self.save({'reports':[report]},self.admin)[0],200)
        state=self.state(self.branch)['state']
        self.assertEqual(self.save(state,self.branch)[0],200)
        self.assertEqual(app.get_state()['reports'][0]['author'],'readonly')
        state=self.state(self.branch)['state'];state['reports'][0]['title']='modified'
        self.assertEqual(self.save(state,self.branch)[0],403)

    def test_other_users_message_id_cannot_be_overwritten(self):
        message={'id':'M1','sender':'readonly','recipient':'ALL','dm':False,'text':'original'}
        self.assertEqual(self.save({'chat':[message]},self.admin)[0],200)
        state=self.state(self.branch)['state'];state['chat'][0]['sender']='branch';state['chat'][0]['text']='modified'
        self.assertEqual(self.save(state,self.branch)[0],403)
        self.assertEqual(app.get_state()['chat'][0]['text'],'original')

    def test_completed_legacy_expense_migrates_without_duplicates(self):
        record={'id':1,'group':'서울','requester':'branch','date':'2026-10-14','status':'승인완료','amount':100}
        with app.db() as conn:
            conn.execute('INSERT INTO system_state(id,state_json,updated_at) VALUES(1,?,?)',
                         (json.dumps({'expense':[record],'expenseHistory':[]}), 'legacy'));conn.commit()
        with contextlib.redirect_stdout(io.StringIO()):app.init_db();app.init_db()
        state=app.get_state();self.assertEqual(state['expense'],[]);self.assertEqual(state['expenseHistory'],[record])
        self.assertEqual(self.save(self.state(self.branch)['state'],self.branch)[0],200)

    def test_branch_registrar_delete_preserves_other_branch(self):
        with app.db() as conn:
            conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_reg']),'branch'));conn.commit()
        cards=[{'id':1,'group':'서울','num':'SEOUL','status':'available'},
               {'id':2,'group':'인천','num':'INCHEON','status':'available'}]
        self.assertEqual(self.save({'cards':cards},self.admin)[0],200)
        state=self.state(self.branch)['state'];state['cards']=[]
        self.assertEqual(self.save(state,self.branch)[0],200)
        self.assertEqual([item['num'] for item in app.get_state()['cards']],['INCHEON'])


    def test_password_update_records_ledger_and_latest_encrypted_value(self):
        new='Newest-admin-test-pass!'
        status,_,_=self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':new},self.admin)
        self.assertEqual(status,200)
        entries=self.request('/api/admin/account-history',cookie=self.admin)[1]['entries']
        self.assertEqual(len(entries),1);self.assertEqual(entries[0]['action'],'ACCOUNT_PASSWORD_RESET')
        self.assertEqual(entries[0]['actor'],'admin');self.assertEqual(entries[0]['target'],'branch');self.assertTrue(entries[0]['passwordChanged'])
        self.assertNotIn(new,json.dumps(entries))
        accounts=self.request('/api/admin/accounts',cookie=self.admin)[1]['accounts']
        target=next(a for a in accounts if a['username']=='branch')
        self.assertEqual(target['latestPassword'],new);self.assertTrue(target['passwordUpdatedAt'])
        self.assertEqual(target['passwordUpdatedBy'],'admin')
        with app.db() as conn:
            token=conn.execute("SELECT ciphertext FROM password_display WHERE username='branch'").fetchone()[0]
        self.assertNotIn(new,token);self.assertNotIn(new,app.DB_PATH.read_bytes().decode('latin1'))
        with contextlib.redirect_stdout(io.StringIO()):app.init_db()
        again=self.request('/api/admin/accounts',cookie=self.admin)[1]['accounts']
        self.assertEqual(next(a for a in again if a['username']=='branch')['latestPassword'],new)
        self.assertEqual(len(self.request('/api/admin/account-history',cookie=self.admin)[1]['entries']),1)

    def test_permission_only_change_records_delta_without_erasing_password(self):
        self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':'Latest-test-pass!'},self.admin)
        self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_card_rent'],'password':''},self.admin)
        entries=self.request('/api/admin/account-history',cookie=self.admin)[1]['entries']
        self.assertEqual(len(entries),2)
        entry=next(e for e in entries if e['action']=='ACCOUNT_PERMISSIONS_CHANGE')
        self.assertFalse(entry['passwordChanged']);self.assertEqual(entry['before']['permissions'],['v_expense']);self.assertEqual(entry['after']['permissions'],['v_card_rent'])
        account=next(a for a in self.request('/api/admin/accounts',cookie=self.admin)[1]['accounts'] if a['username']=='branch')
        self.assertEqual(account['latestPassword'],'Latest-test-pass!')

    def test_nonadmin_cannot_read_history_or_password(self):
        self.assertEqual(self.request('/api/admin/account-history',cookie=self.branch)[0],403)
        self.assertEqual(self.request('/api/admin/accounts',cookie=self.branch)[0],403)
        self.assertEqual(self.request('/api/admin/account-history')[0],401)
        public=self.request('/api/bootstrap')[1]
        self.assertNotIn('latestPassword',json.dumps(public));self.assertNotIn('latestPassword',json.dumps(self.state(self.admin)))

    def test_self_password_change_updates_latest_and_history(self):
        self.assertEqual(self.request('/api/change-password',{'currentPassword':'Branch-test-pass!','newPassword':'Self-new-pass!'},self.branch)[0],200)
        account=next(a for a in self.request('/api/admin/accounts',cookie=self.admin)[1]['accounts'] if a['username']=='branch')
        self.assertEqual(account['latestPassword'],'Self-new-pass!');self.assertEqual(account['passwordUpdatedBy'],'branch')
        entry=self.request('/api/admin/account-history',cookie=self.admin)[1]['entries'][0]
        self.assertEqual(entry['action'],'PASSWORD_CHANGE');self.assertEqual(entry['actor'],'branch')

    def test_legacy_hash_shows_unknown_not_a_fake_password(self):
        account=next(a for a in self.request('/api/admin/accounts',cookie=self.admin)[1]['accounts'] if a['username']=='branch')
        self.assertIsNone(account['latestPassword']);self.assertEqual(account['passwordDisplayStatus'],'legacy')

    def test_failed_change_does_not_create_history(self):
        self.assertEqual(self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':[],'password':'short'},self.admin)[0],400)
        self.assertEqual(self.request('/api/admin/account-history',cookie=self.admin)[1]['entries'],[])

    def test_old_server_audit_events_are_visible(self):
        app.audit('admin','ACCOUNT_UPDATE','127.0.0.1','target=branch')
        entry=self.request('/api/admin/account-history',cookie=self.admin)[1]['entries'][0]
        self.assertEqual(entry['target'],'branch');self.assertTrue(str(entry['id']).startswith('legacy-'))

    def test_missing_display_key_rolls_back_new_password_and_history(self):
        self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':'Saved-test-pass!'},self.admin)
        key=app.DB_PATH.parent/'password_display.key';saved=key.read_bytes();key.unlink()
        try:
            status,_,_=self.request('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':'Rejected-test-pass!'},self.admin)
            self.assertEqual(status,400)
            with app.db() as conn:row=conn.execute("SELECT password_hash FROM users WHERE username='branch'").fetchone()
            self.assertTrue(app.verify_password(row['password_hash'],'Saved-test-pass!'))
            self.assertEqual(len(self.request('/api/admin/account-history',cookie=self.admin)[1]['entries']),1)
        finally:key.write_bytes(saved)


if __name__ == '__main__':
    unittest.main()

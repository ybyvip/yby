@echo off
setlocal
title V3.2.6 Private Network Firewall Setup
echo Adding a Windows Firewall rule for TCP ports 5000-5010
echo Profile: Private networks only; remote scope: Local Subnet
netsh advfirewall firewall add rule name="V3.2.6 LAN access" dir=in action=allow protocol=TCP localport=5000-5010 profile=private remoteip=localsubnet
if errorlevel 1 (
  echo.
  echo Failed. Right-click this file and choose Run as administrator.
) else (
  echo.
  echo Firewall rule added. Restart START_V3.bat and try the displayed LAN address.
)
pause

import os
import json
import ssl
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
APP = BASE / 'app.py'


def free_port(port=5000):
    """Use only the documented shared port; never silently split clients across servers."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(('0.0.0.0', port))
        return port
    except OSError:
        return None
    finally:
        s.close()


def open_browser(url):
    try:
        if sys.platform.startswith('win'):
            os.startfile(url)
            return True
    except Exception:
        pass
    try:
        import webbrowser
        return bool(webbrowser.open(url, new=1))
    except Exception:
        return False


def main():
    print('=' * 68)
    print(' 법인카드 & 하이패스 통합관리시스템 V3.9.8')
    print('=' * 68)
    print(f'[폴더] {BASE}')

    required=['app.py','security.py','password_vault.py','requirements.txt','templates/index.html','static/vendor/chart.umd.min.js','static/vendor/xlsx.full.min.js']
    missing=[name for name in required if not (BASE/name).is_file()]
    if missing:
        print('[오류] 필수 파일 누락: '+', '.join(missing))
        input('계속하려면 Enter 키를 누르세요...')
        return 1
    if not APP.exists():
        print('[오류] app.py가 없습니다.')
        input('계속하려면 Enter 키를 누르세요...')
        return 1
    if not (BASE / 'templates' / 'index.html').exists():
        print('[오류] templates\\index.html이 없습니다.')
        input('계속하려면 Enter 키를 누르세요...')
        return 1

    runtime_packages=BASE/'.runtime_packages'
    if runtime_packages.is_dir():sys.path.insert(0,str(runtime_packages))
    try:
        import cryptography
        major=int(cryptography.__version__.split('.')[0])
        if not 46 <= major <= 50: raise ImportError('지원하는 암호화 라이브러리 필요')
    except ImportError:
        print('[준비] 비밀번호 표시용 암호화 라이브러리를 설치합니다 (최초 인터넷 연결 필요).')
        result=subprocess.run([sys.executable,'-m','pip','install','--disable-pip-version-check','--target',str(runtime_packages),'--upgrade','-r',str(BASE/'requirements.txt')])
        if result.returncode:
            print('[오류] 설치 실패. INSTALL_DEPENDENCIES.bat을 실행한 후 다시 시도하세요.')
            input('계속하려면 Enter 키를 누르세요...')
            return 1

    port = free_port()
    if port is None:
        print('[오류] 기본 공유 포트 5000이 이미 사용 중입니다.')
        print('       다른 PC가 이전 서버에 연결되는 일을 막기 위해 임의 포트로 시작하지 않았습니다.')
        print('       기존 V3 서버 창에서 STOP_V3.bat을 실행하거나, 작업 관리자에서 이전 app.py 서버를 종료한 뒤 다시 시작하세요.')
        input('계속하려면 Enter 키를 누르세요...')
        return 1

    env = os.environ.copy()
    env['V3_PORT'] = str(port)
    env['V3_AUTO_BROWSER'] = '0'
    env['V3_HOST'] = '0.0.0.0'

    print(f'[1/3] 서버 시작: Python {sys.version.split()[0]}')
    print(f'      포트: {port}')
    print('[2/3] 서버 응답을 기다립니다...')

    try:
        proc = subprocess.Popen([sys.executable, str(APP)], cwd=str(BASE), env=env)
    except Exception as exc:
        print(f'[오류] Python 서버를 실행하지 못했습니다: {exc}')
        input('계속하려면 Enter 키를 누르세요...')
        return 1

    scheme = 'https' if env.get('V3_TLS_CERT') else 'http'
    url = f'{scheme}://localhost:{port}/' if scheme=='https' else f'http://127.0.0.1:{port}/'
    health = url+'health'
    tls_context = ssl.create_default_context(cafile=env.get('V3_TLS_CA')) if scheme=='https' else None
    ready = False
    for _ in range(80):
        if proc.poll() is not None:
            print(f'[오류] 서버가 시작 직후 종료되었습니다. 종료코드: {proc.returncode}')
            input('계속하려면 Enter 키를 누르세요...')
            return 1
        try:
            with urllib.request.urlopen(health, timeout=2, context=tls_context) as r:
                body=json.load(r)
                if r.status == 200 and body.get('ok') and body.get('database') and body.get('version')=='3.9.8':
                    ready = True
                    break
        except Exception:
            time.sleep(0.15)

    if not ready:
        print('[오류] 서버 응답을 받지 못했습니다.')
        print('       서버 창의 Python 오류 메시지를 확인하세요.')
        proc.terminate()
        input('계속하려면 Enter 키를 누르세요...')
        return 1

    print('[3/3] 서버 정상 확인 → 로그인 화면을 엽니다.')
    print('')
    print(f' 서버 PC에서 접속 : {url}')
    print(f' 다른 PC에서 접속 : {scheme}://서버PC의IPv4주소:{port}/')
    lan_ips = set()
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(('192.0.2.1', 80))
        candidate = probe.getsockname()[0]
        if not candidate.startswith('127.'):
            lan_ips.add(candidate)
    except OSError:
        pass
    finally:
        probe.close()
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidate = item[4][0]
            if not candidate.startswith('127.') and not candidate.startswith('169.254.'):
                lan_ips.add(candidate)
    except OSError:
        pass
    for lan_ip in sorted(lan_ips):
        print(f'                   {scheme}://{lan_ip}:{port}/')
    if not lan_ips:
        print('                   IPv4 주소는 Windows의 ipconfig 명령으로 확인하세요.')
    print(' 관리자ID : admin')
    print(' 비밀번호 : 새 설치는 위 최초 임시 비밀번호 안내를 확인하세요.')
    print('')

    if not open_browser(url):
        print('[안내] 자동 브라우저 실행에 실패했습니다.')
        print(f'       위 주소를 Chrome/Edge 주소창에 입력하면 됩니다: {url}')
    else:
        print('[완료] 브라우저를 열었습니다.')

    print('')
    print('이 창을 닫으면 서버도 종료됩니다.')
    print('서버를 종료하려면 Ctrl+C를 누르세요.')
    print('=' * 68)

    try:
        return proc.wait()
    except KeyboardInterrupt:
        print('\n서버를 종료합니다...')
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
        return 0


if __name__ == '__main__':
    raise SystemExit(main())

@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 (
  py -3 -m pip install --disable-pip-version-check --target "%~dp0.runtime_packages" --upgrade -r "%~dp0requirements.txt"
  goto result
)
where python.exe >nul 2>&1
if not errorlevel 1 (
  python -m pip install --disable-pip-version-check --target "%~dp0.runtime_packages" --upgrade -r "%~dp0requirements.txt"
  goto result
)
echo Python 3.11 이상이 필요합니다.
pause
exit /b 1
:result
if errorlevel 1 (
  echo 설치 실패. 인터넷 연결과 위 오류를 확인하세요.
) else (
  echo 설치 완료. START_V3.bat을 실행하세요.
)
pause

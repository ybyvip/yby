"""Local recovery only; stop the program server before running this helper."""
import getpass
import socket
import app


def main():
    probe = socket.socket()
    try:
        probe.settimeout(1)
        if probe.connect_ex(('127.0.0.1', app.PORT)) == 0:
            raise RuntimeError('서버를 먼저 종료하세요. STOP_V3.bat 실행 후 다시 시도하세요.')
    finally:
        probe.close()
    password = getpass.getpass('새 관리자 비밀번호 (10~128자): ')
    app.validate_password(password)
    if password != getpass.getpass('새 비밀번호 확인: '):
        raise ValueError('비밀번호가 일치하지 않습니다.')
    app.prepare_db()
    app.backup('before_admin_reset')
    with app.db() as conn:
        conn.execute('UPDATE users SET password_hash=?,active=1,scope=?,permissions_json=?,must_change_password=0 WHERE username=?',
                     (app.phash(password),'ALL',app.json.dumps(app.ALL_VIEWS,ensure_ascii=False),'admin'))
        app.store_password(conn,app.DB_PATH.parent/'password_display.key','admin',password,'서버 관리자',app.now())
        app.record_account_change(conn,'서버 관리자','admin','ADMIN_LOCAL_RESET',password_changed=True)
        conn.commit()
        state=app.get_state() or {};state['accounts']=app.account_metadata(conn)
        app.persist_state(conn,state,'admin')
    print('관리자 비밀번호를 변경했습니다. START_V3.bat으로 서버를 다시 실행하세요.')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError) as error:
        print(f'[오류] {error}')
        raise SystemExit(1)

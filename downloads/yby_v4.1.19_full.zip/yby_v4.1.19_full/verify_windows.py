"""Read-only live Windows acceptance, plus a rejected lock attempt and repeat launch."""
import ctypes
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import ssl
import subprocess
import sys
import urllib.request
import urllib.error

SOURCE=Path(__file__).resolve().parent


def main():
    if sys.platform!='win32':
        raise RuntimeError('실제 Windows PC에서 실행하는 검증 도구입니다. Linux 결과를 Windows 통과로 표시하지 않습니다.')
    if ctypes.windll.shell32.IsUserAnAdmin():
        raise RuntimeError('일반 더블클릭으로 검증하세요. 실제 로그인 사용자의 권한을 검사해야 합니다.')
    root=Path(os.environ['LOCALAPPDATA'])/'YBY/app'
    report={'time':datetime.now().astimezone().isoformat(),'platform':sys.platform,'python':sys.version.split()[0],'checks':[]}
    def passed(name):
        report['checks'].append({'name':name,'result':'PASS'});print('PASS: '+name,flush=True)
    try:
        manifest=json.loads((SOURCE/'MANIFEST.json').read_text(encoding='utf-8'))
        for name,expected in manifest['files'].items():
            path=(SOURCE/name).resolve()
            if not path.is_relative_to(SOURCE) or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
                raise RuntimeError('패키지 무결성 불일치: '+name)
        passed('다운로드 패키지 파일 무결성')
        import active_runtime
        info=active_runtime.probe(root)
        if not info or info['version']!='4.1.19' or not info['url'].startswith('https:'):
            raise RuntimeError('V4.1.19 사내망 서버를 먼저 실행하세요. 구버전이 동작 중이면 STOP_SERVER.bat 후 다시 실행하세요.')
        passed('실제 프로세스 경로·PID·인증서·V4.1.19 서버·DB 상태')
        certificate=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        certificate.load_cert_chain(str(root/'certificates/server.pem'),str(root/'certificates/server-key.pem'))
        passed('일반 사용자 권한에서 실제 서버 인증서/개인키 읽기·로드')
        import password_vault,secrets
        sample=secrets.token_urlsafe(24)
        ciphertext=password_vault.seal(root/'data','__windows_validation__',sample,'temporary-check')
        if password_vault.reveal(root/'data','__windows_validation__',ciphertext,'temporary-check')!=sample:
            raise RuntimeError('Windows DPAPI 암호화/복호화 불일치')
        passed('현재 Windows 사용자의 실제 DPAPI 암호화·복호화 (업무 비밀번호 미사용)')
        settings=json.loads((root/'lan_settings.json').read_text(encoding='utf-8'))
        context=ssl.create_default_context()  # Actual Windows trust, with no custom CA bypass.
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
        for host in ('localhost',settings['server_ip']):
            url=f"https://{host}:{settings['port']}/"
            class NoRedirect(urllib.request.HTTPRedirectHandler):
                def redirect_request(self,*args,**kwargs):return None
            plain=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
            try:plain.open(f"http://{host}:{settings['port']}/",timeout=10)
            except urllib.error.HTTPError as redirect:
                if redirect.code!=308 or redirect.headers.get('Location')!=url:
                    raise RuntimeError('HTTP→HTTPS 접속 이동 확인 실패')
            else:raise RuntimeError('일반 HTTP 접속이 HTTPS로 이동하지 않습니다.')
            passed('실제 Windows HTTP→HTTPS 이동: '+host)
            with opener.open(url+'health',timeout=10) as response:
                health=json.load(response)
            if health.get('version')!='4.1.19' or not health.get('ok') or not health.get('database'):
                raise RuntimeError('서버 상태 확인 실패')
            with opener.open(url,timeout=10) as response:
                html=response.read().decode('utf-8')
            if 'value="admin"' not in html or '4.1.19' not in html:
                raise RuntimeError('로그인 HTML 확인 실패')
            passed('Windows 신뢰 저장소를 통한 HTTPS/주소/로그인 화면: '+host)
        child=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',
                              str(SOURCE/'tools/client_templates/client_connect.ps1'),'-ServerRoot',str(root),'-CheckOnly','-NoBrowser'])
        if child.returncode:raise RuntimeError('Windows 사용자 인증서/실제 서버 CA 검증 실패')
        passed('PowerShell/.NET의 실제 현재 사용자 인증서 및 CA 검증')
        script="from db_lock import DatabaseLock, DatabaseBusyError\nfrom pathlib import Path\nimport sys\ntry:\n with DatabaseLock(Path(sys.argv[1])): pass\nexcept DatabaseBusyError: sys.exit(42)\nsys.exit(1)"
        child=subprocess.run([sys.executable,'-c',script,str(root/'data')],cwd=SOURCE)
        if child.returncode!=42:raise RuntimeError('실제 서버 자료 잠금 보호를 확인하지 못했습니다.')
        passed('Windows CreateFileW/LockFileEx의 중복 자료 접근 차단')
        marker=(root/'server.pid').read_bytes()
        cert_hash=hashlib.sha256((root/'certificates/root-ca.cer').read_bytes()).hexdigest()
        child=subprocess.run([sys.executable,str(SOURCE/'windows_bootstrap.py'),'--lan','--no-browser'],cwd=SOURCE,timeout=30)
        if child.returncode or (root/'server.pid').read_bytes()!=marker:
            raise RuntimeError('재실행이 같은 서버를 유지하지 못했습니다.')
        if hashlib.sha256((root/'certificates/root-ca.cer').read_bytes()).hexdigest()!=cert_hash:
            raise RuntimeError('재실행 중 CA 내용이 바뀌었습니다.')
        passed('RUN_LAN 재실행 성공·동일 PID·기존 CA 유지')
        report['result']='PASS'
        print('이 서버 PC의 검증을 통과했습니다. 다른 PC에서는 LAN_CLIENT/CHECK_CONNECTION.bat로 별도 확인하세요.')
        return 0
    except Exception as error:
        report['result']='FAIL';report['error']=str(error)
        print('검증 실패: '+str(error));return 1
    finally:
        output=Path(os.environ['LOCALAPPDATA'])/'YBY/diagnostics'
        output.mkdir(parents=True,exist_ok=True)
        path=output/('windows_validation_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
        path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print('검증 보고서: '+str(path))


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as error:print('검증 시작 실패: '+str(error));raise SystemExit(1)

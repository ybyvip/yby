/* Request identity and a review-first normalized inbox picker. No Oracle SQL here. */
const rentalIntake={application:null,settlement:null,picker:null,serial:0};
function intakeSourceLabel(row){if(row?.historicalImport&&row?.inputRoute==='EXCEL_LEDGER')return '엑셀 이관';return row?.entrySource==='EXCEL'?'외부 엑셀 자료':row?.entrySource==='ORACLE'?'외부 Oracle 자료':row?.entrySource==='YBY'?'YBY 직접 입력':'기존 자료 · 출처 미기록';}
function intakeSourceHTML(row){return '<span class="intake-source">'+escapeHtml(intakeSourceLabel(row))+(row?.sourceAdjusted?' · YBY에서 보완':'')+'</span>'+(row?.sourceRef?'<small class="intake-subtext">문서 '+escapeHtml(row.sourceRef.documentNo)+' · 외부 결재(연결 시점): '+escapeHtml(row.sourceRef.approvalStatus||'미확인')+'</small>':'');}
function prepareRentalFormDefaults(){
    const date=document.getElementById('rentApplicationDate');if(date&&!date.value)date.value=localDate();
    syncRentalApplicant();
    const label=document.getElementById('rentalSourceLabel');
    if(label)label.textContent=rentalIntake.application?(rentalIntake.application.source==='EXCEL'?'외부 엑셀 자료 · ':'외부 Oracle 자료 · ')+rentalIntake.application.documentNo:'YBY 직접 입력';
}
function syncRentalApplicant(){const same=document.getElementById('rentApplicantSame'),name=document.getElementById('rentApplicant');if(!same||!name)return;name.readOnly=same.checked;if(same.checked)name.value=document.getElementById('rentUser').value;}
function rentalCardCandidates(){return cardsData.filter(c=>c.status==='available'&&(userScope==='ALL'||c.group===userScope)&&(!rentalIntake.application||(c.group===rentalIntake.application.group&&(!rentalIntake.application.selectedCardNum||c.num===rentalIntake.application.selectedCardNum&&String(c.id)===rentalIntake.application.selectedCardId)&&(!rentalIntake.application.cardLast4||String(c.num).replace(/\D/g,'').slice(-4)===rentalIntake.application.cardLast4))));}
function clearRentalApplication(){rentalIntake.application=null;renderRentDropdowns();updateLiveSelection();}
function resetRentalIntake(){rentalIntake.application=null;rentalIntake.settlement=null;prepareRentalFormDefaults();renderRentDropdowns();}
function intakeReference(document){return document?{externalDocumentId:document.key,externalRevision:document.revision,externalConfirmed:true,...(document.matchVersion?{externalMatchVersion:document.matchVersion}:{})}:{};}
function clearExternalSettlement(){rentalIntake.settlement=null;updateLiveSelection();}
function intakeSessionReset(){closeExternalPicker();rentalIntake.application=null;rentalIntake.settlement=null;}
function closeExternalPicker(){const state=rentalIntake.picker;rentalIntake.serial++;state?.controller?.abort();document.getElementById('externalPicker')?.remove();rentalIntake.picker=null;if(state?.focus?.isConnected)state.focus.focus();}
function openExternalPicker(kind,cardId=null,documentKey=null){
    if(!hasViewPermission('v_card_rent'))return;
    closeExternalPicker();
    const overlay=document.createElement('div');overlay.id='externalPicker';overlay.className='intake-picker';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-labelledby','externalPickerTitle');
    overlay.innerHTML='<div class="intake-picker-card"><header><h2 id="externalPickerTitle">'+(kind==='application'?'외부 사용신청서 선택':'외부 사용정산서 선택')+'</h2><button type="button" id="externalPickerClose" class="btn-secondary">닫기</button></header><div class="intake-picker-body"><p id="externalInboxStatus" role="status">수신 자료를 확인하고 있습니다.</p><div class="intake-picker-search"><label for="externalInboxQuery">문서번호·신청자·사용목적 검색</label><input id="externalInboxQuery" type="search" maxlength="200"><button type="button" class="btn-primary" id="externalInboxSearch">조회</button></div><div id="externalInboxList"></div><div class="intake-picker-pages"><button type="button" class="btn-secondary" id="externalInboxPrev">이전</button><span id="externalInboxCount"></span><button type="button" class="btn-secondary" id="externalInboxNext">다음</button></div><div id="externalDocumentReview"></div></div></div>';
    const focus=document.activeElement;rentalIntake.picker={kind,cardId,offset:0,focus};document.body.appendChild(overlay);
    document.getElementById('externalPickerClose').onclick=closeExternalPicker;
    document.getElementById('externalInboxSearch').onclick=()=>{rentalIntake.picker.offset=0;loadExternalInbox();};
    document.getElementById('externalInboxQuery').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('externalInboxSearch').click();}};
    document.getElementById('externalInboxPrev').onclick=()=>{rentalIntake.picker.offset=Math.max(0,rentalIntake.picker.offset-50);loadExternalInbox();};
    document.getElementById('externalInboxNext').onclick=()=>{rentalIntake.picker.offset+=50;loadExternalInbox();};
    overlay.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeExternalPicker();}else if(e.key==='Tab'){const focusable=[...overlay.querySelectorAll('button,input')].filter(x=>!x.disabled&&x.offsetParent!==null);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}},true);
    document.getElementById('externalPickerClose').focus();const picker=rentalIntake.picker;loadExternalInbox().then(()=>{if(documentKey&&rentalIntake.picker===picker)reviewExternalDocument(documentKey);});
}
async function loadExternalInbox(automatic=false){
    const state=rentalIntake.picker;if(!state||(automatic&&(state.loading||state.reviewing)))return;state.loading=true;state.controller?.abort();state.controller=new AbortController();const serial=++rentalIntake.serial;
    const params=new URLSearchParams({kind:state.kind,q:document.getElementById('externalInboxQuery').value,offset:state.offset});if(state.cardId!=null)params.set('cardId',state.cardId);
    if(!automatic){document.getElementById('externalDocumentReview').innerHTML='';document.getElementById('externalInboxList').textContent='조회 중…';}
    try{const response=await fetch('/api/external-documents?'+params,{signal:state.controller.signal,cache:'no-store'});const data=await response.json();if(!response.ok||!data.ok)throw Error(data.message||'수신 자료 조회 실패');if(serial!==rentalIntake.serial)return;
        document.getElementById('externalInboxStatus').textContent='서버 수신함 · Oracle 직접 연결 준비 중. 외부 결재 상태는 참고 정보이며 YBY 결재는 별도로 진행합니다.';
        const list=document.getElementById('externalInboxList');list.innerHTML='';
        if(!data.items.length)list.textContent='아직 선택할 외부 수신 자료가 없습니다. Oracle DB 연결 후 수신된 문서가 여기에 표시됩니다. YBY 직접 입력은 계속 사용할 수 있습니다.';
        for(const doc of data.items){const box=document.createElement('div');box.className='intake-document-row';const text=document.createElement('div');text.textContent=doc.documentNo+' · '+doc.group+' · 신청자 '+doc.applicantName+' · '+(doc.approvalStatus||'외부 상태 미확인')+(doc.bound?' · 적용':doc.withdrawn?' · 회수됨':' · 미적용');const small=document.createElement('small');small.textContent=doc.purpose;const button=document.createElement('button');button.type='button';button.className='btn-primary';button.textContent='내용 확인';button.textContent=doc.bound||doc.withdrawn?'원문 확인':'내용 확인';button.onclick=()=>reviewExternalDocument(doc.key);box.append(text,small,button);list.appendChild(box);}
        document.getElementById('externalInboxCount').textContent=data.total+'건 · '+(data.total?state.offset+1:0)+'~'+Math.min(data.total,state.offset+50);
        document.getElementById('externalInboxPrev').disabled=state.offset===0;document.getElementById('externalInboxNext').disabled=state.offset+50>=data.total;
    }catch(error){if(error.name!=='AbortError'&&serial===rentalIntake.serial)document.getElementById('externalInboxStatus').textContent='갱신 실패 · 표시된 자료는 최신이 아닐 수 있습니다: '+error.message;}finally{state.loading=false;}
}
async function reviewExternalDocument(key){
    const state=rentalIntake.picker;if(!state)return;state.reviewing=true;state.controller?.abort();state.controller=new AbortController();const serial=++rentalIntake.serial;
    const params=new URLSearchParams({key,kind:state.kind});if(state.cardId!=null)params.set('cardId',state.cardId);
    try{const response=await fetch('/api/external-document?'+params,{signal:state.controller.signal,cache:'no-store'});const data=await response.json();if(!response.ok||!data.ok)throw Error(data.message||'문서 조회 실패');if(serial!==rentalIntake.serial)return;
        const d=data.document;d.matchVersion=data.match?.version;const area=document.getElementById('externalDocumentReview');
        const card=state.cardId==null?null:cardsData.find(c=>String(c.id)===String(state.cardId));
        area.innerHTML='<h3>선택 문서 확인</h3><dl><dt>문서번호 · 지점</dt><dd>'+escapeHtml(d.documentNo)+' · '+escapeHtml(d.group)+'</dd><dt>신청자 / 실제 사용자</dt><dd>'+escapeHtml(d.applicantName)+' / '+escapeHtml(d.user||'작성 시 확인 필요')+'</dd><dt>외부 결재 상태</dt><dd>'+escapeHtml(d.approvalStatus||'미확인')+' · 수신 버전 '+escapeHtml(d.revision)+'</dd><dt>사용 목적</dt><dd>'+escapeHtml(d.purpose)+'</dd>'+(d.kind==='application'?'<dt>신청일 / 반납예정일</dt><dd>'+escapeHtml(d.applicationDate)+' / '+escapeHtml(d.dueDate)+'</dd>':'<dt>반납 대상 카드</dt><dd>'+escapeHtml(card?.group||'')+' · '+escapeHtml(card?.num||'')+'</dd><dt>문서 카드 끝자리 / 금액</dt><dd>'+escapeHtml(d.cardLast4)+' / '+escapeHtml(d.amount.toLocaleString())+'원</dd>')+'</dl>'+(d.kind==='settlement'?expenseLineTable(d):'')+'<p class="ledger-help">신청서와 정산서는 독립된 문서입니다. 실제 카드·사용자·기간을 확인하세요. 적용하면 입력 중인 '+(d.kind==='application'?'신청 내용':'정산 명세')+'를 선택 문서 내용으로 채웁니다. 외부 첨부는 아직 연결되지 않으므로 필요한 증빙은 별도 첨부하세요.</p><label class="intake-confirm"><input type="checkbox" id="externalDocumentConfirmed">문서와 처리 대상을 확인했습니다.</label><button type="button" class="btn-primary" id="applyExternalDocument" disabled>확인한 내용으로 입력</button>';
        const check=document.getElementById('externalDocumentConfirmed'),button=document.getElementById('applyExternalDocument');check.disabled=data.bound||d.withdrawn;check.onchange=()=>{button.disabled=!check.checked||data.bound||d.withdrawn;};button.onclick=()=>applyExternalDocument(d);area.scrollIntoView({block:'nearest'});
    }catch(error){if(error.name!=='AbortError'&&serial===rentalIntake.serial){const area=document.getElementById('externalDocumentReview');if(area)area.textContent=error.message;}}finally{state.reviewing=false;}
}
async function applyExternalDocument(d){
    const state=rentalIntake.picker;if(!state||!document.getElementById('externalDocumentConfirmed')?.checked)return;
    const button=document.getElementById('applyExternalDocument');button.disabled=true;
    try{const params=new URLSearchParams({key:d.key,kind:d.kind});if(state.cardId!=null)params.set('cardId',state.cardId);const response=await fetch('/api/external-document?'+params,{cache:'no-store'}),value=await response.json();if(!response.ok||!value.ok)throw Error(value.message||'문서 확인 실패');if(rentalIntake.picker!==state)return;if(value.bound||value.document.withdrawn||value.document.revision!==d.revision)throw Error('이미 적용되었거나 원문이 변경·회수되었습니다. 다시 조회하여 확인하세요.');}catch(error){if(rentalIntake.picker===state){alert(error.message);button.disabled=false;}return;}
    if(d.kind==='application'){
        rentalIntake.application=d;renderRentDropdowns();
        document.getElementById('rentApplicationDate').value=d.applicationDate;document.getElementById('rentApplicantSame').checked=!!d.user&&d.user===d.applicantName;
        document.getElementById('rentUser').value=d.user||'';document.getElementById('rentApplicant').value=d.applicantName;document.getElementById('rentDept').value=d.dept;document.getElementById('rentDueDate').value=d.dueDate;document.getElementById('rentDetailPurpose').value=d.purpose;
        const options=[...document.querySelectorAll('input[name=purposeChk]')],prefix=d.source==='EXCEL'?d.purpose.match(/^\[([^\]]+)\]\s*/):null,categories=prefix?prefix[1].split(/[,·]/).map(v=>v.trim()):[],known=categories.length&&categories.every(v=>options.some(input=>input.value===v));if(known){document.getElementById('rentDetailPurpose').value=d.purpose.slice(prefix[0].length);options.forEach(input=>input.checked=categories.includes(input.value));}else options.forEach(input=>input.checked=input.value==='기타');prepareRentalFormDefaults();
    }else{
        const card=cardsData.find(c=>String(c.id)===String(state.cardId));if(!card||card.status!=='rented'){alert('반납 대상을 다시 확인하세요.');return;}
        document.getElementById('returnUsedCheckbox').checked=true;setReturnUsageMode('used');
        initializeSettlementForm({...d,user:d.user||card.user,dept:card.dept||d.dept});rentalIntake.settlement=d;
        updateLiveSelection();
    }
    closeExternalPicker();refreshWorkflowInbox();
}

# V4.1.21 소프트웨어 자산 목록

| 구성 | 버전/출처 | 용도/조건 |
|---|---|---|
| Python | 3.11 이상, python.org/회사 관리 배포 | 표준 라이브러리 HTTP/SQLite/TLS·파일 도구 |
| SQLite | 실행 Python에 포함 | 업무 DB. 실제 버전은 Python 설치별 다름 |
| Windows DPAPI·인증서 도구 | 실행 Windows 제공 | 예외 비밀번호 표시·자동 보관 암호 보호·CA/PFX |
| cryptography | 50.0.0 | AES-GCM 암호화 백업; Linux Fernet. Windows는 설치 도우미/회사 IT 설치 |
| Chart.js | 4.4.8, static/vendor/NOTICE.md의 출처·해시 | 통계 차트. MIT 고지 동봉 |
| Playwright | 1.62.0 | 개발/브라우저 검증 전용, 업무 실행에 필요 없음 |
| Node.js | 검증 환경24 | 개발 검사 전용 |
| Edge/WebView2 | 회사 Windows 설치 버전 | 별도 로그인 창/브라우저. 회사 실기 확인 필요 |
| MET Norway forecast | HTTPS api.met.no / CC BY4.0 | 청주시 공개 예보. 차단 시 로그인은 시간대 배경으로 동작 |

브라우저 XLSX0.18.5는 실제 로딩하지 않던 번들이므로 제거했습니다. XLSX 출력은 서버 exports.py입니다. 이 목록은 자산 관리 자료이며 CycloneDX/SPDX 인증이나 CVE 전수 검증, 코드서명 인증을 뜻하지 않습니다. 정기 취약점 점검과 회사 인프라 보안 관리는 별도 운영 항목입니다.

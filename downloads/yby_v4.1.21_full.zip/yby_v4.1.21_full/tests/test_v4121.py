"""Stabilization acceptance: policy boundaries, financial inspection, encrypted DR."""
import shutil
from urllib.parse import urlencode
import base64,copy,hashlib,io,json,os,sqlite3,tempfile,time,unittest,uuid
from pathlib import Path
from unittest import mock
from zipfile import ZipFile,ZIP_DEFLATED
import test_security as fixtures
import test_v4 as workflow
import backup_crypto,backup_manager,backup_operations,company_policy,reauthentication,attachment_guard

class StabilityTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):fixtures.SecurityTests.setUpClass()
 @classmethod
 def tearDownClass(cls):fixtures.SecurityTests.tearDownClass()
 def setUp(self):
  self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
  with self.a.db() as c:
   company_policy.initialize(c);c.execute('DELETE FROM company_settings');c.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_rent','v_expense','v_stats','v_report_write','v_report_box','v_hipass_reg']),));c.commit()
  for path in self.a.BACKUP_DIR.iterdir():
   if path.is_dir():shutil.rmtree(path)
   else:path.unlink()
  reauthentication.FAILURES.clear()
 def post(self,path,data,cookie=None):return self.c.request(path,data,cookie or self.c.admin)
 def policy(self,**values):return self.w.operation('/api/company-policy/update',{'password':'Admin-test-pass!','reason':'회사 통제 정책 확인',**values},self.c.admin)
 def review(self,period='2026-10',cookie=None,group=''):return self.c.request('/api/business-review?'+urlencode({'period':period,'group':group}),cookie=cookie or self.c.admin)
 def test_default_password_reveal_is_disabled_and_new_login_is_not_captured(self):
  self.assertFalse(self.c.request('/api/company-policy',cookie=self.c.admin)[1]['policy']['passwordDisplayEnabled'])
  self.assertEqual(self.post('/api/admin/password-reveal',{'username':'branch','adminPassword':'Admin-test-pass!'})[0],403)
  with self.a.db() as c:c.execute('DELETE FROM credential_vault');c.commit()
  self.c.login('branch','Branch-test-pass!')
  with self.a.db() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM credential_vault').fetchone()[0],0)
 def test_explicit_policy_opt_in_restores_legacy_view_with_reauthentication(self):
  self.assertEqual(self.policy(passwordDisplayEnabled=True)[0],200);self.c.login('branch','Branch-test-pass!')
  self.assertEqual(self.post('/api/admin/password-reveal',{'username':'branch','adminPassword':'wrong'})[0],403)
  self.assertEqual(self.post('/api/admin/password-reveal',{'username':'branch','adminPassword':'Admin-test-pass!'})[1]['password'],'Branch-test-pass!')
 def test_admin_password_reset_revokes_only_target_and_permission_only_does_not(self):
  self.assertEqual(self.post('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':''})[0],200)
  self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],200)
  self.assertEqual(self.post('/api/admin/account-update',{'username':'branch','scope':'서울','permissions':['v_expense'],'password':'Changed-admin-reset!'})[0],200)
  self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],401);self.assertEqual(self.c.request('/api/state',cookie=self.c.admin)[0],200)
 def test_shared_reauthentication_budget_limits_sixth_request(self):
  for _ in range(5):self.assertEqual(self.c.request('/api/verify-current-password',{'password':'wrong'},self.c.branch)[0],403)
  self.assertEqual(self.c.request('/api/verify-current-password',{'password':'Branch-test-pass!'},self.c.branch)[0],429)
 def test_policy_permissions_password_and_revision_are_enforced(self):
  value={'password':'Branch-test-pass!','reason':'다른 지점 정책 변경','branches':['서울']}
  self.assertEqual(self.w.operation('/api/company-policy/update',value,self.c.branch)[0],403)
  self.assertEqual(self.policy(password='wrong')[0],403)
  self.assertEqual(self.policy(reason='')[0],400)
  self.assertEqual(self.policy(branches=['서울'])[0],400)
 def test_new_branch_master_survives_reload_and_card_registration(self):
  names=company_policy.DEFAULT_BRANCHES+['부산'];self.assertEqual(self.policy(branches=names)[0],200)
  self.assertIn('부산',self.c.request('/api/bootstrap')[1]['branches'])
  self.assertEqual(self.w.operation('/api/cards/register',{'group':'부산','company':'시험','num':'BUSAN-TEST'},self.c.admin)[0],200)
  self.assertEqual(self.policy(branches=company_policy.DEFAULT_BRANCHES)[0],400)
 def test_unapplied_external_branch_cannot_be_removed(self):
  with self.a.db() as c:c.execute("INSERT INTO external_documents VALUES('branch-test','application','광주',1,'{}','time')");c.commit()
  self.assertEqual(self.policy(branches=[n for n in company_policy.DEFAULT_BRANCHES if n!='광주'])[0],400)
 def test_public_names_can_be_disabled_without_disabling_typed_login(self):
  self.assertEqual(self.policy(publicAccountList=False)[0],200)
  self.assertEqual(self.c.request('/api/bootstrap')[1]['users'],[]);self.c.login('branch','Branch-test-pass!')
 def own_expense(self):
  self.assertEqual(self.w.operation('/api/expenses/submit',{'expense':self.w.draft()},self.c.admin)[0],200)
  return self.a.get_state()['expense'][0]
 def test_self_approval_requires_reason_password_and_can_be_disabled(self):
  row=self.own_expense();body={k:row[k] for k in ('id','group','requester')};body['decision']='approve'
  self.assertEqual(self.w.operation('/api/expenses/decision',body,self.c.admin)[0],400)
  self.assertEqual(self.w.operation('/api/expenses/decision',{**body,'reason':'본인 결재 예외','password':'wrong'},self.c.admin)[0],403)
  self.assertEqual(self.policy(allowSelfApproval=False)[0],200)
  self.assertEqual(self.w.operation('/api/expenses/decision',{**body,'reason':'본인 결재 예외','password':'Admin-test-pass!'},self.c.admin)[0],403)
  self.assertEqual(self.policy(allowSelfApproval=True)[0],200)
  self.assertEqual(self.w.operation('/api/expenses/decision',{**body,'reason':'책임자 사후 검토 예정','password':'Admin-test-pass!'},self.c.admin)[0],200)
  self.assertTrue(self.a.get_state()['expenseHistory'][0]['selfApproved'])
 def test_monthly_summary_keeps_import_approval_cancel_unused_and_missing_separate(self):
  rows=[{'id':1,'date':'2026-10-01','group':'서울','status':'승인완료','amount':100,'requester':'branch'}, {'id':2,'date':'2026-10-01','group':'서울','status':'이관완료','amount':200,'historicalImport':True,'returnDate':'2026-10-02'}, {'id':3,'date':'2026-10-01','group':'서울','status':'금액미기재','amount':None,'historicalImport':True}, {'id':4,'date':'2026-10-01','group':'서울','status':'승인취소','amount':500}, {'id':5,'date':'2026-10-01','group':'서울','status':'이관완료','amount':900,'used':False,'historicalImport':True}, {'id':6,'date':'2026-10-01','group':'인천','status':'승인완료','amount':7000}]
  with self.a.db() as c:self.a.persist_state(c,{'expenseHistory':rows},'fixture')
  result=self.review(cookie=self.c.branch,group='인천')[1]
  self.assertEqual(result['group'],'서울');self.assertEqual(result['summary']['approvedAmount'],100);self.assertEqual(result['summary']['importedAmount'],200);self.assertEqual(result['summary']['missingAmount'],1);self.assertEqual(result['summary']['unused'],1);self.assertEqual(result['summary']['cancelled'],1)
  self.assertNotIn('인천',json.dumps(result,ensure_ascii=False))
 def test_review_denies_unprivileged_account_and_invalid_month(self):
  readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.review(cookie=readonly)[0],403);self.assertEqual(self.review(period='2026-99')[0],400)
 def test_review_ack_is_scoped_idempotent_and_detects_changed_snapshot(self):
  result=self.review(cookie=self.c.branch)[1];body={'period':'2026-10','group':'서울','fingerprint':result['fingerprint'],'reference':'카드사 명세 시험001','note':'미결 내용 확인 완료','confirmed':True,'acknowledgeIssues':True,'password':'Branch-test-pass!','requestId':'review-ack-idempotent','revision':self.c.state(self.c.branch)['revision']}
  first=self.c.request('/api/business-review/acknowledge',body,self.c.branch);self.assertEqual(first[0],200,first)
  self.assertEqual(self.c.request('/api/business-review/acknowledge',body,self.c.branch)[1],first[1])
  self.w.rent();self.assertEqual(self.w.operation('/api/business-review/acknowledge',body,self.c.branch)[0],409)
  with self.a.db() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM business_reviews').fetchone()[0],1)
 def test_backup_encrypted_roundtrip_and_wrong_password_leave_live_data(self):
  with tempfile.TemporaryDirectory() as t:
   path=Path(t)/'test.ybybackup';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,path,password='Portable-test-secret!')
   self.assertTrue(backup_crypto.encrypted(path));self.assertNotIn(b'SQLite format 3',path.read_bytes());live=self.a.get_state()
   with self.assertRaises(ValueError):backup_manager.restore(path,Path(t)/'restored',password='Wrong-test-secret!')
   self.assertFalse((Path(t)/'restored').exists());self.assertEqual(self.a.get_state(),live)
   backup_manager.restore(path,Path(t)/'restored',password='Portable-test-secret!')
   self.assertEqual(backup_manager.inventory(self.a.DB_PATH),backup_manager.inventory(Path(t)/'restored'/self.a.DB_PATH.name))
 def test_tampered_or_truncated_encrypted_backup_cannot_restore(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);original=root/'a';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,original,password='Portable-test-secret!');raw=original.read_bytes()
   for index,data in enumerate((raw[:-16],raw[:300]+bytes([raw[300]^1])+raw[301:])):
    bad=root/str(index);bad.write_bytes(data)
    with self.assertRaises(ValueError):backup_manager.restore(bad,root/('restore'+str(index)),password='Portable-test-secret!')
 def test_backup_disk_space_failure_does_not_publish_file(self):
  with tempfile.TemporaryDirectory() as t,mock.patch.object(backup_manager.shutil,'disk_usage',return_value=type('Usage',(),{'free':0})()):
   path=Path(t)/'failed.zip'
   with self.assertRaises(ValueError):backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,path)
   self.assertFalse(path.exists())
 def test_new_manager_still_restores_legacy_archive(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);path=root/'legacy.zip';db=self.a.DB_PATH.read_bytes();manifest={'version':'4.1.20','database':self.a.DB_PATH.name,'files':{'data/'+self.a.DB_PATH.name:hashlib.sha256(db).hexdigest()}}
   with ZipFile(path,'w',ZIP_DEFLATED) as z:z.writestr('manifest.json',json.dumps(manifest));z.writestr('data/'+self.a.DB_PATH.name,db)
   value=backup_manager.restore(path,root/'restored');self.assertEqual(value['version'],'4.1.20')
 def test_secondary_is_encrypted_verified_and_path_guarded(self):
  with tempfile.TemporaryDirectory() as t:
   secondary=Path(t)/'secondary';api={'enabled':True,'destination':str(secondary),'keepCount':2,'keepDays':30,'intervalHours':24,'backupPassword':'Portable-test-secret!','password':'Admin-test-pass!'}
   self.assertEqual(self.post('/api/admin/backup-policy',{**api,'destination':str(self.a.DB_PATH.parent/'bad')})[0],400)
   self.assertEqual(self.post('/api/admin/backup-policy',api)[0],200)
   self.assertEqual(len(list(secondary.glob('*.ybybackup'))),1)
   self.a.backup('manual');files=list(secondary.glob('*.ybybackup'));self.assertEqual(len(files),2);self.assertTrue(backup_crypto.encrypted(files[0]));self.assertIn('lastSecondarySuccess',backup_operations.state(self.a))
   self.assertNotIn('Portable-test-secret!',json.dumps(self.c.request('/api/admin/backup-status',cookie=self.c.admin)[1]))
 def test_local_retention_keeps_manual_unknown_files_and_two_latest(self):
  for i in range(4):
   p=self.a.BACKUP_DIR/('corporate_card_system_20260101_00000'+str(i)+'_auto.zip');backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,p);os.utime(p,(time.time()-1000-i,time.time()-1000-i))
  manual=self.a.BACKUP_DIR/'corporate_card_system_20260101_manual.zip';manual.write_bytes(b'keep');other=self.a.BACKUP_DIR/'unrelated.zip';other.write_bytes(b'keep')
  backup_operations.atomic(backup_operations.paths(self.a)[0],{**backup_operations.DEFAULT,'keepCount':2})
  self.assertEqual(backup_operations.prune_local(self.a),2);self.assertTrue(manual.exists());self.assertTrue(other.exists())
 def test_restore_drill_does_not_replace_operating_business_data(self):
  self.a.backup('manual');name=max(self.a.BACKUP_DIR.glob('*_manual.zip'),key=lambda p:p.stat().st_mtime).name;before=copy.deepcopy(self.a.get_state())
  response=self.post('/api/admin/backup-drill',{'name':name,'password':'Admin-test-pass!'});self.assertEqual(response[0],200,response);self.assertEqual(self.a.get_state(),before);self.assertTrue(backup_operations.state(self.a)['lastDrill'])
 def test_protected_download_requires_current_admin_and_one_time_token(self):
  result=self.post('/api/admin/protected-backup',{'password':'Admin-test-pass!','backupPassword':'Portable-test-secret!'});self.assertEqual(result[0],200,result);url=result[1]['download']
  self.assertEqual(self.c.request(url,cookie=self.c.branch)[0],403);status,raw,_=self.c.request(url,cookie=self.c.admin);self.assertEqual(status,200);self.assertTrue(raw.startswith(backup_crypto.MAGIC));self.assertEqual(self.c.request(url,cookie=self.c.admin)[0],403)
 def test_recovery_payload_requires_encryption_and_does_not_auto_replace_identity(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);recovery=root/'recovery';recovery.mkdir();(recovery/'server-key.pem').write_bytes(b'synthetic key')
   with self.assertRaises(ValueError):backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,root/'plain.zip',recovery_dir=recovery)
   archive=root/'r.ybybackup';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive,recovery_dir=recovery,password='Portable-test-secret!')
   value=backup_manager.restore(archive,root/'restored',password='Portable-test-secret!');self.assertTrue(value['recoveryIncluded']);self.assertFalse((root/'restored/server-key.pem').exists())
 def test_attachment_guards_reject_active_content_fake_signature_and_nested_archive(self):
  for name,raw in [('run.exe',b'MZ'),('fake.pdf',b'MZ'),('fake.png',b'bad')]:
   with self.assertRaises(ValueError):attachment_guard.validate(name,raw)
  buffer=io.BytesIO()
  with ZipFile(buffer,'w') as z:z.writestr('run.ps1','Write-Host test')
  with self.assertRaises(ValueError):attachment_guard.validate('test.zip',buffer.getvalue())
  attachment_guard.validate('ok.pdf',b'%PDF-test');attachment_guard.validate('ok.txt','한글'.encode())
 def test_no_unsigned_blanket_static_file_serving(self):
  for path in ['/static/app-core-v4121.js','/static/app-v4121.css','/static/stability-v4121.css']:self.assertEqual(self.c.request(path)[0],200)
  for path in ['/static/app-../../app.py','/static/app-unknown.js','/static/vendor/xlsx.full.min.js']:self.assertEqual(self.c.request(path)[0],404)
 def test_hipass_issue_and_return_require_both_selected_physical_cards(self):
  from test_v4112 import FleetTests
  payload=FleetTests().payload(distributionStatus='불출중')
  row=self.w.operation('/api/hipass/register',payload)[1]['hipass'];ref={'id':row['id'],'recordGroup':'서울','expectedVersion':row['recordVersion']}
  self.assertEqual(self.w.operation('/api/hipass/confirm',ref)[0],400)
  self.assertEqual(self.w.operation('/api/hipass/confirm',{**ref,'physicalChecks':{'holder':True,'hipass':True}})[0],400)
  row=self.w.operation('/api/hipass/confirm',{**ref,'physicalChecks':{'holder':True,'hipass':True,'fuel':True}})[1]['hipass'];self.assertTrue(row['issuedChecks']['checks']['fuel'])
  row=self.w.operation('/api/hipass/update',{**payload,'id':row['id'],'recordGroup':'서울','expectedVersion':row['recordVersion'],'distributionStatus':'회수중','changeReason':'실물 회수 진행','password':'Branch-test-pass!'})[1]['hipass']
  value={'id':row['id'],'recordGroup':'서울','expectedVersion':row['recordVersion'],'returnDate':self.a.business_date(),'changeReason':'실물 전체 회수','password':'Branch-test-pass!'}
  self.assertEqual(self.w.operation('/api/hipass/complete-return',value)[0],400)
  complete=self.w.operation('/api/hipass/complete-return',{**value,'physicalChecks':{'holder':True,'hipass':True,'fuel':True}})
  self.assertEqual(complete[0],200,complete);self.assertTrue(complete[1]['hipass']['returnChecks']['checks']['hipass'])
 def test_secondary_failure_is_visible_and_does_not_prune_local_backup(self):
  with tempfile.TemporaryDirectory() as t:
   backup_operations.configure(self.a,{'enabled':True,'destination':str(Path(t)/'secondary'),'backupPassword':'Portable-test-secret!'},'admin')
   archive=self.a.BACKUP_DIR/'corporate_card_system_synthetic_auto.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive)
   with mock.patch.object(backup_crypto,'encrypt',side_effect=OSError('synthetic unavailable share')),mock.patch.object(backup_operations,'prune_local') as prune:
    backup_operations.after_backup(self.a,archive);prune.assert_not_called()
   self.assertTrue(archive.is_file());self.assertIn('lastFailure',backup_operations.state(self.a));self.assertTrue(backup_operations.status(self.a)['warnings'])
 def test_legacy_windows_manifest_backslashes_restore_portably(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);path=root/'windows-legacy.zip';raw=self.a.DB_PATH.read_bytes();manifest={'version':'4.1.20','database':self.a.DB_PATH.name,'files':{'data\\'+self.a.DB_PATH.name:hashlib.sha256(raw).hexdigest()}}
   with ZipFile(path,'w',ZIP_DEFLATED) as z:z.writestr('manifest.json',json.dumps(manifest));z.writestr('data/'+self.a.DB_PATH.name,raw)
   backup_manager.restore(path,root/'restored');self.assertTrue((root/'restored'/self.a.DB_PATH.name).is_file())
 def test_scoped_storage_read_preserves_global_messages_but_excludes_foreign_business(self):
  with self.a.db() as conn:
   self.a.persist_state(conn,{'cards':[{'id':1,'group':'서울','num':'LOCAL','status':'available'},{'id':2,'group':'인천','num':'FOREIGN','status':'available'}],'notices':[{'id':1,'text':'공통 공지'}]},'fixture')
  result=self.c.state(self.c.branch)['state'];self.assertEqual([r['num'] for r in result['cards']],['LOCAL']);self.assertEqual(result['notices'][0]['text'],'공통 공지')
  self.assertEqual(len(self.c.state(self.c.admin)['state']['cards']),2)
 def test_windows_reserved_and_case_colliding_archive_names_are_rejected_before_extract(self):
  raw=self.a.DB_PATH.read_bytes();sha=hashlib.sha256(raw).hexdigest()
  for names in [('data/CON.db',),('data/a.db','data/A.db')]:
   with tempfile.TemporaryDirectory() as t:
    root=Path(t);archive=root/'bad.zip';stage=root/'stage';stage.mkdir();(stage/'keep').write_text('untouched')
    manifest={'version':'4.1.21','format':2,'database':Path(names[0]).name,'files':{n:sha for n in names}}
    with ZipFile(archive,'w',ZIP_DEFLATED) as z:
     z.writestr('manifest.json',json.dumps(manifest))
     for n in names:z.writestr(n,raw)
    with self.assertRaises(ValueError):backup_manager.verify(archive,stage)
    self.assertEqual((stage/'keep').read_text(),'untouched');self.assertFalse((stage/'data').exists())
 def test_legacy_invalid_money_is_reported_without_truncating_or_fabricating_totals(self):
  rows=[{'id':1,'date':'2026-10-01','group':'서울','status':'승인완료','amount':1.9}, {'id':2,'date':'2026-10-01','group':'서울','status':'승인완료','amount':'1,000'}, {'id':3,'date':'2026-10-01','group':'서울','status':'승인완료','amount':10}]
  with self.a.db() as c:self.a.persist_state(c,{'expenseHistory':rows},'fixture')
  value=self.review(cookie=self.c.branch)[1];self.assertEqual(value['summary']['approvedAmount'],10);self.assertEqual(value['summary']['invalidAmounts'],2);self.assertEqual(value['issueCounts']['invalidAmount'],2)
 def test_future_schema_restore_does_not_replace_existing_data(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);source=root/'future.db';source.write_bytes(self.a.DB_PATH.read_bytes())
   with sqlite3.connect(source) as c:c.execute("INSERT INTO schema_versions VALUES(999,'future')");c.commit()
   archive=root/'future.zip';backup_manager.create(source,self.a.ATTACHMENT_DIR,archive)
   target=root/'data';target.mkdir();(target/'keep').write_text('original')
   with self.assertRaises(ValueError):backup_manager.restore(archive,target)
   self.assertEqual((target/'keep').read_text(),'original');self.assertFalse(list(root.glob('data_before_restore_*')))

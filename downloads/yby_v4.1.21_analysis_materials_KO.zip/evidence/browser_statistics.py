from pathlib import Path
import sys,importlib.util,json,tempfile
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
root=Path(sys.argv[1]).resolve();sys.path.insert(0,str(root));base=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixture',root/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests()
try:
 c.setUp();a=f.app
 common={'group':'서울','dept':'총무','user':'시험사용자','requester':'branch','date':'2026-10-31','purpose':'[출장, 접대] 시험 목적','cardNum':'TEST-5545','cardCompany':'시험사','status':'승인완료','amount':300}
 rows=[{**common,'id':'BROWSER-A','lineItems':[{'date':'2026-10-31','category':'출장','amount':100},{'date':'2026-11-01','category':'접대','amount':200}]},{**common,'id':'BROWSER-I','status':'이관완료','amount':225000,'historicalImport':True,'inputRoute':'EXCEL_LEDGER','used':True}]
 with a.db() as conn:a.persist_state(conn,{'cards':[{'id':1,'num':'TEST-5545','group':'서울','company':'시험사','status':'available'}],'expenseHistory':rows},'admin')
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false}'))
  page.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>!!currentUser&&!loginInFlight');page.evaluate('stopLiveSync()')
  expect(page.locator('#dashTotalCards')).to_have_text('1개');page.click('#nav_v_stats');page.fill('#statsMonth','2026-10');page.fill('#statsCompareMonth','2026-11')
  results={}
  for mode in ['overall','branch','dept','user','purpose']:
   page.select_option('#statsModeSelect',mode);model=page.evaluate('currentStatsExport.model');assert model['current']=={'documents':2,'usage':3,'amount':225300};assert model['comparison']['amount']==0;results[mode]=model['current']
   expect(page.locator('#reportSummaryText')).to_contain_text('225,300원')
  page.select_option('#statsModeSelect','overall');page.locator('#v_stats').screenshot(path=str(base/'actual-statistics-synthetic.png'))
  with page.expect_download() as dl:page.evaluate('exportToExcel()')
  with tempfile.TemporaryDirectory() as temp:
   file=Path(temp)/dl.value.suggested_filename;dl.value.save_as(file)
   with ZipFile(file) as z:assert z.testzip() is None;assert '225300' in ''.join(z.read(n).decode() for n in z.namelist() if n.endswith('.xml'))
  assert not errors,errors
  print('PASS: real dashboard and overall/branch/department/user/purpose screens show 2 documents, 3 line-based uses, 225300 won in October and zero in November; actual XLSX export agrees; no JS errors')
  (base/'statistics-browser-observations.json').write_text(json.dumps({'synthetic':True,'screenResults':results,'comparisonAmount':0,'actualXlsxVerified':True,'javascriptErrors':errors},ensure_ascii=False,indent=2))
  browser.close()
finally:f.SecurityTests.tearDownClass()

"""Synthetic observations for auxiliary card custody review. No production connection."""
import sys,json,importlib.util,copy
from pathlib import Path
root=Path(sys.argv[1]).resolve();sys.path[:0]=[str(root),str(root/'tests')]
import test_security as f,test_v4 as w
f.SecurityTests.setUpClass();out={}
try:
 x=w.V4Tests();x.setUp();a=x.a;c=x.c;a=x.a;c=x.c
 with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_rent']),));conn.commit()
 assert x.rent()[0]==200
 status,body,_=x.operation('/api/cards/return',{'cardId':1,'used':True,'expense':x.draft()})
 out['custody_only_account_used_return']={'http':status,'message':body.get('message'),'cardStillRented':a.get_state()['cards'][0]['status']=='rented'}
 assert status==403 and out['custody_only_account_used_return']['cardStillRented']
 x.setUp();a=x.a;c=x.c;assert x.rent()[0]==200
 status,body,_=x.operation('/api/cards/return',{'cardId':1,'used':True})
 out['used_return_without_internal_expense']={'http':status,'message':body.get('message'),'cardStillRented':a.get_state()['cards'][0]['status']=='rented'}
 assert status==400 and out['used_return_without_internal_expense']['cardStillRented']
 status,body,_=x.operation('/api/cards/return',{'cardId':1,'used':True,'expense':x.draft()})
 s=a.get_state();out['valid_used_return']={'http':status,'card':s['cards'][0]['status'],'internalExpenseStatus':s['expense'][0]['status'],'externalFinalStatusKnown':bool(s['expense'][0].get('sourceRef'))}
 assert status==200 and s['expense'][0]['status']=='승인대기' and s['cards'][0]['status']=='available'
 x.setUp();a=x.a;c=x.c;assert x.rent()[0]==200
 status,body,_=x.operation('/api/cards/return',{'cardId':1,'used':False})
 out['unused_return']={'http':status,'card':a.get_state()['cards'][0]['status'],'expenseCount':len(a.get_state()['expense'])};assert status==200 and out['unused_return']['expenseCount']==0
 x.setUp();a=x.a;c=x.c
 full='1234-5678-9012-3456';cards=copy.deepcopy(a.get_state()['cards']);cards[0]['num']=full
 assert c.save({'cards':cards},c.admin)[0]==200
 out['authorized_branch_receives_full_number']=c.state(c.branch)['state']['cards'][0]['num']==full;assert out['authorized_branch_receives_full_number']
 with a.db() as conn:conn.execute("UPDATE users SET permissions_json='[]' WHERE username='admin'");conn.commit()
 status,body,_=x.operation('/api/cards/register',{'num':'SYNTHETIC-ADMIN-CARD','group':'본사','company':'test'},c.admin)
 out['all_scope_with_no_menu_permissions']={'registrationHttp':status,'allScope':a.user_scope('admin'),'permissions':sorted(a.permissions_for('admin'))};assert status==200
 cards=copy.deepcopy(a.get_state()['cards']);cards[0]['status']='lost'
 out['lost_status_not_in_corporate_card_state_enum']={'http':c.save({'cards':cards},c.admin)[0]};assert out['lost_status_not_in_corporate_card_state_enum']['http']==400
 expense={'lineItems':[{'date':'2026-10-31','category':'출장','merchant':'A','description':'a','quantity':1,'unitPrice':100},{'date':'2026-11-01','category':'접대','merchant':'B','description':'b','quantity':1,'unitPrice':200}]}
 a.domain.prepare_expense(expense)
 out['cross_month_expense_preparation']={'date':expense['date'],'amount':expense['amount'],'lineDates':[r['date'] for r in expense['lineItems']]};assert expense['date']=='2026-10-31' and expense['amount']==300
 print(json.dumps(out,ensure_ascii=False,indent=2))
finally:f.SecurityTests.tearDownClass()

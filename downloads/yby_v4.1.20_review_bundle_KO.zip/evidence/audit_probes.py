import sys,importlib.util,json,tempfile,zipfile,pathlib,hashlib
# Linux review reproduction: python audit_probes.py EXTRACTED_PACKAGE_DIR ORIGINAL_ZIP
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/analysis/v4120-review/extracted/yby_v4.1.20_full').resolve();sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('fixture',root/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();out={}
try:
 c.setUp();a=f.app
 out['unauthenticated_account_choices']={'status':c.request('/api/bootstrap')[0],'usernames_exposed':len(c.request('/api/bootstrap')[1]['users'])}
 out['authenticated_reauthentication_no_shared_throttle']=[c.request('/api/verify-current-password',{'password':'wrong'},c.branch)[0] for _ in range(6)]
 card={'id':1,'num':'1234-5678-9012-3456','group':'서울','status':'available','company':'synthetic-only'}
 with a.db() as db:a.persist_state(db,{'cards':[card]},'admin')
 out['authorized_branch_state_contains_full_card_number']=c.state(c.branch)['state']['cards'][0]['num']==card['num']
 with a.db() as db:db.execute("UPDATE users SET permissions_json='[]' WHERE username='admin'");db.commit()
 out['all_scope_is_superadministrator_independent_of_menu_permissions']=len(c.state(c.admin)['state']['cards'])==1
 a.backup('manual');archive=next(a.BACKUP_DIR.glob('*_manual.zip'))
 with zipfile.ZipFile(archive) as z:
  files=z.namelist();out['backup']={'zip_encrypted':any(i.flag_bits&1 for i in z.infolist()),'database_plain_sqlite_header':z.read('data/test.db').startswith(b'SQLite format 3'),'vault_key_included': 'data/admin_password_vault.key' in files,'tls_certificate_or_lan_settings_included':any('certificate' in n or 'lan_settings' in n for n in files)}
  with tempfile.TemporaryDirectory() as t:
   z.extractall(t)
   import sqlite3,password_vault
   with sqlite3.connect(pathlib.Path(t)/'data/test.db') as db:row=db.execute("SELECT ciphertext,credential_hash FROM credential_vault WHERE username='branch'").fetchone()
   out['backup']['linux_archive_alone_can_decrypt_stored_password']=bool(row and password_vault.reveal(pathlib.Path(t)/'data','branch',row[0],row[1])=='Branch-test-pass!')
 out['source_files_inspected']={'html_lines':len((root/'templates/index.html').read_text().splitlines()),'app_lines':len((root/'app.py').read_text().splitlines()),'operations_lines':len((root/'operations.py').read_text().splitlines())}
 with zipfile.ZipFile(sys.argv[2] if len(sys.argv)>2 else '/workspace/analysis/v4120-review/reviewed.zip') as z:
  prefix='yby_v4.1.20_full/';manifest=json.loads(z.read(prefix+'MANIFEST.json'));out['manifest_file_count']=len(manifest['files']);out['manifest_all_hashes_match']=all(hashlib.sha256(z.read(prefix+n)).hexdigest()==h for n,h in manifest['files'].items())
 print(json.dumps(out,ensure_ascii=False,indent=2))
finally:f.SecurityTests.tearDownClass()

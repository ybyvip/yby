/* Poll the normalized local inbox. Oracle collection is a separate future adapter. */
const workflowLive={widgets:new Map(),timer:null,session:0,reportRef:null};
function liveInboxHTML(id,kind){
    return `<section id="${id}" class="live-inbox" aria-label="외부 ${kind==='application'?'신청서':'정산서'} 수신 목록">
      <header><div><h3>외부 ${kind==='application'?'신청서':'정산서'} 수신 목록</h3><span class="live-auto">10초 자동 갱신</span></div><button type="button" class="btn-secondary live-refresh">지금 갱신</button></header>
      <div class="live-meta"><p class="live-health" role="status">수신함 확인 중…</p><p class="live-counts"></p></div>
      <details class="live-filter"><summary>검색·상태 필터</summary><div class="live-controls"><label>문서번호·신청자·목적<input class="live-query" type="search" maxlength="200" placeholder="검색어 입력 후 Enter"></label><label>YBY 적용 상태<select class="live-status"><option value="all">전체</option><option value="unapplied">미적용</option><option value="applied">적용</option><option value="withdrawn">회수·삭제</option></select></label></div></details>
      <div class="live-list"></div><div class="live-selected" hidden></div>
      <footer hidden><button type="button" class="btn-secondary live-prev">이전</button><span class="live-page"></span><button type="button" class="btn-secondary live-next">다음</button></footer></section>`;
}
function updateLiveSelection(){
    for(const widget of workflowLive.widgets.values()){
        if(!widget.root.isConnected)continue;
        const area=widget.root.querySelector('.live-selected'),doc=widget.kind==='application'?rentalIntake.application:rentalIntake.settlement;
        if(!area)continue;
        if(!doc){area.hidden=true;area.replaceChildren();delete area.dataset.key;continue;}
        if(area.dataset.key===doc.key)continue;
        const text=document.createElement('span');text.textContent='선택 문서 '+doc.documentNo+' · 입력 중 / 저장 전';
        const clear=document.createElement('button');clear.type='button';clear.className='btn-secondary';clear.textContent='선택 해제';
        clear.onclick=()=>{if(widget.kind==='application')clearRentalApplication();else clearExternalSettlement();updateLiveSelection();refreshWorkflowInbox();};
        area.replaceChildren(text,clear);area.hidden=false;area.dataset.key=doc.key;
    }
}
function attachLiveInbox(id,kind,cardId=null){
    const root=document.getElementById(id);if(!root)return;
    const previous=workflowLive.widgets.get(id);if(previous?.root===root)return previous;
    previous?.controller?.abort();
    const widget={root,id,kind,cardId,offset:0,busy:false,serial:0,signature:null};workflowLive.widgets.set(id,widget);
    const refresh=()=>{widget.signature=null;refreshLiveInbox(widget);};
    root.querySelector('.live-refresh').onclick=refresh;
    root.querySelector('.live-status').onchange=()=>{widget.offset=0;refresh();};
    root.querySelector('.live-query').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();widget.offset=0;refresh();}};
    root.querySelector('.live-prev').onclick=()=>{widget.offset=Math.max(0,widget.offset-50);refresh();};
    root.querySelector('.live-next').onclick=()=>{widget.offset+=50;refresh();};
    return widget;
}
function liveInboxVisible(widget){return currentUser&&hasViewPermission('v_card_rent')&&!document.hidden&&widget.root.isConnected&&widget.root.offsetParent!==null;}
async function refreshLiveInbox(widget){
    if(!widget||widget.busy||!liveInboxVisible(widget))return;
    widget.busy=true;const serial=++widget.serial,session=workflowLive.session;widget.controller=new AbortController();
    const timeout=setTimeout(()=>widget.controller.abort(),12000);
    const root=widget.root,params=new URLSearchParams({kind:widget.kind,q:root.querySelector('.live-query').value,status:root.querySelector('.live-status').value,offset:widget.offset});
    if(widget.cardId!==null)params.set('cardId',widget.cardId);
    try{
        const response=await fetch('/api/external-documents?'+params,{signal:widget.controller.signal,cache:'no-store'}),data=await response.json();
        if(!response.ok||!data.ok)throw Error(data.message||'수신함 조회 실패');
        if(serial!==widget.serial||session!==workflowLive.session||!liveInboxVisible(widget))return;
        root.querySelector('.live-health').textContent='Oracle 연결 대기 · 확인 '+formatServerTime(data.checkedAt);
        root.querySelector('.live-health').classList.remove('live-error');
        const counts=data.counts||{};root.querySelector('.live-counts').textContent=`미적용 ${counts.unapplied||0} · 적용 ${counts.applied||0} · 회수·삭제 ${counts.withdrawn||0}`;
        if(widget.offset>0&&widget.offset>=data.total){widget.offset=Math.max(0,Math.floor((data.total-1)/50)*50);widget.busy=false;refreshLiveInbox(widget);return;}
        const selected=widget.kind==='application'?rentalIntake.application:rentalIntake.settlement;
        const signature=JSON.stringify([data.items,selected?.key]);
        if(signature!==widget.signature){
            const list=root.querySelector('.live-list');list.replaceChildren();
            if(!data.items.length){const empty=document.createElement('p');empty.className='ledger-help';empty.textContent='수신 자료 없음 · 직접 입력할 수 있습니다.';list.append(empty);}
            for(const doc of data.items){
                const row=document.createElement('article');row.className='live-document';row.dataset.key=doc.key;
                const body=document.createElement('div'),title=document.createElement('strong'),badge=document.createElement('span');
                title.textContent=doc.documentNo+' · '+doc.group;
                badge.className='live-badge '+doc.applicationStatus;badge.textContent=doc.bound?'적용':doc.withdrawn?'회수·삭제':'미적용';
                const info=document.createElement('p');info.textContent='신청자 '+doc.applicantName+' / 사용자 '+(doc.user||'확인 필요')+' · 카드 끝자리 '+(doc.cardLast4||'미지정')+(doc.amount!=null?' · '+Number(doc.amount).toLocaleString()+'원':'');
                const purpose=document.createElement('p');purpose.textContent=doc.purpose;
                const status=document.createElement('small');status.textContent='외부 결재: '+(doc.approvalStatus||'미확인')+(doc.bound&&doc.withdrawn?' · 원문 회수·삭제됨':'')+' · 수신 '+formatServerTime(doc.receivedAt)+(doc.appliedAt?' · YBY 적용 '+formatServerTime(doc.appliedAt):selected?.key===doc.key?' · 현재 입력 중 (저장 전)':'');
                body.append(title,badge,info,purpose,status);
                const button=document.createElement('button');button.type='button';button.className='btn-secondary';button.textContent=doc.bound||doc.withdrawn?'원문 확인':'선택·확인';
                button.onclick=()=>openExternalPicker(widget.kind,widget.cardId,doc.key);row.append(body,button);list.append(row);
            }
            widget.signature=signature;
        }
        root.querySelector('footer').hidden=data.total<=50&&widget.offset===0;
        root.querySelector('.live-filter summary').textContent='검색·상태 필터'+(params.get('q')||params.get('status')!=='all'?' (조건 적용 중)':'');
        updateLiveSelection();
        root.querySelector('.live-page').textContent=`${data.total}건 · ${data.total?widget.offset+1:0}~${Math.min(data.total,widget.offset+50)}`;
        root.querySelector('.live-prev').disabled=widget.offset===0;root.querySelector('.live-next').disabled=widget.offset+50>=data.total;
    }catch(error){
        if(serial===widget.serial&&session===workflowLive.session&&root.isConnected){root.querySelector('.live-health').textContent='자동 갱신 실패: 마지막 표시 자료는 최신이 아닐 수 있습니다. 지금 갱신을 눌러 다시 확인하세요.';root.querySelector('.live-health').classList.add('live-error');}
    }finally{clearTimeout(timeout);widget.busy=false;}
}
function refreshWorkflowInbox(){
    if(!currentUser||!hasViewPermission('v_card_rent'))return;
    let root=document.getElementById('applicationLiveInbox');
    if(root&&!root.children.length)root.innerHTML=liveInboxHTML('applicationLiveContent','application');
    attachLiveInbox('applicationLiveContent','application');updateLiveSelection();
    for(const [id,widget] of workflowLive.widgets){if(!widget.root.isConnected){widget.controller?.abort();workflowLive.widgets.delete(id);}else refreshLiveInbox(widget);}
    if(!workflowLive.timer)workflowLive.timer=setInterval(()=>{refreshWorkflowInbox();if(rentalIntake.picker&&!document.hidden)loadExternalInbox(true);},10000);
}
function mountReturnLiveInbox(cardId){
    const area=document.getElementById('returnLiveInbox');if(area)area.innerHTML=liveInboxHTML('settlementLiveContent','settlement');
    attachLiveInbox('settlementLiveContent','settlement',cardId);refreshWorkflowInbox();
}
function workflowSessionReset(){
    workflowLive.session++;clearInterval(workflowLive.timer);workflowLive.timer=null;
    for(const widget of workflowLive.widgets.values())widget.controller?.abort();workflowLive.widgets.clear();
    document.getElementById('applicationLiveInbox')?.replaceChildren();clearReportCopyReference();
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshWorkflowInbox();});
function returnReportCopyHTML(){
    return hasViewPermission('v_report_write')?'<section class="settlement-section"><label class="intake-confirm"><input type="checkbox" id="returnCopyReport">반납·정산 저장 후 관련 보고서 초안 열기</label><p class="settlement-help">사용 정보·건별 명세·합계를 복사합니다. 보고서는 검토 후 별도로 상신하며, 증빙 파일은 원본 정산에서 확인합니다.</p></section>':'<p class="settlement-help">보고서 초안 복사는 ‘보고서 작성 및 기안’ 권한이 필요합니다.</p>';
}
function reportCopyPayload(){return workflowLive.reportRef?{sourceExpenseRef:{...workflowLive.reportRef}}:{};}
function clearReportCopyReference(){workflowLive.reportRef=null;const banner=document.getElementById('reportCopyBanner');if(banner){banner.hidden=true;banner.replaceChildren();}}
async function openReturnReportDraft(reference){
    if(!hasViewPermission('v_report_write')||!hasViewPermission('v_card_rent')){alert('보고서 작성 및 카드 불출·반납 권한이 필요합니다.');return;}
    const session=workflowLive.session;
    try{
        const response=await fetch('/api/report-prefill?'+new URLSearchParams(reference),{cache:'no-store'}),value=await response.json();
        if(!response.ok||!value.ok)throw Error(value.message||'보고서 초안 조회 실패');
        if(session!==workflowLive.session)return;
        if((document.getElementById('repTitle').value.trim()||document.getElementById('repContent').value.trim())&&!confirm('작성 중인 보고서 제목과 본문을 정산 자료로 바꾸시겠습니까?'))return;
        const draft=value.draft;document.getElementById('repGroup').value=draft.group;updateApprovalChoices(true);
        document.getElementById('repType').value=draft.type;document.getElementById('repTitle').value=draft.title;document.getElementById('repContent').value=draft.content;
        workflowLive.reportRef=draft.sourceExpenseRef;
        const banner=document.getElementById('reportCopyBanner');banner.hidden=false;banner.replaceChildren();
        const text=document.createElement('p');text.textContent='반납 정산 '+draft.sourceExpenseRef.id+'에서 복사한 미상신 초안 · 정산 결재 상태(복사 시점): '+draft.sourceStatus+' · 본인 검토·최고관리자 결재선을 확인하고 내용을 검토하세요.';
        const clear=document.createElement('button');clear.type='button';clear.className='btn-secondary';clear.textContent='원본 연결 해제';clear.onclick=clearReportCopyReference;banner.append(text,clear);
        switchView('v_report_write',document.getElementById('nav_v_report_write'));document.getElementById('repTitle').focus();
    }catch(error){alert('반납 자료는 저장되어 있습니다. 보고서 초안을 열지 못했습니다: '+error.message);}
}

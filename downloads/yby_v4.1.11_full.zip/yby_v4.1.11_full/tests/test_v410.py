"""Requested session, credential-view, detailed settlement and transport regressions."""
import copy
import io
import json
from pathlib import Path
import ssl
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from unittest import mock
import test_security as fixtures
import test_v4 as workflow
import backup_manager
import lan_setup
import operations
import password_vault


class FeatureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixtures.SecurityTests.setUpClass()
    @classmethod
    def tearDownClass(cls):fixtures.SecurityTests.tearDownClass()
    def setUp(self):
        self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
    def update(self,**overrides):
        payload={'username':'branch','scope':'서울','permissions':['v_card_rent','v_expense','v_report_write','v_report_box'],'password':''};payload.update(overrides)
        return self.c.request('/api/admin/account-update',payload,self.c.admin)
    def reveal(self,username='branch',password='Admin-test-pass!',cookie=None):
        return self.c.request('/api/admin/password-reveal',{'username':username,'adminPassword':password},cookie or self.c.admin)
    def detailed(self):
        value=self.w.draft();value['amount']=23000
        value['lineItems']=[{'date':'2026-10-15','category':'식대','merchant':'식당 <&>','description':'점심 식대','quantity':2,'unitPrice':9000,'amount':18000,'note':'회의'}, {'date':'2026-10-16','category':'교통','merchant':'택시','description':'외근 이동','quantity':1,'unitPrice':5000,'amount':5000,'note':''}]
        return value
    def test_permissions_apply_immediately_without_ending_either_session(self):
        other=self.c.login('readonly','Branch-test-pass!')
        self.assertEqual(self.update(permissions=['v_dashboard'])[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=other)[0],200)
        self.assertEqual(self.w.operation('/api/expenses/submit',{'expense':self.w.draft()})[0],403)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.admin)[0],200)
    def test_admin_reset_preserves_active_user_and_other_branch(self):
        other=self.c.login('readonly','Branch-test-pass!')
        self.assertEqual(self.update(password='Admin-reset-new-pass!')[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=other)[0],200)
        self.assertEqual(self.c.request('/api/login',{'username':'branch','password':'Branch-test-pass!'})[0],401)
        fresh=self.c.login('branch','Admin-reset-new-pass!')
        self.assertEqual(self.c.request('/api/state',cookie=fresh)[0],403)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],200)
    def test_explicit_session_revoke_targets_only_chosen_account(self):
        other=self.c.login('readonly','Branch-test-pass!')
        self.assertEqual(self.c.request('/api/admin/account-sessions/revoke',{'username':'branch'},self.c.admin)[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],401)
        self.assertEqual(self.c.request('/api/state',cookie=other)[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.admin)[0],200)
    def test_admin_save_does_not_logout_self(self):
        self.assertFalse(self.update(username='admin',scope='ALL',permissions=[])[1]['reloginRequired'])
        self.assertEqual(self.c.request('/api/state',cookie=self.c.admin)[0],200)
    def test_current_password_requires_admin_reauthentication(self):
        self.assertEqual(self.reveal(password='incorrect')[0],403)
        self.assertEqual(self.reveal(cookie=self.c.branch)[0],403)
        self.assertEqual(self.c.request('/api/admin/password-reveal',{'username':'branch','adminPassword':'Admin-test-pass!'})[0],401)
        status,value,headers=self.reveal();self.assertEqual(status,200);self.assertEqual(value['password'],'Branch-test-pass!');self.assertEqual(value['expiresIn'],30)
        self.assertEqual(headers['Cache-Control'],'no-store')
    def test_reveal_failure_rate_is_limited(self):
        for _ in range(5):self.assertEqual(self.reveal(password='incorrect')[0],403)
        self.assertEqual(self.reveal()[0],429)
    def test_reveal_audit_and_general_state_never_contain_secret(self):
        secret='Vault-updated-secret!';self.assertEqual(self.update(password=secret)[0],200)
        self.assertEqual(self.reveal()[1]['password'],secret)
        for path in ('/api/state','/api/admin/accounts','/api/admin/account-history','/api/audit'):
            self.assertNotIn(secret,json.dumps(self.c.request(path,cookie=self.c.admin)[1]))
        with self.a.db() as c:
            data=' '.join(r[0] or '' for r in c.execute('SELECT details FROM audit_events'))
            self.assertNotIn(secret,data)
            self.assertTrue(c.execute("SELECT 1 FROM audit_events WHERE action='PASSWORD_REVEALED'").fetchone())
            encrypted=c.execute("SELECT ciphertext FROM credential_vault WHERE username='branch'").fetchone()[0]
            self.assertNotIn(secret,encrypted)
    def test_missing_legacy_value_recaptured_after_successful_login(self):
        with self.a.db() as c:c.execute("DELETE FROM credential_vault WHERE username='branch'");c.commit()
        self.assertEqual(self.reveal()[0],409)
        self.c.login('branch','Branch-test-pass!')
        self.assertEqual(self.reveal()[1]['password'],'Branch-test-pass!')
    def test_tampered_or_moved_ciphertext_is_rejected(self):
        with self.a.db() as c:
            ciphertext=c.execute("SELECT ciphertext FROM credential_vault WHERE username='admin'").fetchone()[0]
            c.execute("UPDATE credential_vault SET ciphertext=? WHERE username='branch'",(ciphertext,));c.commit()
        self.assertEqual(self.reveal()[0],409)
        self.c.login('branch','Branch-test-pass!')
        self.assertEqual(self.reveal()[1]['password'],'Branch-test-pass!')
    def test_encrypted_value_and_linux_key_survive_full_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            archive=Path(folder)/'full.zip'
            backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive)
            restored=Path(folder)/'restored';backup_manager.restore(archive,restored)
            import sqlite3
            with sqlite3.connect(restored/self.a.DB_PATH.name) as c:row=c.execute("SELECT ciphertext,credential_hash FROM credential_vault WHERE username='branch'").fetchone()
            self.assertEqual(password_vault.reveal(restored,'branch',*row),'Branch-test-pass!')
    def test_multi_line_return_saves_atomic_server_calculated_total(self):
        self.assertEqual(self.w.rent()[0],200)
        status,_,_=self.w.operation('/api/cards/return',{'cardId':1,'used':True,'expense':self.detailed()});self.assertEqual(status,200)
        state=self.a.get_state();self.assertEqual(state['cards'][0]['status'],'available')
        expense=state['expense'][0];self.assertEqual(expense['amount'],23000);self.assertEqual(len(expense['lineItems']),2)
        self.assertEqual(expense['category'],'복수 항목');self.assertIn('외 1곳',expense['merchant'])
    def test_inconsistent_total_rolls_back_card_return(self):
        self.w.rent();expense=self.detailed();expense['amount']=1
        self.assertEqual(self.w.operation('/api/cards/return',{'cardId':1,'used':True,'expense':expense})[0],400)
        self.assertEqual(self.a.get_state()['cards'][0]['status'],'rented');self.assertEqual(self.a.get_state()['expense'],[])
    def test_invalid_line_values_are_rejected(self):
        for key,value in [('quantity',True),('quantity',0),('quantity',1.5),('unitPrice',-1),('date','2026-02-30'),('amount',7),('description','')]:
            expense=self.detailed();expense['lineItems'][0][key]=value
            self.assertEqual(self.w.operation('/api/expenses/submit',{'expense':expense})[0],400,(key,value))
    def test_empty_or_excessive_line_count_is_rejected(self):
        for lines in ([],self.detailed()['lineItems']*51):
            expense=self.detailed();expense['lineItems']=lines
            self.assertEqual(self.w.operation('/api/expenses/submit',{'expense':expense})[0],400)
    def test_branch_cannot_approve_even_own_settlement(self):
        row=self.w.operation('/api/expenses/submit',{'expense':self.detailed()})[1]['expense']
        self.assertEqual(self.w.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'branch','decision':'approve'})[0],403)
    def test_top_admin_can_approve_and_reject_own_with_detail_preserved(self):
        for decision in ('approve','reject'):
            row=self.w.operation('/api/expenses/submit',{'expense':self.detailed()},self.c.admin)[1]['expense']
            status,body,_=self.w.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'admin','decision':decision,'reason':'본인 처리 시험'},self.c.admin)
            self.assertEqual(status,200,body);self.assertTrue(body['expense']['selfDecision']);self.assertEqual(len(body['expense']['lineItems']),2)
    def test_pending_line_total_cannot_be_edited_to_forge_approval(self):
        self.w.operation('/api/expenses/submit',{'expense':self.detailed()})
        state=copy.deepcopy(self.a.get_state());state['expense'][0]['amount']=1
        self.assertEqual(self.c.save({'expense':state['expense']},self.c.branch)[0],400)


class RedirectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixtures.SecurityTests.setUpClass();cls.temp=tempfile.TemporaryDirectory()
        root=Path(cls.temp.name)
        import contextlib
        with contextlib.redirect_stdout(io.StringIO()):lan_setup.create_certificates(root,root,'10.10.0.121','test-server',None)
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.minimum_version=ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(str(root/'server.pem'),str(root/'server-key.pem'))
        cls.server=operations.HTTPSWithRedirectServer(('127.0.0.1',0),fixtures.app.Handler);cls.server.configure_tls(context,'10.10.0.121')
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,*args,**kwargs):return None
        cls.http=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
        cls.https=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=ssl.create_default_context(cafile=str(root/'root-ca.pem'))))
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.temp.cleanup();fixtures.SecurityTests.tearDownClass()
    def test_http_navigation_redirects_to_same_https_port_and_path(self):
        port=self.server.server_port
        with self.assertRaises(urllib.error.HTTPError) as error:self.http.open(f'http://localhost:{port}/?from=bookmark')
        response=error.exception;self.assertEqual(response.code,308);self.assertEqual(response.headers['Location'],f'https://localhost:{port}/?from=bookmark');self.assertIsNone(response.headers.get('Set-Cookie'))
    def test_unknown_host_cannot_create_an_open_redirect(self):
        request=urllib.request.Request(f'http://localhost:{self.server.server_port}/',headers={'Host':'attacker.invalid'})
        with self.assertRaises(urllib.error.HTTPError) as error:self.http.open(request)
        self.assertEqual(error.exception.code,400);self.assertIsNone(error.exception.headers.get('Location'))
    def test_plaintext_credentials_are_not_authenticated(self):
        request=urllib.request.Request(f'http://localhost:{self.server.server_port}/api/login',data=b'{"username":"admin","password":"unused"}',headers={'Content-Type':'application/json'})
        before=len(fixtures.app.SESSIONS)
        with self.assertRaises(urllib.error.HTTPError) as error:self.http.open(request)
        self.assertEqual(error.exception.code,400);self.assertEqual(len(fixtures.app.SESSIONS),before)
    def test_https_still_verifies_certificate_and_serves_login(self):
        with self.https.open(f'https://localhost:{self.server.server_port}/') as response:self.assertIn(b'value="admin"',response.read())
        with self.https.open(f'https://localhost:{self.server.server_port}/health') as response:self.assertEqual(json.load(response)['version'],'4.1.11')

if __name__=='__main__':unittest.main()

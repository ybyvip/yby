"""Real UI acceptance: submission, decisions, export, failure input retention, mobile."""
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();case=f.SecurityTests()
try:
    case.setUp();a=f.app
    case.save({'cards':[{'id':1,'num':'TEST','group':'서울','status':'available','company':'test'}]},case.admin)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=__import__('os').environ.get('V3_TEST_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
        errors=[];dialogs=[]
        def login(name,password,width=1280):
            page=browser.new_page(viewport={'width':width,'height':900})
            page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()))
            page.goto(f'http://127.0.0.1:{case.server.server_port}/')
            page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter')
            page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'")
            page.evaluate('stopLiveSync()');return page
        branch=login('branch','Branch-test-pass!')
        branch.evaluate("switchView('v_report_write',document.getElementById('nav_v_report_write'))")
        branch.fill('#repTitle','한글 <&> 기안');branch.fill('#repContent','실제 브라우저 검증');branch.select_option('#approver2','admin')
        branch.evaluate('async()=>await handleReportSubmit({preventDefault(){},target:{reset(){}}})')
        assert len(a.get_state()['reports'])==1
        doc=a.get_state()['reports'][0]['id'];assert a.get_state()['reports'][0]['group']=='서울'
        admin=login('admin','Admin-test-pass!')
        admin.evaluate("switchView('v_report_box',document.getElementById('nav_v_report_box'))")
        admin.locator('#reportTable tr').filter(has_text='한글 <&> 기안').locator('button').filter(has_text='최종 승인').click()
        admin.wait_for_function("() => reportList.some(x=>x.status==='approved')")
        print('Document UI submit, server identity, final approval PASS')
        branch.evaluate('async()=>await loadServerState()')
        branch.evaluate("switchView('v_report_write',document.getElementById('nav_v_report_write'))")
        branch.fill('#repTitle','실패 시 보존되는 입력');branch.fill('#repContent','보존할 본문');branch.select_option('#approver2','admin')
        before=len(a.get_state()['reports'])
        branch.route('**/api/documents/submit',lambda r:r.fulfill(status=500,content_type='application/json',body='{"ok":false,"message":"SIMULATED_SAVE_FAILURE"}'))
        count=len(dialogs)
        branch.evaluate('async()=>await handleReportSubmit({preventDefault(){},target:{reset(){document.getElementById("repTitle").value=""}}})')
        assert branch.input_value('#repTitle')=='실패 시 보존되는 입력'
        assert len(a.get_state()['reports'])==before and '기안이 서버에 저장되었습니다.' not in dialogs[count:]
        print('Save failure keeps form inputs and never shows success PASS')
        with branch.expect_download() as download:
            branch.evaluate("downloadExcelReport('검증.xls','검증',['항목','금액'],[['한글 <&>',100]])")
        from zipfile import ZipFile
        with ZipFile(download.value.path()) as z:xml=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        assert len(xml.findall('.//s:row',ns))==2
        cells=xml.findall('.//s:c',ns)
        assert cells[2].find('s:is/s:t',ns).text=='한글 <&>' and cells[3].find('s:v',ns).text=='100'
        assert download.value.suggested_filename.endswith('.xlsx')
        print('Real XLSX download: rows/cells/Korean/special chars/numeric cell PASS')
        admin.evaluate("switchView('v_admin',document.getElementById('nav_v_admin'));createFullBackup()")
        admin.fill('#backupPassword','Admin-test-pass!')
        with admin.expect_download() as backup:admin.evaluate('async()=>await confirmFullBackup()')
        from zipfile import ZipFile
        with ZipFile(backup.value.path()) as z:assert 'manifest.json' in z.namelist() and z.testzip() is None
        print('Full backup UI reauthentication and real ZIP download PASS')
        admin.evaluate("switchView('v_hipass_reg',document.getElementById('nav_v_hipass_reg'))")
        admin.select_option('#regHipassType','선불형');admin.select_option('#regHipassGroup','서울')
        for name,value in {'regHipassCompany':'test','regHipassNum':'HP-BROWSER','regHipassUser':'fixture','regHipassCar':'TEST-CAR','regHipassIssueDate':'2026-01-01','regHipassExpiryDate':'2099-01-01','regHipassReason':'fixture'}.items():admin.fill('#'+name,value)
        admin.evaluate('async()=>await handleRegisterHiPass({preventDefault(){},target:{reset(){}}})')
        assert a.get_state()['hipass'][0]['num']=='HP-BROWSER'
        admin.evaluate("switchView('v_complaint',document.getElementById('nav_v_complaint'))")
        admin.select_option('#compGroup','서울')
        for name,value in {'compPhone':'010-0000-0000','compTitle':'UI fixture','compContent':'UI test'}.items():admin.fill('#'+name,value)
        admin.evaluate('async()=>await handleComplaintSubmit({preventDefault(){},target:{reset(){}}})')
        complaint=a.get_state()['complaint'][0]['id']
        admin.evaluate('(id)=>updateComplaintStatus(id,"처리완료")',complaint)
        assert a.get_state()['complaint'][0]['status']=='처리완료'
        admin.evaluate('openNoticeManageModal()');admin.fill('#newNoticeTitle','UI notice');admin.fill('#newNoticeInput','UI notice body')
        admin.evaluate('async()=>await addNewNotice()');assert a.get_state()['notices'][0]['title']=='UI notice'
        admin.evaluate("closeModal();switchView('v_dashboard',document.getElementById('nav_v_dashboard'))")
        admin.locator('#v_dashboard').click(button='right',position={'x':20,'y':20})
        admin.fill('#newMemoText','Private UI memo')
        admin.locator('#modalFooter button').filter(has_text='저장하기').click();admin.wait_for_selector('#commonModal',state='hidden')
        assert any(x['text']=='Private UI memo' and x['owner']=='admin' for x in a.get_state()['memos'].values())
        admin.evaluate('toggleChatPanel(true)')
        admin.evaluate('async()=>await sendChatMessage("UI message","ALL")')
        assert a.get_state()['chat'][-1]['text']=='UI message'
        print('Hi-pass registration, complaint completion, notice, private memo and actual chat save PASS')
        mobile=login('branch','Branch-test-pass!',390)
        mobile.evaluate("switchView('v_report_write',document.getElementById('nav_v_report_write'))")
        assert mobile.locator('#repTitle').is_visible()
        admin.evaluate('openAddAccountModal()');admin.press('#newAccName','Tab')
        assert admin.evaluate("document.getElementById('commonModal').contains(document.activeElement)")
        admin.press('#newAccScope','Escape');assert admin.locator('#commonModal').is_hidden()
        assert not errors,errors
        print('390px viewport, modal keyboard focus/Escape, no JS runtime errors PASS')
        browser.close()
finally:f.SecurityTests.tearDownClass()

import os
os.umask(0o077)
from db_lock import DatabaseLock
import storage, domain, backup_manager, operations, login_weather
from datetime import timezone, timedelta
import logging
from logging.handlers import RotatingFileHandler
from contextlib import closing
import sys
import json
import re
import base64
import mimetypes
import uuid
import pathlib
from urllib.parse import quote
import sqlite3
import ssl
from http.cookies import SimpleCookie
from security import (legacy_hash, encode_hash, password_hash, verify_password, validate_password,
                      clean_accounts, normalize_expenses, READ_VIEWS, validate_branch_changes, StateConflict)
import hashlib
import shutil
import threading
import time
import secrets
import password_vault
import webbrowser
from html import escape as html_escape
from datetime import datetime
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs

APP_VERSION = "4.1.11"
LOGIN_WEATHER = login_weather.WeatherCache()
BASE_DIR = Path(__file__).resolve().parent
DB_DIR = BASE_DIR / "data"
BACKUP_DIR = BASE_DIR / "backups"
HTML_PATH = BASE_DIR / "templates" / "index.html"
DB_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)
DB_PATH = DB_DIR / "corporate_card_system.db"
HOST = os.environ.get("V3_HOST", "127.0.0.1")
PORT = int(os.environ.get("V3_PORT", "5000"))
AUTO_BROWSER = os.environ.get("V3_AUTO_BROWSER", "0") == "1"
LOCK = threading.RLock()
SESSIONS = {}
SESSION_ACTIVITY = {}
SESSION_IPS = {}
SESSION_IDLE_TIMEOUT = max(60,int(os.environ.get("V4_SESSION_IDLE_SECONDS","900")))
SESSION_ABSOLUTE_TIMEOUT = max(300,int(os.environ.get("V4_SESSION_ABSOLUTE_SECONDS","28800")))
SESSION_CREATED = {}
SESSION_REQUIRE_CHANGE = {}
PASSWORD_REVEAL_FAILURES = {}
OPERATION_WARNINGS = []
BACKUP_DOWNLOAD_TOKENS = {}
LAST_FULL_BACKUP = 0
DB_PATH = Path(os.environ.get("V3_DATA_DIR",str(DB_DIR))) / "corporate_card_system.db"
DB_DIR = DB_PATH.parent
DB_DIR.mkdir(parents=True,exist_ok=True)

def store_password(conn,key_path,username,password,actor,timestamp):
    credential_hash=conn.execute('SELECT password_hash FROM users WHERE username=?',(username,)).fetchone()[0]
    ciphertext=password_vault.seal(DB_PATH.parent,username,password,credential_hash)
    conn.execute('''INSERT INTO credential_vault VALUES(?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET
        ciphertext=excluded.ciphertext,credential_hash=excluded.credential_hash,updated_at=excluded.updated_at,updated_by=excluded.updated_by''',
        (username,ciphertext,credential_hash,timestamp,actor))
    conn.execute("INSERT INTO password_changes VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET updated_at=excluded.updated_at,updated_by=excluded.updated_by",(username,timestamp,actor))
    conn.execute("DELETE FROM password_display WHERE username=?",(username,))

def password_metadata(conn,username):
    row=conn.execute("SELECT updated_at,updated_by FROM password_changes WHERE username=?",(username,)).fetchone()
    available=conn.execute('SELECT 1 FROM credential_vault v JOIN users u ON v.username=u.username AND v.credential_hash=u.password_hash WHERE v.username=?',(username,)).fetchone()
    return {"latestPassword":None,"passwordDisplayStatus":"available" if available else "not_captured","passwordUpdatedAt":row[0] if row else None,"passwordUpdatedBy":row[1] if row else None}

LOGIN_FAILURES = {}
TLS_CERT = os.environ.get("V3_TLS_CERT")
TLS_KEY = os.environ.get("V3_TLS_KEY")

ALL_VIEWS = [
    'v_dashboard','v_card_status','v_card_rent','v_card_history','v_expense',
    'v_expense_history','v_card_reg','v_hipass_reg','v_hipass_box','v_stats','v_complaint',
    'v_admin','v_access_status','v_report_write','v_report_box'
]
DEFAULT_ACCOUNTS = {
    'admin': ('ALL', ALL_VIEWS),
    '본사 담당자 A': ('본사', ['v_dashboard','v_card_status','v_card_rent','v_card_history','v_expense','v_expense_history','v_stats','v_complaint','v_report_write','v_report_box','v_hipass_reg','v_hipass_box','v_access_status']),
    '서울 담당자': ('서울', ['v_dashboard','v_card_status','v_card_rent','v_expense','v_expense_history','v_stats','v_complaint','v_report_write','v_report_box','v_hipass_reg','v_hipass_box','v_access_status']),
    '인천 담당자': ('인천', ['v_dashboard','v_card_status','v_card_rent','v_expense','v_expense_history','v_stats','v_complaint','v_report_write','v_report_box','v_hipass_reg','v_hipass_box']),
    '정봉 담당자': ('정봉', ['v_dashboard','v_card_status','v_card_rent','v_expense','v_expense_history','v_stats','v_report_write','v_report_box','v_hipass_reg','v_hipass_box']),
    '임원실 담당자': ('임원실', ['v_dashboard','v_card_status','v_card_history','v_expense','v_expense_history','v_stats','v_complaint','v_report_write','v_report_box','v_hipass_reg','v_hipass_box'])
}


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def business_date():
    return datetime.now(timezone(timedelta(hours=9))).date().isoformat()

def phash(password):
    return password_hash(password)


def invalidate_sessions(username):
    with LOCK:
        for token, user in list(SESSIONS.items()):
            if user == username:
                SESSIONS.pop(token, None)
                SESSION_ACTIVITY.pop(token, None)
                SESSION_IPS.pop(token, None)
                SESSION_CREATED.pop(token,None)
                SESSION_REQUIRE_CHANGE.pop(token,None)


def permissions_for(username):
    with db() as conn:
        row = conn.execute('SELECT permissions_json FROM users WHERE username=? AND active=1', (username,)).fetchone()
    try:
        return set(json.loads(row['permissions_json'])) if row else set()
    except (ValueError, TypeError):
        return set()


def require_permission(username, *views):
    if user_scope(username) != 'ALL' and not permissions_for(username).intersection(views):
        raise PermissionError('해당 작업 권한이 없습니다.')


def record_account_change(conn, actor, target, action, ip='', before=None, after=None, password_changed=False):
    before = before or {}; after = after or {}
    entry_time = now()
    cursor=conn.execute('''INSERT INTO account_change_history(event_time,actor,target,action,ip,before_json,after_json,password_changed)
                  VALUES(?,?,?,?,?,?,?,?)''',
                 (entry_time, actor, target, action, ip, json.dumps(before,ensure_ascii=False),
                  json.dumps(after,ensure_ascii=False), bool(password_changed)))
    # The generic audit stream and dedicated ledger share the account transaction.
    details=json.dumps({'target':target,'passwordChanged':bool(password_changed),'ledgerId':cursor.lastrowid},ensure_ascii=False)
    conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',
                 (entry_time,actor,action,ip,details))


def account_history(conn):
    rows=conn.execute('SELECT * FROM account_change_history ORDER BY id DESC LIMIT 1000').fetchall()
    entries=[{'id':row['id'],'time':row['event_time'],'actor':row['actor'],'target':row['target'],
             'action':row['action'],'ip':row['ip'],'before':json.loads(row['before_json']),
             'after':json.loads(row['after_json']),'passwordChanged':bool(row['password_changed'])} for row in rows]
    # Earlier versions already stored server events, but did not render them here.
    actions=('ACCOUNT_CREATE','ACCOUNT_UPDATE','ACCOUNT_PASSWORD_RESET','ACCOUNT_DEACTIVATED','ACCOUNT_RESTORED','PASSWORD_CHANGE','ADMIN_LOCAL_RESET')
    marks=','.join('?' for _ in actions)
    previous=conn.execute(f'SELECT * FROM audit_events WHERE action IN ({marks}) ORDER BY id DESC LIMIT 1000',actions).fetchall()
    for row in previous:
        try: details=json.loads(row['details'])
        except (ValueError,TypeError):details={}
        if not isinstance(details,dict):details={}
        if details.get('ledgerId') is not None:continue
        target=details.get('target')
        if not target:
            match=re.search(r'(?:^|;)target=([^;]+)',row['details'] or '')
            target=match.group(1) if match else row['username']
        entries.append({'id':'legacy-'+str(row['id']),'time':row['event_time'],'actor':row['username'],
                        'target':target,'action':row['action'],'ip':row['ip'],'before':{},'after':{},
                        'passwordChanged':row['action'] in ('PASSWORD_CHANGE','ACCOUNT_PASSWORD_RESET','ADMIN_LOCAL_RESET')})
    entries.sort(key=lambda item:(item['time'],int(str(item['id']).replace('legacy-',''))),reverse=True)
    return entries[:1000]


def account_metadata(conn, active_only=True):
    suffix = ' WHERE active=1' if active_only else ''
    rows = conn.execute('SELECT username,scope,permissions_json,last_login,last_ip,active,must_change_password FROM users' + suffix).fetchall()
    return {row['username']: {'scope': row['scope'], 'permissions': json.loads(row['permissions_json']),
            'lastLogin': row['last_login'], 'ip': row['last_ip'], 'active': bool(row['active']),
            'mustChangePassword': bool(row['must_change_password'])} for row in rows}


def persist_state(conn, state, user, commit=True):
    clean_accounts(state); normalize_expenses(state)
    revision=storage.write(conn,state,user,APP_VERSION)
    if commit:conn.commit()
    if commit:write_latest_snapshot(state)
    return revision


def write_latest_snapshot(state):
    try:
        target=BACKUP_DIR/'latest_state.json';temp=target.with_suffix('.tmp')
        temp.write_text(json.dumps(state,ensure_ascii=False),encoding='utf-8')
        os.chmod(temp,0o600);os.replace(temp,target)
    except OSError:
        OPERATION_WARNINGS.append('최신 JSON 보조 파일 기록 실패: 핵심 DB 저장은 완료됨')
        del OPERATION_WARNINGS[:-20]
        logging.exception('Auxiliary snapshot failed after committed transaction')


class ClosingConnection(sqlite3.Connection):
    def __exit__(self,*args):
        try:return super().__exit__(*args)
        finally:self.close()

def db():
    conn = sqlite3.connect(DB_PATH, timeout=30,factory=ClosingConnection)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA secure_delete=ON')
    return conn


def init_db():
    with db() as conn:
        conn.execute('''CREATE TABLE IF NOT EXISTS system_state(
            id INTEGER PRIMARY KEY CHECK(id=1),
            version INTEGER,
            state_json TEXT,
            updated_at TEXT,
            updated_by TEXT)''')
        storage.initialize(conn)
        conn.execute('''CREATE TABLE IF NOT EXISTS users(
            username TEXT PRIMARY KEY,
            password_hash TEXT NOT NULL,
            scope TEXT NOT NULL,
            permissions_json TEXT NOT NULL,
            last_login TEXT,
            last_ip TEXT,
            active INTEGER DEFAULT 1)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS audit_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_time TEXT,
            username TEXT,
            action TEXT,
            ip TEXT,
            details TEXT)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS account_change_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,event_time TEXT NOT NULL,
            actor TEXT NOT NULL,target TEXT NOT NULL,action TEXT NOT NULL,ip TEXT,
            before_json TEXT NOT NULL,after_json TEXT NOT NULL,password_changed INTEGER NOT NULL DEFAULT 0)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS password_display(
            username TEXT PRIMARY KEY,ciphertext TEXT NOT NULL,updated_at TEXT NOT NULL,updated_by TEXT NOT NULL)''')
        conn.execute('''CREATE TABLE IF NOT EXISTS credential_vault(
            username TEXT PRIMARY KEY,ciphertext TEXT NOT NULL,credential_hash TEXT NOT NULL,
            updated_at TEXT NOT NULL,updated_by TEXT NOT NULL)''')
        conn.execute('INSERT OR IGNORE INTO password_changes SELECT username,updated_at,updated_by FROM password_display')
        conn.execute('DELETE FROM password_display')
        columns = {row['name'] for row in conn.execute('PRAGMA table_info(users)')}
        if 'must_change_password' not in columns:
            conn.execute('ALTER TABLE users ADD COLUMN must_change_password INTEGER DEFAULT 0')
        # Import legacy accounts once, never revive an explicitly inactive user.
        row = conn.execute('SELECT state_json FROM system_state WHERE id=1').fetchone()
        try:
            state = storage.read(conn) or {}
        except (ValueError, TypeError):
            state = {}
        accounts = state.get('accounts', {}) if isinstance(state, dict) else {}
        for name, info in accounts.items() if isinstance(accounts, dict) else []:
            if not isinstance(info, dict):
                continue
            digest = info.get('passwordHash')
            if not digest and info.get('pw') is not None:
                digest = legacy_hash(info['pw'])
            if isinstance(digest, str) and (re.fullmatch(r'[0-9a-f]{64}', digest) or digest.startswith('pbkdf2_sha256$')):
                conn.execute('INSERT OR IGNORE INTO users(username,password_hash,scope,permissions_json,active) VALUES(?,?,?,?,1)',
                             (name, digest, info.get('scope', ''), json.dumps(info.get('permissions', []), ensure_ascii=False)))
        for username, (scope, permissions) in DEFAULT_ACCOUNTS.items():
            if conn.execute('SELECT 1 FROM users WHERE username=?', (username,)).fetchone():
                continue
            initial = secrets.token_urlsafe(12)
            conn.execute('INSERT INTO users(username,password_hash,scope,permissions_json,active,must_change_password) VALUES(?,?,?,?,1,1)',
                         (username, phash(initial), scope, json.dumps(permissions, ensure_ascii=False)))
            store_password(conn, DB_PATH.parent/'password_display.key', username, initial, '초기 설치', now())
            print(f'[최초 임시 비밀번호] {username}: {initial} (최초 로그인 후 변경 필수)', flush=True)
        for user in conn.execute('SELECT username,password_hash FROM users').fetchall():
            digest = user['password_hash']
            if re.fullmatch(r'[0-9a-f]{64}', digest or ''):
                weak = secrets.compare_digest(digest, legacy_hash('1234'))
                conn.execute('UPDATE users SET password_hash=?,must_change_password=CASE WHEN ? THEN 1 ELSE must_change_password END WHERE username=?',
                             (encode_hash(digest), weak, user['username']))
        if isinstance(state, dict) and row:
            clean_accounts(state)
            normalize_expenses(state)
            state['accounts'] = account_metadata(conn)
            storage.write(conn,state,'migration',APP_VERSION)
        conn.commit()


def database_ok():
    if not DB_PATH.exists():
        return False
    try:
        with db() as conn:
            result = conn.execute('PRAGMA quick_check').fetchone()[0]
            conn.execute('SELECT username FROM users LIMIT 1').fetchone()
            return result == 'ok'
    except Exception:
        return False


def prepare_db():
    if DB_PATH.exists():
        with db() as conn:
            if conn.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise RuntimeError('DB가 손상되었습니다. 원본은 보존했습니다. 백업 복원 절차를 사용하세요.')
            tables={r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            source_schema=(conn.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0] or 0) if 'schema_versions' in tables else 0
            if source_schema>storage.SCHEMA_VERSION:raise RuntimeError('더 최신 버전의 DB입니다. 원본을 보존하고 해당 버전의 프로그램을 사용하세요.')
            if 'system_state' not in tables:raise RuntimeError('지원하지 않는 DB입니다. 원본을 보존하고 관리자에게 문의하세요.')
        if 'schema_versions' not in tables:backup('before_upgrade')
        elif 'credential_vault' not in tables:backup('before_v410_upgrade')
        elif source_schema<storage.SCHEMA_VERSION:
            print('[자료 보호] V4.1.11 업데이트 전 DB·첨부 전체 백업을 만듭니다.',flush=True)
            backup('before_v419_upgrade')
        init_db()
        return 'migrated_or_existing'
    init_db()
    return 'created'


def audit(user, action, ip='', details=''):
    try:
        with db() as conn:
            conn.execute(
                'INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',
                (now(), user or '', action, ip, str(details)[:2000])
            )
            conn.commit()
    except Exception as exc:
        print(f'[AUDIT] 기록 실패: {exc}')


def backup(reason='auto'):
    global LAST_FULL_BACKUP
    if not DB_PATH.exists():return
    important=reason in ('before_upgrade','before_admin_reset','test','manual')
    if not important and time.time()-LAST_FULL_BACKUP<300:return
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    target=BACKUP_DIR/f'corporate_card_system_{stamp}_{reason}.db'
    try:
        with db() as source,closing(sqlite3.connect(target)) as destination:source.backup(destination)
        os.chmod(target,0o600)
        backup_manager.create(DB_PATH,ATTACHMENT_DIR,target.with_suffix('.zip'),APP_VERSION)
        LAST_FULL_BACKUP=time.time()
    except Exception:
        OPERATION_WARNINGS.append('전체 백업 실패: 운영 로그와 저장 공간을 확인하세요.')
        logging.exception('Full backup failed')
        if important:raise


def get_state():
    with db() as conn:return storage.read(conn)


def user_scope(username):
    with db() as conn:
        row=conn.execute('SELECT scope FROM users WHERE username=? AND active=1',(username,)).fetchone()
    return row['scope'] if row else None


BRANCH_LISTS=('cards','history','hipass','hipassBox','expense','expenseHistory','complaint')


def get_state_for(username, snapshot=None):
    with db() as conn: state=storage.read(conn) or {} if snapshot is None else json.loads(json.dumps(snapshot))

    scope=user_scope(username)
    if not scope: raise PermissionError('inactive account')
    # Full data access follows the account's server-side scope, not its display/login name.
    if scope=='ALL':
        if not isinstance(state,dict): state={}
        with db() as conn:
            state['accounts'] = account_metadata(conn)
        for card in state.get('cards',[]):card.pop('cardKey',None)
        for field in (*BRANCH_LISTS, 'reports', 'chat', 'inbox', 'notices', 'logs'): state.setdefault(field, [])
        for field in ('memos', 'shortcuts'): state.setdefault(field, {})
        state['chat']=[x for x in state['chat'] if not x.get('dm') or x.get('sender')==username or username in x.get('recipients',[]) or x.get('recipient')==username]
        state['inbox']=[x for x in state['inbox'] if x.get('sender')==username or x.get('recipient')==username]
        state['memos']={k:v for k,v in state['memos'].items() if v.get('owner','admin')==username}
        return clean_accounts(state)
    if not isinstance(state,dict): return state
    result={k:v for k,v in state.items() if k in {*BRANCH_LISTS,'reports','chat','inbox','logs','memos','accounts','notices','shortcuts'}}
    for field in BRANCH_LISTS: result.setdefault(field, [])
    for field in BRANCH_LISTS:
        result[field]=[x for x in state.get(field,[]) if isinstance(x,dict) and x.get('group')==scope]
    # Card verification keys are administrator-only metadata. Do not send them
    # to branch clients; put_state below preserves the stored value on their saves.
    for card in result.get('cards',[]):
        card.pop('cardKey',None)
    result['reports']=[x for x in state.get('reports',[]) if isinstance(x,dict) and x.get('group')==scope]
    result['chat']=[x for x in state.get('chat',[]) if isinstance(x,dict) and (not x.get('dm') or x.get('sender')==username or x.get('recipient')==username or username in x.get('recipients',[]))]
    result['inbox']=[x for x in state.get('inbox',[]) if isinstance(x,dict) and (x.get('sender')==username or x.get('recipient')==username)]
    result['logs']=[]
    result['memos']={k:v for k,v in state.get('memos',{}).items() if v.get('owner','admin')==username}
    with db() as conn:
        result['accounts'] = {name:{'scope':info['scope'],'permissions':info['permissions']} for name,info in account_metadata(conn).items()}
    permissions = permissions_for(username)
    if 'v_dashboard' in permissions:
        result['dashboardSummary']={'cards':len(result['cards']),'rented':sum(x.get('status')=='rented' for x in result['cards']),'pending':sum(x.get('status')=='승인대기' for x in result.get('expense',[])),'hipass':len(result.get('hipass',[]))}
    for field, views in READ_VIEWS.items():
        if not permissions.intersection(views):
            result[field] = []
    result['shortcuts']={username:state.get('shortcuts',{}).get(username,[])}
    return result


def scoped_record_key(item, scope=None):
    actor=item.get('requester') or item.get('author') or item.get('handler') or item.get('created_by') or ''
    return (str(item.get('group', scope)), str(actor), str(item.get('id')))


def upsert_scoped(existing,incoming,scope):
    rows=list(existing) if isinstance(existing,list) else []
    positions={scoped_record_key(x):i for i,x in enumerate(rows) if isinstance(x,dict) and x.get('id') is not None}
    for item in incoming if isinstance(incoming,list) else []:
        if not isinstance(item,dict) or item.get('group')!=scope: continue
        key=scoped_record_key(item,scope) if item.get('id') is not None else None
        if key is not None and key in positions:
            rows[positions[key]]=item
        else:
            rows.append(item)
            if key is not None: positions[key]=len(rows)-1
    return rows


def put_state(state,user,expected_revision):
    if not isinstance(state,dict): raise ValueError('잘못된 데이터 형식입니다.')
    requested_memos=state.get('memos')
    with LOCK:
        with db() as conn:
            row=conn.execute('SELECT state_json,updated_at FROM system_state WHERE id=1').fetchone()
            actual_revision = row['updated_at'] if row else None
            if expected_revision != actual_revision: raise StateConflict('다른 사용자가 자료를 변경했습니다. 최신 자료를 불러온 후 다시 작업하세요.')
            current=storage.read(conn) or {}
        if not isinstance(current,dict): current={}
        scope=user_scope(user)
        is_global_admin=(scope=='ALL')
        if not scope: raise PermissionError('inactive account')
        if is_global_admin:state={**current,**state}
        if not is_global_admin:
            permissions=permissions_for(user)
            validate_branch_changes(state, current, scope, permissions, user)
            merged=dict(current) if isinstance(current,dict) else {}
            for field in BRANCH_LISTS:
                incoming=state.get(field,[])
                if field=='cards' and isinstance(incoming,list):
                    stored={(str(x.get('group')),str(x.get('num'))):x.get('cardKey') for x in merged.get('cards',[]) if isinstance(x,dict) and x.get('cardKey')}
                    safe_incoming=[]
                    for item in incoming:
                        if not isinstance(item,dict): continue
                        candidate=dict(item);key=(str(candidate.get('group')),str(candidate.get('num')))
                        if key in stored: candidate['cardKey']=stored[key]
                        else: candidate.pop('cardKey',None)
                        safe_incoming.append(candidate)
                    incoming=safe_incoming
                if field in state and ((field=='cards' and 'v_card_reg' in permissions) or (field=='hipass' and 'v_hipass_reg' in permissions)):
                    merged[field]=[x for x in merged.get(field,[]) if isinstance(x,dict) and x.get('group')!=scope]+incoming
                else:
                    merged[field]=upsert_scoped(merged.get(field,[]),incoming,scope)
            reports=list(merged.get('reports',[]))
            report_pos={scoped_record_key(x):i for i,x in enumerate(reports) if isinstance(x,dict) and x.get('id') is not None}
            for item in state.get('reports',[]) if isinstance(state.get('reports',[]),list) else []:
                if not isinstance(item,dict) or item.get('author') != user: continue
                candidate=dict(item); candidate['group']=scope; candidate['author']=user
                key=scoped_record_key(candidate,scope) if candidate.get('id') is not None else None
                if key is not None and key in report_pos:
                    reports[report_pos[key]]=candidate
                else:
                    reports.append(candidate)
                    if key is not None: report_pos[key]=len(reports)-1
            merged['reports']=reports
            merged['accounts']=current.get('accounts',{})
            merged['notices']=current.get('notices',[])
            merged['memos']=current.get('memos',{})
            merged['logs']=current.get('logs',[])
            shortcuts=dict(current.get('shortcuts',{}))
            if user in state.get('shortcuts',{}): shortcuts[user]=state['shortcuts'][user]
            merged['shortcuts']=shortcuts
            with db() as conn:
                known={r['username'] for r in conn.execute('SELECT username FROM users WHERE active=1').fetchall()}
            chat=list(merged.get('chat',[])); chat_pos={str(x.get('id')):i for i,x in enumerate(chat) if isinstance(x,dict) and x.get('id') is not None}
            for item in state.get('chat',[]) if isinstance(state.get('chat',[]),list) else []:
                if not isinstance(item,dict) or item.get('sender')!=user: continue
                candidate=dict(item)
                recipients=candidate.get('recipients')
                if not isinstance(recipients,list):
                    legacy=candidate.get('recipient','ALL')
                    recipients=[] if legacy=='ALL' else [legacy]
                recipients=list(dict.fromkeys(x for x in recipients if isinstance(x,str) and x in known and x!=user))
                if candidate.get('recipient')=='ALL' and not candidate.get('dm'):
                    recipients=[]
                elif not recipients:
                    continue
                candidate['recipients']=recipients
                candidate['recipient']='ALL' if not candidate.get('dm') else (recipients[0] if len(recipients)==1 else 'GROUP')
                candidate['sender']=user; key=str(candidate.get('id')) if candidate.get('id') is not None else None
                if key is not None and key in chat_pos:
                    if chat[chat_pos[key]].get('sender') != user: raise PermissionError('다른 사용자의 메시지는 변경할 수 없습니다.')
                    chat[chat_pos[key]]=candidate
                else:
                    chat.append(candidate)
                    if key is not None: chat_pos[key]=len(chat)-1
            merged['chat']=chat
            inbox=list(merged.get('inbox',[])); inbox_pos={str(x.get('id')):i for i,x in enumerate(inbox) if isinstance(x,dict) and x.get('id') is not None}
            for item in state.get('inbox',[]) if isinstance(state.get('inbox',[]),list) else []:
                if not isinstance(item,dict) or item.get('id') is None: continue
                key=str(item['id'])
                if item.get('sender')==user and item.get('recipient') in known:
                    candidate=dict(item); candidate['sender']=user
                    if key in inbox_pos:
                        if inbox[inbox_pos[key]].get('sender') != user: raise PermissionError('다른 사용자의 쪽지는 변경할 수 없습니다.')
                        inbox[inbox_pos[key]]=candidate
                    else: inbox_pos[key]=len(inbox); inbox.append(candidate)
                elif item.get('recipient')==user and key in inbox_pos and inbox[inbox_pos[key]].get('recipient')==user:
                    inbox[inbox_pos[key]]['read']=bool(item.get('read'))
            merged['inbox']=inbox
            state=merged
        state['_next_card_id']=current.get('_next_card_id',0)
        stored_keys={str(x.get('id')):x.get('cardKey') for x in current.get('cards',[]) if x.get('cardKey')}
        for card in state.get('cards',[]):
            key=stored_keys.get(str(card.get('id')))
            if key:card['cardKey']=key
            elif card.get('cardKey'):raise ValueError('새 카드에 인증 비밀값을 저장하지 마세요.')
        if is_global_admin:
            for field in ('chat','inbox'):
                visible=get_state_for(user,current).get(field,[])
                visible_ids={str(x.get('id')) for x in visible}
                hidden=[x for x in current.get(field,[]) if str(x.get('id')) not in visible_ids]
                hidden_ids={str(x.get('id')) for x in hidden}
                state[field]=hidden+[x for x in state.get(field,[]) if str(x.get('id')) not in hidden_ids]
        incoming_memos=current.get('memos',{}) if requested_memos is None else requested_memos
        if not isinstance(incoming_memos,dict):raise ValueError('메모 형식 오류')
        preserved={k:v for k,v in current.get('memos',{}).items() if v.get('owner','admin')!=user}
        for key,value in incoming_memos.items():
            if key in preserved:
                if requested_memos is None:continue
                raise PermissionError('다른 사용자의 메모입니다.')
            if not isinstance(value,dict):raise ValueError('메모 형식 오류')
            preserved[key]={**value,'owner':user}
        state['memos']=preserved
        domain.validate(state,current,user,is_global_admin)
        for expense in state.get('expense',[]):
            if expense not in current.get('expense',[]):operations.attachment_refs(__import__('types').SimpleNamespace(**globals()),expense.get('attachments',[]),user,expense.get('group'))
        backup('before_write')
        with db() as conn:
            state['accounts'] = account_metadata(conn)
            revision=persist_state(conn,state,user,commit=False)
            conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',(now(),user,'BUSINESS_CHANGE','',json.dumps(operations.diff(current,state),ensure_ascii=False)))
            conn.commit()
            write_latest_snapshot(state)
            return revision


ATTACHMENT_DIR = DB_DIR / 'attachments'
ATTACHMENT_DIR.mkdir(parents=True, exist_ok=True)
MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024
MAX_ATTACHMENT_REQUEST_BYTES = (MAX_ATTACHMENT_BYTES * 4 // 3) + (1024 * 1024)
MAX_STATE_REQUEST_BYTES = 8 * 1024 * 1024
INLINE_MIME_TYPES = {'application/pdf', 'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'text/plain'}

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        self.request.settimeout(20)
        super().setup()

    server_version = 'CorporateCardV3/4.1.11'

    def log_message(self, fmt, *args):
        return

    def log_error(self, fmt, *args):
        # Keep useful request failures visible in the launcher window.
        print(f'[HTTP 오류] {self.client_address[0]}: {fmt % args}', flush=True)

    def send_json(self, obj, status=200, extra_headers=None):
        raw = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(raw)

    def body(self, max_bytes=2 * 1024 * 1024):
        try: length = int(self.headers.get('Content-Length', '0'))
        except ValueError: return None
        if length < 0 or length > max_bytes:
            return None
        raw = self.rfile.read(length) if length else b'{}'
        try:
            result = json.loads(raw or b'{}')
            return result if isinstance(result, dict) else None
        except (json.JSONDecodeError,UnicodeDecodeError,RecursionError):
            return None

    def session_user(self):
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get('Cookie', ''))
        except Exception:
            return None
        value = cookie.get('V3SESSION')
        token = value.value if value else None
        with LOCK:
            user = SESSIONS.get(token)
            if not user:
                return None
            if time.time()-SESSION_ACTIVITY.get(token,0)>SESSION_IDLE_TIMEOUT or time.time()-SESSION_CREATED.get(token,time.time())>SESSION_ABSOLUTE_TIMEOUT:
                SESSIONS.pop(token, None); SESSION_ACTIVITY.pop(token, None); SESSION_IPS.pop(token, None); SESSION_CREATED.pop(token,None);SESSION_REQUIRE_CHANGE.pop(token,None)
                return None
            with db() as conn:
                row = conn.execute('SELECT active,must_change_password FROM users WHERE username=?', (user,)).fetchone()
            if not row or not row['active']:
                invalidate_sessions(user)
                return None
            # An administrator reset affects the next login, without terminating an existing session.
            self.must_change_password = bool(row['must_change_password'] and SESSION_REQUIRE_CHANGE.get(token,True))
            if urlparse(self.path).path not in ('/api/state','/api/operations','/api/access-status'):
                SESSION_ACTIVITY[token] = time.time()
            return user

    def cookie_header(self, token, logout=False):
        secure = '; Secure' if isinstance(self.connection, ssl.SSLSocket) else ''
        age = '; Max-Age=0' if logout else ''
        return f'V3SESSION={token}; HttpOnly; SameSite=Strict; Path=/{secure}{age}'

    def do_GET(self):
        path = urlparse(self.path).path
        if operations.get(self,globals(),path):return
        if path == '/api/login-weather':
            return self.send_json(LOGIN_WEATHER.snapshot())
        if path in ('/static/history-ledger-v418.js','/static/rental-intake-v419.js','/static/workflow-v4110.js'):
            raw=(BASE_DIR/'static'/path.rsplit('/',1)[-1]).read_bytes()
            self.send_response(200)
            self.send_header('Content-Type','application/javascript; charset=utf-8')
            self.send_header('Cache-Control','public, max-age=86400')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path in ('/static/login-day-v416.jpg','/static/login-sunrise-v416.jpg',
                    '/static/login-sunset-v416.jpg','/static/login-night-v416.jpg',
                    '/static/login-rain-v416.jpg','/static/login-snow-v416.jpg','/static/login-classic-v416.jpg',
                    '/static/login-beach-v415.jpg'):
            asset=BASE_DIR/'static'/path.rsplit('/',1)[-1]
            if not asset.is_file():return self.send_json({'ok':False,'message':'Not Found'},404)
            raw=asset.read_bytes();self.send_response(200)
            self.send_header('Content-Type','image/jpeg')
            self.send_header('Cache-Control','public, max-age=86400')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path.startswith('/static/vendor/'):
            name = path.rsplit('/',1)[-1]
            if name not in ('chart.umd.min.js','xlsx.full.min.js'):
                return self.send_json({'ok':False,'message':'Not Found'},404)
            asset = BASE_DIR/'static'/'vendor'/name
            if not asset.is_file():return self.send_json({'ok':False,'message':'라이브러리 파일을 찾을 수 없습니다.'},404)
            raw=asset.read_bytes();self.send_response(200)
            self.send_header('Content-Type','application/javascript; charset=utf-8')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw);return
        if path == '/':
            try:
                raw = HTML_PATH.read_bytes()
            except FileNotFoundError:
                return self.send_json({'ok': False, 'message': 'templates/index.html 파일을 찾을 수 없습니다.'}, 500)
            # Render the account choices into the initial HTML response. This keeps
            # the Edge login list usable even if client-side bootstrap JavaScript hangs.
            try:
                with db() as conn:
                    account_rows=conn.execute('SELECT username,scope FROM users WHERE active=1 ORDER BY username').fetchall()
                if not any(row['username']=='admin' for row in account_rows):
                    account_rows=[{'username':'admin','scope':'ALL'},*account_rows]
                options=[]
                for row in account_rows:
                    username=row['username']; scope=row['scope'] or 'ALL'
                    label=username
                    options.append(f'<option value="{html_escape(username, quote=True)}">{html_escape(label)}</option>')
                option_markup=''.join(options)
                status_markup=f'서버 버전 {APP_VERSION} · 활성 계정 {len(account_rows)}개 · 서버 목록'
            except Exception as exc:
                print(f'[로그인 목록 렌더링 오류] {type(exc).__name__}: {exc}', flush=True)
                option_markup='<option value="admin">🔑 최고 관리자 (전체 권한)</option>'
                status_markup=f'서버 버전 {APP_VERSION} · 계정 목록 조회 오류'
            raw=raw.replace(b'<!--SERVER_LOGIN_ACCOUNT_OPTIONS-->',option_markup.encode('utf-8'))
            raw=raw.replace(b'<!--SERVER_LOGIN_STATUS-->',html_escape(status_markup).encode('utf-8'))
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('X-Frame-Options','DENY')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; font-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'")
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
            return
        if path == '/health':
            return self.send_json({'ok': True, 'version': APP_VERSION, 'database': database_ok(), 'time': now()})
        if path == '/api/bootstrap':
            with db() as conn:
                accounts = account_metadata(conn)
            users = [{'username': name, 'scope': info['scope'], 'permissions': info['permissions']}
                     for name, info in accounts.items()]
            user=self.session_user()
            if not user:users=[{'username':x['username']} for x in users]
            return self.send_json({'ok': True, 'users': users, 'server_time': now(), 'version': APP_VERSION})
        user = self.session_user()
        if path.startswith('/api/') and not user:
            return self.send_json({'ok': False, 'message': '로그인이 필요합니다.'}, 401)
        if path.startswith('/api/') and getattr(self, 'must_change_password', False):
            return self.send_json({'ok':False,'message':'최초 비밀번호를 변경하세요.'},403)
        if path == '/api/admin/accounts':
            if user_scope(user) != 'ALL':
                return self.send_json({'ok': False, 'message': '최고관리자 권한이 필요합니다.'}, 403)
            with db() as conn:
                accounts = [{'username': name, **info, **password_metadata(conn,name)} for name, info in account_metadata(conn, False).items()]
            return self.send_json({'ok':True,'accounts':accounts})
        if path == '/api/admin/account-history':
            if user_scope(user) != 'ALL':
                return self.send_json({'ok':False,'message':'최고관리자 권한이 필요합니다.'},403)
            with db() as conn:
                entries=account_history(conn)
            return self.send_json({'ok':True,'entries':entries})
        if path.startswith('/api/attachments/'):
            attachment_id = path.rsplit('/', 1)[-1]
            if not re.fullmatch(r'[0-9a-f]{32}', attachment_id):
                return self.send_json({'ok': False, 'message': '첨부파일 주소가 올바르지 않습니다.'}, 404)
            meta_path = ATTACHMENT_DIR / (attachment_id + '.json')
            file_path = ATTACHMENT_DIR / (attachment_id + '.bin')
            try:
                meta = json.loads(meta_path.read_text(encoding='utf-8'))
                allowed=operations.attachment_allowed(globals(),meta,user)
                if not allowed or not file_path.is_file():
                    return self.send_json({'ok': False, 'message': '파일에 접근할 권한이 없습니다.'}, 403)
                raw = file_path.read_bytes()
                name = pathlib.Path(str(meta.get('name', 'attachment'))).name.replace('\\', '_').replace('\r', '_').replace('\n', '_')
                mime = meta.get('mime') if meta.get('mime') in INLINE_MIME_TYPES else 'application/octet-stream'
                disposition = 'inline' if mime in INLINE_MIME_TYPES and parse_qs(urlparse(self.path).query).get('download',[''])[0]!='1' else 'attachment'
                self.send_response(200)
                self.send_header('Content-Type', mime)
                self.send_header('Content-Disposition', f"{disposition}; filename*=UTF-8''{quote(name)}")
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Cache-Control', 'private, no-store')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers(); self.wfile.write(raw)
                return
            except (OSError, ValueError, json.JSONDecodeError):
                return self.send_json({'ok': False, 'message': '첨부파일을 찾을 수 없습니다.'}, 404)
        if path == '/api/state':
            with LOCK,db() as conn:
                row=conn.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone()
                revision=row['updated_at'] if row else None
                if self.headers.get('If-None-Match') is not None and self.headers.get('If-None-Match')==revision:
                    return self.send_json({'ok':True,'unchanged':True,'revision':revision,'online_users':sorted({u for t,u in SESSIONS.items() if time.time()-SESSION_ACTIVITY.get(t,0)<SESSION_IDLE_TIMEOUT and time.time()-SESSION_CREATED.get(t,0)<SESSION_ABSOLUTE_TIMEOUT})})
                snapshot=storage.read(conn) or {}
                state=get_state_for(user,snapshot)
            with LOCK:online=sorted({u for t,u in SESSIONS.items() if time.time()-SESSION_ACTIVITY.get(t,0)<SESSION_IDLE_TIMEOUT and time.time()-SESSION_CREATED.get(t,0)<SESSION_ABSOLUTE_TIMEOUT})
            return self.send_json({'ok':True,'state':state,'revision':revision,'online_users':online})
        if path == '/api/access-status':
            if user_scope(user) != 'ALL' and 'v_access_status' not in permissions_for(user):
                return self.send_json({'ok':False,'message':'접속 현황 조회 권한이 없습니다.'},403)
            with db() as conn:
                if user_scope(user) == 'ALL':
                    rows = conn.execute('SELECT username,scope,last_login,last_ip,active FROM users').fetchall()
                else:
                    rows = conn.execute('SELECT username,scope,last_login,last_ip,active FROM users WHERE scope=? AND active=1', (user_scope(user),)).fetchall()
            return self.send_json({'ok':True,'users':[dict(r) for r in rows],'current':user})
        if path == '/api/audit':
            if user_scope(user) != 'ALL':
                return self.send_json({'ok':False,'message':'최고관리자 권한이 필요합니다.'},403)
            with db() as conn:
                rows = conn.execute('SELECT * FROM audit_events ORDER BY id DESC LIMIT 500').fetchall()
            return self.send_json({'ok': True, 'events': [dict(r) for r in rows]})
        if path == '/api/backups':
            if user_scope(user) != 'ALL':
                return self.send_json({'ok': False, 'message': '최고관리자 권한이 필요합니다.'}, 403)
            items = []
            for path_item in sorted(BACKUP_DIR.glob('*.db'), key=lambda p: p.stat().st_mtime, reverse=True)[:100]:
                items.append({'name': path_item.name, 'size': path_item.stat().st_size,
                              'modified': datetime.fromtimestamp(path_item.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')})
            return self.send_json({'ok': True, 'backups': items})
        return self.send_json({'ok': False, 'message': 'Not Found'}, 404)

    def do_POST(self):
        origin = self.headers.get('Origin')
        if origin and urlparse(origin).netloc != self.headers.get('Host'):
            return self.send_json({'ok':False,'message':'다른 사이트에서의 요청은 허용하지 않습니다.'},403)
        path = urlparse(self.path).path
        request_limit = MAX_ATTACHMENT_REQUEST_BYTES if path == '/api/attachments' else (MAX_STATE_REQUEST_BYTES if path in ('/api/state','/api/exports') else 2 * 1024 * 1024)
        if path not in ('/api/login','/api/logout') and not self.session_user():return self.send_json({'ok':False,'message':'로그인이 필요합니다.'},401)
        data = self.body(request_limit)
        if data is None:
            return self.send_json({'ok': False, 'message': 'JSON 형식이 올바르지 않습니다.'}, 400)
        ip = self.client_address[0]

        if operations.post(self,globals(),path,data):return

        if path == '/api/login':
            username = str(data.get('username', '')).strip()
            password = str(data.get('password', ''))
            if not 1<=len(username)<=80 or not 1<=len(password)<=128:return self.send_json({'ok':False,'message':'계정 또는 비밀번호 길이가 올바르지 않습니다.'},400)
            try:
                with db() as conn:
                    row = conn.execute('SELECT * FROM users WHERE username=? AND active=1', (username,)).fetchone()
                with LOCK:
                    attempts = [t for t in LOGIN_FAILURES.get((ip, username), []) if t > time.time()-300]
                    global_attempts=[t for t in LOGIN_FAILURES.get((ip,None),[]) if t>time.time()-300]
                    if len(attempts)>=10 or len(global_attempts)>=100:
                        return self.send_json({'ok':False,'message':'로그인 실패가 반복됐습니다. 5분 뒤 다시 시도하세요.'},429)
                    LOGIN_FAILURES[(ip, username)] = attempts
                authenticated = bool(row and verify_password(row['password_hash'], password))
                if not authenticated:
                    with LOCK:
                        LOGIN_FAILURES[(ip, username)].append(time.time());LOGIN_FAILURES[(ip,None)]=global_attempts+[time.time()]
                        while len(LOGIN_FAILURES)>2000:LOGIN_FAILURES.pop(next(iter(LOGIN_FAILURES)),None)
                    audit(username, 'LOGIN_FAIL', ip)
                    return self.send_json({'ok': False, 'message': '계정 또는 비밀번호가 올바르지 않습니다.'}, 401)
                with LOCK: LOGIN_FAILURES.pop((ip, username), None)
                token = secrets.token_urlsafe(32)
                SESSION_CREATED[token]=time.time()
                replaced_same_ip=False
                with LOCK:
                    with db() as conn:fresh=conn.execute('SELECT * FROM users WHERE username=? AND active=1',(username,)).fetchone()
                    if not fresh or not secrets.compare_digest(row['password_hash'],fresh['password_hash']):
                        SESSION_CREATED.pop(token,None)
                        return self.send_json({'ok':False,'message':'인증 중 계정이 변경되었습니다. 다시 로그인하세요.'},401)
                    row=fresh
                    with db() as conn:
                        saved=conn.execute('SELECT credential_hash,ciphertext FROM credential_vault WHERE username=?',(username,)).fetchone()
                        usable=False
                        if saved and saved[0]==row['password_hash']:
                            try:usable=password_vault.reveal(DB_PATH.parent,username,saved[1],row['password_hash'])==password
                            except Exception:pass
                        if not usable:
                            previous=conn.execute('SELECT updated_at,updated_by FROM password_changes WHERE username=?',(username,)).fetchone()
                            store_password(conn,DB_PATH.parent/'password_display.key',username,password,username,now())
                            if previous:conn.execute('UPDATE password_changes SET updated_at=?,updated_by=? WHERE username=?',(*previous,username))
                            conn.commit()
                    cutoff=time.time()-SESSION_IDLE_TIMEOUT
                    for old_token,seen in list(SESSION_ACTIVITY.items()):
                        if seen<cutoff:
                            SESSIONS.pop(old_token,None);SESSION_ACTIVITY.pop(old_token,None);SESSION_IPS.pop(old_token,None);SESSION_CREATED.pop(old_token,None);SESSION_REQUIRE_CHANGE.pop(old_token,None)
                    existing=sorted((t for t,u in SESSIONS.items() if u==username),key=lambda t:SESSION_CREATED.get(t,0))
                    for old_token in existing[:-4]:
                        SESSIONS.pop(old_token,None);SESSION_ACTIVITY.pop(old_token,None);SESSION_IPS.pop(old_token,None);SESSION_CREATED.pop(old_token,None);SESSION_REQUIRE_CHANGE.pop(old_token,None)
                    SESSIONS[token]=username;SESSION_ACTIVITY[token]=time.time();SESSION_IPS[token]=ip
                    SESSION_REQUIRE_CHANGE[token]=bool(row['must_change_password'])
                with db() as conn:
                    conn.execute('UPDATE users SET last_login=?,last_ip=? WHERE username=?', (now(), ip, username))
                    conn.commit()
                audit(username, 'LOGIN_REPLACED_SAME_IP' if replaced_same_ip else 'LOGIN', ip)
                return self.send_json(
                    {'ok': True, 'username': username, 'scope': row['scope'],
                     'permissions': json.loads(row['permissions_json']), 'mustChangePassword': bool(row['must_change_password'])},
                    200,
                    {'Set-Cookie': self.cookie_header(token)}
                )
            except Exception as exc:
                logging.exception('Login failed')
                return self.send_json({'ok': False, 'message': '로그인 서버 오류입니다. 운영 로그를 확인하세요.'}, 500)

        if path == '/api/logout':
            user = self.session_user()
            if user:
                audit(user, 'LOGOUT', ip)
            cookie = self.headers.get('Cookie', '')
            for part in cookie.split(';'):
                part = part.strip()
                if part.startswith('V3SESSION='):
                    token = part.split('=', 1)[1]
                    with LOCK:
                        SESSIONS.pop(token, None)
                        SESSION_ACTIVITY.pop(token, None)
                        SESSION_IPS.pop(token, None)
                        SESSION_CREATED.pop(token,None)
                        SESSION_REQUIRE_CHANGE.pop(token,None)
            return self.send_json({'ok': True}, 200, {'Set-Cookie': self.cookie_header('', True)})

        if path == '/api/verify-current-password':
            user = self.session_user()
            if not user:
                return self.send_json({'ok': False, 'message': '로그인이 필요합니다.'}, 401)
            password = str(data.get('password', ''))
            if not password:
                return self.send_json({'ok': False, 'message': '비밀번호를 입력해 주세요.'}, 400)
            try:
                with db() as conn:
                    row = conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1', (user,)).fetchone()
                if row and verify_password(row['password_hash'], password):
                    return self.send_json({'ok': True})
                return self.send_json({'ok': False, 'message': '비밀번호가 올바르지 않습니다.'}, 403)
            except Exception as exc:
                logging.exception('Password verification failed')
                return self.send_json({'ok': False, 'message': '비밀번호 확인을 처리하지 못했습니다.'}, 500)

        if path == '/api/change-password':
            user = self.session_user()
            if not user: return self.send_json({'ok':False,'message':'로그인이 필요합니다.'},401)
            try:
                new_password = data.get('newPassword')
                validate_password(new_password)
                with LOCK, db() as conn:
                    row = conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
                    if not row or not verify_password(row['password_hash'], data.get('currentPassword', '')):
                        return self.send_json({'ok':False,'message':'현재 비밀번호가 올바르지 않습니다.'},403)
                    if verify_password(row['password_hash'], new_password):
                        raise ValueError('현재 비밀번호와 다른 새 비밀번호를 입력하세요.')
                    conn.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(phash(new_password),user))
                    store_password(conn,DB_PATH.parent/'password_display.key',user,new_password,user,now())
                    record_account_change(conn,user,user,'PASSWORD_CHANGE',ip,password_changed=True)
                    state=storage.read(conn) or {};state['accounts']=account_metadata(conn)
                    persist_state(conn,state,user,commit=False)
                    conn.commit();invalidate_sessions(user);write_latest_snapshot(state)
                return self.send_json({'ok':True},200,{'Set-Cookie':self.cookie_header('',True)})
            except ValueError as exc:
                return self.send_json({'ok':False,'message':str(exc)},400)
            except Exception:
                logging.exception('Password change failed')
                return self.send_json({'ok':False,'message':'비밀번호 변경 실패. 변경 결과를 확인하고 관리자에게 문의하세요.'},500)
        user = self.session_user()
        if path.startswith('/api/') and not user:
            return self.send_json({'ok': False, 'message': '로그인이 필요합니다.'}, 401)
        if path.startswith('/api/') and getattr(self, 'must_change_password', False):
            return self.send_json({'ok':False,'message':'최초 비밀번호를 변경하세요.'},403)
        if path == '/api/admin/password-reveal':
            if user_scope(user)!='ALL':return self.send_json({'ok':False,'message':'최고관리자 권한이 필요합니다.'},403)
            try:
                with LOCK,db() as conn:
                    failures=[t for t in PASSWORD_REVEAL_FAILURES.get(user,[]) if t>time.time()-300]
                    if len(failures)>=5:return self.send_json({'ok':False,'message':'관리자 확인 실패가 반복되었습니다. 5분 후 다시 시도하세요.'},429)
                    actor=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
                    if not actor or not verify_password(actor[0],data.get('adminPassword','')):
                        PASSWORD_REVEAL_FAILURES[user]=failures+[time.time()]
                        return self.send_json({'ok':False,'message':'현재 관리자 비밀번호를 확인하세요.'},403)
                    PASSWORD_REVEAL_FAILURES.pop(user,None)
                    target=str(data.get('username',''))
                    row=conn.execute('SELECT v.ciphertext,u.password_hash FROM credential_vault v JOIN users u ON v.username=u.username AND v.credential_hash=u.password_hash WHERE u.username=? AND u.active=1',(target,)).fetchone()
                    if not row:return self.send_json({'ok':False,'message':'이전 해시만 보관된 계정입니다. 해당 사용자가 새 버전에서 로그인하거나 비밀번호를 변경한 뒤 확인하세요.'},409)
                    try:password=password_vault.reveal(DB_PATH.parent,target,row[0],row[1])
                    except Exception:return self.send_json({'ok':False,'message':'표시용 암호화 자료를 읽을 수 없습니다. 해당 사용자가 로그인하거나 비밀번호를 재설정하세요.'},409)
                    conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',(now(),user,'PASSWORD_REVEALED',ip,json.dumps({'target':target})))
                    conn.commit()
                return self.send_json({'ok':True,'username':target,'password':password,'expiresIn':30})
            except Exception:
                logging.error('Administrator credential view failed')
                return self.send_json({'ok':False,'message':'현재 비밀번호 조회를 완료하지 못했습니다.'},500)
        if path == '/api/admin/account-sessions/revoke':
            if user_scope(user)!='ALL':return self.send_json({'ok':False,'message':'최고관리자 권한이 필요합니다.'},403)
            target=str(data.get('username',''));invalidate_sessions(target);audit(user,'ACCOUNT_SESSIONS_REVOKED',ip,json.dumps({'target':target}))
            return self.send_json({'ok':True,'reloginRequired':target==user})
        if path in ('/api/admin/account-create', '/api/admin/account-update'):
            if user_scope(user) != 'ALL':
                return self.send_json({'ok':False,'message':'최고관리자 권한이 필요합니다.'},403)
            try:
                username = data.get('username')
                permissions = data.get('permissions', [])
                scope = data.get('scope', '')
                password = data.get('password', '')
                creating = path.endswith('account-create')
                if not isinstance(username,str) or not 1 <= len(username.strip()) <= 80:
                    raise ValueError('계정 이름은 1~80자로 입력하세요.')
                username = username.strip()
                if scope not in ('ALL', '본사', '서울', '인천', '정봉', '임원실') or not isinstance(permissions,list) or any(v not in ALL_VIEWS for v in permissions):
                    raise ValueError('계정 지점 또는 권한이 올바르지 않습니다.')
                if scope=='ALL':permissions=ALL_VIEWS
                if creating or password: validate_password(password)
                if username == 'admin':
                    scope = 'ALL'; permissions = ALL_VIEWS
                    if password: raise ValueError('본인 비밀번호는 상단 비밀번호 변경 버튼을 사용하세요.')
                with LOCK, db() as conn:
                    target = conn.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
                    if creating and target:
                        raise ValueError('이미 존재하는 계정입니다. 삭제된 계정은 복구 메뉴를 사용하세요.')
                    if not creating and (not target or not target['active']):
                        raise ValueError('활성 계정을 찾을 수 없습니다.')
                    if scope=='ALL' and (creating or target['scope']!='ALL'):
                        actor_hash=conn.execute('SELECT password_hash FROM users WHERE username=?',(user,)).fetchone()[0]
                        if not verify_password(actor_hash,data.get('adminPassword','')):return self.send_json({'ok':False,'message':'전체 관리자 권한 부여에는 현재 관리자 재인증이 필요합니다.'},403)
                    backup('before_account_update')
                    if creating:
                        conn.execute('INSERT INTO users(username,password_hash,scope,permissions_json,active,must_change_password) VALUES(?,?,?,?,1,1)',
                                     (username,phash(password),scope,json.dumps(permissions,ensure_ascii=False)))
                    else:
                        conn.execute('UPDATE users SET scope=?,permissions_json=? WHERE username=?',(scope,json.dumps(permissions,ensure_ascii=False),username))
                        if password:
                            conn.execute('UPDATE users SET password_hash=?,must_change_password=1 WHERE username=?',(phash(password),username))
                    if creating or password:
                        store_password(conn,DB_PATH.parent/'password_display.key',username,password,user,now())
                    before={} if creating else {'scope':target['scope'],'permissions':json.loads(target['permissions_json'])}
                    after={'scope':scope,'permissions':list(dict.fromkeys(permissions))}
                    actual_delta=creating or bool(password) or before['scope']!=scope or set(before['permissions'])!=set(permissions)
                    if actual_delta:
                        action='ACCOUNT_CREATE' if creating else ('ACCOUNT_PASSWORD_RESET' if password else 'ACCOUNT_PERMISSIONS_CHANGE')
                        record_account_change(conn,user,username,action,ip,before,after,bool(password))
                    state=storage.read(conn) or {};state['accounts']=account_metadata(conn)
                    revision=persist_state(conn,state,user,commit=False)
                    conn.commit()
                    changed = bool(not creating and (password or target['scope'] != scope or set(json.loads(target['permissions_json'])) != set(permissions)))
                    # Permissions are checked against the database on every request; no logout is needed.
                    write_latest_snapshot(state)
                return self.send_json({'ok':True,'revision':revision,'reloginRequired':False,'activeSessionsPreserved':True})
            except ValueError as exc:
                return self.send_json({'ok':False,'message':str(exc)},400)
            except Exception:
                logging.exception('Account update failed')
                return self.send_json({'ok':False,'message':'계정 변경을 완료하지 못했습니다. 기존 값을 보존했습니다.'},500)
        if path in ('/api/admin/account-delete', '/api/admin/account-restore'):
            if user_scope(user) != 'ALL':
                return self.send_json({'ok': False, 'message': '최고관리자 권한이 필요합니다.'}, 403)
            username=str(data.get('username','')).strip()
            if not username or username=='admin':
                return self.send_json({'ok':False,'message':'대상 담당자 계정이 올바르지 않습니다.'},400)
            restoring=path.endswith('account-restore')
            try:
                with LOCK:
                    with db() as conn:
                        row=conn.execute('SELECT username,password_hash,scope,permissions_json,active FROM users WHERE username=?',(username,)).fetchone()
                        if not row:
                            return self.send_json({'ok':False,'message':'서버에서 계정을 찾을 수 없습니다.'},404)
                        backup('before_account_status')
                        conn.execute('UPDATE users SET active=? WHERE username=?',(1 if restoring else 0,username))
                        invalidate_sessions(username)
                        state=storage.read(conn) or {}
                        if not isinstance(state,dict): state={}
                        clean_accounts(state)
                        accounts=state.get('accounts') if isinstance(state.get('accounts'),dict) else {}
                        if restoring:
                            try: permissions=json.loads(row['permissions_json'])
                            except Exception: permissions=[]
                            accounts[username]={'scope':row['scope'],'permissions':permissions}
                        else:
                            accounts.pop(username,None)
                        state['accounts']=accounts
                        revision=storage.write(conn,state,user,APP_VERSION)
                        record_account_change(conn,user,username,'ACCOUNT_RESTORED' if restoring else 'ACCOUNT_DEACTIVATED',ip,{'active':bool(row['active'])},{'active':restoring})
                        conn.commit()
                    write_latest_snapshot(state)
                return self.send_json({'ok':True,'username':username,'revision':revision,'active':restoring})
            except Exception as exc:
                print(f'[계정 상태 변경 오류] 관리자={user}, 대상={username}, 원인={type(exc).__name__}: {exc}',flush=True)
                return self.send_json({'ok':False,'message':f'계정 상태를 저장하지 못했습니다: {exc}'},500)
        if path == '/api/state':
            state = data.get('state')
            if not isinstance(state, dict):
                return self.send_json({'ok': False, 'message': '잘못된 데이터 형식입니다.'}, 400)
            try:
                if 'revision' not in data: raise StateConflict('최신 버전의 화면으로 새로고침하세요.')
                revision = put_state(state, user, data['revision'])
                audit(user, 'STATE_SAVE', ip, f'bytes={len(json.dumps(state, ensure_ascii=False))}')
                return self.send_json({'ok': True, 'saved_at': now(), 'revision': revision})
            except PermissionError as exc:
                return self.send_json({'ok':False,'message':str(exc)},403)
            except StateConflict as exc:
                return self.send_json({'ok':False,'message':str(exc)},409)
            except ValueError as exc:
                return self.send_json({'ok':False,'message':str(exc)},400)
            except Exception as exc:
                logging.exception('State save failed')
                return self.send_json({'ok': False, 'message': 'DB 저장을 완료하지 못했습니다. 관리자에게 문의하세요.'}, 500)
        return self.send_json({'ok': False, 'message': 'Not Found'}, 404)


def find_free_port(start_port):
    # V3.2.3에서는 실행 주소를 항상 5000으로 고정합니다.
    # 포트가 사용 중이면 다른 포트로 조용히 바꾸지 않고 명확한 오류를 보여줍니다.
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name=='nt':sock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        else:sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        sock.bind((HOST, start_port))
        return start_port
    except OSError:
        return None
    finally:
        sock.close()


def main():
    global PORT
    if bool(TLS_CERT) != bool(TLS_KEY):raise RuntimeError('V3_TLS_CERT와 V3_TLS_KEY를 함께 지정하세요.')
    if HOST not in ('127.0.0.1','localhost') and not TLS_CERT:
        raise RuntimeError('공유 네트워크 실행에는 HTTPS가 필요합니다. RUN_LAN_WINDOWS.bat를 사용하세요.')
    log_dir=BASE_DIR/'logs';log_dir.mkdir(exist_ok=True)
    logging.Formatter.converter=time.gmtime
    logging.basicConfig(level=logging.INFO,format='%(asctime)sZ %(levelname)s %(message)s',handlers=[RotatingFileHandler(log_dir/'server.log',maxBytes=2*1024*1024,backupCount=5,encoding='utf-8')])
    print('')
    print('=' * 60)
    print(f' 법인카드 & 하이패스 통합관리시스템 V{APP_VERSION}')
    print('=' * 60)
    print(f'[경로] {BASE_DIR}')
    print('[1/4] SQLite 데이터베이스 확인...')
    db_status = prepare_db()
    print(f'      DB 상태: {db_status}')
    print('[2/4] 사용자 계정 확인...')
    with db() as conn:
        count = conn.execute('SELECT COUNT(*) FROM users WHERE active=1').fetchone()[0]
    print(f'      활성 계정: {count}개')
    print('[3/4] 포트 확인...')
    free = find_free_port(PORT)
    if free is None:
        raise RuntimeError(f'포트 {PORT}을 사용할 수 없습니다. 다른 프로그램이 사용 중인지 확인하세요.')
    if free != PORT:
        print(f'      기본 포트 {PORT} 사용 중 → {free}번 포트로 실행합니다.')
        PORT = free
    else:
        print(f'      포트 {PORT} 사용 가능')
    print('[4/4] 서버 시작...')
    server_class=operations.HTTPSWithRedirectServer if TLS_CERT else operations.BoundedHTTPServer
    server = server_class((HOST,PORT),Handler)
    if bool(TLS_CERT) != bool(TLS_KEY): raise RuntimeError('V3_TLS_CERT와 V3_TLS_KEY를 함께 지정하세요.')
    if TLS_CERT:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(TLS_CERT, TLS_KEY)
        server.configure_tls(context,os.environ.get('V4_LAN_SERVER_IP',''))
    operations.register_server(globals(),server)
    scheme = 'https' if TLS_CERT else 'http'
    url = f'{scheme}://localhost:{PORT}/' if TLS_CERT else f'{scheme}://127.0.0.1:{PORT}/'
    print('')
    print(f'  접속 주소 : {url}')
    print(f'  수신 설정 : {HOST}:{PORT}')
    if os.environ.get('V4_LAN_SERVER_IP'):
        print(f"  다른 PC   : https://{os.environ['V4_LAN_SERVER_IP']}:{PORT}/ (LAN_CLIENT 설치 후 접속)")
    print('  관리자    : admin (새 설치의 임시 비밀번호는 위 최초 발급 안내 참조)')
    print('  종료      : 이 창에서 Ctrl+C')
    print('')
    if AUTO_BROWSER:
        def open_browser():
            import time
            time.sleep(0.8)
            try:
                webbrowser.open(url)
            except Exception as exc:
                print(f'[브라우저] 자동 실행 실패: {exc}')
        threading.Thread(target=open_browser, daemon=True).start()
    if HOST not in ('127.0.0.1','localhost') and not TLS_CERT:
        server.server_close()
        raise RuntimeError('공유 네트워크 실행에는 V3_TLS_CERT와 V3_TLS_KEY를 설정하세요.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n서버를 종료합니다.')
    finally:
        server.server_close()
        (BASE_DIR/'server.pid').unlink(missing_ok=True)


if __name__ == '__main__':
    try:
        with DatabaseLock(DB_DIR):main()
    except Exception as exc:
        print('')
        print('[치명적 오류] V4.0 서버를 시작하지 못했습니다.')
        print(f'원인: {exc}')
        print('')
        raise

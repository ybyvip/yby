/* YBY V4.1.21 cards screen module; global compatibility preserved. */
function renderCardStatus() {
    const hqAlwaysSection = document.getElementById("hqAlwaysSection");
    if(hqAlwaysSection) hqAlwaysSection.style.display = userScope === "ALL" ? "block" : "none";
    let hqGrid = document.getElementById("hqCardGrid");
    if(hqGrid) {
        hqGrid.innerHTML = "";
        cardsData.filter(c=>!c.archived).filter(c => c.group === "본사").forEach(c => {
            let cardEl = document.createElement("div");
            cardEl.className = `card-item ${c.status === 'rented' ? 'in-use' : ''}`;
            cardEl.innerHTML = `
                <span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span>
                <span class="card-status ${escapeHtml(c.status === 'available' ? 'status-available' : 'status-rented')}">${escapeHtml(c.status === 'rented' ? '대여중' : c.managementStatus&&c.managementStatus!=='정상'?'불출 제한 · '+c.managementStatus:'사용가능')}</span>
                <div class="card-num">${escapeHtml(maskCardNumber(c.num))}</div>
                <div class="card-info">카드사: ${escapeHtml(c.company)}<br>${c.status === 'rented' ? `부서: ${escapeHtml(c.dept)}<br>사용자: ${escapeHtml(c.user)}` : '보유 및 대기중'}</div>
            `;
            hqGrid.appendChild(cardEl);
        });
    }

    let grid = document.getElementById("cardGrid");
    let rentedTbody = document.getElementById("rentedTable");
    let singleSection = document.getElementById("singleCardSection");
    let adminTreeSection = document.getElementById("adminBranchTreeSection");

    if(!grid || !rentedTbody) return;
    grid.innerHTML = ""; rentedTbody.innerHTML = "";

    if(userScope === "ALL") {
        singleSection.style.display = "none";
        adminTreeSection.style.display = "block";
        renderAdminBranchTree();
        return;
    } else {
        singleSection.style.display = "block";
        adminTreeSection.style.display = "none";
    }

    cardsData.filter(c=>!c.archived).filter(c => c.group === userScope).forEach(c => {
        let cardEl = document.createElement("div");
        cardEl.className = `card-item ${c.status === 'rented' ? 'in-use' : ''}`;
        cardEl.innerHTML = `
            <span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span>
            <span class="card-status ${escapeHtml(c.status === 'available' ? 'status-available' : 'status-rented')}">${escapeHtml(c.status === 'rented' ? '대여중' : c.managementStatus&&c.managementStatus!=='정상'?'불출 제한 · '+c.managementStatus:'사용가능')}</span>
            <div class="card-num">${escapeHtml(maskCardNumber(c.num))}</div>
            <div class="card-info">카드사: ${escapeHtml(c.company)}<br>${c.status === 'rented' ? `부서: ${escapeHtml(c.dept)}<br>사용자: ${escapeHtml(c.user)}<br>반납예정: ${escapeHtml(c.dueDate)}` : '보유 및 대기중'}</div>
        `;
        grid.appendChild(cardEl);

        if(c.status === 'rented') {
            let tr = document.createElement("tr");
            tr.innerHTML = `
                <td><b>${escapeHtml(maskCardNumber(c.num))}</b></td>
                <td><span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span></td>
                <td>${escapeHtml(c.paymentType||'미기록')}</td><td>${escapeHtml(c.usageScope||'미기록')}</td>
                <td>${escapeHtml(c.company)}</td>
                <td>${escapeHtml(c.dept)}</td>
                <td><b>${escapeHtml(c.user)}</b></td>
                <td style="text-align:left;">${escapeHtml(c.purpose || '-')}</td>
                <td>${escapeHtml(c.rentDate)}</td>
                <td style="color:${escapeHtml(isOverdue(c.dueDate) ? '#dc2626' : 'inherit')}">${escapeHtml(c.dueDate)}</td>
                <td><span class="badge badge-processing">대여중</span></td>
            `;
            rentedTbody.appendChild(tr);
        }
    });
}

function isOverdue(dateStr) {
    if(!dateStr) return false;
    return dateStr < localDate();
}

function renderAdminBranchTree() {
    let container = document.getElementById("branchTreeContainer");
    if(!container) return;
    container.innerHTML = "";
    BRANCHES.forEach(b => {
        let bCards = cardsData.filter(c=>!c.archived).filter(c => c.group === b);
        let node = document.createElement("div");
        node.className = "branch-node";
        node.innerHTML = `
            <div class="branch-header" onclick="toggleBranchNode(this)">
                <span>🏢 ${escapeHtml(b)} 지점 보유 카드 (${escapeHtml(bCards.length)}개)</span>
                <span>▼ 펼치기/접기</span>
            </div>
            <div class="branch-content">
                <div class="card-grid">
                    ${bCards.map(c => `
                        <div class="card-item ${escapeHtml(c.status === 'rented' ? 'in-use' : '')}">
                            <span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span>
                            <span class="card-status ${escapeHtml(c.status === 'available' ? 'status-available' : 'status-rented')}">${escapeHtml(c.status === 'rented' ? '대여중' : c.managementStatus&&c.managementStatus!=='정상'?'불출 제한 · '+c.managementStatus:'사용가능')}</span>
                            <div class="card-num">${escapeHtml(maskCardNumber(c.num))}</div>
                            <div class="card-info">카드사: ${escapeHtml(c.company)}<br>${escapeHtml(c.status === 'rented' ? `사용자: ${c.user}` : '보유중')}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        container.appendChild(node);
    });
}

function toggleBranchNode(header) {
    let content = header.nextElementSibling;
    if(content) content.classList.toggle("open");
}

function renderRentDropdowns() {
    let select = document.getElementById("rentCardSelect");
    if(select) {
        const previous=select.value;select.innerHTML = "";
        rentalCardCandidates().forEach(c => {
            let opt = document.createElement("option");
            opt.value = c.id;
            opt.innerText = `[${c.group}] ${c.company} (${c.num})`;
            select.appendChild(opt);
        });
        if([...select.options].some(x=>x.value===previous))select.value=previous;
        prepareRentalFormDefaults();
    }

    renderRentalDrafts();
    let returnTbody = document.getElementById("returnTable");
    if(returnTbody) {
        returnTbody.innerHTML = "";
        (userScope === "ALL" ? cardsData.filter(c=>!c.archived).filter(c => c.status === 'rented') : cardsData.filter(c=>!c.archived).filter(c => c.group === userScope && c.status === 'rented')).forEach(c => {
            let tr = document.createElement("tr");
            tr.innerHTML = `
                <td><b>${escapeHtml(maskCardNumber(c.num))}</b></td>
                <td><span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span></td>
                <td><b>${escapeHtml(c.user)}</b><small class="intake-subtext">신청자: ${escapeHtml(c.applicantName||'미기록')}<br>신청일: ${escapeHtml(c.applicationDate||'미기록')}</small></td>
                <td>${escapeHtml(c.dept)}</td>
                <td style="text-align:left;">${escapeHtml(c.purpose)}<br>${intakeSourceHTML(c)}</td>
                <td>${escapeHtml(c.dueDate)}</td>
                <td><button class="btn-warning" onclick="openReturnModal(${escapeHtml(Number(c.id))})">반납 회수</button></td>
            `;
            returnTbody.appendChild(tr);
        });
    }
}

async function handleRentCard(e){
    e.preventDefault();if(rentalDraftSaving)return;const selectedPurposes=Array.from(document.querySelectorAll('input[name="purposeChk"]:checked')).map(x=>x.value);
    if(!selectedPurposes.length){alert('목적을 선택하세요.');return;}
    const payload={applicationDate:document.getElementById('rentApplicationDate').value,applicantName:document.getElementById('rentApplicant').value.trim(),...intakeReference(rentalIntake.application),cardId:document.getElementById('rentCardSelect').value,dept:document.getElementById('rentDept').value,user:document.getElementById('rentUser').value,dueDate:document.getElementById('rentDueDate').value,purpose:'['+selectedPurposes.join(', ')+'] '+document.getElementById('rentDetailPurpose').value};
    const button=document.getElementById('rentalApplyButton');rentalDraftSaving=true;button.disabled=true;
    try{const card=cardsData.find(x=>String(x.id)===payload.cardId);if(!card)throw Error('대여 가능 카드를 선택하세요.');payload.attachments=await uploadRentalFiles(card.group);await businessOperation('/api/cards/draft-save',{...payload,...rentalDraftIdentity()});e.target.reset();clearRentalDraftEditor();resetRentalIntake();alert('불출예정으로 임시저장했습니다. 실제 인계 시 불출 확정하세요.');}catch(error){alert(error.message);}finally{rentalDraftSaving=false;button.disabled=false;}
}

let returnExpenseFiles = [];
let returnExpenseSubmitting = false;

function setReturnUsageMode(mode) {
    const used=document.getElementById('returnUsedCheckbox');
    const unused=document.getElementById('returnUnusedCheckbox');
    const fields=document.getElementById('returnExpenseFields');
    if(mode==='used'&&used?.checked&&unused)unused.checked=false;
    if(mode==='unused'&&unused?.checked&&used)used.checked=false;
    if(fields)fields.style.display=used?.checked?'flex':'none';
    const hint=document.getElementById('returnUsageHint'),submit=document.getElementById('returnCardSubmitButton');
    if(hint)hint.textContent=used?.checked?'입력한 정산은 반납과 함께 저장되어 결재 대기 목록에 등록됩니다.':unused?.checked?'정산 내역을 등록하지 않고 카드만 반납합니다.':'사용함 또는 미사용을 선택한 뒤 반납을 처리하세요.';
    if(submit)submit.textContent=used?.checked?'반납 및 정산 신청':'반납 처리';
}

function renderReturnExpenseFiles() {
    const list=document.getElementById('returnExpenseFileList'); if(!list)return;
    list.innerHTML=returnExpenseFiles.map((file,index)=>`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;"><span>📎 ${escapeHtml(file.name)} <small>(${escapeHtml((file.size/1024/1024).toFixed(2))}MB)</small></span><button type="button" class="btn-danger" style="padding:2px 7px;" onclick="removeReturnExpenseFile(${escapeHtml(Number(index))})">삭제</button></div>`).join('')||'<small style="color:#64748b;">첨부된 파일이 없습니다.</small>';
}
function addReturnExpenseFiles(input) {
    const selected=Array.from(input.files||[]);
    if(returnExpenseFiles.length+selected.length>5){alert('첨부파일은 최대 5개까지 선택할 수 있습니다.');input.value='';return;}
    for(const file of selected){if(file.size>20*1024*1024){alert(`${file.name}: 파일 하나당 20MB 이하로 첨부해 주세요.`);continue;}returnExpenseFiles.push(file);}
    input.value='';renderReturnExpenseFiles();
}
function removeReturnExpenseFile(index){returnExpenseFiles.splice(index,1);renderReturnExpenseFiles();}
async function uploadSettlementAttachment(file, group) {
    const bytes=new Uint8Array(await file.arrayBuffer());let binary='';
    for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
    const requestBody=JSON.stringify({name:file.name,content:btoa(binary),purpose:'settlement',group});
    let lastError=null;
    for(let attempt=1;attempt<=2;attempt++){
        try {
            const controller=new AbortController();
            const timer=setTimeout(()=>controller.abort(),60000);
            let response;
            try { response=await fetch('/api/attachments',{method:'POST',headers:{'Content-Type':'application/json'},body:requestBody,signal:controller.signal,cache:'no-store'}); }
            finally { clearTimeout(timer); }
            const data=await response.json().catch(()=>({}));
            if(!response.ok||!data.ok)throw Object.assign(new Error(data.message||`${file.name} 업로드 실패 (HTTP ${response.status})`),{serverResponse:true});
            return {id:data.attachment_id,name:data.name};
        } catch(error) {
            lastError=error;
            if(error.serverResponse)throw error;
            if(error.name==='AbortError')throw new Error(`${file.name} 업로드가 60초 동안 응답을 받지 못해 중단되었습니다. 서버 실행창과 연결 상태를 확인해 주세요.`);
            // A lost response may mean the file was stored already; retrying uses a new id,
            // but the duplicate remains unreferenced and never replaces another file.
            if(attempt<2){await new Promise(resolve=>setTimeout(resolve,700));continue;}
        }
    }
    let healthText='';
    try {
        const health=await fetch('/health',{cache:'no-store',signal:AbortSignal.timeout(5000)});
        healthText=health.ok?'서버는 응답하지만 첨부 업로드 응답이 끊겼습니다.':'서버 상태 확인에 실패했습니다.';
    } catch(_){healthText='서버에 연결할 수 없습니다. 서버 PC에서 START_V3.bat 실행 창이 열려 있는지, 접속 주소의 포트가 서버 화면의 포트와 같은지 확인해 주세요.';}
    throw new Error(`${file.name} 업로드 실패: ${lastError?.message||'네트워크 연결 오류'}\n${healthText}`);
}
async function saveReturnSettlement(expense) {
    const response=await fetch('/api/expense-submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expense})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok||!data.ok||!data.expense)throw new Error(data.message||'정산 신청을 서버에 저장하지 못했습니다.');
    serverStateRevision=data.revision||serverStateRevision;
    return data.expense;
}

function settlementFormHTML(record,revision=false) {
    const attachments=revision?`<div id="resubmissionKeepFiles" class="settlement-file-list"></div><div class="form-group"><label for="resubmissionFiles">증빙 추가</label><input type="file" id="resubmissionFiles" multiple></div>`:`<div class="form-group"><label for="returnExpenseFileInput">증빙 추가</label><input type="file" id="returnExpenseFileInput" multiple onchange="addReturnExpenseFiles(this)" accept=".jpg,.jpeg,.png,.gif,.pdf,.xlsx,.xls,.doc,.docx,.hwp,.hwpx,.txt,.zip"><div id="returnExpenseFileList" class="settlement-file-list"></div></div>`;
    return `
        <section class="settlement-section" data-settlement-section="basic"><h3 class="settlement-section-title">1. 정산 기본정보</h3><div class="settlement-grid">
            <div class="form-group"><label for="returnExpenseDate">기본 사용일 *</label><input type="date" id="returnExpenseDate" required onchange="syncSettlementDate(this.value)"></div>
            <div class="form-group"><label for="returnExpenseCategory">기본 정산 구분 *</label><select id="returnExpenseCategory" required><option value="">선택하세요</option><option>식대</option><option>교통·출장</option><option>숙박</option><option>주유·차량</option><option>접대·회의</option><option>비품·업무용품</option><option>기타</option></select></div>
            <div class="form-group"><label for="returnExpenseUser">사용자 *</label><input id="returnExpenseUser" maxlength="200" required></div>
            <div class="form-group"><label for="returnExpenseDept">부서·담당 지점</label><input id="returnExpenseDept" maxlength="200" ${revision?'':'readonly'}></div>
        </div></section>
        <section class="settlement-section" data-settlement-section="usage"><h3 class="settlement-section-title">2. 사용 및 금액</h3><div class="settlement-grid">
            <div class="form-group"><label for="returnExpenseMerchant">사용처 요약 · 자동 집계</label><input id="returnExpenseMerchant" placeholder="건별 사용처에서 자동 집계" readonly></div>
            <div class="form-group"><label for="returnExpenseAmount">정산 금액(원) · 자동 합계</label><input type="number" id="returnExpenseAmount" readonly></div>
            <div class="form-group full"><label for="returnExpensePurpose">사용 목적 및 업무 관련 내용 *</label><textarea id="returnExpensePurpose" rows="2" maxlength="2000" placeholder="사용 목적과 업무 관련 내용을 입력하세요." required></textarea></div>
            <div class="form-group"><label for="returnExpenseAttendees">참석자 / 동행자</label><input id="returnExpenseAttendees" maxlength="2000" placeholder="해당 시 입력"></div>
            <div class="form-group"><label for="returnExpenseNote">비고</label><textarea id="returnExpenseNote" rows="2" maxlength="2000" placeholder="추가 전달사항"></textarea></div>
        </div></section>
        <section class="settlement-section" data-settlement-section="lines"><h3 class="settlement-section-title">3. 건별 세부 정산 명세</h3>
            <p class="settlement-help">사용 건별로 입력하세요. 구분을 비우면 기본 정산 구분을 적용하며, 수량 × 단가와 합계는 자동 계산합니다.</p>
            <table class="settlement-lines-table" aria-label="건별 세부 정산 명세"><thead><tr><th>사용일</th><th>구분</th><th>사용처</th><th>수량</th><th>단가(원)</th><th>금액(원)</th><th>상세내역</th><th>비고</th><th>관리</th></tr></thead><tbody id="returnExpenseLines"></tbody></table>
            <div class="settlement-lines-actions"><button type="button" class="btn-secondary" onclick="addSettlementLine()">+ 사용 건 추가</button><div class="settlement-total">총 정산 금액 <strong><span id="returnExpenseTotal" aria-live="polite">0</span>원</strong></div></div>
        </section>
        <section class="settlement-section" data-settlement-section="attachments"><h3 class="settlement-section-title">4. 증빙 자료</h3><p class="settlement-help">영수증·세금계산서 등 최대 5개, 파일당 20MB까지 첨부할 수 있습니다.${revision?' 유지할 기존 증빙을 선택하세요.':''}</p>${attachments}</section>
        ${revision?'<section class="settlement-section settlement-workflow" data-settlement-section="resubmission"><h3 class="settlement-section-title">5. 재보고 메시지</h3><div class="form-group"><label for="resubmissionMessage">수정한 내용과 재보고 사유 *</label><textarea id="resubmissionMessage" rows="3" maxlength="1000" placeholder="요청받은 사항과 수정한 내용을 입력하세요." required></textarea></div></section>':''}`;
}

let settlementLineSequence=0,settlementDefaultDate='';
function initializeSettlementForm(record) {
    document.getElementById('returnExpenseLines').replaceChildren();
    const values={returnExpenseDate:record.date||localDateTime().slice(0,10),returnExpenseCategory:record.category||'',returnExpenseUser:record.user||'',returnExpenseDept:record.dept||record.group||'',returnExpensePurpose:record.purpose||'',returnExpenseAttendees:record.attendees||'',returnExpenseNote:record.note||''};
    const category=document.getElementById('returnExpenseCategory');
    if(values.returnExpenseCategory&&!Array.from(category.options).some(option=>option.value===values.returnExpenseCategory)){
        const option=document.createElement('option');option.value=values.returnExpenseCategory;option.textContent=values.returnExpenseCategory;category.appendChild(option);
    }
    for(const [id,value] of Object.entries(values))document.getElementById(id).value=value;
    settlementDefaultDate=values.returnExpenseDate;
    if(record.lineItems?.length){
        for(const line of record.lineItems){addSettlementLine();const tr=document.querySelector('#returnExpenseLines tr:last-child');for(const [cls,field] of Object.entries({date:'date',category:'category',merchant:'merchant',description:'description',quantity:'quantity',price:'unitPrice',note:'note'}))tr.querySelector('.line-'+cls).value=line[field]??'';}
    }else addSettlementLine();
    updateSettlementTotal();
}
function syncSettlementDate(date){
    document.querySelectorAll('#returnExpenseLines .line-date').forEach(input=>{if(!input.value||input.value===settlementDefaultDate)input.value=date;});
    settlementDefaultDate=date;
}
function addSettlementLine(){
    const body=document.getElementById('returnExpenseLines');if(body.children.length>=100){alert('최대 100건입니다.');return;}
    const tr=document.createElement('tr');tr.className='settlement-line';const key='settlementLine'+(++settlementLineSequence);
    const field=(name,label,html)=>'<td class="field-'+name+'"><label for="'+key+name+'">'+label+'</label>'+html.replace('FIELD_ID',key+name)+'</td>';
    tr.innerHTML=field('date','사용일 *','<input id="FIELD_ID" class="line-date" type="date" required>')+
        field('category','구분','<input id="FIELD_ID" class="line-category" placeholder="기본 구분" maxlength="80">')+
        field('merchant','사용처 *','<input id="FIELD_ID" class="line-merchant" required maxlength="200">')+
        field('quantity','수량 *','<input id="FIELD_ID" class="line-quantity" type="number" min="1" max="1000000" step="1" value="1" required>')+
        field('price','단가(원) *','<input id="FIELD_ID" class="line-price" type="number" min="1" max="1000000000000" step="1" required>')+
        field('amount','금액(원)','<output id="FIELD_ID" class="line-amount">0</output>')+
        field('description','상세내역 *','<input id="FIELD_ID" class="line-description" required maxlength="1000" placeholder="품목 또는 사용 내역">')+
        field('note','비고','<input id="FIELD_ID" class="line-note" maxlength="1000">')+
        '<td class="field-remove"><button type="button" class="btn-danger" aria-label="이 사용 건 삭제">삭제</button></td>';
    tr.querySelector('.line-date').value=document.getElementById('returnExpenseDate').value;
    tr.querySelector('button').onclick=()=>{if(body.children.length<=1){alert('정산에는 최소 한 건이 필요합니다.');return;}tr.remove();updateSettlementTotal();};
    tr.addEventListener('input',updateSettlementTotal);body.appendChild(tr);updateSettlementTotal();
}



function updateSettlementTotal(){
    let total=0;const merchants=[];document.querySelectorAll('#returnExpenseLines tr').forEach(tr=>{const quantity=Number(tr.querySelector('.line-quantity').value),price=Number(tr.querySelector('.line-price').value),amount=quantity*price;const valid=Number.isSafeInteger(amount)&&amount>0;tr.querySelector('.line-amount').textContent=(valid?amount:0).toLocaleString();total+=valid?amount:0;const merchant=tr.querySelector('.line-merchant').value.trim();if(merchant&&!merchants.includes(merchant))merchants.push(merchant);});
    document.getElementById('returnExpenseAmount').value=total;document.getElementById('returnExpenseTotal').textContent=total.toLocaleString();document.getElementById('returnExpenseMerchant').value=merchants.length>1?merchants[0]+' 외 '+(merchants.length-1)+'곳':merchants[0]||'';
}
function collectSettlementLines(){
    const lines=Array.from(document.querySelectorAll('#returnExpenseLines tr')).map(tr=>{const value=cls=>tr.querySelector('.line-'+cls).value;const quantity=Number(value('quantity')),unitPrice=Number(value('price'));return {date:value('date'),category:value('category').trim()||document.getElementById('returnExpenseCategory').value,merchant:value('merchant').trim(),description:value('description').trim(),quantity,unitPrice,amount:quantity*unitPrice,note:value('note').trim()};});
    if(!lines.length||lines.some(x=>!x.date||!x.category||!x.merchant||!x.description||!Number.isInteger(x.quantity)||x.quantity<=0||!Number.isInteger(x.unitPrice)||x.unitPrice<=0||!Number.isSafeInteger(x.amount))||lines.reduce((sum,x)=>sum+x.amount,0)>1e12)throw new Error('건별 사용일·구분·사용처·상세내역·양의 정수 수량/단가를 확인하세요. 합계는 1조원 이하입니다.');
    return lines;
}
function expenseLineTable(ex){
    const lines=Array.isArray(ex.lineItems)&&ex.lineItems.length?ex.lineItems:[{date:ex.date,category:ex.category,merchant:ex.merchant,description:ex.purpose,quantity:ex.historicalImport?null:1,unitPrice:ex.historicalImport||ex.amount==null?null:Math.abs(Number(ex.amount)||0),amount:ex.amount==null?null:Math.abs(Number(ex.amount)||0),note:ex.note}];
    const cell=value=>escapeHtml(String(value??''));
    return '<div class="expense-line-readonly"><table style="width:100%"><thead><tr><th>사용일</th><th>구분</th><th>사용처</th><th>상세내역</th><th>수량</th><th>단가</th><th>금액</th><th>비고</th></tr></thead><tbody>'+lines.map(x=>'<tr>'+[x.date,x.category,x.merchant,x.description,x.quantity,Number(x.unitPrice).toLocaleString(),Number(x.amount).toLocaleString(),x.note||''].map(v=>'<td>'+cell(v)+'</td>').join('')+'</tr>').join('')+'</tbody><tfoot><tr><th colspan="6">'+(ex.isCorrection?'정정 합계':'합계')+'</th><td colspan="2">'+cell(Number(ex.amount).toLocaleString())+'원</td></tr></tfoot></table></div>';
}

function openReturnModal(cardId) {
    const card=cardsData.find(c=>String(c.id)===String(cardId));if(!card||card.status!=='rented')return;
    clearExternalSettlement();returnExpenseFiles=[];returnExpenseSubmitting=false;
    document.getElementById('modalTitle').innerText='카드 반납 및 사용 정산';
    document.getElementById('modalBody').innerHTML=`<div class="settlement-form" data-mode="initial">
        <div class="settlement-context"><div><strong>법인카드 사용 정산서</strong><small>카드 ${escapeHtml(card.num)} · ${escapeHtml(card.group||'')} · ${escapeHtml(card.user||'')} / ${escapeHtml(card.dept||'')}</small></div><span class="settlement-stage">최초 정산</span></div>
        <fieldset class="return-usage-options"><legend>카드 사용 여부를 선택하세요</legend>
            <label><input type="radio" name="returnUsage" id="returnUsedCheckbox" onchange="setReturnUsageMode('used')"><span>사용함<small>반납과 함께 정산 신청</small></span></label>
            <label><input type="radio" name="returnUsage" id="returnUnusedCheckbox" onchange="setReturnUsageMode('unused')"><span>미사용<small>정산 없이 반납만 처리</small></span></label>
        </fieldset>
        <div id="returnLiveInbox"></div>
        <div id="returnExpenseFields" class="settlement-form" style="display:none">${settlementFormHTML(card)}${returnReportCopyHTML()}</div>
        <p id="returnUsageHint" class="settlement-help">사용함 또는 미사용을 선택한 뒤 반납을 처리하세요.</p>
        </div>`;
    initializeSettlementForm({user:card.user||currentUser||'',dept:card.dept||card.group||''});renderReturnExpenseFiles();
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">취소</button><button id="returnCardSubmitButton" class="btn-primary" onclick="returnCard('+Number(cardId)+')">반납 처리</button>';
    document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;mountReturnLiveInbox(cardId);
}



async function returnCard(cardId) {
    const card=cardsData.find(c=>String(c.id)===String(cardId));
    if(!card||card.status!=='rented'||returnExpenseSubmitting)return;
    const used=!!document.getElementById('returnUsedCheckbox')?.checked;
    const unused=!!document.getElementById('returnUnusedCheckbox')?.checked;
    if(!used&&!unused){alert('사용함 또는 미사용을 선택해 주세요.');return;}
    const copyReport=used&&!!document.getElementById('returnCopyReport')?.checked;
    let expenseDraft=null;
    if(used){
        let lineItems;try{lineItems=collectSettlementLines();}catch(error){alert(error.message);return;}
        updateSettlementTotal();
        const date=document.getElementById('returnExpenseDate').value;
        const merchant=document.getElementById('returnExpenseMerchant').value.trim();
        const amount=parseInt(document.getElementById('returnExpenseAmount').value,10);
        const purpose=document.getElementById('returnExpensePurpose').value.trim();
        const category=document.getElementById('returnExpenseCategory').value||'복수 항목';
        const expenseUser=document.getElementById('returnExpenseUser').value.trim();
        if(!date||!category||!expenseUser||!merchant||!Number.isInteger(amount)||amount<=0||!purpose){alert('별표(*) 표시된 정산 기본정보와 사용 내역을 모두 입력해 주세요.');return;}
        expenseDraft={lineItems,id:nextNumericId(expenseData),date,cardNum:card.num,cardCompany:card.company,group:card.group,dept:card.dept||'기타팀',user:expenseUser,merchant,purpose,amount,category,attendees:document.getElementById('returnExpenseAttendees').value.trim(),note:document.getElementById('returnExpenseNote').value.trim(),attachments:[],status:'승인대기',requester:currentUser,requestedAt:localDateTime(true),returnSource:true};
    }
    const button=document.getElementById('returnCardSubmitButton');returnExpenseSubmitting=true;if(button){button.disabled=true;button.innerText='처리 중...';}
    try {
    if(expenseDraft&&returnExpenseFiles.length){for(const file of returnExpenseFiles)expenseDraft.attachments.push(await uploadSettlementAttachment(file,card.group));}
    const result=await businessOperation('/api/cards/return',{cardId:card.id,used,expense:expenseDraft,...intakeReference(rentalIntake.settlement)});closeModal();refreshWorkflowInbox();
    if(copyReport&&result.expenseRef)await openReturnReportDraft(result.expenseRef);
    returnExpenseSubmitting=false;alert(used?'반납과 정산이 함께 저장되었습니다.':'미사용 카드 반납 처리가 완료되었습니다.');
    } catch(error){returnExpenseSubmitting=false;if(button){button.disabled=false;button.innerText='반납 처리';}alert(error.message||'정산 첨부파일 또는 반납 정보를 저장하지 못했습니다.');}
}

function historyIssueDate(record, rows) {
    if(record.rentDate) return record.rentDate;
    if(record.type === '불출') return String(record.time || '').slice(0, 10);
    if(record.type !== '반납') return '';
    const events=rows.filter(x=>x.group===record.group&&x.cardNum===record.cardNum).slice().sort((a,b)=>String(a.time||'').localeCompare(String(b.time||'')));
    let activeIssue='';
    for(const event of events){if(event.type==='불출')activeIssue=event.rentDate||String(event.time||'').slice(0,10);else if(event.type==='반납'){if(event===record)return activeIssue;activeIssue='';}}
    return '';
}

function setHistorySelectOptions(id, values, emptyLabel, formatter=value=>value) {
    const select=document.getElementById(id);if(!select)return;
    const selected=select.value;const unique=[...new Set(values.map(v=>String(v??'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ko',{numeric:true}));
    select.innerHTML=`<option value="">${escapeHtml(emptyLabel)}</option>`+unique.map(value=>`<option value="${escapeHtml(value)}">${escapeHtml(formatter(value))}</option>`).join('');
    if(unique.includes(selected))select.value=selected;
}
function cardHistoryDate(row){return row.type==='반납'?(row.returnDate||String(row.time||'').slice(0,10)):(row.rentDate||String(row.time||'').slice(0,10));}
function historyYearMonthOptions(rows,dateField){
    const dates=rows.map(row=>String(dateField(row)||'')).filter(date=>/^\d{4}-\d{2}-\d{2}/.test(date));
    return {years:dates.map(date=>date.slice(0,4)),months:[...new Set(dates.map(date=>date.slice(5,7)))].sort()};
}
function setHistoryDateOptions(yearId,monthId,dates){
    setHistorySelectOptions(yearId,dates.years,'전체 연도',value=>`${value}년`);
    setHistorySelectOptions(monthId,dates.months,'전체 월',value=>`${Number(value)}월`);
}
function getFilteredCardHistory(){
    const base=userScope==='ALL'?cardHistoryData:cardHistoryData.filter(row=>row.group===userScope);
    setHistorySelectOptions('historyGroupFilter',base.map(row=>row.group),'전체 지역');
    setHistorySelectOptions('historyUserFilter',base.map(row=>row.user),'전체 사용자');
    setHistorySelectOptions('historyDeptFilter',base.map(row=>row.dept),'전체 부서');
    setHistorySelectOptions('historyCompanyFilter',base.map(row=>row.cardCompany||cardsData.find(card=>card.num===row.cardNum)?.company),'전체 카드사');
    setHistorySelectOptions('historyCardFilter',base.map(row=>row.cardNum),'전체 카드');
    setHistoryDateOptions('historyYearFilter','historyMonthFilter',historyYearMonthOptions(base,cardHistoryDate));
    const query=(document.getElementById('historySearchInput')?.value||'').trim().toLocaleLowerCase();
    const group=document.getElementById('historyGroupFilter')?.value||'',user=document.getElementById('historyUserFilter')?.value||'',dept=document.getElementById('historyDeptFilter')?.value||'';
    const company=document.getElementById('historyCompanyFilter')?.value||'',cardNum=document.getElementById('historyCardFilter')?.value||'',used=document.getElementById('historyUsedFilter')?.value||'';
    const year=document.getElementById('historyYearFilter')?.value||'',month=document.getElementById('historyMonthFilter')?.value||'';
    const type=document.getElementById('historyTypeFilter')?.value||'',from=document.getElementById('historyFromFilter')?.value||'',to=document.getElementById('historyToFilter')?.value||'';
    return ledgerNewFirst('card',filterLedgerColumns('card',base.filter(row=>{
        const date=cardHistoryDate(row),rowCompany=row.cardCompany||cardsData.find(card=>card.num===row.cardNum)?.company||'';const haystack=[row.id,row.time,row.type,row.used?'사용':(row.used===false?'미사용':''),row.group,row.cardNum,rowCompany,row.dept,row.user,row.applicantName,row.applicationDate,row.entrySource,row.sourceRef?.documentNo,row.purpose,row.dueDate,row.handler,date].map(value=>String(value??'').toLocaleLowerCase()).join(' ');
        return (!query||haystack.includes(query))&&(!group||row.group===group)&&(!user||String(row.user||'')===user)&&(!dept||String(row.dept||'')===dept)&&(!company||rowCompany===company)&&(!cardNum||row.cardNum===cardNum)&&(!used||(used==='used'?ledgerUsed(row)==='사용':ledgerUsed(row)==='미사용'))&&(!year||date.slice(0,4)===year)&&(!month||date.slice(5,7)===month)&&(!type||row.type===type)&&(!from||date>=from)&&(!to||date<=to);
    })));
}
function resetCardHistoryFilters(){clearLedgerFilters('card');['historySearchInput','historyGroupFilter','historyUserFilter','historyDeptFilter','historyCompanyFilter','historyCardFilter','historyUsedFilter','historyYearFilter','historyMonthFilter','historyTypeFilter','historyFromFilter','historyToFilter'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});renderCardHistory();}

/* YBY V4.1.21 ledgers screen module; global compatibility preserved. */
function renderCardHistory() {
    const tbody=document.getElementById('cardHistoryTable');if(!tbody)return;tbody.innerHTML='';
    const allRows=userScope==='ALL'?cardHistoryData:cardHistoryData.filter(row=>row.group===userScope);
    renderLedgerScope('card');const list=getFilteredCardHistory(),context=YbyLedger.cardContext(allRows,cardsData,[...expenseData,...expenseHistoryData],userScope);
    const count=document.getElementById('cardHistoryResultCount');if(count)count.textContent=`검색 결과 ${list.length.toLocaleString()}건 / 전체 ${allRows.length.toLocaleString()}건`;
    list.forEach(h => {
        const progress=context.progress(h),uses=context.count(h);
        let tr = document.createElement("tr");tr.dataset.progress=progress.tone;
        tr.innerHTML = `
            <td>${ledgerSerial(h,'card')}</td><td>${escapeHtml(h.id)}</td><td><span class="intake-source">${escapeHtml(intakeSourceLabel(h))}</span></td><td>${escapeHtml(ledgerCreatedLabel(h))}</td><td>${escapeHtml(h.historicalImport?h.time:formatServerTime(h.time))}</td>
            <td><span class="badge ${escapeHtml(h.type === '불출' ? 'badge-issue' : 'badge-return')}">${escapeHtml(h.type)}</span></td>
            <td>${escapeHtml(h.historicalImport||h.type==='반납'?ledgerUsed(h):'-')}</td>
            <td>${escapeHtml(historyIssueDate(h, allRows) || '-')}</td><td>${escapeHtml(ledgerReturnDate(h)||'-')}</td>
            <td><span class="card-tag tag-${escapeHtml(h.group)}">${escapeHtml(h.group)}</span></td>
            <td><b>${escapeHtml(maskCardNumber(h.cardNum))}</b></td><td>${escapeHtml(h.dept)}</td><td><b>${escapeHtml(h.user)}</b><small class="ledger-user-count">${uses===null?'불출 횟수 확인 필요':'누적 불출 '+escapeHtml(uses)+'회'}</small></td><td><span class="ledger-progress ${escapeHtml(progress.tone)}">${escapeHtml(progress.label)}</span></td>
            <td style="text-align:left;">${escapeHtml(h.purpose || '-')}<small class="intake-subtext">신청일 ${escapeHtml(h.applicationDate||'미기록')} · 신청자 ${escapeHtml(h.applicantName||'미기록')}</small></td><td>${escapeHtml(h.dueDate)}</td><td>${escapeHtml(h.handler)}</td><td class="history-actions"></td>
        `;
        if(h.historicalImport&&canCorrectImported()){const ex=importedExpenseFor(h);if(ex){const button=fleetButton('수기 정정',()=>openImportedCorrection(ex));tr.lastElementChild.append(button);}}
        tbody.appendChild(tr);
    });
    renderLedgerTools('card',list);
    if(!list.length)tbody.innerHTML='<tr><td colspan="18" class="ledger-empty">조회 조건에 맞는 이력이 없습니다.</td></tr>';
}

function excelCell(value){return `<Cell><Data ss:Type="String">${escapeHtml(value===undefined||value===null?'':String(value))}</Data></Cell>`;}
async function downloadExcelReport(filename,title,headers,rows){try{const r=await fetch('/api/exports',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,headers,rows:rows.map(row=>row.map((value,index)=>{if(String(headers[index]).includes('금액')&&typeof value==='string'){const number=value.replace(/[,\s원]/g,'');if(/^-?\d+(\.\d+)?$/.test(number))return Number(number);}return value;}))})});if(!r.ok){const v=await r.json();throw new Error(v.message);}const blob=await r.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=filename.replace(/\.xlsx?$/i,'')+'.xlsx';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);}catch(e){alert(e.message);}}
function openHistoryPrintReport(title,headers,rows){
    const win=window.open('','_blank');if(!win){alert('보고서 창이 차단되었습니다. 브라우저에서 팝업을 허용한 뒤 다시 시도해 주세요.');return;}
    const th=headers.map(value=>`<th>${escapeHtml(value)}</th>`).join('');
    const body=rows.length?rows.map(row=>`<tr>${row.map(value=>`<td>${escapeHtml(value)}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${escapeHtml(headers.length)}" class="empty">검색 결과가 없습니다.</td></tr>`;
    win.document.write(`<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>body{font-family:Arial,'Malgun Gothic',sans-serif;margin:18px;color:#111827}h1{font-size:20px}.meta{font-size:12px;color:#475569;margin-bottom:14px}table{width:100%;border-collapse:collapse;font-size:10px}th,td{border:1px solid #94a3b8;padding:6px;text-align:left;vertical-align:top;word-break:break-word}th{background:#eff6ff}.empty{text-align:center;padding:24px}@media print{body{margin:8mm}}</style></head><body><h1>${escapeHtml(title)}</h1><div class="meta">조회 범위: ${escapeHtml(userScope==='ALL'?'전체 지점':userScope+' 지점')}　|　출력 시각: ${escapeHtml(localDateTime(true))}　|　검색 결과 ${escapeHtml(rows.length)}건</div><table><thead><tr>${th}</tr></thead><tbody>${body}</tbody></table><script>window.onload=()=>window.print()<\/script></body></html>`);win.document.close();
}
function cardHistoryExportRows(){
    const allRows=userScope==='ALL'?cardHistoryData:cardHistoryData.filter(row=>row.group===userScope);
    const context=YbyLedger.cardContext(allRows,cardsData,[...expenseData,...expenseHistoryData],userScope);
    return getFilteredCardHistory().map(h=>[ledgerSerial(h,'card'),h.id,intakeSourceLabel(h),ledgerCreatedLabel(h),h.time,h.type,h.historicalImport||h.type==='반납'?ledgerUsed(h):'-',historyIssueDate(h,allRows)||'',ledgerReturnDate(h),h.group,h.cardNum,h.cardCompany||cardsData.find(c=>c.num===h.cardNum)?.company||'',h.dept,h.user,context.count(h)??'',context.progress(h).label,h.purpose,h.dueDate,h.handler,h.applicationDate||'',h.applicantName||'',intakeSourceLabel(h),h.sourceRef?.documentNo||'',h.settlementSource||'',h.settlementSourceRef?.documentNo||'']);
}
const cardHistoryExportHeaders=['일련번호','이력 ID','입력경로','작성기준일','처리 일시','구분','사용 여부','최초 불출일','반납일','소속','카드번호','카드사','부서','사용자','사용자 누적 불출(회)','반납·정산 진행상태','목적','반납예정일','처리자','사용신청일','신청자명','불출 자료 출처','외부 신청 문서','정산 자료 출처','외부 정산 문서'];
function exportHistoryExcel(){downloadExcelReport(`불출반납이력_${userScope}.xls`,'불출반납이력',cardHistoryExportHeaders,cardHistoryExportRows());}
function printCardHistoryReport(){openHistoryPrintReport('법인카드 불출 및 반납 이력 보고서',cardHistoryExportHeaders,cardHistoryExportRows());}

function cardRemainingDays(expiryDate){if(!expiryDate)return '-';const expiry=new Date(`${expiryDate}T00:00:00`);if(Number.isNaN(expiry.getTime()))return '-';const today=new Date();today.setHours(0,0,0,0);const days=Math.ceil((expiry-today)/86400000);return days<0?`만료 ${Math.abs(days)}일`:`${days}일`;}
function toggleCardDesignatedUser(){const type=document.getElementById('regCardUserType'),name=document.getElementById('regCardAssignedUser');if(!type||!name)return;name.disabled=type.value!=='지정';name.required=type.value==='지정';if(name.disabled)name.value='';}

async function handleRegisterCard(e) {
    e.preventDefault();
    if(!hasViewPermission("v_card_reg")){alert("카드 등록 권한이 없습니다.");return;}
    let group = document.getElementById("regCardGroup").value;
    let company = document.getElementById("regCardCompany").value;
    let num = document.getElementById("regCardNum").value.trim();
    if(cardsData.some(c=>c.num===num)){ alert("이미 등록된 카드번호입니다."); return; }
    const userType=document.getElementById('regCardUserType').value,assignedUser=document.getElementById('regCardAssignedUser').value.trim();
    if(userType==='지정'&&!assignedUser){alert('지정 사용자를 입력해 주세요.');return;}
    const issueDate=document.getElementById('regCardIssueDate').value,expiryDate=document.getElementById('regCardExpiryDate').value;if(issueDate&&expiryDate&&expiryDate<issueDate){alert('만료일은 발급일보다 빠를 수 없습니다.');return;}
    try{await businessOperation('/api/cards/register',{withdrawalAccount:document.getElementById('regCardWithdrawalAccount').value,limitAmount:document.getElementById('regCardLimitAmount').value===''?null:Number(document.getElementById('regCardLimitAmount').value),group,company,num,userType,assignedUser,issueDate,expiryDate,paymentType:document.getElementById('regCardPaymentType').value,usageScope:document.getElementById('regCardUsageScope').value,cardAlias:document.getElementById('regCardAlias').value.trim()});alert('카드가 서버에 등록되었습니다.');e.target.reset();}catch(e){alert(e.message);}
}

async function deleteCard(id) {
 const card=cardsData.find(c=>c.id===id);if(!card||!hasViewPermission('v_card_reg'))return;
 const reason=prompt('이력은 보존하고 등록 목록에서 사용중지합니다. 삭제 사유를 입력하세요.');if(!reason)return;
 try{await businessOperation('/api/cards/archive',{cardId:id,expectedVersion:card.managementVersion||'',reason});}catch(e){alert(e.message);}
}

function editCard(id) {
    if(!hasViewPermission("v_card_reg")){alert("카드 등록·수정 권한이 없습니다.");return;}
    let card = cardsData.find(c => c.id === id);
    if(!card) return;
    document.getElementById('modalTitle').innerText='법인카드 정보 수정';
    document.getElementById('modalBody').innerHTML=`<div class="form-row"><div class="form-group"><label>소속 지점</label><select id="editCardGroup"><option>본사</option><option>서울</option><option>인천</option><option>정봉</option><option>임원실</option><option>광주</option></select></div><div class="form-group"><label>카드사</label><input id="editCardCompany" value="${escapeHtml(card.company||'')}"></div><div class="form-group"><label>카드번호</label><input id="editCardNum" value="${escapeHtml(card.num||'')}"></div><div class="form-group"><label>사용자 구분</label><select id="editCardUserType" onchange="document.getElementById('editCardAssignedUser').disabled=this.value!=='지정'"><option ${escapeHtml(card.userType!=='지정'?'selected':'')}>비지정</option><option ${escapeHtml(card.userType==='지정'?'selected':'')}>지정</option></select></div><div class="form-group"><label>지정 사용자</label><input id="editCardAssignedUser" value="${escapeHtml(card.assignedUser||'')}" ${escapeHtml(card.userType==='지정'?'':'disabled')}></div><div class="form-group"><label>발급일</label><input type="date" id="editCardIssueDate" value="${escapeHtml(card.issueDate||'')}"></div><div class="form-group"><label>만료일</label><input type="date" id="editCardExpiryDate" value="${escapeHtml(card.expiryDate||'')}"></div><div class="form-group"><label>카드 별칭</label><input id="editCardAlias" value="${escapeHtml(card.cardAlias||'')}"></div><div class="form-group"><label>관리 식별자 (인증 비밀값 입력 금지)</label><input type="password" id="editCardKey" disabled autocomplete="new-password" placeholder="비워두면 기존 KEY 유지"></div></div>`;
    document.getElementById('modalBody').querySelector('.form-row').insertAdjacentHTML('afterbegin',fleetSelect('editCardPaymentType','신용/체크',['','신용','체크'],card.paymentType||'')+fleetSelect('editCardUsageScope','사용 범위',['','국내전용','해외겸용'],card.usageScope||''));
    document.getElementById('modalBody').insertAdjacentHTML('beforeend',managementEditorHTML(card));
    document.getElementById('editCardGroup').value=card.group||'본사';
    document.getElementById('modalFooter').innerHTML=`<button class="btn-secondary" onclick="closeModal()">취소</button><button class="btn-success" onclick="saveCardEdit(${escapeHtml(Number(card.id))})">저장</button>`;
    document.getElementById('commonModal').style.display='flex';
}

async function saveCardEdit(id){const card=cardsData.find(c=>Number(c.id)===Number(id));if(!card)return;const payload={cardId:id,expectedVersion:card.managementVersion||'',reason:document.getElementById('editCardReason').value,managementStatus:document.getElementById('editCardManagementStatus').value,withdrawalAccount:document.getElementById('editCardWithdrawalAccount').value,limitAmount:document.getElementById('editCardLimitAmount').value===''?null:Number(document.getElementById('editCardLimitAmount').value)};
 for(const [key,suffix] of Object.entries({paymentType:'PaymentType',usageScope:'UsageScope',group:'Group',company:'Company',num:'Num',userType:'UserType',assignedUser:'AssignedUser',issueDate:'IssueDate',expiryDate:'ExpiryDate',cardAlias:'Alias'}))payload[key]=document.getElementById('editCard'+suffix).value;
 try{await businessOperation('/api/cards/manage',payload);closeModal();}catch(e){alert(e.message);}}


function expenseAttachmentLinks(ex) {
    const files=Array.isArray(ex.attachments)?ex.attachments:[];
    if(!files.length)return '-';
    return files.map(file=>file&&file.id?`<a target="_blank" rel="noopener" href="/api/attachments/${escapeHtml(encodeURIComponent(file.id))}" style="display:block;white-space:nowrap;">📎 ${escapeHtml(file.name||'첨부파일')}</a>`:'').join('')||'-';
}

function renderExpenseTable() {
    let tbody = document.getElementById("expenseTable");
    if(!tbody) return;
    tbody.innerHTML = "";
    (userScope === "ALL" ? expenseData : expenseData.filter(ex => ex.group === userScope)).filter(ex => ["승인대기","재보고대기"].includes(ex.status)).forEach(ex => {
        let tr = document.createElement("tr");
        tr.innerHTML = `
            <td class="history-dates"><small>사용일</small>${escapeHtml(ex.date)}<small>${ex.status==='재보고대기'?'대기 생성':'신청'}: ${escapeHtml(formatServerTime(ex.requestedAt))}</small></td><td><b>${escapeHtml(maskCardNumber(ex.cardNum))}</b></td><td><span class="card-tag tag-${escapeHtml(ex.group)}">${escapeHtml(ex.group)}</span></td>
            <td>${escapeHtml(ex.user||'-')}</td><td>${escapeHtml(ex.category||'-')}</td><td>${escapeHtml(ex.merchant||'-')}</td><td style="text-align:left;">${escapeHtml(ex.purpose||'-')}${ex.attendees?`<br><small>참석: ${escapeHtml(ex.attendees)}</small>`:''}${ex.note&&!ex.historicalImport?`<br><small>비고: ${escapeHtml(ex.note)}</small>`:''}</td>
            <td class="num-right">${expenseAmountLabel(ex)}</td><td>${expenseAttachmentLinks(ex)}</td>
            <td><span class="badge ${escapeHtml(ex.status === '승인완료' ? 'badge-approved' : 'badge-pending')}">${escapeHtml(ex.status)}</span></td>
            <td style="text-align:left;max-width:240px">${workflowMessageSummary(ex)}</td>
            <td>${ex.status === '승인대기' && userScope === 'ALL' ? `<button class="btn-success" style="padding:3px 6px;" onclick="approveExpense(${jsArg(ex.id)}, ${jsArg(ex.group)}, ${jsArg(ex.requester||'')})">승인</button> <button class="btn-danger" style="padding:3px 6px;" onclick="rejectExpense(${jsArg(ex.id)}, ${jsArg(ex.group)}, ${jsArg(ex.requester||'')})">반려</button>` : '-'}</td>
        `;
        const detail=document.createElement('button');detail.type='button';detail.className='btn-primary';detail.textContent='명세 보기';detail.onclick=()=>showExpenseHistoryDetail(ex);tr.lastElementChild.appendChild(detail);
        if(ex.status==='재보고대기'&&(userScope==='ALL'||ex.requester===currentUser)){const edit=document.createElement('button');edit.className='btn-warning';edit.textContent='정정 작성·재보고';edit.onclick=()=>openResubmission(ex);tr.lastElementChild.appendChild(edit);}
        tbody.appendChild(tr);
    });
}

function getFilteredExpenseHistory(){
    const base=userScope==='ALL'?expenseHistoryData:expenseHistoryData.filter(ex=>ex.group===userScope);
    setHistorySelectOptions('expenseHistoryGroupFilter',base.map(ex=>ex.group),'전체 지역');
    setHistorySelectOptions('expenseHistoryUserFilter',base.map(ex=>ex.user),'전체 사용자');
    setHistorySelectOptions('expenseHistoryDeptFilter',base.map(ex=>ex.dept),'전체 부서');
    setHistorySelectOptions('expenseHistoryCompanyFilter',base.map(ex=>ex.cardCompany||cardsData.find(card=>card.num===ex.cardNum)?.company),'전체 카드사');
    setHistorySelectOptions('expenseHistoryCardFilter',base.map(ex=>ex.cardNum),'전체 카드');
    setHistoryDateOptions('expenseHistoryYearFilter','expenseHistoryMonthFilter',historyYearMonthOptions(base,ex=>ex.date));
    setHistorySelectOptions('expenseHistoryCategoryFilter',base.map(ex=>ex.category),'전체 구분');
    const query=(document.getElementById('expenseHistorySearch')?.value||'').trim().toLocaleLowerCase();
    const group=document.getElementById('expenseHistoryGroupFilter')?.value||'',user=document.getElementById('expenseHistoryUserFilter')?.value||'',dept=document.getElementById('expenseHistoryDeptFilter')?.value||'';
    const company=document.getElementById('expenseHistoryCompanyFilter')?.value||'',cardNum=document.getElementById('expenseHistoryCardFilter')?.value||'';
    const year=document.getElementById('expenseHistoryYearFilter')?.value||'',month=document.getElementById('expenseHistoryMonthFilter')?.value||'';
    const category=document.getElementById('expenseHistoryCategoryFilter')?.value||'',status=document.getElementById('expenseHistoryStatusFilter')?.value||'';
    const from=document.getElementById('expenseHistoryFromFilter')?.value||'',to=document.getElementById('expenseHistoryToFilter')?.value||'';
    return ledgerNewFirst('expense',filterLedgerColumns('expense',base.filter(ex=>{
        const date=String(ex.date||'').slice(0,10),rowCompany=ex.cardCompany||cardsData.find(card=>card.num===ex.cardNum)?.company||'';const haystack=[ex.id,ex.date,ex.requestedAt,ex.group,ex.cardNum,rowCompany,ex.user,ex.dept,ex.category,ex.merchant,ex.purpose,ex.attendees,ex.note,ex.applicantName,ex.entrySource,ex.sourceRef?.documentNo,ex.status,ex.approvedBy,ex.rejectedBy,ex.approvedAt,ex.rejectedAt].map(value=>String(value??'').toLocaleLowerCase()).join(' ');
        return (!query||haystack.includes(query))&&(!group||ex.group===group)&&(!user||String(ex.user||'')===user)&&(!dept||String(ex.dept||'')===dept)&&(!company||rowCompany===company)&&(!cardNum||ex.cardNum===cardNum)&&(!year||date.slice(0,4)===year)&&(!month||date.slice(5,7)===month)&&(!category||ex.category===category)&&(!status||ex.status===status)&&(!from||date>=from)&&(!to||date<=to);
    })));
}
function resetExpenseHistoryFilters(){clearLedgerFilters('expense');['expenseHistorySearch','expenseHistoryGroupFilter','expenseHistoryUserFilter','expenseHistoryDeptFilter','expenseHistoryCompanyFilter','expenseHistoryCardFilter','expenseHistoryYearFilter','expenseHistoryMonthFilter','expenseHistoryCategoryFilter','expenseHistoryStatusFilter','expenseHistoryFromFilter','expenseHistoryToFilter'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});renderExpenseHistory();}
function expenseHistorySerial(ex){return ledgerSerial(ex,'expense');}
function expenseAmountLabel(ex){return ex.amount==null?'금액미기재':Number(ex.amount).toLocaleString()+'원';}
function expenseStatusHTML(ex){
    const style=ex.status==='승인취소'?'cancelled':ex.status==='승인완료'?'approved':ex.status==='반려됨'?'rejected':'pending';
    return '<span class="expense-state '+style+'">'+escapeHtml(ex.status||'-')+'</span>';
}
function expenseDecisionInfo(ex){
    if(ex.historicalImport)return {by:ex.importedBy,at:ex.importedAt,label:'원본 이관 · YBY 결재 없음'};
    if(ex.status==='승인취소')return {by:ex.cancelledBy,at:ex.cancelledAt,label:'승인취소'};
    if(ex.status==='반려됨')return {by:ex.rejectedBy,at:ex.rejectedAt,label:'반려'};
    if(ex.status==='승인완료')return {by:ex.approvedBy,at:ex.approvedAt,label:'승인'};
    return {by:'-',at:null,label:ex.status==='재보고대기'?'재보고 대기':'결재 대기'};
}
function expenseSummaryMetricsHTML(summary) {
    const amount=summary.invalidAmounts?'확인 필요':summary.amount.toLocaleString()+'원';
    const metrics=[['조회 이력',summary.documents.toLocaleString()+'건','documents'],['유효 승인·이관 정산',summary.approvedDocuments.toLocaleString()+'건','approvedDocuments'],['승인·이관 사용 횟수',summary.usageCount.toLocaleString()+'회','usageCount'],['승인·이관 사용금액',amount,'amount'],['반려 이력',summary.rejected.toLocaleString()+'건','rejected'],['승인취소 이력',summary.cancelled.toLocaleString()+'건','cancelled']];
    return '<div class="ledger-metrics">'+metrics.map(([label,value,id])=>`<div class="ledger-metric" data-metric="${id}"><small>${label}</small><strong>${escapeHtml(value)}</strong></div>`).join('')+'</div>';
}
function expenseSummaryCategoriesHTML(summary) {
    const rows=summary.categories.map(cat=>`<tr><td>${escapeHtml(cat.name)}</td><td class="num-right">${escapeHtml(cat.documents.toLocaleString())}건</td><td class="num-right">${escapeHtml(cat.count.toLocaleString())}회</td><td class="num-right">${summary.invalidAmounts?'확인 필요':escapeHtml(cat.amount.toLocaleString())+'원'}</td></tr>`).join('');
    return '<div class="ledger-category-wrap"><table><thead><tr><th>정산 구분</th><th>승인·이관 문서</th><th>사용 횟수</th><th>승인·이관 사용금액</th></tr></thead><tbody>'+ (rows || '<tr><td colspan="4" class="ledger-empty">조회 조건에 해당하는 유효 승인·이관 내역이 없습니다.</td></tr>')+'</tbody></table></div>';
}
function expenseSummaryNoteHTML(summary) {
    return '<p class="ledger-help">사용 횟수는 조회된 유효 승인 문서와 금액 확인된 이관 문서의 건별 명세 수입니다. 명세가 없는 이전 자료는 문서 1건을 1회로 계산합니다. 반려·승인취소·교체된 원본·이전 차감 정정은 승인·이관 사용금액에서 제외합니다. 복수 구분 문서는 구분별 문서 수에 중복 포함될 수 있습니다. 조회 조건은 문서 기준이며, 해당 문서의 전체 명세를 집계합니다.</p>'+(summary.invalidAmounts?'<p role="alert" class="ledger-help">금액 형식 또는 문서·명세 합계가 일치하지 않는 자료가 있어 금액 합계를 표시하지 않았습니다. 상세내역을 확인하세요.</p>':'');
}
function renderExpenseSummary(rows) {
    const target=document.getElementById('expenseHistorySummary');if(!target)return;
    const summary=YbyLedger.summary(rows,userScope);
    target.innerHTML='<h3>현재 조회 결과 요약</h3>'+expenseSummaryMetricsHTML(summary)+expenseSummaryCategoriesHTML(summary)+expenseSummaryNoteHTML(summary);
}
function expenseSummaryFilterLabels() {
    const fields=[['expenseHistorySearch','검색어'],['expenseHistoryGroupFilter','지점'],['expenseHistoryUserFilter','사용자'],['expenseHistoryDeptFilter','부서'],['expenseHistoryCompanyFilter','카드사'],['expenseHistoryCardFilter','카드'],['expenseHistoryYearFilter','사용 연도'],['expenseHistoryMonthFilter','사용 월'],['expenseHistoryCategoryFilter','정산 구분'],['expenseHistoryStatusFilter','결재 상태'],['expenseHistoryFromFilter','시작일'],['expenseHistoryToFilter','종료일']];
    const active=fields.flatMap(([id,label])=>{const el=document.getElementById(id);if(!el?.value)return [];return [[label,el.tagName==='SELECT'?el.selectedOptions[0].textContent:el.value]];});
    active.push(...ledgerActiveFilterLabels('expense'));return active.length?active:[['조회 조건','전체 이력']];
}
function showExpenseSummaryReport() {
    if(!hasViewPermission('v_expense_history')){alert('사용정산 이력 조회 권한이 없습니다.');return;}
    const rows=JSON.parse(JSON.stringify(getFilteredExpenseHistory())),summary=YbyLedger.summary(rows,userScope),at=localDateTime(true);
    const condition=expenseSummaryFilterLabels().map(([label,value])=>`<div><b>${escapeHtml(label)}</b> · ${escapeHtml(value)}</div>`).join('');
    const statuses=summary.statuses.map(item=>`<tr><td>${escapeHtml(item.name)}</td><td class="num-right">${escapeHtml(item.count.toLocaleString())}건</td></tr>`).join('');
    const details=rows.map(ex=>`<tr${ex.status==='승인취소'?' class="expense-cancelled"':''}><td>${escapeHtml(ex.date||'-')}</td><td>${escapeHtml(ex.group||'-')}<br>${escapeHtml(ex.cardNum||'-')}</td><td>${escapeHtml(ex.user||'-')}<br>${escapeHtml(ex.dept||'-')}</td><td>${escapeHtml(ex.category||'-')}<br>${escapeHtml(ex.merchant||'-')}</td><td>${escapeHtml(ex.purpose||'-')}</td><td class="num-right">${expenseAmountLabel(ex)}</td><td>${expenseStatusHTML(ex)}<br><small>${YbyLedger.effectiveApproved(ex)?'유효 사용 합계 포함':'유효 사용 합계 제외'}</small></td></tr>`).join('');
    document.getElementById('modalTitle').textContent='사용정산 조회 요약 보고서';
    document.getElementById('modalBody').innerHTML=`<article id="expenseDetailPrintArea" class="ledger-report"><header class="report-header-box"><h2>법인카드 사용정산 조회 보고서</h2><p>조회 범위: ${escapeHtml(userScope==='ALL'?'전체 지점':userScope+' 지점')} · 작성자: ${escapeHtml(currentUser)}<br>기준 시각: ${escapeHtml(at)} · 현재 조회 결과 ${escapeHtml(rows.length)}건</p></header><div class="report-filter-list">${condition}</div><h3>1. 조회 지표</h3>${expenseSummaryMetricsHTML(summary)}${expenseSummaryNoteHTML(summary)}<h3>2. 정산 구분별 사용 현황</h3>${expenseSummaryCategoriesHTML(summary)}<h3>3. 결재 상태별 이력 건수</h3><table><thead><tr><th>결재 상태</th><th>이력 건수</th></tr></thead><tbody>${statuses||'<tr><td colspan="2" class="ledger-empty">조회 결과가 없습니다.</td></tr>'}</tbody></table><h3>4. 조회 이력 상세</h3><table><thead><tr><th>사용일</th><th>지점 · 카드</th><th>사용자 · 부서</th><th>구분 · 사용처</th><th>사용 목적</th><th>문서 금액</th><th>결재 상태</th></tr></thead><tbody>${details||'<tr><td colspan="7" class="ledger-empty">조회 결과가 없습니다.</td></tr>'}</tbody></table><p class="ledger-help">보고서 열기 시점의 조회 결과를 보관한 화면입니다. 승인·취소 등 상태가 변경되면 닫은 후 다시 열어 최신 결과를 확인하세요. 상세 문서 금액은 이력 보존용으로 표시하며, 총 사용금액은 유효 승인 지표를 사용하세요.</p></article>`;
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button><button class="btn-primary" id="expenseSummaryPrintButton" onclick="printExpenseDetailReport(\'사용정산_조회보고서\')">보고서 인쇄 / PDF 저장</button>';
    document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}
function renderExpenseHistory() {
    const tbody=document.getElementById('expenseHistoryTable');if(!tbody)return;tbody.innerHTML='';
    const allRows=userScope==='ALL'?expenseHistoryData:expenseHistoryData.filter(ex=>ex.group===userScope),rows=getFilteredExpenseHistory();
    const count=document.getElementById('expenseHistoryResultCount');if(count)count.textContent=`검색 결과 ${rows.length.toLocaleString()}건 / 전체 ${allRows.length.toLocaleString()}건`;
    renderLedgerScope('expense');renderExpenseSummary(rows);
    rows.forEach(ex=>{
        const decision=expenseDecisionInfo(ex),tr=document.createElement('tr');tr.dataset.status=ex.status||'';
        if(ex.status==='승인취소')tr.classList.add('expense-cancelled');
        tr.innerHTML=`<td>${expenseHistorySerial(ex)}</td><td><span class="intake-source">${escapeHtml(intakeSourceLabel(ex))}</span></td><td>${escapeHtml(ex.group||'-')}</td><td>${escapeHtml(ex.cardNum||'-')}</td><td>${escapeHtml(ex.user||'-')}</td><td>${escapeHtml(ex.dept||'-')}</td><td>${escapeHtml(ledgerCreatedLabel(ex))}</td><td>${escapeHtml(ex.date||'-')}</td>
            <td>${escapeHtml(ex.category||'-')}<br><small>${escapeHtml(ex.merchant||'-')}</small></td>
            <td class="history-purpose">${escapeHtml(ex.purpose||'-')}${ex.attendees?`<br><small>참석: ${escapeHtml(ex.attendees)}</small>`:''}${ex.note&&!ex.historicalImport?`<br><small>비고: ${escapeHtml(ex.note)}</small>`:''}</td>
            <td class="num-right">${expenseAmountLabel(ex)}</td><td>${ledgerUsed(ex)}</td><td>${escapeHtml(ledgerReturnDate(ex)||'-')}</td><td>${expenseAttachmentLinks(ex)}</td>
            <td class="history-dates history-requested">${escapeHtml(ex.historicalImport?ex.applicationDate:formatServerTime(ex.requestedAt))}<small>${ex.reapproval?'재보고자':'신청자'}: ${escapeHtml(ex.historicalImport?ex.applicantName:(ex.resubmittedBy||ex.requester||'-'))}</small></td>
            <td class="history-dates history-decided">${escapeHtml(formatServerTime(decision.at))}<small>${escapeHtml(decision.label)} · ${escapeHtml(decision.by||'-')}</small>${ex.status==='승인취소'&&ex.approvedAt?`<small>원 승인: ${escapeHtml(formatServerTime(ex.approvedAt))}</small>`:''}</td>
            <td class="history-actions">${expenseStatusHTML(ex)}${ex.manualProgress?'<small>'+escapeHtml(ex.manualProgress)+' · 수기정정</small>':''}<div style="margin-top:8px"></div></td>`;
        const actions=tr.lastElementChild;
        const detail=document.createElement('button');detail.type='button';detail.className='btn-primary';detail.textContent='상세 보기';detail.onclick=()=>showExpenseHistoryDetail(ex);actions.appendChild(detail);
        if(ex.historicalImport&&canCorrectImported())actions.append(fleetButton('수기 정정',()=>openImportedCorrection(ex)));
        if(userScope==='ALL'&&ex.status==='승인완료'&&!ex.isCorrection&&!ex.correctionId&&!ex.resubmissionId){const button=document.createElement('button');button.className='btn-warning';button.textContent='승인 취소·정정';button.onclick=()=>openCorrection(ex);actions.appendChild(button);}
        if(ex.status==='반려됨'&&!ex.resubmissionId&&!ex.isCorrection&&(userScope==='ALL'||ex.requester===currentUser)){const button=document.createElement('button');button.className='btn-warning';button.textContent='수정 후 재보고';button.onclick=()=>reopenRejectedExpense(ex);actions.appendChild(button);}
        tbody.appendChild(tr);
    });
    renderLedgerTools('expense',rows);
}



const expenseHistoryExportHeaders=['일련번호','입력경로','작성기준일','사용일','신청일시','소속','카드사','카드번호','사용자','부서','정산 구분','사용처','사용 목적','참석자','비고','금액(원)','결재 상태','신청자','결재자','결재일시','증빙파일','상세내역','수량','단가(원)','정산 문서번호','사용신청일','신청자명','정산 출처','외부 정산 문서','사용 여부','반납일','반납·정산 진행상태'];
function expenseHistoryExportRows(){return getFilteredExpenseHistory().flatMap(ex=>{
    const items=Array.isArray(ex.lineItems)&&ex.lineItems.length?ex.lineItems:[{date:ex.date,category:ex.category,merchant:ex.merchant,description:ex.purpose,quantity:ex.historicalImport?null:1,unitPrice:ex.historicalImport||ex.amount==null?null:Math.abs(Number(ex.amount)||0),amount:ex.amount==null?null:Math.abs(Number(ex.amount)||0),note:ex.note}];
    return items.map(item=>[expenseHistorySerial(ex),intakeSourceLabel(ex),ledgerCreatedLabel(ex),item.date,ex.requestedAt,ex.group,ex.cardCompany||cardsData.find(c=>c.num===ex.cardNum)?.company||'',ex.cardNum,ex.user,ex.dept,item.category,item.merchant,ex.purpose,ex.attendees,item.note||ex.note,item.amount==null?'':(ex.isCorrection?-1:1)*Number(item.amount),ex.status,ex.historicalImport?ex.applicantName:ex.requester,ex.status==='승인취소'?ex.cancelledBy:(ex.approvedBy||ex.rejectedBy||''),ex.status==='승인취소'?ex.cancelledAt:(ex.approvedAt||ex.rejectedAt||''),(ex.attachments||[]).map(f=>f.name).filter(Boolean).join(', '),item.description,item.quantity,item.unitPrice,ex.id,ex.applicationDate||'',ex.applicantName||ex.externalApplicantName||'',intakeSourceLabel(ex),ex.sourceRef?.documentNo||'',ledgerUsed(ex),ledgerReturnDate(ex),ex.manualProgress||'']);
});}
function exportExpenseHistoryExcel(){downloadExcelReport(`사용정산이력_${userScope}.xls`,'사용정산이력',expenseHistoryExportHeaders,expenseHistoryExportRows());}
function printExpenseHistoryReport(){openHistoryPrintReport('법인카드 사용정산 이력 보고서',expenseHistoryExportHeaders,expenseHistoryExportRows());}

function showExpenseHistoryDetail(ex) {
    if(!ex)return;if(ex.historicalImport){showHistoricalLedgerDetail(ex);return;}
    const val=value=>escapeHtml(value===undefined||value===null||String(value).trim()===''?'-':String(value));
    const attachments=Array.isArray(ex.attachments)?ex.attachments:[],decision=expenseDecisionInfo(ex),cancelled=ex.status==='승인취소';
    const decisionDate=cancelled?ex.approvedAt:decision.at,decisionBy=cancelled?ex.approvedBy:decision.by;
    document.getElementById('modalTitle').innerText='사용정산 상세 보고서';
    document.getElementById('modalBody').innerHTML=`
        <article id="expenseDetailPrintArea" class="expense-detail" data-status="${val(ex.status)}" style="width:100%;max-width:760px;margin:0 auto;background:#fff;color:#0f172a;padding:16px;">
            <header class="report-header-box"><h2>법인카드 사용 정산 보고서</h2><p>문서번호 ${val(ex.id)}</p></header>
            <div class="expense-status-summary ${cancelled?'cancelled':''}" style="display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;padding:13px 16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
                <div><small>정산 금액</small><div style="font-size:24px;font-weight:700">${expenseAmountLabel(ex)}</div></div>${expenseStatusHTML(ex)}
            </div>
            <section aria-label="신청 및 결재 일시" class="expense-date-grid">
                <div data-date="requested"><small>${ex.status==='재보고대기'?'재보고 대기 생성 일시':ex.reapproval?'재보고 신청 일시':'신청 일시'}</small><strong>${val(formatServerTime(ex.requestedAt))}</strong><span>${ex.resubmittedBy?'재보고자':'신청자'}: ${val(ex.resubmittedBy||ex.requester)}</span></div>
                <div data-date="decided"><small>${cancelled?'원 승인 일시':ex.status==='반려됨'?'반려 일시':'결재 일시'}</small><strong>${val(formatServerTime(decisionDate))}</strong><span>${decisionDate?'처리자: '+val(decisionBy):val(decision.label)}${!cancelled&&(ex.selfDecision||ex.selfApproved)?' (최고관리자 본인 결재)':''}</span></div>
                ${cancelled?`<div data-date="cancelled" class="cancelled-date" style="grid-column:1 / -1"><small>승인취소 일시 · 처리자</small><strong>${val(formatServerTime(ex.cancelledAt))}</strong><span>${val(ex.cancelledBy)} · ${val(ex.cancelReason)}</span></div>`:''}
            </section>
            <section style="margin-bottom:18px"><h3 class="settlement-section-title">1. 신청 및 카드 정보</h3><table><tbody>
                <tr><th>소속 지점</th><td>${val(ex.group)}</td><th>부서</th><td>${val(ex.dept)}</td></tr>
                <tr><th>카드번호</th><td>${val(ex.cardNum)}</td><th>실제 사용자</th><td>${val(ex.user)}</td></tr><tr><th>사용신청일</th><td>${val(ex.applicationDate)}</td><th>사용 신청자</th><td>${val(ex.applicantName)}</td></tr><tr><th>정산 자료 출처</th><td>${val(intakeSourceLabel(ex))}${ex.sourceAdjusted?' · YBY에서 보완':''}</td><th>외부 정산 문서</th><td>${val(ex.sourceRef?.documentNo)}</td></tr><tr><th>외부 정산 기안자</th><td>${val(ex.externalApplicantName)}</td><th>외부 결재(연결 시점)</th><td>${val(ex.sourceRef?.approvalStatus)}</td></tr>
            </tbody></table></section>
            <section style="margin-bottom:18px"><h3 class="settlement-section-title">2. 사용 및 지출 내역</h3><table><tbody>
                <tr><th>사용일자</th><td>${val(ex.date)}</td><th>정산 구분</th><td>${val(ex.category)}</td></tr>
                <tr><th>사용처</th><td colspan="3">${val(ex.merchant)}</td></tr>
                <tr><th>사용 목적</th><td colspan="3" style="white-space:pre-wrap">${val(ex.purpose)}</td></tr>
                <tr><th>참석자</th><td colspan="3">${val(ex.attendees)}</td></tr>
                <tr><th>비고</th><td colspan="3" style="white-space:pre-wrap">${val(ex.note)}</td></tr>
            </tbody></table></section>
            <section style="margin-bottom:18px"><h3 class="settlement-section-title">3. 건별 세부 명세</h3>${expenseLineTable(ex)}</section>
            <section style="margin-bottom:18px"><h3 class="settlement-section-title">4. 증빙 자료</h3><div>${attachments.length?attachments.map(file=>file&&file.id?`<div style="padding:5px 0;overflow-wrap:anywhere">${val(file.name)} <a class="no-print" target="_blank" rel="noopener" href="/api/attachments/${escapeHtml(encodeURIComponent(file.id))}">파일 열기 / 저장</a></div>`:'').join(''):'첨부파일 없음'}</div></section>
            <section><h3 class="settlement-section-title">5. 재보고·결재 메시지 및 처리 이력</h3>${workflowMessagesHTML(ex)}</section>
            <footer style="margin-top:24px;padding-top:10px;border-top:1px solid #cbd5e1;text-align:right;font-size:11px;color:#64748b">출력 일시: ${escapeHtml(localDateTime(true))}</footer>
        </article>`;
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button><button class="btn-primary no-print" onclick="printExpenseDetailReport()">보고서 인쇄 / PDF 저장</button>';
    if(ex.returnSource&&hasViewPermission('v_report_write')&&hasViewPermission('v_card_rent')){const button=document.createElement('button');button.type='button';button.className='btn-secondary';button.textContent='관련 보고서 초안 작성';button.onclick=()=>{closeModal();openReturnReportDraft({id:ex.id,group:ex.group,requester:ex.requester});};document.getElementById('modalFooter').appendChild(button);}
    document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}


function printExpenseDetailReport(reportName='사용정산_상세보고서') {
    const oldTitle=document.title;
    document.title=`${reportName}_${new Date().toISOString().slice(0,10)}`;
    document.body.classList.add('print-expense-detail');
    const cleanup=()=>{document.body.classList.remove('print-expense-detail');document.title=oldTitle;window.removeEventListener('afterprint',cleanup);};
    window.addEventListener('afterprint',cleanup,{once:true});
    requestAnimationFrame(()=>{window.print();setTimeout(cleanup,2000);});
}

async function approveExpense(id,group,requester){try{await selfDecision('/api/expenses/decision',{id,group,requester,decision:'approve'},expenseData.find(x=>String(x.id)===String(id)&&x.group===group&&x.requester===requester),'정산 승인');}catch(error){alert(error.message);}}
async function rejectExpense(id,group,requester){const reason=prompt('반려 사유:');if(reason===null)return;try{await businessOperation('/api/expenses/decision',{id,group,requester,decision:'reject',reason});}catch(error){alert(error.message);}}

function renderComplaintTable() {
    let tbody = document.getElementById("complaintTableBody");
    if(!tbody) return;
    tbody.innerHTML = "";
    (userScope === "ALL" ? complaintData : complaintData.filter(c => c.group === userScope)).forEach(c => {
        let tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${escapeHtml(c.id)}</td><td><span class="card-tag tag-본사">${escapeHtml(c.category)}</span></td><td><span class="card-tag tag-${escapeHtml(c.group)}">${escapeHtml(c.group)}</span></td>
            <td style="text-align:left;"><b>${escapeHtml(c.title)}</b></td><td>${escapeHtml(c.author)}</td><td>${escapeHtml(c.date)}</td>
            <td><span class="badge ${escapeHtml(c.status === '처리완료' ? 'badge-approved' : 'badge-processing')}">${escapeHtml(c.status)}</span></td>
            <td><button class="btn-primary" style="padding:3px 8px;" onclick="viewComplaint(${escapeHtml(Number(c.id))})">상세보기</button></td>
        `;
        tbody.appendChild(tr);
    });
}

async function handleComplaintSubmit(e) {
    e.preventDefault();
    let category = document.getElementById("compCategory").value;
    let group = userScope === "ALL" ? document.getElementById("compGroup").value : userScope;
    let author = currentUser;
    let phone = document.getElementById("compPhone").value;
    let title = document.getElementById("compTitle").value;
    let content = document.getElementById("compContent").value;
    let nowStr = localDateTime();

    complaintData.push({ id: nextNumericId(complaintData), category, group, author, phone, title, content, date: nowStr, status: "접수대기", file: null });
    await saveData(); alert("민원이 정상 접수되었습니다."); e.target.reset(); initApp();
}

function viewComplaint(id) {
    let c = complaintData.find(item => item.id === id);
    if(!c) return;
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = `민원 상세 내용 [#${c.id}]`;
    modalBody.innerHTML = `
        <div><b>제목:</b> ${escapeHtml(c.title)}</div>
        <div><b>유형 / 소속:</b> ${escapeHtml(c.category)} / ${escapeHtml(c.group)} 지점</div>
        <div><b>작성자 / 연락처:</b> ${escapeHtml(c.author)} (${escapeHtml(c.phone)})</div>
        <div><b>접수시점:</b> ${escapeHtml(c.date)} | 상태: <span class="badge badge-processing">${escapeHtml(c.status)}</span></div>
        <hr style="border:0; border-top:1px solid #e2e8f0; margin:4px 0;">
        <div style="background:#f8fafc; padding:12px; border-radius:6px; min-height:80px; white-space:pre-wrap;">${escapeHtml(c.content)}</div>
    `;
    let footerHtml = `<button class="btn-secondary" onclick="closeModal()">닫기</button>`;
    if(userScope === 'ALL' || c.group === userScope) {
        footerHtml = `<button class="btn-success" onclick="updateComplaintStatus(${escapeHtml(Number(c.id))}, '처리완료')">처리완료로 변경</button>` + footerHtml;
    }
    modalFooter.innerHTML = footerHtml;
    document.getElementById("commonModal").style.display = "flex";
}

async function updateComplaintStatus(id, status) {
    let c = complaintData.find(item => item.id === id);
    if(c) { c.status = status; await saveData(); closeModal(); initApp(); alert("상태가 변경되었습니다."); }
}

async function handleReportSubmit(e){e.preventDefault();
    const payload={...reportCopyPayload(),group:userScope==='ALL'?(document.getElementById('repGroup')?.value||'본사'):userScope,type:document.getElementById('repType').value,title:document.getElementById('repTitle').value,content:document.getElementById('repContent').value,reviewer:document.getElementById('approver1').value,approver:document.getElementById('approver2').value};
    try{await businessOperation('/api/documents/submit',payload);alert('기안이 서버에 저장되었습니다.');e.target.reset();clearReportCopyReference();updateApprovalChoices(true);switchView('v_report_box',document.getElementById('nav_v_report_box'));}catch(error){alert(error.message);}
}
function renderReportList() {
    let tbody = document.getElementById("reportTable");
    let filter = document.getElementById("reportFilter").value;
    if(!tbody) return;
    tbody.innerHTML = "";
    let list = reportList;
    if(filter !== 'all') { list = list.filter(r => r.status === filter); }

    list.forEach(r => {
        let badgeClass = r.status === 'pending' ? 'badge-pending' : (r.status === 'approved' ? 'badge-approved' : 'badge-issue');
        let statusText = {pending_review:'1차 검토대기',pending:'최종 결재대기',approved:'승인완료',rejected:'반려됨'}[r.status]||r.status;
        let tr = document.createElement("tr");
        tr.innerHTML = `
            <td><b>${escapeHtml(r.id)}</b></td><td>${escapeHtml(formatServerTime(r.date))}</td><td><span class="card-tag tag-본사">${escapeHtml(r.type)}</span></td>
            <td style="text-align:left;"><b>${escapeHtml(r.title)}</b></td><td>${escapeHtml(r.author)}</td><td>${escapeHtml(r.line)}</td>
            <td><span class="badge ${escapeHtml(badgeClass)}">${escapeHtml(statusText)}</span></td>
            <td>
                <button class="btn-primary" style="padding:3px 6px;" onclick="viewReportDetail(${jsArg(r.id)})">보기</button>
                ${((r.status==='pending_review'&&r.reviewer===currentUser)||(r.status==='pending'&&(r.approver===currentUser||(!r.approver&&userScope==='ALL'))))?`<button class="btn-success" onclick="approveReport(${jsArg(r.id)})">${r.status==='pending_review'?'검토 완료':'최종 승인'}</button><button class="btn-danger" onclick="rejectReport(${jsArg(r.id)})">반려</button>`:''}
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function viewReportDetail(id) {
    let r = reportList.find(item => item.id === id);
    if(!r) return;
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = `내부 보고서 기안서 [${r.id}]`;
    modalBody.innerHTML = `
        <div><b>제목:</b> ${escapeHtml(r.title)}</div>
        <div><b>유형 / 기안자:</b> ${escapeHtml(r.type)} / ${escapeHtml(r.author)} (${escapeHtml(formatServerTime(r.date))})</div>
        <div><b>결재라인:</b> ${escapeHtml(r.line)}</div>
        <div><b>결재 이력:</b><ol class="report-decisions">${(r.decisions||[]).map(d=>'<li>'+escapeHtml(d.stage==='pending_review'?'1차 검토':'최종 결재')+' · '+escapeHtml(d.actor)+' · '+escapeHtml(d.decision==='approve'?'승인':'반려')+' · '+escapeHtml(formatServerTime(d.time))+(d.selfDecision?' (본인 처리)':'')+(d.reason?' — '+escapeHtml(d.reason):'')+'</li>').join('')||'<li>처리 이력 없음</li>'}</ol></div>
        ${reportSourceStatusHTML(r)}${r.sourceExpenseRef?'<div><b>복사 원본 정산:</b> '+escapeHtml(r.sourceExpenseRef.id)+' · '+escapeHtml(r.sourceExpenseRef.group)+' / '+escapeHtml(r.sourceExpenseRef.requester)+' · 상신 시 정산 상태 '+escapeHtml(r.sourceExpenseStatus||'미기록')+'</div>':''}
        <hr style="border:0; border-top:1px solid #e2e8f0; margin:4px 0;">
        <div style="background:#f8fafc; padding:12px; border-radius:6px; min-height:100px; white-space:pre-wrap;">${escapeHtml(r.content)}</div>
    `;
    modalFooter.innerHTML = `<button class="btn-secondary" onclick="closeModal()">닫기</button>`;
    document.getElementById("commonModal").style.display = "flex";
}

async function approveReport(id){try{await selfDecision('/api/documents/decision',{id,decision:'approve'},reportList.find(x=>x.id===id),'최종 승인');}catch(error){alert(error.message);}}
async function rejectReport(id){const reason=prompt('반려 사유:');if(reason===null)return;try{await businessOperation('/api/documents/decision',{id,decision:'reject',reason});}catch(error){alert(error.message);}}

function showOperations(){switchView('v_backup_ops',document.getElementById('nav_v_backup_ops'));}
async function searchServerAudit(){const q=prompt('계정·업무 종류·카드번호·문서 ID 검색:','');if(q===null)return;try{const r=await fetch('/api/audit/search?q='+encodeURIComponent(q));const v=await r.json();if(!r.ok)throw new Error(v.message);document.getElementById('modalTitle').textContent='서버 업무 감사 기록 (최근 200건)';document.getElementById('modalBody').textContent=JSON.stringify(v.events,null,2);document.getElementById('modalBody').style.whiteSpace='pre-wrap';document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button>';document.getElementById('commonModal').style.display='flex';}catch(e){alert(e.message);}}

let correctionTarget=null;
function workflowMessageSummary(ex){const last=(ex.reviewMessages||[]).at(-1);return last?escapeHtml((last.author||'')+' · '+last.text):ex.reapproval?'재보고 건':'';}
function workflowMessagesHTML(ex){
    const labels={cancel:'승인취소·정정 요청',reopen:'반려 후 재작성',resubmit:'재보고',approve:'승인',reject:'반려'};
    const messages=Array.isArray(ex.reviewMessages)?ex.reviewMessages:[];
    return (ex.replaces?'<p>정정 차수: '+escapeHtml(ex.correctionCycle||1)+' · 원본 정산: '+escapeHtml(ex.replaces.id)+'</p>':'')+(messages.length?'<ol>'+messages.map(item=>'<li class="workflow-event '+(item.type==='cancel'?'workflow-event-cancel':'')+'" style="margin:8px 0"><b>'+escapeHtml(labels[item.type]||item.type)+'</b> · '+escapeHtml(item.author)+' · '+escapeHtml(formatServerTime(item.time))+'<div style="white-space:pre-wrap">'+escapeHtml(item.text)+'</div></li>').join('')+'</ol>':'<p>이전 버전에서 작성된 정산입니다.</p>');
}
function openCorrection(record){correctionTarget=record;document.getElementById('modalTitle').textContent='승인취소 및 정정·재보고 요청';document.getElementById('modalBody').innerHTML='<p>원본은 승인취소 이력으로 보존하고 사용정산 및 결재에 재보고 대기 건을 만듭니다. 마이너스 승인완료 자료는 만들지 않습니다.</p><label>승인취소 사유 / 정정 요청 메시지 (필수)<textarea id="correctionReason" maxlength="1000" required></textarea></label><label>현재 관리자 비밀번호<input type="password" id="correctionPassword" autocomplete="current-password"></label>';document.getElementById('modalFooter').innerHTML='<button class="btn-warning" onclick="confirmCorrection()">승인취소 후 재보고 요청</button><button class="btn-secondary" onclick="closeModal()">취소</button>';document.getElementById('commonModal').style.display='flex';}
async function confirmCorrection(){const secret=document.getElementById('correctionPassword');try{await businessOperation('/api/expenses/correct',{id:correctionTarget.id,group:correctionTarget.group,requester:correctionTarget.requester,reason:document.getElementById('correctionReason').value,password:secret.value});closeModal();switchView('v_expense',document.getElementById('nav_v_expense'));alert('승인을 취소하고 재보고 대기로 옮겼습니다. 정정 작성·재보고에서 내용을 보완한 뒤 결재를 요청하세요.');}catch(e){alert(e.message);}finally{secret.value='';}}
async function reopenRejectedExpense(record){const reason=prompt('반려 건의 수정·재보고 사유:','반려 사유를 보완하여 재보고합니다.');if(reason===null)return;try{const result=await businessOperation('/api/expenses/reopen-rejected',{id:record.id,group:record.group,requester:record.requester,reason});switchView('v_expense',document.getElementById('nav_v_expense'));openResubmission(result.expense);}catch(error){alert(error.message);}}
let resubmissionTarget=null,resubmissionBusy=false,resubmissionUploads=new WeakMap();
function openResubmission(record){
    resubmissionTarget=record;resubmissionBusy=false;resubmissionUploads=new WeakMap();
    document.getElementById('modalTitle').textContent='정산 정정 작성 및 재보고';
    document.getElementById('modalBody').innerHTML=`<div class="settlement-form" data-mode="revision">
        <div class="settlement-context"><div><strong>법인카드 사용 정산서</strong><small>카드 ${escapeHtml(record.cardNum)} · ${escapeHtml(record.group)} · 최초 신청자 ${escapeHtml(record.requester)}</small></div><span class="settlement-stage">정정 · 재보고</span></div>
        <section class="settlement-section settlement-workflow"><h3 class="settlement-section-title">정정 요청 사항</h3><p class="settlement-help">요청 내용을 확인하고 아래의 동일한 정산 양식에서 보완하세요.</p><p style="white-space:pre-wrap;overflow-wrap:anywhere">${escapeHtml(record.correctionReason||record.cancelReason||'이전 처리 메시지를 확인하세요.')}</p><details><summary>이전 처리 메시지 보기</summary>${workflowMessagesHTML(record)}</details></section>
        ${settlementFormHTML(record,true)}</div>`;
    const lines=record.lineItems?.length?record.lineItems:[{date:record.date,category:record.category,merchant:record.merchant,description:record.purpose,quantity:1,unitPrice:record.amount,note:record.note}];
    initializeSettlementForm({...record,lineItems:lines});
    const files=document.getElementById('resubmissionKeepFiles');
    for(const file of record.attachments||[]){const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.checked=true;input.dataset.keepAttachment=file.id;label.append(input,document.createTextNode(' 기존 증빙 유지: '+file.name));files.appendChild(label);}
    document.getElementById('resubmissionMessage').value='정정 요청 사항을 보완하여 재보고합니다.';
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button><button class="btn-primary" id="resubmitExpenseButton" onclick="confirmResubmission()">재보고하여 결재 요청</button>';
    document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}


async function confirmResubmission(){
    if(resubmissionBusy)return;const button=document.getElementById('resubmitExpenseButton');
    try{
        const lineItems=collectSettlementLines(),purpose=document.getElementById('returnExpensePurpose').value.trim(),user=document.getElementById('returnExpenseUser').value.trim(),message=document.getElementById('resubmissionMessage').value.trim();
        if(!purpose||!user||!message)throw new Error('사용자·사용 목적·재보고 메시지를 입력하세요.');
        const keep=new Set(Array.from(document.querySelectorAll('[data-keep-attachment]:checked')).map(input=>input.dataset.keepAttachment));
        const attachments=(resubmissionTarget.attachments||[]).filter(file=>keep.has(file.id));const newFiles=Array.from(document.getElementById('resubmissionFiles').files||[]);
        if(attachments.length+newFiles.length>5||newFiles.some(file=>file.size>20*1024*1024))throw new Error('첨부는 최대 5개, 파일당 20MB입니다.');
        resubmissionBusy=true;button.disabled=true;
        for(const file of newFiles){if(!resubmissionUploads.has(file))resubmissionUploads.set(file,await uploadSettlementAttachment(file,resubmissionTarget.group));attachments.push(resubmissionUploads.get(file));}
        const expense={lineItems,amount:lineItems.reduce((sum,line)=>sum+line.amount,0),date:lineItems[0].date,user,dept:document.getElementById('returnExpenseDept').value.trim(),purpose,attendees:document.getElementById('returnExpenseAttendees').value.trim(),note:document.getElementById('returnExpenseNote').value.trim(),attachments};
        await businessOperation('/api/expenses/resubmit',{id:resubmissionTarget.id,group:resubmissionTarget.group,requester:resubmissionTarget.requester,expense,message});closeModal();alert('재보고가 저장되었습니다. 승인 또는 반려 결재를 기다립니다.');
    }catch(error){alert(error.message);}finally{resubmissionBusy=false;if(button)button.disabled=false;}
}

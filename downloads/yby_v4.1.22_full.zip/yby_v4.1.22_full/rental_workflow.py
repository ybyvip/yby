"""Drafts are not reservations. Confirmation joins the existing atomic issue operation."""
import copy, uuid
import domain, external_documents
MANAGEMENT=('정상','분실','파손','장기사용','교체','사용중지')
def usable(card):return not card.get('archived') and card.get('managementStatus','정상')=='정상'
def finance(data):
    account=external_documents.short(data.get('withdrawalAccount',''),'인출 계좌정보')
    amount=data.get('limitAmount')
    if amount in ('',None):amount=None
    elif type(amount)!=int or not 0<=amount<=10**12:raise ValueError('한도금액은 0~1조 원의 정수입니다.')
    return dict(withdrawalAccount=account,limitAmount=amount)
def draft(a,conn,state,data,user,scope,path,attachments):
    a.require_permission(user,'v_card_rent')
    rows=state.setdefault('rentalDrafts',[])
    row=next((x for x in rows if x['id']==data.get('draftId')),None)
    if data.get('draftId'):
        if not row:raise ValueError('불출예정을 찾을 수 없습니다.')
        if scope not in ('ALL',row['group']):raise PermissionError('다른 지점 불출예정입니다.')
        if row['status']!='대기':raise a.StateConflict('이미 처리된 불출예정입니다.')
        if row['version']!=data.get('expectedVersion'):raise a.StateConflict('불출예정이 변경되었습니다.')
    if path.endswith('/draft-delete'):
        if not row:raise ValueError('불출예정이 필요합니다.')
        row.update(status='삭제',version=uuid.uuid4().hex,updatedAt=a.now(),updatedBy=user)
        return {'draft':row}
    card=next((x for x in state.get('cards',[]) if str(x['id'])==str(data.get('cardId'))),None)
    if not card:raise ValueError('카드가 없습니다.')
    if scope not in ('ALL',card['group']):raise PermissionError('다른 지점 카드입니다.')
    if row and row['group']!=card['group']:raise ValueError('불출예정의 지점은 바꿀 수 없습니다.')
    if not usable(card):raise ValueError('사고·교체·사용중지 또는 삭제된 카드는 불출할 수 없습니다.')
    values={k:external_documents.short(data.get(k,''),k,True) for k in ('dept','user','purpose','applicantName')}
    for k in ('applicationDate','dueDate'):
        domain.date_value(data.get(k),k,True);values[k]=data[k]
    if values['dueDate']<max(values['applicationDate'],a.business_date()):raise ValueError('반납예정일을 확인하세요.')
    if row is None:
        row=dict(id=uuid.uuid4().hex,group=card['group'],createdAt=a.now(),createdBy=user,status='대기',changes=[]);rows.append(row)
    else:row.setdefault('changes',[]).append({k:copy.deepcopy(v) for k,v in row.items() if k!='changes'})
    values.update({k:copy.deepcopy(data[k]) for k in ('externalDocumentId','externalRevision','externalConfirmed','externalMatchVersion') if k in data})
    for k in ('externalDocumentId','externalRevision','externalConfirmed','externalMatchVersion'):row.pop(k,None)
    row.update(values,cardId=card['id'],cardNum=card['num'],attachments=attachments(a,data.get('attachments',[]),user,card['group'],row.get('attachments',[])),version=uuid.uuid4().hex,updatedAt=a.now(),updatedBy=user)
    return {'draft':row}
def manage(a,state,data,user,scope,path):
    a.require_permission(user,'v_card_reg')
    card=next((x for x in state.get('cards',[]) if str(x['id'])==str(data.get('cardId'))),None)
    if card is None:raise ValueError('카드가 없습니다.')
    if scope not in ('ALL',card['group']):raise PermissionError('다른 지점 카드입니다.')
    if data.get('expectedVersion','')!=card.get('managementVersion',''):raise a.StateConflict('카드 관리정보가 변경되었습니다.')
    reason=external_documents.short(data.get('reason',''),'변경 사유',True)
    before=copy.deepcopy({k:v for k,v in card.items() if k not in ('cardKey','managementHistory')})
    if path.endswith('/archive'):
        if card['status']=='rented':raise ValueError('불출중 카드는 반납 후 삭제하세요.')
        card['archived']=True
    else:
        status=data.get('managementStatus','정상')
        if status not in MANAGEMENT:raise ValueError('관리 상태 오류')
        card.update(finance(data),managementStatus=status)
        for k in ('company','num','userType','assignedUser','issueDate','expiryDate','cardAlias','paymentType','usageScope'):
            if k in data:card[k]=external_documents.short(data[k],k,k in ('company','num'))
        if 'group' in data and data['group']!=card['group']:
            if scope!='ALL':raise PermissionError('지점 이동은 최고관리자만 가능합니다.')
            if card['status']=='rented':raise ValueError('불출 중에는 지점을 바꿀 수 없습니다.')
            card['group']=data['group']
    card['managementVersion']=uuid.uuid4().hex
    after=copy.deepcopy({k:v for k,v in card.items() if k not in ('cardKey','managementHistory')})
    card.setdefault('managementHistory',[]).append(dict(time=a.now(),actor=user,reason=reason,before=before,after=after))
    return {'card':card}

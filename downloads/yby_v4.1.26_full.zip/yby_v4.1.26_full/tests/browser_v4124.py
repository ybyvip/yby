"""Synthetic account workflows for ten V4.1.24 requests in actual Chromium."""
import sys,json,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright,expect
import test_v4124 as fixture
import test_v4112 as fleet
fixture.Dashboard124Tests.setUpClass();t=fixture.Dashboard124Tests();t.setUp();a=t.a;c=t.c
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/workspace/v4124-screens'));screens.mkdir(exist_ok=True,parents=True)
try:
 perms=['v_dashboard','v_card_reg','v_card_status','v_card_rent','v_card_history','v_expense_history','v_expense','v_hipass_reg','v_hipass_box','v_stats','v_complaint','v_report_write','v_report_box']
 with a.db() as db:
  db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(perms),));db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_box']),));db.commit();state=a.get_state();state['accounts']=a.account_metadata(db);a.persist_state(db,state,'fixture')
 ft=fleet.FleetTests();ft.a=a;ft.c=c;ft.w=t.t.w;row=ft.register();ft.confirm(row)
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1500,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.route('**/api/login-weather',lambda r:r.fulfill(json={'ready':False}))
  def login(name='branch',password='Branch-test-pass!'):
   page.goto('http://127.0.0.1:'+str(c.server.server_port));page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>!!currentUser&&!loginInFlight');page.evaluate('stopLiveSync()');expect(page.locator('#v_dashboard')).to_be_visible();page.wait_for_function('()=>dashboard24.data!==null')
  def view(name):page.evaluate('(name)=>switchView(name,document.getElementById("nav_"+name))',name)
  def sync():page.evaluate('async()=>{await loadServerState();initApp();stopLiveSync();await refreshDashboard24(true)}')
  login();view('v_card_reg');login();assert page.evaluate('dashboard24.active')=='v_dashboard';assert page.locator('#dashboardActivity24 table th').all_text_contents()==['구분','최근 시각','내용','상태','연결']
  assert t.t.manage()[0]==200;sync();page.locator('#dashTotalCards .dash-abnormal').click();expect(page.locator('#modalTitle')).to_have_text('정상 이외 법인카드 목록');expect(page.locator('#modalBody')).to_contain_text('분실');assert page.locator('#modalBody tbody tr').count()==1;page.locator('#modalFooter button').click();view('v_card_reg');expect(page.locator('#registeredCardSummary24')).to_contain_text('사용가능 0장');expect(page.locator('#registeredCardTable')).to_contain_text('분실 · 신규불출 제한');expect(page.locator('#incidentRegister24')).to_contain_text('정상 → 분실')
  assert t.t.manage(managementStatus='정상')[0]==200;sync();expect(page.locator('#incidentRegister24')).to_contain_text('분실 → 정상');expect(page.locator('#registeredCardSummary24')).to_contain_text('사용가능 1장');page.locator('#incidentRegister24 button').first.click();expect(page.locator('#modalBody')).to_contain_text('시험 제보자');page.locator('#modalFooter button').click();page.screenshot(path=str(screens/'card-history-summary.png'))
  shades={}
  for status in ['분실','파손','교체','사용중지']:
   assert t.t.manage(managementStatus=status)[0]==200;sync();expect(page.locator('#registeredCardTable')).to_contain_text(status+' · 신규불출 제한');shades[status]=page.locator('#registeredCardTable tr').first.locator('td').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')
  assert len(set(shades.values()))==4,shades
  print('PASS repeated-login dashboard landing, activity table, independent abnormal button, retained restored incidents, card summary and four distinct status tints',flush=True)
  view('v_hipass_box');expect(page.locator('#hipassBoxTable')).to_contain_text('HP-001');expect(page.locator('#hipassBoxTable')).to_contain_text('FUEL-001');page.uncheck('#fleetListFuel24');expect(page.locator('#hipassBoxTable')).not_to_contain_text('FUEL-001');page.check('#fleetListFuel24');page.uncheck('#fleetListHipass24');expect(page.locator('#hipassBoxTable')).to_contain_text('FUEL-001');expect(page.locator('#hipassBoxTable')).not_to_contain_text('HP-001');page.uncheck('#fleetListFuel24');expect(page.locator('#hipassBoxTable')).to_contain_text('조회된 자료가 없습니다');page.check('#fleetListHipass24');page.check('#fleetListFuel24');assert page.locator('#hipassBoxTable .fleet-actions button').filter(has_text='수정').count()==1;assert float(page.locator('#hipassBoxTable .fleet-actions button').first.evaluate('(e)=>getComputedStyle(e).fontSize').replace('px',''))<=12
  login('readonly');expect(page.locator('#dashboardMetrics24')).to_be_hidden();view('v_hipass_box');assert page.locator('#hipassBoxTable .fleet-actions button').all_text_contents()==['내용 확인'];assert t.t.w.operation('/api/hipass/update',{**ft.payload(),**ft.ref(a.get_state()['hipass'][0]),'car':'우회수정','changeReason':'시험','password':'Branch-test-pass!'},c.login('readonly','Branch-test-pass!'))[0]==403
  print('PASS hipass/fuel checkboxes, compact actions, readonly UI and direct mutation denial, minimal landing does not show restricted aggregates',flush=True)
  login();view('v_complaint')
  for month,season in [(4,'spring'),(7,'summer'),(10,'autumn'),(1,'winter')]:
   page.evaluate('(m)=>{window.originalLocalDate24=window.originalLocalDate24||localDate;localDate=()=>"2026-"+String(m).padStart(2,"0")+"-01";applySeason24()}',month)
   for panel in ['v_complaint','v_report_write']:
    assert page.locator('#'+panel).get_attribute('data-season')==season;bg=page.locator('#'+panel).evaluate('(e)=>getComputedStyle(e).backgroundImage');assert 'linear-gradient' in bg and 'login-' in bg,bg
   photo=page.locator('#v_complaint').evaluate('(e)=>e.style.getPropertyValue("--season-photo24")').split('"')[1];assert page.request.get('http://127.0.0.1:'+str(c.server.server_port)+photo).status==200
  page.evaluate('localDate=window.originalLocalDate24;applySeason24()');page.screenshot(path=str(screens/'season-complaint.png'));view('v_report_write');page.screenshot(path=str(screens/'season-report.png'))
  assert t.t.op('/api/complaints/submit',{'group':'서울','category':'일반문의','phone':'010-TEST','title':'연결 민원','content':'연결 내용','attachments':[]})[0]==200
  assert t.t.op('/api/documents/submit',{'group':'서울','title':'연결 보고서','content':'연결 본문','reviewer':'','approver':'admin','attachments':[]})[0]==200
  sync();view('v_dashboard');expect(page.locator('#dashboardActivityRows24')).not_to_contain_text('연결 민원');expect(page.locator('#dashboardActivityRows24')).not_to_contain_text('연결 보고서');view('v_complaint');page.locator('#complaintTableBody button').first.click();expect(page.locator('#modalBody')).to_contain_text('연결 내용');page.locator('#modalFooter button').filter(has_text='닫기').click();view('v_report_box');page.locator('#reportTable button').filter(has_text='보기').first.click();expect(page.locator('#modalBody')).to_contain_text('연결 본문');page.locator('#modalFooter button').filter(has_text='닫기').click()

  # A change arrives while another screen is active; viewing the notice menu acknowledges only this account.
  view('v_card_reg');assert t.t.w.operation('/api/notices/create',{'title':'새 공지','text':'시험 공지 본문','noticeType':'긴급공지'},c.admin)[0]==200;sync();expect(page.locator('#nav_v_notices .menu-new24')).to_have_count(1);view('v_dashboard');expect(page.locator('#dashboardActivityRows24')).to_contain_text('새 공지');page.locator('#dashboardActivityRows24 tr').filter(has_text='새 공지').locator('button').click();expect(page.locator('#v_notices')).to_be_visible();expect(page.locator('#noticeReader25')).to_contain_text('새 공지');expect(page.locator('#nav_v_notices .menu-new24')).to_have_count(0)
  view('v_dashboard');page.uncheck('#dashboardNotices24');page.uncheck('#dashboardShortcuts24');page.wait_for_function('()=>!dashboard24.prefSaving&&dashboard24.prefs.notices===false&&dashboard24.prefs.shortcuts===false');expect(page.locator('#noticeWidget24')).to_be_hidden();expect(page.locator('#shortcutWidget24')).to_be_hidden();view('v_notices');expect(page.locator('#noticeWidget24')).to_be_visible();view('v_shortcuts');expect(page.locator('#shortcutWidget24')).to_be_visible();login();expect(page.locator('#dashboardNotices24')).not_to_be_checked();expect(page.locator('#dashboardShortcuts24')).not_to_be_checked();page.check('#dashboardNotices24');page.check('#dashboardShortcuts24');page.wait_for_function('()=>!dashboard24.prefSaving&&dashboard24.prefs.notices&&dashboard24.prefs.shortcuts');page.locator('#dashboardGraphButton24').click();expect(page.locator('.branch-graph24 svg')).to_have_count(10);expect(page.locator('#modalBody')).to_contain_text('서울');expect(page.locator('#modalBody')).not_to_contain_text('인천');page.screenshot(path=str(screens/'branch-graphs.png'));page.locator('#modalFooter button').click()
  print('PASS all four seasonal local images, green unread dot and activity link acknowledgement, persisted widget toggles and dedicated submenus, ten scoped graph panels',flush=True)
  login('admin','Admin-test-pass!');view('v_admin');labels=page.evaluate('allViewIds.map(permissionLabel24)');assert all(any("가"<=ch<="힣" for ch in text) for text in labels),labels;assert not any('v_' in text for text in labels)
  for width in [1500,1024,768,390]:
   page.set_viewport_size({'width':width,'height':1000});view('v_dashboard');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),width
  # Exercise responsive action CSS on real ledger markup with approved synthetic rows.
  t.t.seed_approved();sync();view('v_expense_history');buttons=page.locator('#expenseHistoryTable .history-actions button');assert buttons.count()>0
  for width in [1500,768,390]:
   page.set_viewport_size({'width':width,'height':1000});size=float(buttons.first.evaluate('(e)=>getComputedStyle(e).fontSize').replace('px',''));assert 9<=size<=12;assert buttons.first.evaluate('(e)=>e.scrollWidth<=e.clientWidth+1')
  assert not errors,errors;browser.close();print('PASS Korean permission labels, responsive ledger action text and dashboard at 1500/1024/768/390; no JavaScript errors',flush=True)
finally:fixture.Dashboard124Tests.tearDownClass()

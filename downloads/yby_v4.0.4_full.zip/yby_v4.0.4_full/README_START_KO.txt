﻿YBY V4.0.4 — 먼저 읽어주세요

기존 사용자는 새 폴더의 STOP_SERVER.bat → RUN_LAN_WINDOWS.bat 순서로 실행하세요.
AppData의 기존 업무 자료·계정·인증서를 유지하면서 업데이트합니다.
자료 폴더나 인증서를 삭제하지 마세요.

서버 최초 인증서 등록: 안내창의 SHA-256 확인 → 예 → Windows 등록 승인.
서버 재접속: CONNECT_SERVER.bat.
서버 방화벽 최초 1회: SETUP_SERVER_FIREWALL.bat → 요청할 때 관리자 승인.
다른 PC 전달: OPEN_LAN_CLIENT.bat → LAN_CLIENT.zip 복사.
다른 PC 접속: ZIP 압축 해제 → INSTALL_AND_CONNECT.bat → 최초 등록 예.
서버 검증: VERIFY_WINDOWS.bat. 다른 PC 검증: CHECK_CONNECTION.bat.

자세한 안내: README_LAN_KO.md
수정 사항·검증 범위: VALIDATION_V4.md

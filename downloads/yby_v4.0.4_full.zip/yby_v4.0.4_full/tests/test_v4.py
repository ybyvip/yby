"""V4 acceptance tests covering report F01-F11 and new security policies."""
import base64
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
import copy
import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from unittest import mock
import test_security as fixtures
import backup_manager
import operations


class V4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixtures.SecurityTests.setUpClass()
    @classmethod
    def tearDownClass(cls):fixtures.SecurityTests.tearDownClass()
    def setUp(self):
        self.c=fixtures.SecurityTests();self.c.setUp();self.a=fixtures.app
        with self.a.db() as conn:conn.execute('DELETE FROM operation_receipts');conn.commit()
        self.assertEqual(self.c.save({'cards':[{'id':1,'num':'TEST','group':'서울','status':'available','company':'test'}]},self.c.admin)[0],200)
    def operation(self,path,payload,cookie=None,request_id=None):
        body={**payload,'requestId':request_id or str(time.time_ns()),'revision':self.c.state(cookie or self.c.branch)['revision']}
        return self.c.request(path,body,cookie or self.c.branch)
    def draft(self):
        return {'date':'2026-10-15','cardNum':'TEST','group':'서울','user':'staff','merchant':'shop','purpose':'work','amount':100,'category':'일반'}
    def rent(self):
        return self.operation('/api/cards/rent',{'cardId':1,'dept':'test','user':'staff','purpose':'work','dueDate':'2099-01-01'})
    def test_negative_expense_blocked_every_path(self):
        value=self.draft();value['amount']=-100
        self.assertEqual(self.operation('/api/expenses/submit',{'expense':value})[0],400)
        value.update(id=9,requester='branch',status='승인대기')
        self.assertEqual(self.c.save({'expense':[value]},self.c.branch)[0],400)
        self.assertEqual(self.a.get_state().get('expense',[]),[])
    def test_invalid_card_status_and_direct_rental_blocked(self):
        value=copy.deepcopy(self.a.get_state()['cards'][0]);value['status']='invalid'
        self.assertEqual(self.c.save({'cards':[value]},self.c.branch)[0],400)
        value.update(status='rented',dept='x',user='staff',purpose='work',rentDate='2026-10-15',dueDate='2099-01-01')
        self.assertEqual(self.c.save({'cards':[value]},self.c.branch)[0],403)
    def test_return_and_expense_are_atomic(self):
        self.assertEqual(self.rent()[0],200)
        self.assertEqual(self.operation('/api/cards/return',{'cardId':1,'used':True,'expense':self.draft()})[0],200)
        state=self.a.get_state()
        self.assertEqual(state['cards'][0]['status'],'available');self.assertEqual(len(state['expense']),1)
        self.assertEqual([x['type'] for x in state['history']],['불출','반납'])
    def test_invalid_return_expense_rolls_back_all(self):
        self.rent();value=self.draft();value['amount']=0
        self.assertEqual(self.operation('/api/cards/return',{'cardId':1,'used':True,'expense':value})[0],400)
        state=self.a.get_state();self.assertEqual(state['cards'][0]['status'],'rented');self.assertEqual(state['expense'],[]);self.assertEqual(len(state['history']),1)
    def test_database_failure_rolls_back_atomic_return(self):
        self.rent()
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated disk failure')):
            self.assertEqual(self.operation('/api/cards/return',{'cardId':1,'used':True,'expense':self.draft()})[0],500)
        state=self.a.get_state();self.assertEqual(state['cards'][0]['status'],'rented');self.assertEqual(state['expense'],[])
    def test_idempotent_return_prevents_duplicate_expense(self):
        self.rent();body={'cardId':1,'used':True,'expense':self.draft(),'requestId':'repeat-operation-id','revision':self.c.state(self.c.branch)['revision']}
        first=self.c.request('/api/cards/return',body,self.c.branch)
        second=self.c.request('/api/cards/return',body,self.c.branch)
        self.assertEqual(first[0],200);self.assertEqual(first[1],second[1]);self.assertEqual(len(self.a.get_state()['expense']),1)
        body['used']=False;self.assertEqual(self.c.request('/api/cards/return',body,self.c.branch)[0],409)
    def test_concurrent_rental_has_one_winner(self):
        body={'cardId':1,'dept':'test','user':'staff','purpose':'work','dueDate':'2099-01-01','revision':self.c.state(self.c.branch)['revision']}
        with ThreadPoolExecutor(max_workers=2) as pool:
            responses=list(pool.map(lambda rid:self.c.request('/api/cards/rent',{**body,'requestId':rid},self.c.branch)[0],['race-request-one','race-request-two']))
        self.assertEqual(sorted(responses),[200,409]);self.assertEqual(len(self.a.get_state()['history']),1)
    def test_changed_state_revision_is_same_snapshot(self):
        response=self.c.state(self.c.branch)
        with self.a.db() as conn:revision=conn.execute('SELECT updated_at FROM system_state').fetchone()[0]
        self.assertEqual(response['revision'],revision)
        self.assertEqual(self.c.save(response['state'],self.c.branch,revision)[0],200)
    def test_unchanged_poll_is_lightweight(self):
        revision=self.c.state(self.c.branch)['revision']
        status,body,_=self.c.request('/api/state',cookie=self.c.branch,headers={'If-None-Match':revision})
        self.assertEqual(status,200);self.assertTrue(body['unchanged']);self.assertNotIn('state',body)
    def test_poll_does_not_extend_user_activity(self):
        token=self.c.branch.split('=',1)[1];before=time.time()-50;self.a.SESSION_ACTIVITY[token]=before
        self.assertEqual(self.c.state(self.c.branch)['ok'],True);self.assertEqual(self.a.SESSION_ACTIVITY[token],before)
        self.assertEqual(self.c.request('/api/session/touch',{},self.c.branch)[0],200);self.assertGreater(self.a.SESSION_ACTIVITY[token],before)
    def test_absolute_session_expiry(self):
        token=self.c.branch.split('=',1)[1];self.a.SESSION_CREATED[token]=time.time()-self.a.SESSION_ABSOLUTE_TIMEOUT-1
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],401)
    def test_auxiliary_file_failure_does_not_lie_about_commit(self):
        with mock.patch.object(Path,'write_text',side_effect=PermissionError('simulated auxiliary failure')):
            self.assertEqual(self.c.save({'notices':[{'id':1,'text':'saved'}]},self.c.admin)[0],200)
        self.assertEqual(self.a.get_state()['notices'][0]['text'],'saved');self.assertTrue(self.a.OPERATION_WARNINGS)
    def test_password_failure_followup_always_revokes_sessions(self):
        with mock.patch.object(Path,'write_text',side_effect=PermissionError('simulated auxiliary failure')):
            self.assertEqual(self.c.request('/api/change-password',{'currentPassword':'Branch-test-pass!','newPassword':'Changed-fixture-pass!'},self.c.branch)[0],200)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],401)
        with self.a.db() as c:self.assertTrue(self.a.verify_password(c.execute("SELECT password_hash FROM users WHERE username='branch'").fetchone()[0],'Changed-fixture-pass!'))
    def test_receipt_download_requires_current_permission(self):
        payload={'name':'test.txt','content':base64.b64encode(b'receipt').decode(),'purpose':'settlement','group':'서울'}
        status,value,_=self.c.request('/api/attachments',payload,self.c.branch);self.assertEqual(status,200)
        readonly=self.c.login('readonly','Branch-test-pass!');path='/api/attachments/'+value['attachment_id']
        self.assertEqual(self.c.request(path,cookie=readonly)[0],403)
        payload['broadcast']=True;self.assertEqual(self.c.request('/api/attachments',payload,self.c.branch)[0],403)
        with self.a.db() as c:c.execute("UPDATE users SET permissions_json='[]' WHERE username='branch'");c.commit()
        self.assertEqual(self.c.request(path,cookie=self.c.branch)[0],403)
    def test_document_identity_is_server_owned(self):
        payload={'title':'test','content':'content','group':'인천','author':'admin','approver':'admin'}
        status,body,_=self.operation('/api/documents/submit',payload);self.assertEqual(status,200)
        self.assertEqual(body['document']['group'],'서울');self.assertEqual(body['document']['author'],'branch')
        self.assertEqual(self.c.save({'reports':[dict(body['document'],status='approved')]},self.c.branch)[0],403)
    def test_two_stage_document_approval(self):
        with self.a.db() as c:c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_report_box']),'readonly'));c.commit()
        reviewer=self.c.login('readonly','Branch-test-pass!')
        status,body,_=self.operation('/api/documents/submit',{'title':'test','content':'content','reviewer':'readonly','approver':'admin'});self.assertEqual(status,200)
        doc=body['document']['id']
        self.assertEqual(self.operation('/api/documents/decision',{'id':doc,'decision':'approve'},self.c.admin)[0],403)
        self.assertEqual(self.operation('/api/documents/decision',{'id':doc,'decision':'approve'},reviewer)[0],200)
        self.assertEqual(self.operation('/api/documents/decision',{'id':doc,'decision':'approve'},self.c.admin)[0],200)
        row=self.a.get_state()['reports'][0];self.assertEqual(row['status'],'approved');self.assertEqual(len(row['decisions']),2)
    def test_expense_approval_records_actor(self):
        status,body,_=self.operation('/api/expenses/submit',{'expense':self.draft()});self.assertEqual(status,200)
        row=body['expense']
        result=self.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'branch','decision':'approve'},self.c.admin)
        self.assertEqual(result[0],200);self.assertEqual(self.a.get_state()['expense'],[]);self.assertEqual(self.a.get_state()['expenseHistory'][0]['approvedBy'],'admin')
    def test_full_backup_and_restore_preserves_all_files(self):
        key=self.a.DB_PATH.parent/'password_display.key';key.write_bytes(b'legacy-preserved-key')
        (self.a.ATTACHMENT_DIR/'fixture.bin').write_bytes(b'attachment')
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);archive=backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,root/'backup.zip')
            backup_manager.restore(archive,root/'restored')
            self.assertEqual((root/'restored/attachments/fixture.bin').read_bytes(),b'attachment')
            self.assertEqual((root/'restored/password_display.key').read_bytes(),b'legacy-preserved-key')
            with closing(sqlite3.connect(root/'restored'/self.a.DB_PATH.name)) as c:self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
    def test_malformed_backup_cannot_overwrite_existing_data(self):
        from zipfile import ZipFile
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);data=root/'data';data.mkdir();(data/'keep').write_text('keep')
            with ZipFile(root/'bad.zip','w') as z:z.writestr('../escape','bad')
            with self.assertRaises(ValueError):backup_manager.restore(root/'bad.zip',data)
            self.assertEqual((data/'keep').read_text(),'keep')
    def test_normalized_storage_survives_restart_initialization(self):
        before=self.a.get_state()
        import contextlib,io
        with contextlib.redirect_stdout(io.StringIO()):self.a.init_db();self.a.init_db()
        self.assertEqual(self.a.get_state()['cards'],before['cards'])
        with self.a.db() as c:
            self.assertIsNone(c.execute('SELECT state_json FROM system_state').fetchone()[0])
            self.assertEqual(c.execute('SELECT COUNT(*) FROM business_cards').fetchone()[0],1)
    def test_legacy_schema_migrates_without_false_corruption(self):
        paths=self.a.DB_PATH,self.a.BACKUP_DIR,self.a.ATTACHMENT_DIR
        try:
            with tempfile.TemporaryDirectory() as t:
                root=Path(t);self.a.DB_PATH=root/'old.db';self.a.BACKUP_DIR=root/'backups';self.a.BACKUP_DIR.mkdir();self.a.ATTACHMENT_DIR=root/'attachments';self.a.ATTACHMENT_DIR.mkdir()
                with closing(sqlite3.connect(self.a.DB_PATH)) as c:
                    c.execute('CREATE TABLE system_state(id INTEGER PRIMARY KEY,version INTEGER,state_json TEXT,updated_at TEXT,updated_by TEXT)')
                    c.execute('INSERT INTO system_state VALUES(1,3,?,?,?)',(json.dumps({'cards':[{'id':1,'num':'LEGACY','group':'서울','status':'available'}]}),'old','admin'));c.commit()
                import contextlib,io
                with contextlib.redirect_stdout(io.StringIO()):self.a.prepare_db()
                self.assertEqual(self.a.get_state()['cards'][0]['num'],'LEGACY');self.assertFalse(list(self.a.BACKUP_DIR.glob('*corrupt*')))
        finally:self.a.DB_PATH,self.a.BACKUP_DIR,self.a.ATTACHMENT_DIR=paths
    def test_pagination_respects_scope(self):
        status,body,_=self.c.request('/api/records?collection=cards&limit=1',cookie=self.c.branch)
        self.assertEqual(status,200);self.assertEqual(body['total'],1);self.assertEqual(body['items'][0]['group'],'서울')
    def test_backup_api_requires_reauthentication(self):
        self.assertEqual(self.c.request('/api/admin/backup',{'password':'wrong'},self.c.admin)[0],403)
    def test_legacy_card_key_is_not_exposed_by_admin_or_operation(self):
        state=self.a.get_state();state['cards'][0]['cardKey']='legacy-private-key'
        with self.a.db() as c:self.a.persist_state(c,state,'migration')
        self.assertNotIn('cardKey',json.dumps(self.c.state(self.c.admin)))
        result=self.rent();self.assertEqual(result[0],200);self.assertNotIn('cardKey',json.dumps(result[1]))
    def test_private_notes_are_scoped_and_preserved(self):
        self.assertEqual(self.c.save({'memos':{'admin-note':{'text':'private','panelId':'v_dashboard'}}},self.c.admin)[0],200)
        self.assertEqual(self.c.state(self.c.branch)['state']['memos'],{})
        self.assertEqual(self.c.save({'memos':{'branch-note':{'text':'private','panelId':'v_dashboard'}}},self.c.branch)[0],200)
        self.assertEqual(set(self.a.get_state()['memos']),{'admin-note','branch-note'})
        self.assertEqual(set(self.c.state(self.c.admin)['state']['memos']),{'admin-note'})
    def test_admin_cannot_read_unrelated_direct_messages(self):
        state=self.a.get_state();state['chat']=[{'id':'private-message','sender':'branch','recipient':'readonly','recipients':['readonly'],'dm':True,'text':'private'}]
        with self.a.db() as c:self.a.persist_state(c,state,'migration')
        self.assertEqual(self.c.state(self.c.admin)['state']['chat'],[])
        self.assertEqual(self.c.save({'notices':[]},self.c.admin)[0],200)
        self.assertEqual(self.a.get_state()['chat'][0]['text'],'private')
    def test_reading_unchanged_state_skips_bulk_reconstruction(self):
        revision=self.c.state(self.c.branch)['revision']
        with mock.patch.object(self.a.storage,'read',side_effect=AssertionError('bulk read should not occur')):
            self.assertEqual(self.c.request('/api/state',cookie=self.c.branch,headers={'If-None-Match':revision})[1]['unchanged'],True)
    def test_duplicate_request_id_cannot_be_used_by_another_actor(self):
        self.rent();body={'cardId':1,'used':False,'requestId':'shared-request-id','revision':self.c.state(self.c.branch)['revision']}
        self.assertEqual(self.c.request('/api/cards/return',body,self.c.branch)[0],200)
        self.assertEqual(self.c.request('/api/cards/return',body,self.c.admin)[0],409)
    def test_blank_required_expense_field_and_missing_card_rejected(self):
        value=self.draft();value['merchant']=''
        self.assertEqual(self.operation('/api/expenses/submit',{'expense':value})[0],400)
        value=self.draft();value['cardNum']='UNREGISTERED'
        self.assertEqual(self.operation('/api/expenses/submit',{'expense':value})[0],400)
    def test_deleted_rented_card_is_rejected(self):
        self.rent();self.assertEqual(self.c.save({'cards':[]},self.c.admin)[0],400)
    def test_audit_records_real_changed_card_fields(self):
        self.rent();events=self.c.request('/api/audit',cookie=self.c.admin)[1]['events']
        event=next(x for x in events if x['action']=='/api/cards/rent')
        self.assertEqual(event['username'],'branch');self.assertIn('TEST',event['details']);self.assertIn('rented',event['details'])
    def test_password_database_failure_rolls_back_hash_and_history(self):
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated DB failure')):
            self.assertEqual(self.c.request('/api/change-password',{'currentPassword':'Branch-test-pass!','newPassword':'New-transaction-pass!'},self.c.branch)[0],500)
        with self.a.db() as c:
            self.assertTrue(self.a.verify_password(c.execute("SELECT password_hash FROM users WHERE username='branch'").fetchone()[0],'Branch-test-pass!'))
            self.assertEqual(c.execute('SELECT COUNT(*) FROM account_change_history').fetchone()[0],0)
        self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],200)
    def test_account_database_failure_rolls_back_permissions(self):
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated DB failure')):
            status,_,_=self.c.request('/api/admin/account-update',{'username':'branch','scope':'인천','permissions':[]},self.c.admin)
        self.assertEqual(status,500);self.assertEqual(self.a.user_scope('branch'),'서울')
    def test_approved_expense_correction_preserves_original_and_net_amount(self):
        _,value,_=self.operation('/api/expenses/submit',{'expense':self.draft()});row=value['expense']
        self.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'branch','decision':'approve'},self.c.admin)
        payload={'id':row['id'],'group':'서울','requester':'branch','reason':'중복 청구 취소','password':'Admin-test-pass!'}
        self.assertEqual(self.operation('/api/expenses/correct',payload,self.c.admin)[0],200)
        ledger=self.a.get_state()['expenseHistory'];self.assertEqual(len(ledger),2);self.assertEqual(ledger[0]['amount'],100);self.assertEqual(sum(x['amount'] for x in ledger),0)
        self.assertEqual(self.operation('/api/expenses/correct',payload,self.c.admin)[0],400)
    def test_correction_requires_reauthentication(self):
        _,value,_=self.operation('/api/expenses/submit',{'expense':self.draft()});row=value['expense']
        self.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'branch','decision':'approve'},self.c.admin)
        payload={'id':row['id'],'group':'서울','requester':'branch','reason':'취소','password':'wrong'}
        self.assertEqual(self.operation('/api/expenses/correct',payload,self.c.admin)[0],403)
        self.assertEqual(len(self.a.get_state()['expenseHistory']),1)
    def test_corrupt_database_bytes_are_preserved(self):
        old=self.a.DB_PATH
        try:
            with tempfile.TemporaryDirectory() as t:
                self.a.DB_PATH=Path(t)/'corrupt.db';self.a.DB_PATH.write_bytes(b'not a sqlite database')
                with self.assertRaises(sqlite3.DatabaseError):self.a.prepare_db()
                self.assertEqual(self.a.DB_PATH.read_bytes(),b'not a sqlite database')
        finally:self.a.DB_PATH=old
    def test_registration_ids_are_server_assigned_and_scope_is_enforced(self):
        with self.a.db() as c:c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_reg']),'branch'));c.commit()
        status,row,_=self.operation('/api/cards/register',{'num':'NEW','company':'test','group':'인천','id':1})
        self.assertEqual(status,200);self.assertEqual(row['card']['group'],'서울');self.assertNotEqual(row['card']['id'],1)
        self.assertEqual(self.operation('/api/cards/register',{'num':'NEW','company':'test'})[0],400)
    def test_dashboard_permission_returns_counts_without_details(self):
        with self.a.db() as c:c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_dashboard']),'readonly'));c.commit()
        cookie=self.c.login('readonly','Branch-test-pass!');body=self.c.state(cookie)['state']
        self.assertEqual(body['cards'],[]);self.assertEqual(body['dashboardSummary']['cards'],1);self.assertEqual(body['expense'],[])
    def test_anonymous_directory_omits_roles(self):
        body=self.c.request('/api/bootstrap')[1]
        self.assertTrue(all(set(x)=={'username'} for x in body['users']))
    def test_expense_self_approval_is_denied(self):
        with self.a.db() as c:c.execute("UPDATE users SET scope='ALL' WHERE username='branch'");c.commit()
        _,value,_=self.operation('/api/expenses/submit',{'expense':self.draft()});row=value['expense']
        self.assertEqual(self.operation('/api/expenses/decision',{'id':row['id'],'group':'서울','requester':'branch','decision':'approve'})[0],403)
    def test_xlsx_export_keeps_numbers_and_formula_like_strings_as_text(self):
        import exports,io
        from zipfile import ZipFile
        import xml.etree.ElementTree as ET
        raw=exports.make_xlsx('한글',['금액','문자'],[[100,'=HYPERLINK("test")']])
        with ZipFile(io.BytesIO(raw)) as z:root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        cells=root.findall('.//s:row',ns)[1].findall('s:c',ns)
        self.assertEqual(cells[0].find('s:v',ns).text,'100');self.assertEqual(cells[1].get('t'),'inlineStr');self.assertEqual(root.findall('.//s:f',ns),[])
    def test_readonly_export_is_denied(self):
        cookie=self.c.login('readonly','Branch-test-pass!')
        self.assertEqual(self.c.request('/api/exports',{'title':'test','headers':['a'],'rows':[[1]]},cookie)[0],403)
    def test_partial_admin_save_preserves_unrelated_business_data(self):
        self.operation('/api/documents/submit',{'title':'preserve','content':'content','approver':'admin'})
        self.assertEqual(self.c.save({'notices':[{'id':1,'text':'notice'}]},self.c.admin)[0],200)
        self.assertEqual(len(self.a.get_state()['cards']),1);self.assertEqual(len(self.a.get_state()['reports']),1)
        self.assertEqual(self.c.save({'reports':[]},self.c.admin)[0],403)
    def test_creating_second_administrator_requires_reauthentication(self):
        body={'username':'second-admin','scope':'ALL','permissions':[],'password':'Temporary-admin-pass!'}
        self.assertEqual(self.c.request('/api/admin/account-create',body,self.c.admin)[0],403)
        body['adminPassword']='Admin-test-pass!'
        self.assertEqual(self.c.request('/api/admin/account-create',body,self.c.admin)[0],200)
        with self.a.db() as c:
            row=c.execute("SELECT scope,permissions_json FROM users WHERE username='second-admin'").fetchone()
            self.assertEqual(row['scope'],'ALL');self.assertEqual(set(json.loads(row['permissions_json'])),set(self.a.ALL_VIEWS))
    def test_future_database_version_is_rejected_without_rewrite(self):
        with self.a.db() as c:c.execute("INSERT INTO schema_versions VALUES(99,'future')");c.commit()
        before=self.a.DB_PATH.read_bytes()
        try:
            with self.assertRaises(RuntimeError):self.a.prepare_db()
            self.assertEqual(self.a.DB_PATH.read_bytes(),before)
        finally:
            with self.a.db() as c:c.execute('DELETE FROM schema_versions WHERE version=99');c.commit()
    def test_login_race_cannot_issue_session_for_changed_password(self):
        original=self.a.verify_password;changed=[False]
        def change_during_check(stored,password):
            valid=original(stored,password)
            if valid and not changed[0]:
                changed[0]=True
                with self.a.LOCK,self.a.db() as c:
                    c.execute("UPDATE users SET password_hash=? WHERE username='branch'",(self.a.phash('Changed-race-pass!'),));c.commit();self.a.invalidate_sessions('branch')
            return valid
        with mock.patch.object(self.a,'verify_password',change_during_check):
            self.assertEqual(self.c.request('/api/login',{'username':'branch','password':'Branch-test-pass!'} )[0],401)
        self.assertNotIn('branch',self.a.SESSIONS.values())
    def test_anonymous_logout_and_creation_metadata_cleanup(self):
        self.assertEqual(self.c.request('/api/logout',{})[0],200)
        token=self.c.branch.split('=',1)[1]
        self.assertEqual(self.c.request('/api/logout',{},self.c.branch)[0],200)
        self.assertNotIn(token,self.a.SESSION_CREATED);self.assertEqual(self.c.request('/api/state',cookie=self.c.branch)[0],401)
    def test_database_process_lock_excludes_other_server_or_restore(self):
        from db_lock import DatabaseLock
        with tempfile.TemporaryDirectory() as t:
            data=Path(t)/'data'
            with DatabaseLock(data):
                with self.assertRaises(RuntimeError):
                    with DatabaseLock(data):pass
            with DatabaseLock(data):pass
    def test_large_existing_dataset_does_not_block_small_business_request(self):
        state=self.a.get_state();state['reports']=[{'id':str(i),'group':'서울','author':'branch','status':'pending','title':'legacy','content':'x'*100000} for i in range(85)]
        with self.a.db() as c:self.a.persist_state(c,state,'migration')
        self.assertGreater(len(json.dumps(state).encode()),8*1024*1024)
        self.assertEqual(self.rent()[0],200);self.assertEqual(self.a.get_state()['cards'][0]['status'],'rented')
    def test_hipass_registration_uses_server_id_and_branch_scope(self):
        with self.a.db() as c:c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_hipass_reg']),'branch'));c.commit()
        value={'type':'선불형','group':'인천','company':'test','num':'HP-TEST','hipassUser':'staff','issueDate':'2026-01-01','expiryDate':'2099-01-01'}
        status,body,_=self.operation('/api/hipass/register',value)
        self.assertEqual(status,200);self.assertEqual(body['hipass']['group'],'서울')
        self.assertEqual(self.a.get_state()['hipassBox'][0]['handler'],'branch')
        self.assertEqual(self.operation('/api/hipass/register',value)[0],400)
    def test_hipass_invalid_dates_are_rejected(self):
        value={'type':'선불형','group':'서울','company':'test','num':'HP-TEST','hipassUser':'staff','issueDate':'2026-01-01','expiryDate':'2025-01-01'}
        self.assertEqual(self.operation('/api/hipass/register',value,self.c.admin)[0],400)
        self.assertEqual(self.a.get_state()['hipass'],[])
    def test_http_service_has_bounded_worker_pool(self):
        server=operations.BoundedHTTPServer(('127.0.0.1',0),self.a.Handler)
        try:self.assertEqual(server.pool._max_workers,16)
        finally:server.server_close()

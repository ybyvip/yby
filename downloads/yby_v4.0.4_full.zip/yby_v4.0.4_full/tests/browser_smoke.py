import contextlib,importlib.util,io,json,pathlib,sys,tempfile,threading
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('browser_app',root/'app.py');app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
with tempfile.TemporaryDirectory() as t:
 app.DB_PATH=pathlib.Path(t)/'test.db';app.BACKUP_DIR=pathlib.Path(t)/'backups';app.BACKUP_DIR.mkdir();app.ATTACHMENT_DIR=pathlib.Path(t)/'attachments';app.ATTACHMENT_DIR.mkdir()
 with contextlib.redirect_stdout(io.StringIO()):app.prepare_db()
 with app.db() as c:
  c.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(app.phash('Browser-test-pass!'),'admin'));c.commit()
 app.persist_state(app.db(),{'cards':[{'id':1,'group':'서울','num':'TEST-CARD','company':'company','status':'available'}], 'history':[{'id':1,'group':'서울','handler':'admin','user':'<img src=x onerror="window.XSS=1">','purpose':'<svg onload="window.XSS=2">','type':'불출'}]},'admin')
 server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path=__import__('os').environ.get('V3_TEST_CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox']);page=browser.new_page();errors=[];dialogs=[]
   page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()))
   page.goto(f'http://127.0.0.1:{server.server_port}/');page.wait_for_function("() => typeof handleLogin==='function'")
   page.select_option('#loginUserSelect','admin');page.fill('#loginPasswordInput','Browser-test-pass!');page.locator('#loginPasswordInput').press('Enter');page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'",timeout=10000)
   print('LOGIN UI PASS; runtime errors:',errors,'dialogs:',dialogs)
   page.evaluate("stopLiveSync();switchView('v_card_history',document.getElementById('nav_v_card_history'));renderCardHistory()")
   print('XSS payload rendered as text:',page.locator('#cardHistoryTable').inner_text());assert page.evaluate('window.XSS||0')==0
   assert page.locator('#cardHistoryTable img, #cardHistoryTable svg').count()==0
   page.evaluate("openAddAccountModal()")
   page.fill('#newAccName',"담당자 '<&> 특별");page.fill('#newAccPw','Temporary-user-pass!');page.select_option('#newAccScope','서울');page.locator('#modalFooter button').filter(has_text='등록하기').click();page.wait_for_function("() => Object.keys(accountsData).includes(\"담당자 '<&> 특별\")")
   page.wait_for_timeout(300);print('ACCOUNT CREATE UI PASS; dialogs:',dialogs[-1:])
   page.evaluate("switchView('v_admin',document.getElementById('nav_v_admin'));renderAdminPermissions()")
   row=page.locator('#permissionTable tr').filter(has_text="담당자 '<&> 특별");assert row.count()==1
   row.locator('button').filter(has_text='저장').click();page.wait_for_timeout(500)
   print('QUOTED ACCOUNT INLINE HANDLER PASS; errors:',errors,'dialogs:',dialogs[-1:]);assert not errors
   row.locator('.account-password').fill('Updated-user-pass!')
   row.locator('input[value="v_hipass_reg"]').check()
   row.locator('button').filter(has_text='저장').click()
   page.wait_for_function("() => document.getElementById('accountHistoryTable').textContent.includes('관리자 비밀번호 수정')")
   row=page.locator('#permissionTable tr').filter(has_text="담당자 '<&> 특별")
   assert row.locator('.latest-account-password').input_value()==''
   assert page.evaluate("JSON.stringify(adminPasswordRows).includes('Updated-user-pass!')") is False
   ledger=page.locator('#accountHistoryTable').inner_text()
   assert '관리자 비밀번호 수정' in ledger and '권한 추가: v_hipass_reg' in ledger
   assert 'Updated-user-pass!' not in ledger
   assert page.evaluate("JSON.stringify(accountsData).includes('Updated-user-pass!')") is False
   page.fill('#accountHistorySearch',"담당자 '<&> 특별")
   assert '관리자 비밀번호 수정' in page.locator('#accountHistoryTable').inner_text()
   print('PASSWORD RESET METADATA + STRUCTURED HISTORY + SEARCH UI PASS')
   page.reload();page.wait_for_function("() => typeof handleLogin==='function'")
   page.select_option('#loginUserSelect','admin');page.fill('#loginPasswordInput','Browser-test-pass!');page.locator('#loginPasswordInput').press('Enter');page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'")
   page.evaluate("stopLiveSync();switchView('v_admin',document.getElementById('nav_v_admin'))")
   page.wait_for_function("() => document.getElementById('accountHistoryTable').textContent.includes('관리자 비밀번호 수정')")
   assert '관리자 비밀번호 수정' in page.locator('#accountHistoryTable').inner_text()
   print('HASH-ONLY POLICY AND HISTORY RETAINED AFTER RELOAD/RELOGIN UI PASS')
   page.evaluate('handleLogout()');page.wait_for_function("() => currentUser===null");assert page.evaluate("Object.keys(localStorage).filter(k=>k.startsWith('sys_')).length")==0
   page.select_option('#loginUserSelect',"담당자 '<&> 특별");page.fill('#loginPasswordInput','Updated-user-pass!');page.locator('#loginPasswordInput').press('Enter');page.wait_for_selector('#ownNewPassword',state='visible')
   page.fill('#ownNewPassword','Changed-user-pass!');page.fill('#ownConfirmPassword','Changed-user-pass!');page.click('#ownPasswordSave');page.wait_for_timeout(600)
   page.select_option('#loginUserSelect',"담당자 '<&> 특별");page.fill('#loginPasswordInput','Changed-user-pass!');page.locator('#loginPasswordInput').press('Enter');page.wait_for_function("() => document.getElementById('appContainer').style.display==='flex'")
   print('MANDATORY PASSWORD CHANGE UI PASS; errors:',errors,'dialogs:',dialogs[-1:]);assert not errors
   page.evaluate("toggleChatPanel(true);toggleChatFormat('bold')")
   assert page.locator('#chatPrivacyPassword').is_visible()
   page.fill('#chatPrivacyPassword','wrong');page.evaluate('clearChatPrivacy()');page.wait_for_timeout(300);assert page.evaluate('chatFormatState.bold')
   page.fill('#chatPrivacyPassword','Changed-user-pass!');page.evaluate('clearChatPrivacy()');page.wait_for_timeout(300);assert not page.evaluate('chatFormatState.bold')
   print('CHAT PRIVACY PASSWORD UI PASS')
   page.evaluate("stopLiveSync();document.getElementById('rentCardSelect').value='1';document.getElementById('rentDept').value='test department';document.getElementById('rentUser').value='test staff';document.getElementById('rentDueDate').value='2026-12-31';document.querySelector('input[name=purposeChk]').checked=true")
   page.evaluate("async()=>{await handleRentCard({preventDefault(){},target:{reset(){}}})}")
   assert app.get_state()['cards'][0]['status']=='rented'
   page.evaluate('openReturnModal(1)');page.check('#returnUnusedCheckbox');page.evaluate('async()=>await returnCard(1)')
   assert app.get_state()['cards'][0]['status']=='available'
   print('CARD RENT AND UNUSED RETURN UI PASS')
   page.evaluate("document.getElementById('rentCardSelect').value='1';document.getElementById('rentDept').value='test department';document.getElementById('rentUser').value='test staff';document.getElementById('rentDueDate').value='2026-12-31';document.querySelector('input[name=purposeChk]').checked=true")
   page.evaluate("async()=>{await handleRentCard({preventDefault(){},target:{reset(){}}})}")
   page.evaluate('openReturnModal(1)');page.check('#returnUsedCheckbox');page.evaluate("setReturnUsageMode('used');document.getElementById('returnExpenseCategory').selectedIndex=1")
   page.fill('#returnExpenseMerchant','test shop');page.fill('#returnExpensePurpose','work');page.fill('#returnExpenseAmount','100');page.evaluate('async()=>await returnCard(1)')
   assert app.get_state()['cards'][0]['status']=='available'
   assert len(app.get_state()['expense'])==1
   print('CARD RETURN WITH SETTLEMENT UI PASS; errors:',errors);assert not errors

   page.evaluate('handleLogout()');page.wait_for_function("() => currentUser===null");assert page.evaluate('cardsData.length+chatMessagesList.length+inboxMessages.length')==0
   print('LOGOUT DATA CLEAR PASS');browser.close()
 finally:server.shutdown();server.server_close();thread.join()

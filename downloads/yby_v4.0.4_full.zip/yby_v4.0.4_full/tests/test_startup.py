import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import windows_bootstrap as boot
import startup_diagnostics as diagnostics
from db_lock import DatabaseLock


class StartupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.source=Path(self.temp.name)/'바탕화면 원본';self.target=Path(self.temp.name)/'사용자 실행 폴더'
        self.source.mkdir();(self.source/'app.py').write_text('version = "test"')
        self.manifest()
        self.output=io.StringIO();self.redirect=contextlib.redirect_stdout(self.output);self.redirect.__enter__();self.addCleanup(self.redirect.__exit__,None,None,None)

    def manifest(self):
        files={p.relative_to(self.source).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in self.source.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and p.suffix!='.db'}
        (self.source/'MANIFEST.json').write_text(json.dumps({'version':'test','files':files}))

    def incoming(self,value=b'original DB'):
        (self.source/'data').mkdir(exist_ok=True);(self.source/'data/corporate_card_system.db').write_bytes(value)

    def test_first_launch_copies_program_and_preserves_source(self):
        self.incoming();original=(self.source/'data/corporate_card_system.db').read_bytes()
        boot.prepare_runtime(self.source,self.target)
        self.assertEqual((self.target/'data/corporate_card_system.db').read_bytes(),original)
        self.assertEqual((self.source/'data/corporate_card_system.db').read_bytes(),original)
        self.assertTrue((self.target/'app.py').exists())

    def test_repeated_launch_preserves_live_changes(self):
        self.incoming();boot.prepare_runtime(self.source,self.target)
        database=self.target/'data/corporate_card_system.db';database.write_bytes(b'new business transactions')
        boot.prepare_runtime(self.source,self.target)
        self.assertEqual(database.read_bytes(),b'new business transactions')

    def test_different_incoming_database_never_overwrites_live_data(self):
        self.incoming();boot.prepare_runtime(self.source,self.target)
        database=self.target/'data/corporate_card_system.db';database.write_bytes(b'live')
        self.incoming(b'new import')
        with self.assertRaisesRegex(RuntimeError,'서로 다른 업무 DB'):boot.prepare_runtime(self.source,self.target)
        self.assertEqual(database.read_bytes(),b'live')

    def test_program_update_preserves_old_code_and_live_database(self):
        self.incoming();boot.prepare_runtime(self.source,self.target)
        database=self.target/'data/corporate_card_system.db';database.write_bytes(b'live')
        (self.source/'app.py').write_text('new version');self.manifest()
        boot.prepare_runtime(self.source,self.target)
        self.assertEqual((self.target/'app.py').read_text(),'new version')
        self.assertEqual(database.read_bytes(),b'live')
        self.assertEqual(len(list((self.target/'program_backups').rglob('app.py'))),1)

    def test_active_runtime_cannot_be_updated(self):
        self.target.mkdir()
        with DatabaseLock(self.target/'data'):
            with self.assertRaises(RuntimeError):boot.prepare_runtime(self.source,self.target)
        self.assertFalse((self.target/'app.py').exists())

    def test_tampered_code_is_rejected_before_data_changes(self):
        (self.source/'app.py').write_text('modified without new manifest')
        with self.assertRaisesRegex(RuntimeError,'불완전'):boot.prepare_runtime(self.source,self.target)
        self.assertFalse(self.target.exists())

    def test_original_data_readme_can_be_replaced_by_old_data_folder(self):
        (self.source/'data').mkdir();readme=self.source/'data/README.txt';readme.write_text('new')
        self.manifest();readme.write_text('old customer data folder')
        self.incoming();boot.prepare_runtime(self.source,self.target)
        self.assertTrue((self.target/'data/corporate_card_system.db').exists())

    def test_lock_open_failure_names_exact_path(self):
        with patch('db_lock.os.open',side_effect=PermissionError(13,'denied')):
            with self.assertRaises(OSError) as error:
                with DatabaseLock(self.target/'data'):pass
        self.assertEqual(error.exception.filename,str(self.target/'data.runtime.lock'))
        self.assertIn('쓰기 권한',str(error.exception))

    def test_diagnostic_is_written_without_environment_values(self):
        diagnostics.stage('잠금 확인',self.target/'data.runtime.lock')
        with patch.dict(os.environ,{'LOCALAPPDATA':self.temp.name,'VERY_SECRET_TEST_VALUE':'must-never-be-dumped'}),contextlib.redirect_stderr(io.StringIO()):
            try:raise PermissionError(13,'denied',str(self.target/'data.runtime.lock'))
            except PermissionError as error:diagnostics.report(error,self.source)
        report=next((Path(self.temp.name)/'YBY/diagnostics').glob('startup_error_*.txt')).read_text()
        self.assertIn('잠금 확인',report);self.assertIn('data.runtime.lock',report)
        self.assertNotIn('must-never-be-dumped',report)

    def test_manifest_path_cannot_escape_source(self):
        (self.source/'MANIFEST.json').write_text(json.dumps({'files':{'../outside':'fake'}}))
        with self.assertRaisesRegex(RuntimeError,'경로'):boot.prepare_runtime(self.source,self.target)


if __name__=='__main__':unittest.main()

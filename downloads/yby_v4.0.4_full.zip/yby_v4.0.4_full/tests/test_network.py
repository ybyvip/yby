import base64
import contextlib
import io
import json
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import lan_setup


class NetworkTests(unittest.TestCase):
    def test_only_rfc1918_ipv4_is_accepted(self):
        for value in ('10.10.0.121','172.16.0.1','172.31.255.254','192.168.1.1'):
            self.assertEqual(lan_setup.private_ip(value),value)
        for value in ('127.0.0.1','0.0.0.0','8.8.8.8','172.32.0.1','169.254.1.1','::1','garbage'):
            with self.assertRaises(ValueError):lan_setup.private_ip(value)

    def test_unassigned_ip_does_not_create_configuration(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(lan_setup,'assigned_ip',side_effect=OSError('not assigned')):
            with self.assertRaisesRegex(RuntimeError,'이 서버 PC에 없습니다'):
                lan_setup.ensure_configuration(Path(folder),'10.10.0.121',5000,False)
            self.assertFalse((Path(folder)/lan_setup.SETTINGS).exists())

    def test_multiple_interfaces_requires_explicit_selection_without_console(self):
        with tempfile.TemporaryDirectory() as folder,patch.object(lan_setup,'local_ips',return_value=['10.1.1.1','192.168.1.1']):
            with self.assertRaisesRegex(RuntimeError,'--server-ip'):
                lan_setup.ensure_configuration(Path(folder),interactive=False)

    def test_bad_settings_never_fall_back_to_local_server(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/lan_setup.SETTINGS
            path.write_text(json.dumps({'format':1,'mode':'lan-https','server_ip':'8.8.8.8','port':5000,'hostname':'test'}))
            with self.assertRaises(ValueError):lan_setup.load_settings(folder)

    def test_private_network_environment_always_requires_tls(self):
        env=lan_setup.configured_env(ROOT,{'V3_HOST':'127.0.0.1','OTHER':'retained'}, {'server_ip':'10.10.0.121','port':5443})
        self.assertEqual(env['V3_HOST'],'0.0.0.0');self.assertEqual(env['V3_PORT'],'5443')
        self.assertEqual(env['V4_LAN_SERVER_IP'],'10.10.0.121')
        self.assertEqual(env['OTHER'],'retained')
        self.assertTrue(env['V3_TLS_CERT'].endswith('server.pem'))
        self.assertTrue(env['V3_TLS_KEY'].endswith('server-key.pem'))
        self.assertTrue(env['V3_TLS_CA'].endswith('root-ca.pem'))

    def test_pkcs1_serialization_uses_signed_der_integers(self):
        values={'Modulus':3233,'Exponent':17,'D':2753,'P':61,'Q':53,'DP':53,'DQ':49,'InverseQ':38}
        params={k:base64.b64encode(v.to_bytes((v.bit_length()+7)//8,'big')).decode() for k,v in values.items()}
        raw=lan_setup.rsa_private_pem(params)
        self.assertIn(b'BEGIN RSA PRIVATE KEY',raw)
        decoded=base64.b64decode(b''.join(raw.splitlines()[1:-1]))
        self.assertIn(b'\x02\x02\x0c\xa1',decoded)
        self.assertIn(b'\x02\x01\x00',decoded)
        self.assertEqual(lan_setup.der_length(128),b'\x81\x80')
        self.assertEqual(lan_setup.der_length(256),b'\x82\x01\x00')

    def test_public_client_export_never_copies_private_keys_or_business_data(self):
        import shutil
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'certificates').mkdir();(root/'certificates/root-ca.cer').write_bytes(b'public certificate')
            (root/'certificates/server-key.pem').write_bytes(b'secret must not be copied')
            (root/'data').mkdir();(root/'data/private.db').write_bytes(b'private DB')
            shutil.copytree(ROOT/'tools',root/'tools')
            info=lan_setup.export_client(root,{'server_ip':'10.10.0.121','port':5443})
            names={p.name for p in (root/'LAN_CLIENT').iterdir()}
            self.assertEqual(names,{'YBY_LAN_ROOT.cer','connection.json','INSTALL_AND_CONNECT.bat','CHECK_CONNECTION.bat','client_connect.ps1','접속안내.txt'})
            self.assertEqual(info['url'],'https://10.10.0.121:5443')
            for path in (root/'LAN_CLIENT').iterdir():self.assertNotIn(b'secret must not be copied',path.read_bytes())

    def test_existing_ca_and_settings_are_reused(self):
        from datetime import datetime,timedelta,timezone
        previous={'format':1,'mode':'lan-https','server_ip':'10.10.0.121','port':5000,
                  'hostname':socket.gethostname().rstrip('.'),'expires_utc':(datetime.now(timezone.utc)+timedelta(days=90)).isoformat()}
        with tempfile.TemporaryDirectory() as folder,patch.object(lan_setup,'load_settings',return_value=previous),patch.object(lan_setup,'assigned_ip',side_effect=lambda x:x),patch.object(lan_setup,'create_certificates') as create,patch.object(lan_setup,'export_client',return_value={'url':'https://10.10.0.121:5000','sha256':'TEST'}),contextlib.redirect_stdout(io.StringIO()):
            result=lan_setup.ensure_configuration(folder,interactive=False)
            self.assertEqual(result['server_ip'],previous['server_ip']);create.assert_not_called()
            self.assertTrue((Path(folder)/lan_setup.SETTINGS).exists())

    def test_cli_rejects_invalid_port_without_starting_application(self):
        result=subprocess.run([sys.executable,str(ROOT/'run_ready.py'),'--local','--port','0','--no-browser'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        self.assertEqual(result.returncode,1);self.assertIn('포트 범위',result.stderr)


if __name__=='__main__':unittest.main()

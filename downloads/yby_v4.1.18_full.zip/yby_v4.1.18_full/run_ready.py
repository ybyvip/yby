"""Portable V4.1.18 startup with explicit local and saved private HTTPS modes."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import subprocess
import sys
import time
import urllib.request
import webbrowser
import lan_setup
import active_runtime
import startup_diagnostics as diagnostics

ROOT = Path(__file__).resolve().parent
VERSION = '4.1.18'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-browser', action='store_true')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--lan', action='store_true', help='사내망 HTTPS 최초 설정 또는 IP 갱신')
    mode.add_argument('--local', action='store_true', help='이 PC 전용 HTTP 실행')
    parser.add_argument('--server-ip', help='이 서버 PC에 할당된 사내망 IPv4')
    parser.add_argument('--port', type=int)
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 or later is required.')
    if active_runtime.reconnect(ROOT,no_browser=args.no_browser,local=args.local,lan=args.lan,port=args.port,server_ip=args.server_ip):
        return 0
    os.umask(0o077)
    python = Path(sys.executable)  # V4 runtime uses Python standard library only.
    env = os.environ.copy()
    settings = None
    if args.server_ip and not args.lan:
        raise RuntimeError('--server-ip는 --lan과 함께 지정하세요.')
    if args.local:
        env['V3_HOST'] = '127.0.0.1'
        for name in ('V3_TLS_CERT','V3_TLS_KEY','V3_TLS_CA','V4_LAN_SERVER_IP'):env.pop(name,None)
    elif args.lan:
        from db_lock import DatabaseLock
        diagnostics.stage('자료 폴더 잠금',Path(env.get('V3_DATA_DIR',str(ROOT/'data'))))
        with DatabaseLock(Path(env.get('V3_DATA_DIR',str(ROOT/'data')))):
            settings = lan_setup.ensure_configuration(ROOT,args.server_ip,args.port,sys.stdin.isatty())
        env = lan_setup.configured_env(ROOT,env,settings)
    elif not any(env.get(name) for name in ('V3_HOST','V3_TLS_CERT','V3_TLS_KEY')):
        settings = lan_setup.load_settings(ROOT)
        if settings:
            try:lan_setup.assigned_ip(settings['server_ip'])
            except OSError as error:raise RuntimeError('서버 IP가 변경되었습니다. RUN_LAN_WINDOWS.bat로 다시 설정하세요.') from error
            env = lan_setup.configured_env(ROOT,env,settings)
    if args.port is not None:
        if not 1<=args.port<=65535:raise ValueError('포트 범위는 1~65535입니다.')
        if settings and args.port!=settings['port']:
            raise RuntimeError('저장된 사내망 포트 변경에는 --lan --port를 사용하세요.')
        env['V3_PORT']=str(args.port)
    env.setdefault('V3_HOST', '127.0.0.1')
    env.setdefault('V3_PORT', '5000')
    env['V3_AUTO_BROWSER'] = '0'
    port = int(env['V3_PORT'])
    diagnostics.stage('수신 주소·포트 확인',env['V3_HOST']+':'+str(port))
    if not 1<=port<=65535:raise ValueError('포트 범위는 1~65535입니다.')
    if env['V3_HOST'] not in ('127.0.0.1','localhost') and not env.get('V3_TLS_CERT'):raise RuntimeError('공유 네트워크에는 HTTPS 인증서와 키를 설정하세요.')
    if bool(env.get('V3_TLS_CERT')) != bool(env.get('V3_TLS_KEY')):
        raise RuntimeError('Set V3_TLS_CERT and V3_TLS_KEY together.')
    tls = bool(env.get('V3_TLS_CERT'))
    context = ssl.create_default_context(cafile=env.get('V3_TLS_CA')) if tls else None
    probe_host = '127.0.0.1' if env['V3_HOST'] in ('0.0.0.0','127.0.0.1','localhost') else env['V3_HOST']
    url_host = 'localhost' if tls and probe_host=='127.0.0.1' else probe_host
    url = f'{"https" if tls else "http"}://{url_host}:{port}/'
    # Local readiness requests must reach this server directly, including on PCs with corporate proxy settings.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
    for attempt in range(150):
        try:
            with socket.socket() as probe:
                if os.name=='nt':probe.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
                else:probe.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
                probe.bind((env['V3_HOST'], port))
            break
        except OSError as error:
            if error.errno not in (48, 98, 10048):
                raise
            with socket.socket() as listener:
                listener.settimeout(1)
                if listener.connect_ex((probe_host, port)) == 0:
                    raise RuntimeError(f'Port {port} is in use. Stop your previous server first.')
            if attempt == 0:
                print('Waiting for the recently closed server port to be released...', flush=True)
            time.sleep(0.5)
    else:
        raise RuntimeError(f'Port {port} is still unavailable.')

    process = subprocess.Popen([str(python), '-u', str(ROOT / 'app.py')], cwd=ROOT, env=env)
    try:
        deadline=time.monotonic()+300
        next_progress=time.monotonic()+15
        while time.monotonic()<deadline:
            if process.poll() is not None:
                raise RuntimeError(f'Server exited with code {process.returncode}; see the output above.')
            try:
                with opener.open(url + 'health', timeout=2) as response:
                    health = json.load(response)
                if health.get('ok') and health.get('database') and health.get('version') == VERSION:
                    break
            except ssl.SSLCertVerificationError as error:
                raise RuntimeError('HTTPS 인증서 검증 실패: '+str(error)) from error
            except OSError:
                pass
            if time.monotonic()>=next_progress:
                print('자료 확인·업데이트 전 백업을 진행 중입니다. 서버 실행 창을 열어 두세요.',flush=True)
                next_progress=time.monotonic()+15
            time.sleep(0.15)
        else:
            raise RuntimeError('서버 준비가 5분을 넘었습니다. 위의 DB·백업 안내와 진단 파일을 확인하세요.')
        with opener.open(url, timeout=5) as response:
            html = response.read().decode('utf-8')
            if 'value="admin"' not in html or VERSION not in html:
                raise RuntimeError('The V'+VERSION+' login page did not load correctly.')
        print(f'READY V{VERSION}: {url}', flush=True)
        if settings:
            remote_url=f"https://{settings['server_ip']}:{port}/"
            with opener.open(remote_url+'health',timeout=5) as response:
                if json.load(response).get('version')!=VERSION:raise RuntimeError('사내망 주소의 서버가 다릅니다.')
            print('LAN HTTPS 확인 완료: '+remote_url,flush=True)
            print('다른 PC: LAN_CLIENT 폴더의 INSTALL_AND_CONNECT.bat를 실행하세요.',flush=True)
        print('Keep this window open. Press Ctrl+C to stop the server.', flush=True)
        if not args.no_browser:
            if settings and os.name=='nt':
                active_runtime.trust_server(ROOT)
            else:webbrowser.open(url, new=1)
        return process.wait()
    except KeyboardInterrupt:
        return 0
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()


def stop_on_signal(signum, frame):
    raise KeyboardInterrupt


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, stop_on_signal)
    try:
        raise SystemExit(main())
    except Exception as error:
        diagnostics.report(error,ROOT)
        raise SystemExit(1)

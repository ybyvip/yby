"""Actual click -> historical ledgers, explicit acknowledgement, exports, no live business."""
from pathlib import Path
import importlib.util,os,sys,tempfile,json,subprocess
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import exports
spec=importlib.util.spec_from_file_location('f',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby4118-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
 c.setUp();a=f.app;assert c.save({'cards':[]},c.admin)[0]==200
 headers=['순번','은행명','카드번호(뒤4)','사용자','사용횟수','부서명','직급','목적','사용목적','사용금액','지급일','예정일','반납일']
 rows=[[i,'시험은행',str(i)*4,'시험사용자'+str(i),5,'시험팀','직원','출장','현장 업무 '+str(i),225000 if i==3 else '', '2026-10-17','2099-01-01','2026-10-19' if i<4 else ''] for i in range(1,5)]
 with tempfile.TemporaryDirectory() as folder:
  file=Path(folder)/'Book1형식_시험.xlsx';file.write_bytes(exports.make_xlsx('Sheet1',['']*len(headers),[['']*len(headers)]*3+[headers]+rows))
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1920,'height':1200});errors=[];dialogs=[]
   page.on('pageerror',lambda e:errors.append(str(e)))
   def accept(d):dialogs.append(d.message);d.accept()
   page.on('dialog',accept);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
   page.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>currentUser==="admin"&&!loginInFlight');page.evaluate('stopLiveSync()');page.click('#nav_v_external_match');page.locator('.excel-import summary').click();assert page.input_value('#excelImportMode')=='history';page.select_option('#excelDefaultGroup','본사');page.set_input_files('#excelUploadFile',str(file));page.click('#excelPreviewButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('사용정산이력 4건 · 불출 4건 / 반납 3건');expect(page.locator('#excelIntakeStatus')).to_contain_text('금액미기재 3건');assert not page.is_checked('#excelConfirm');assert page.locator('.excel-row-check:enabled:checked').count()==4
   page.locator('.excel-import').screenshot(path=str(screens/'excel_preview.png'))
   for width in (1920,1440,1024,768,390,320):
    page.set_viewport_size({'width':width,'height':1200});measure=page.locator('#externalMatchingWorkspace').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
   page.set_viewport_size({'width':1920,'height':1200})
   page.check('#excelSelectAll');page.uncheck('#excelSelectAll');page.click('#excelCommitButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('한 개 이상');assert not a.get_state()['expenseHistory'];page.check('#excelSelectAll')
   page.remove_listener('dialog',accept)
   def cancel(d):dialogs.append(d.message);d.dismiss()
   page.on('dialog',cancel);page.click('#excelCommitButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('반영하지 않았습니다');assert not a.get_state()['expenseHistory'];page.remove_listener('dialog',cancel);page.on('dialog',accept)
   page.route('**/api/external-excel/history-import',lambda r:r.fulfill(status=500,content_type='application/json',body='{"ok":false,"message":"TEST_SAVE_FAILURE"}'));page.click('#excelCommitButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('반영 실패');expect(page.locator('#excelCommitButton')).to_be_enabled();assert page.locator('.excel-row-check:checked').count()==4 and not a.get_state()['expenseHistory'];page.unroute('**/api/external-excel/history-import');page.click('#excelCommitButton');expect(page.locator('#v_expense_history')).to_be_visible();expect(page.locator('#expenseHistoryImportResult')).to_contain_text('사용정산이력 4건 / 불출 4건 · 반납 3건');assert any('선택 4행' in d and '금액미기재 3행' in d for d in dialogs)
   expect(page.locator('#expenseHistoryTable tr')).to_have_count(4);assert page.locator('#expenseHistoryTable tr').first.locator('td').nth(1).inner_text()=='엑셀 이관';assert page.locator('#expenseHistoryTable tr td:nth-child(7)').filter(has_text='엑셀 이관').count()==0
   heads=page.locator('#expenseHistoryTable').evaluate('(e)=>[...e.previousElementSibling.querySelectorAll("th")].map(x=>x.textContent)');assert heads[:2]==['일련번호','입력경로'];assert page.locator('#expenseHistoryTable').inner_text().count('금액미기재')>=3
   expect(page.locator('#expenseHistorySummary [data-metric=amount]')).to_contain_text('225,000원');expect(page.locator('#expenseHistorySummary [data-metric=approvedDocuments]')).to_contain_text('1건');page.locator('#v_expense_history').screenshot(path=str(screens/'expense_ledger.png'))
   with page.expect_download() as download:page.evaluate('exportExpenseHistoryExcel()')
   export=Path(folder)/'expense.xlsx';download.value.save_as(str(export))
   with ZipFile(export) as z:xml=z.read('xl/worksheets/sheet1.xml').decode();assert '일련번호' in xml and '입력경로' in xml and '엑셀 이관' in xml and '225000' in xml
   data=page.evaluate('expenseHistoryExportRows()');assert len(data)==4 and sum(row[14]=='' for row in data)==3,(data[0],data)
   page.locator('#expenseHistoryTable button').first.click();expect(page.locator('#modalTitle')).to_have_text('엑셀 이관 원본 이력');expect(page.locator('#modalBody')).to_contain_text('결재 기록 없음');page.evaluate("document.body.classList.add('print-expense-detail')");page.emulate_media(media='print');pdf=Path(folder)/'detail.pdf';page.pdf(path=str(pdf),format='A4',print_background=True);page.emulate_media(media='screen');page.evaluate("document.body.classList.remove('print-expense-detail')");subprocess.run(['pdftotext','-layout',str(pdf),str(Path(folder)/'detail.txt')],check=True);assert '엑셀 이관' in (Path(folder)/'detail.txt').read_text();page.evaluate('closeModal()')
   page.locator('#expenseHistoryImportResult button').filter(has_text='불출반납').click();expect(page.locator('#cardHistoryTable tr')).to_have_count(7);heads=page.locator('#cardHistoryTable').evaluate('(e)=>[...e.previousElementSibling.querySelectorAll("th")].map(x=>x.textContent)');assert heads[1]=='입력경로';expect(page.locator('#cardHistoryTable')).to_contain_text('원본 미반납');assert page.locator('#cardHistoryTable td:nth-child(13)').filter(has_text='엑셀 이관').count()==0;page.locator('#v_card_history').screenshot(path=str(screens/'card_history.png'))
   with page.expect_download() as download:page.evaluate('exportHistoryExcel()')
   export=Path(folder)/'history.xlsx';download.value.save_as(str(export))
   with ZipFile(export) as z:xml=z.read('xl/worksheets/sheet1.xml').decode();assert '입력경로' in xml and '엑셀 이관' in xml and '원본 미반납' in xml
   state=a.get_state();assert len(state['expenseHistory'])==4 and len(state['history'])==7 and not state['expense'] and not state['cards'];assert sum(x['amount'] or 0 for x in state['expenseHistory'])==225000;assert all('approvedBy' not in x for x in state['expenseHistory'])
   page.click('#nav_v_external_match');page.click('#excelPreviewButton');expect(page.locator('#excelCommitButton')).to_be_disabled();assert page.locator('.excel-row-duplicate').count()==4;assert not errors,errors
   print('PASS: real browser no-selection warning/cancel/failed-save retention/retry and unchecked confirmation -> concrete 4-row dialog -> expense ledger4, issue4/return3, source columns, stable serials, 3 missing amounts, 225000 summary, raw no-approval detail, real XLSX exports, repeat duplicate4')
   print('PASS: zero active cards/pending expenses created, original missing return preserved, no JS errors, responsive upload 1920/1440/1024/768/390/320px')
   browser.close()
finally:f.SecurityTests.tearDownClass()

@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title YBY V4 Private HTTPS Firewall Setup
echo YBY V4 기본 포트 5000의 사설망 방화벽 규칙을 추가합니다.
echo 접속 범위는 로컬 서브넷입니다. 서버는 README_V4.md의 HTTPS 설정이 필요합니다.
echo V3_PORT를 변경한 경우 이 기본 포트용 도구 대신 실제 포트에 맞는 규칙을 설정하세요.
netsh advfirewall firewall add rule name="YBY V4 HTTPS 5000" dir=in action=allow protocol=TCP localport=5000 profile=private remoteip=localsubnet
if errorlevel 1 (
  echo 실패했습니다. 관리자 권한으로 실행하여 다시 확인하세요.
) else (
  echo 기본 포트 방화벽 규칙을 추가했습니다. 인증서와 서버 주소 설정은 README_V4.md를 확인하세요.
)
pause

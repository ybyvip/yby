param([switch]$CheckOnly, [switch]$NoBrowser, [string]$ServerRoot)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw '일반 더블클릭으로 실행하세요. 인증서는 현재 로그인한 Windows 사용자에게만 등록합니다.'
    }
    if ($ServerRoot) {
        $settings = [IO.File]::ReadAllText((Join-Path $ServerRoot 'lan_settings.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json
        if ($settings.format -ne 1 -or $settings.mode -ne 'lan-https') { throw '사내망 설정 형식이 잘못되었습니다.' }
        $certificate = Join-Path $ServerRoot 'certificates\root-ca.cer'
        $info = @{server_ip=$settings.server_ip; port=$settings.port; sha256=(Get-FileHash -LiteralPath $certificate -Algorithm SHA256).Hash}
        $url = 'https://localhost:' + [int]$info.port
    } else {
        $info = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'connection.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json
        $certificate = Join-Path $PSScriptRoot 'YBY_LAN_ROOT.cer'
        $url = 'https://' + [string]$info.server_ip + ':' + [int]$info.port
    }
    $ip = [Net.IPAddress]::Parse([string]$info.server_ip)
    $bytes = $ip.GetAddressBytes()
    if ($ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork -or -not (
        $bytes[0] -eq 10 -or ($bytes[0] -eq 172 -and $bytes[1] -ge 16 -and $bytes[1] -le 31) -or
        ($bytes[0] -eq 192 -and $bytes[1] -eq 168))) { throw '사내망 IPv4 주소가 아닙니다.' }
    $port = [int]$info.port
    if ($port -lt 1 -or $port -gt 65535) { throw '포트 범위가 잘못되었습니다.' }
    $actual = (Get-FileHash -LiteralPath $certificate -Algorithm SHA256).Hash
    if ($actual -ne [string]$info.sha256 -or $actual -notmatch '^[0-9A-F]{64}$') {
        throw '인증서 SHA-256이 다릅니다. 서버에서 LAN_CLIENT.zip을 다시 받으세요.'
    }
    $ca = New-Object Security.Cryptography.X509Certificates.X509Certificate2($certificate)
    $basic = $ca.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' } | Select-Object -First 1
    if (-not $basic) { throw 'CA 인증서 확장이 없습니다.' }
    $constraints = New-Object Security.Cryptography.X509Certificates.X509BasicConstraintsExtension
    $constraints.CopyFrom($basic)
    if (-not $constraints.CertificateAuthority -or $ca.Subject -notmatch '^CN=YBY LAN Root ' -or $ca.Subject -ne $ca.Issuer) {
        throw '이 파일은 YBY 자체 발급 루트 CA가 아닙니다.'
    }
    if ((Get-Date) -lt $ca.NotBefore -or (Get-Date) -ge $ca.NotAfter) { throw '인증서 유효기간 또는 PC 날짜/시간을 확인하세요.' }
    if ($ServerRoot -and $settings.root_thumbprint -and $ca.Thumbprint -ne $settings.root_thumbprint) {
        throw '서버 설정과 CA 인증서 지문이 다릅니다. 기존 인증서를 보존하고 진단을 요청하세요.'
    }
    Write-Host ('접속 주소: ' + $url)
    Write-Host ('CA SHA-256: ' + $actual)
    $store = New-Object Security.Cryptography.X509Certificates.X509Store('Root','CurrentUser')
    try {
        $store.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
        $installed = @($store.Certificates | Where-Object { $_.Thumbprint -eq $ca.Thumbprint }).Count -gt 0
    } finally { $store.Close() }
    if (-not $installed) {
        if ($CheckOnly) { throw '이 Windows 사용자에게 YBY 인증서가 등록되지 않았습니다. INSTALL_AND_CONNECT.bat를 먼저 실행하세요.' }
        Add-Type -AssemblyName System.Windows.Forms
        $message = "이 YBY 서버의 인증서를 현재 Windows 사용자에게 신뢰 등록합니다.`n`n접속 주소: $url`nCA SHA-256:`n$actual`n`n서버 실행 창의 지문과 같은지 확인하세요.`n이 CA가 발급한 인증서를 Windows와 Edge/Chrome이 신뢰하게 됩니다.`n등록하시겠습니까?"
        $answer = [Windows.Forms.MessageBox]::Show($message, 'YBY 인증서 최초 1회 등록', [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Question, [Windows.Forms.MessageBoxDefaultButton]::Button2)
        if ($answer -ne [Windows.Forms.DialogResult]::Yes) { throw '사용자가 등록을 취소했습니다. 서버와 기존 자료는 유지됩니다.' }
        & "$env:SystemRoot\System32\certutil.exe" -user -addstore Root $certificate
        if ($LASTEXITCODE -ne 0) { throw '인증서 등록 실패: 회사 정책에서 차단하면 IT 담당자의 인증서 배포가 필요합니다.' }
        try {
            $store.Open([Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)
            $installed = @($store.Certificates | Where-Object { $_.Thumbprint -eq $ca.Thumbprint }).Count -gt 0
            if (-not $installed) { throw '현재 사용자의 신뢰 저장소에서 등록된 인증서를 찾지 못했습니다.' }
        } finally { $store.Close() }
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $request = [Net.HttpWebRequest]::Create($url + '/health')
    $request.Proxy = $null
    $request.AllowAutoRedirect = $false
    $request.Timeout = 10000
    $request.ReadWriteTimeout = 10000
    $response = $request.GetResponse()
    try {
        $remote = New-Object Security.Cryptography.X509Certificates.X509Certificate2($request.ServicePoint.Certificate)
        $chain = New-Object Security.Cryptography.X509Certificates.X509Chain
        try {
            # Locally issued YBY certificates have no Internet CRL endpoint.
            $chain.ChainPolicy.RevocationMode = [Security.Cryptography.X509Certificates.X509RevocationMode]::NoCheck
            if (-not $chain.Build($remote)) { throw 'Windows 인증서 체인 검증 실패' }
            $chainRoot = $chain.ChainElements[$chain.ChainElements.Count - 1].Certificate
            if ($chainRoot.Thumbprint -ne $ca.Thumbprint) { throw '접속한 서버의 CA가 전달받은 YBY CA와 다릅니다.' }
        } finally { $chain.Dispose() }
        $reader = New-Object IO.StreamReader($response.GetResponseStream())
        try { $health = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
    } finally { $response.Close() }
    if (-not $health.ok -or -not $health.database -or [string]$health.version -notmatch '^4\.[0-9]+\.[0-9]+$') {
        throw 'YBY 서버/DB 상태 확인 실패 또는 다른 프로그램이 사용하는 포트입니다.'
    }
    Write-Host ('PASS: 현재 사용자 인증서 등록 · HTTPS/주소/CA 검증 · YBY V' + $health.version + ' · DB 정상') -ForegroundColor Green
    if (-not $CheckOnly) {
        try {
            if ($ServerRoot) {
                $connectScript = Join-Path $ServerRoot 'tools\client_templates\client_connect.ps1'
                $shortcutArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $connectScript + '" -ServerRoot "' + $ServerRoot + '"'
            } else {
                # Retain only the public bundle in a stable user directory, including for USB installs.
                $clientHome = Join-Path $env:LOCALAPPDATA ('YBY\clients\' + $actual.Substring(0,16))
                New-Item -ItemType Directory -Path $clientHome -Force | Out-Null
                foreach ($name in @('client_connect.ps1','connection.json','YBY_LAN_ROOT.cer','INSTALL_AND_CONNECT.bat','CHECK_CONNECTION.bat','접속안내.txt')) {
                    $original = Join-Path $PSScriptRoot $name
                    $destination = Join-Path $clientHome $name
                    if ([IO.Path]::GetFullPath($original) -ne [IO.Path]::GetFullPath($destination)) { Copy-Item -LiteralPath $original -Destination $destination -Force }
                }
                $connectScript = Join-Path $clientHome 'client_connect.ps1'
                $shortcutArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $connectScript + '"'
            }
            $shell = New-Object -ComObject WScript.Shell
            $desktop = [Environment]::GetFolderPath('Desktop')
            $shortcut = $shell.CreateShortcut((Join-Path $desktop 'YBY 로그인.lnk'))
            $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $shortcut.Arguments = $shortcutArgs
            $shortcut.WorkingDirectory = Split-Path -Parent $connectScript
            $shortcut.Description = 'YBY 보안 접속 · 로그인 전용 창'
            $shortcut.WindowStyle = 7
            $shortcut.Save()
            Write-Host '바탕화면에 YBY 로그인 바로가기를 만들었습니다. 다음에는 이 아이콘을 사용하세요.'
        } catch {
            Write-Host '바탕화면 바로가기를 만들지 못했습니다. CONNECT_SERVER.bat 또는 INSTALL_AND_CONNECT.bat로 접속할 수 있습니다.'
        }
    }
    if (-not $CheckOnly -and -not $NoBrowser) {
        $browser = $null
        foreach ($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles,$env:LOCALAPPDATA)) {
            if (-not $base) { continue }
            foreach ($relative in @('Microsoft\Edge\Application\msedge.exe','Google\Chrome\Application\chrome.exe')) {
                $candidate = Join-Path $base $relative
                if (Test-Path -LiteralPath $candidate -PathType Leaf) { $browser=$candidate; break }
            }
            if ($browser) { break }
        }
        if ($browser) { Start-Process -FilePath $browser -ArgumentList ('--app="' + $url + '/"') }
        else { Start-Process ($url + '/') }
    }
    exit 0
} catch {
    Write-Host ('연결 실패: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host '서버 창을 열어 두세요. 사내망 IP, 서버 방화벽(Domain/Private), 회사 VPN 경로를 확인하세요.'
    Write-Host 'HTTPS 인증서 경고를 무시하거나 방화벽 전체를 해제하지 마세요.'
    exit 1
}

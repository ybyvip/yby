param([string]$SettingsPath, [switch]$Elevated)
$ErrorActionPreference = 'Stop'
try {
    if (-not $SettingsPath) { $SettingsPath = Join-Path (Split-Path -Parent $PSScriptRoot) 'lan_settings.json' }
    $SettingsPath = [IO.Path]::GetFullPath($SettingsPath)
    if (-not (Test-Path -LiteralPath $SettingsPath -PathType Leaf)) { throw '먼저 RUN_LAN_WINDOWS.bat로 사내망 설정을 만드세요.' }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        if ($Elevated) { throw '관리자 승인이 필요합니다.' }
        Write-Host 'YBY 서버 포트에 한정된 방화벽 규칙을 추가합니다. 관리자 승인을 진행하세요.'
        $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -SettingsPath "' + $SettingsPath + '" -Elevated'
        $process = Start-Process -FilePath $powershell -ArgumentList $arguments -Verb RunAs -Wait -PassThru
        if ($process.ExitCode -ne 0) { throw '방화벽 규칙 등록이 완료되지 않았습니다. 승인 또는 회사 정책을 확인하세요.' }
        Write-Host 'PASS: YBY 서버 방화벽 규칙 등록 완료'
        exit 0
    }
    $settings = [IO.File]::ReadAllText($SettingsPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ($settings.format -ne 1 -or $settings.mode -ne 'lan-https') { throw 'YBY 사내망 설정이 아닙니다.' }
    $port = [int]$settings.port
    if ($port -lt 1 -or $port -gt 65535) { throw '포트 범위 오류' }
    $python = [string]$settings.python_executable
    if (-not [IO.Path]::IsPathRooted($python) -or -not (Test-Path -LiteralPath $python -PathType Leaf) -or [IO.Path]::GetExtension($python) -ne '.exe') {
        throw '설정된 Python 실행 파일이 없습니다. RUN_LAN_WINDOWS.bat를 다시 실행하세요.'
    }
    $name = 'YBY-V4-LAN-HTTPS-' + $port
    $existing = Get-NetFirewallRule -Name $name -ErrorAction SilentlyContinue
    if ($existing) { $existing | Remove-NetFirewallRule }
    New-NetFirewallRule -Name $name -DisplayName ('YBY V4 LAN HTTPS TCP ' + $port) -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -RemoteAddress @('LocalSubnet','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16') -Profile @('Domain','Private') -Program $python | Out-Null
    Write-Host ('PASS: TCP ' + $port + ' / 회사·개인 프로필 / 사내망 주소 / 지정 Python만 허용')
    Get-NetConnectionProfile | Select-Object -Property @('InterfaceAlias','NetworkCategory') | Format-Table
    Write-Host '공용(Public) 네트워크 프로필은 허용하지 않습니다. 회사 정책/망 ACL/VPN 경로는 IT 담당자 설정을 따릅니다.'
    if ($Elevated) { Read-Host '확인 후 Enter' | Out-Null }
    exit 0
} catch {
    Write-Host ('방화벽 설정 실패: ' + $_.Exception.Message) -ForegroundColor Red
    if ($Elevated) { Read-Host '오류 확인 후 Enter' | Out-Null }
    exit 1
}

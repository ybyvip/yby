"""Explicit 1:1 links between independent received documents; no Oracle SQL.

Matches never rewrite processed financial records. All changes share the business
transaction, version token, scoped immutable history and idempotent receipt.
"""
from copy import deepcopy
import json,uuid
import external_documents as documents

PERMISSIONS={'v_external_match','v_card_rent','v_expense'}

def initialize(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS external_document_matches(id TEXT PRIMARY KEY,application_key TEXT UNIQUE NOT NULL,settlement_key TEXT UNIQUE NOT NULL,branch TEXT NOT NULL,payload TEXT NOT NULL)')
    conn.execute('CREATE INDEX IF NOT EXISTS ix_matches_branch ON external_document_matches(branch)')
    conn.execute('CREATE TABLE IF NOT EXISTS external_match_events(id TEXT PRIMARY KEY,branch TEXT NOT NULL,payload TEXT NOT NULL)')
    conn.execute('CREATE INDEX IF NOT EXISTS ix_match_events_branch ON external_match_events(branch)')

def require(a,user):
    if a.user_scope(user)!='ALL' and not a.permissions_for(user).intersection(PERMISSIONS):raise PermissionError('외부자료 매칭 권한이 없습니다.')

def for_document(conn,key):
    row=conn.execute('SELECT payload FROM external_document_matches WHERE application_key=? OR settlement_key=?',(key,key)).fetchone()
    return json.loads(row[0]) if row else None

def binding(conn,key):
    row=conn.execute('SELECT target_ref FROM external_document_bindings WHERE document_key=?',(key,)).fetchone()
    return json.loads(row[0]) if row else None

def document_pair(conn,pair):return documents.load(conn,pair['applicationKey']),documents.load(conn,pair['settlementKey'])

def target(conn,pair,state):
    app,settlement=document_pair(conn,pair)
    used=binding(conn,settlement['key'])
    if used:return {'phase':'applied','label':'반납·정산 저장완료','expenseRef':used['target']}
    bound=binding(conn,app['key'])
    if not bound:
        if app.get('source')=='EXCEL' and not any(documents.card_matches(app,c) and documents.card_matches(settlement,c) for c in state.get('cards',[])):
            return {'phase':'awaiting_card','label':'매칭완료 · 카드 등록 후 불출','cardLast4':app.get('cardLast4','')}
        return {'phase':'awaiting_issue','label':'매칭완료 · 불출 대기'}
    ref=bound['target'];event_id=ref.get('rentalEventId')
    issue=next((e for e in state.get('history',[]) if e.get('group')==pair['group'] and str(e.get('id'))==str(event_id) and e.get('type')=='불출' and (e.get('sourceRef') or {}).get('key')==app['key']),None)
    if not issue:return {'phase':'review','label':'불출 연결 확인 필요'}
    returned=next((e for e in state.get('history',[]) if e.get('type')=='반납' and e.get('group')==issue['group'] and str(e.get('rentalEventId'))==str(issue['id']) and e.get('cardNum')==issue.get('cardNum')),None)
    if returned:return {'phase':'returned','label':'반납 처리됨 · 기존 내역 확인','rentalEventId':event_id,'expenseRef':returned.get('expenseRef'),'returnEventId':returned['id']}
    card=next((c for c in state.get('cards',[]) if c.get('status')=='rented' and c.get('group')==issue['group'] and str(c.get('rentalEventId'))==str(event_id) and c.get('num')==issue.get('cardNum') and (c.get('sourceRef') or {}).get('key')==app['key']),None)
    if not card:return {'phase':'review','label':'현재 불출 상태 확인 필요'}
    if not documents.card_matches(settlement,card):return {'phase':'review','label':'정산서와 실제 카드 끝자리 확인 필요'}
    return {'phase':'rented','label':'반납·정산 가능','cardId':card['id'],'cardNum':card['num'],'user':card.get('user',''),'rentalEventId':event_id}

def frozen(conn,pair,state):
    info=target(conn,pair,state)
    return info['phase'] in ('applied','returned')

def describe(conn,pair,state):
    app,settlement=document_pair(conn,pair);result=deepcopy(pair)
    stale=app['revision']!=pair['applicationRevision'] or settlement['revision']!=pair['settlementRevision']
    withdrawn=app['withdrawn'] or settlement['withdrawn']
    result.update(application=app,settlement=settlement,target=target(conn,pair,state),stale=stale,withdrawn=withdrawn,locked=frozen(conn,pair,state))
    return result

def listing(conn,state,scope,q='',offset=0):
    sql='SELECT payload FROM external_document_matches';args=[]
    if scope!='ALL':sql+=' WHERE branch=?';args.append(scope)
    sql+=' ORDER BY rowid DESC'
    pairs=[]
    for raw, in conn.execute(sql,args):
        pair=json.loads(raw);detail=describe(conn,pair,state)
        haystack=' '.join(str(d.get(k,'')) for d in (detail['application'],detail['settlement']) for k in ('documentNo','applicantName','user','dept','purpose'))
        if q and q.casefold() not in haystack.casefold():continue
        pairs.append(detail)
    return {'total':len(pairs),'items':pairs[offset:offset+50]}

def history(conn,scope,pair_id,offset=0):
    sql='SELECT payload FROM external_match_events WHERE 1=1';args=[]
    if scope!='ALL':sql+=' AND branch=?';args.append(scope)
    sql+=' ORDER BY rowid DESC'
    items=[json.loads(raw) for raw, in conn.execute(sql,args)]
    if pair_id:items=[item for item in items if item.get('matchId')==pair_id]
    return {'total':len(items),'items':items[offset:offset+50]}

def change(a,conn,state,data,user,scope,path):
    require(a,user)
    old=None
    if path.endswith('/update') or path.endswith('/delete'):
        raw=conn.execute('SELECT payload FROM external_document_matches WHERE id=?',(data.get('id'),)).fetchone()
        if not raw:raise ValueError('매칭을 찾을 수 없습니다. 새로 조회하세요.')
        old=json.loads(raw[0])
        if scope not in ('ALL',old['group']):raise PermissionError('다른 지점 매칭입니다.')
        if data.get('expectedVersion')!=old['version']:raise a.StateConflict('매칭이 변경되었습니다. 다시 확인하세요.')
        if frozen(conn,old,state):raise ValueError('이미 반납·정산 저장된 매칭은 변경할 수 없습니다. 기존 승인취소·정정 절차를 이용하세요.')
        reason=documents.short(data.get('reason',''),'매칭 변경 사유',True,1000)
        auth=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
        if not auth or not a.verify_password(auth[0],data.get('password','')):raise PermissionError('현재 로그인 비밀번호를 확인하세요.')
    else:reason=documents.short(data.get('reason',''),'매칭 메모',False,1000) or '두 문서 내용 확인 후 연결'
    new=None
    if not path.endswith('/delete'):
        if data.get('confirmed') is not True:raise ValueError('신청서·정산서의 사용 건을 확인하세요.')
        app=documents.load(conn,data.get('applicationKey'));settlement=documents.load(conn,data.get('settlementKey'))
        if app['kind']!='application' or settlement['kind']!='settlement':raise ValueError('신청서와 정산서를 각각 선택하세요.')
        if app['group']!=settlement['group'] or scope not in ('ALL',app['group']):raise PermissionError('같은 담당 지점의 두 문서만 연결할 수 있습니다.')
        if old and old['group']!=app['group']:raise PermissionError('기존 매칭의 지점을 바꿀 수 없습니다.')
        if app['withdrawn'] or settlement['withdrawn']:raise ValueError('회수·삭제된 원문은 새로 매칭할 수 없습니다.')
        for doc,key in ((app,'applicationRevision'),(settlement,'settlementRevision')):
            if type(data.get(key))!=int or data[key]!=doc['revision']:raise a.StateConflict('원문이 갱신되었습니다. 두 문서를 다시 확인하세요.')
        if app.get('cardLast4') and app['cardLast4']!=settlement.get('cardLast4'):raise ValueError('두 문서의 카드 끝자리가 다릅니다.')
        existing=conn.execute('SELECT id FROM external_document_matches WHERE (application_key=? OR settlement_key=?) AND id<>?',(app['key'],settlement['key'],old['id'] if old else '')).fetchone()
        if existing:raise ValueError('이미 다른 문서와 매칭된 자료입니다. 기존 연결을 먼저 확인하세요.')
        if app.get('originRowKey') and settlement.get('originRowKey') and app['originRowKey']!=settlement['originRowKey']:
            raise ValueError('엑셀의 서로 다른 원본 행입니다. 같은 행의 신청·정산 자료를 선택하세요.')
        new={'id':old['id'] if old else uuid.uuid4().hex,'group':app['group'],'applicationKey':app['key'],'settlementKey':settlement['key'],'applicationRevision':app['revision'],'settlementRevision':settlement['revision'],'version':uuid.uuid4().hex,'createdAt':old['createdAt'] if old else a.now(),'createdBy':old['createdBy'] if old else user,'updatedAt':a.now(),'updatedBy':user,'reason':reason,'applicationSnapshot':deepcopy(app),'settlementSnapshot':deepcopy(settlement)}
        if binding(conn,settlement['key']) or frozen(conn,new,state):raise ValueError('이미 반납·정산 저장된 자료는 새로 매칭할 수 없습니다. 기존 내역을 확인하세요.')
        bound=binding(conn,app['key'])
        if bound and target(conn,new,state)['phase']!='rented':raise ValueError('현재 불출 건과 정산서 카드가 연결되는지 확인하세요.')
        import external_reception
        for source_doc in (app,settlement):external_reception.acknowledge(conn,source_doc,user,a.now())
        conn.execute('INSERT INTO external_document_matches VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET application_key=excluded.application_key,settlement_key=excluded.settlement_key,payload=excluded.payload',(new['id'],app['key'],settlement['key'],app['group'],json.dumps(new,ensure_ascii=False)))
    else:conn.execute('DELETE FROM external_document_matches WHERE id=?',(old['id'],))
    event={'id':uuid.uuid4().hex,'matchId':(new or old)['id'],'group':(new or old)['group'],'action':'매칭 해제' if new is None else '매칭 수정' if old else '매칭 등록','actor':user,'time':a.now(),'reason':reason,'before':old,'after':new}
    conn.execute('INSERT INTO external_match_events VALUES(?,?,?)',(event['id'],event['group'],json.dumps(event,ensure_ascii=False)))
    return {'match':new,'deleted':new is None}

def validate_return(conn,state,document,card,data):
    """A document pair identifies an exact episode, never just last four digits."""
    app_key=(card.get('sourceRef') or {}).get('key')
    expected=for_document(conn,app_key) if app_key else None
    if expected and (not document or document['key']!=expected['settlementKey']):raise ValueError('이 신청서에 매칭된 외부 정산서를 선택하여 반납·정산하세요.')
    if not document:return None
    pair=for_document(conn,document['key'])
    if not pair:return None  # Manual YBY rentals keep the existing reviewed source flow.
    if data.get('externalMatchVersion')!=pair['version']:raise ValueError('매칭이 변경되었습니다. 외부 정산서를 다시 선택하세요.')
    detail=describe(conn,pair,state)
    if detail['locked']:raise ValueError('이미 처리한 매칭입니다. 기존 정산을 확인하세요.')
    if detail['stale'] or detail['withdrawn']:raise ValueError('매칭 원문이 변경·회수되었습니다. 매칭 화면에서 다시 확인하세요.')
    info=detail['target']
    if info['phase']!='rented' or str(info['cardId'])!=str(card['id']) or str(info['rentalEventId'])!=str(card.get('rentalEventId')):raise ValueError('매칭 신청서의 실제 불출 건과 다릅니다.')
    return {k:pair[k] for k in ('id','version','applicationKey','settlementKey','applicationRevision','settlementRevision')}

"""Positive settlement revisions with preserved cancellation/review history."""
import copy
import uuid
import domain

EDITABLE=('date','user','dept','merchant','purpose','amount','category','attendees','note','lineItems','attachments')

def text(value,label):
    if not isinstance(value,str) or not value.strip() or len(value)>1000:raise ValueError(label+'는 1~1000자로 입력하세요.')
    return value.strip()

def find(rows,data):
    key=(str(data.get('group','')),str(data.get('requester','')),str(data.get('id','')))
    return next((row for row in rows if domain.identity(row)==key),None)

def message(row,kind,user,at,content):
    row.setdefault('reviewMessages',[]).append({'id':uuid.uuid4().hex,'type':kind,'author':user,'time':at,'text':content})

def change(a,state,data,user,scope,path,validate_attachments):
    pending=state.setdefault('expense',[]);ledger=state.setdefault('expenseHistory',[])
    if path=='/api/expenses/resubmit':
        row=find(pending,data)
        if not row or row.get('status')!='재보고대기':raise ValueError('수정할 재보고 대기 정산을 찾을 수 없습니다.')
        a.require_permission(user,'v_expense')
        if scope!='ALL' and (scope!=row['group'] or row['requester']!=user):raise PermissionError('본인 정산만 수정·재보고할 수 있습니다.')
        content=text(data.get('message'),'재보고 메시지');edits=data.get('expense')
        if not isinstance(edits,dict):raise ValueError('수정 정산 양식이 필요합니다.')
        retained=copy.deepcopy(row.get('attachments',[]))
        row.update({key:edits[key] for key in EDITABLE if key in edits})
        domain.prepare_expense(row);domain.expense(row,state.get('cards',[]))
        row['attachments']=validate_attachments(row.get('attachments',[]),user,row['group'],retained)
        at=a.now();row.update(status='승인대기',requestedAt=at,resubmittedAt=at,resubmittedBy=user,reapproval=True)
        message(row,'resubmit',user,at,content)
        return {'expense':row}
    row=find(ledger,data)
    if not row:raise ValueError('원래 정산 이력을 찾을 수 없습니다.')
    if row.get('isCorrection') or row.get('correctionId') or row.get('resubmissionId'):raise ValueError('이미 후속 처리되었거나 이전 버전에서 정정 완료된 자료입니다.')
    reason=text(data.get('reason'),'승인취소·재보고 사유');cancelled=path=='/api/expenses/correct'
    if cancelled:
        if scope!='ALL':raise PermissionError('최고관리자만 승인 취소할 수 있습니다.')
        with a.db() as conn:actor=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
        if not actor or not a.verify_password(actor[0],data.get('password','')):raise PermissionError('현재 관리자 비밀번호를 확인하세요.')
        if row.get('status')!='승인완료':raise ValueError('승인완료 정산만 승인 취소할 수 있습니다.')
    else:
        a.require_permission(user,'v_expense')
        if scope!='ALL' and (scope!=row['group'] or row['requester']!=user):raise PermissionError('본인 반려 정산만 재보고할 수 있습니다.')
        if row.get('status')!='반려됨':raise ValueError('반려 정산만 다시 작성할 수 있습니다.')
    at=a.now();new_id=uuid.uuid4().hex
    reference={'id':row['id'],'group':row['group'],'requester':row.get('requester','')}
    if not row.get('reviewMessages') and row.get('approvedBy') and row.get('approvedAt'):
        message(row,'approve',row['approvedBy'],row['approvedAt'],'이전 버전 승인 완료')
    message(row,'cancel' if cancelled else 'reopen',user,at,reason);draft=copy.deepcopy(row)
    for key in ('approvedBy','approvedAt','rejectedBy','rejectedAt','decisionReason','selfApproved','selfDecision','cancelledAt','cancelledBy','cancelReason','resubmissionId','correctionId','isCorrection','correctsId'):
        draft.pop(key,None)
    draft.update(id=new_id,status='재보고대기',requestedAt=at,draftCreatedAt=at,replaces=reference,
                 correctionRoot=row.get('correctionRoot',reference),correctionCycle=int(row.get('correctionCycle',0))+1,correctionReason=reason,reapproval=True)
    domain.expense(draft,state.get('cards',[]));row['resubmissionId']=new_id
    if cancelled:row.update(status='승인취소',cancelledAt=at,cancelledBy=user,cancelReason=reason)
    pending.append(draft)
    return {'expense':draft,'original':row}

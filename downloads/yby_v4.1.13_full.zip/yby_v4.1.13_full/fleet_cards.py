"""Scoped Hi-pass/fuel bundles, immutable change documents and confirmation."""
from copy import deepcopy
import re
import uuid
import domain

STATUSES=('대기중','불출중','회수중','회수완료')
CLASSES=('임원','직원','직영승무원','업무용차량','기타')
COMMON=('hipassUser','car','issueArea','route','reason','classification','returnDate','distributionStatus')
HIPASS=('type','company','num','issueDate','expiryDate')
FUEL=('company','num','paymentType','usageScope','userType','assignedUser','issueDate','expiryDate','cardAlias')

def enum(value,choices,label,optional=False):
    if optional and value in (None,''):return
    if value not in choices:raise ValueError(label+'을 선택하세요.')

def text(value,label,required=False,limit=200):
    if not isinstance(value,str) or len(value)>limit or (required and not value.strip()):raise ValueError(label+' 형식 오류')
    return value.strip()

def validate(row):
    enabled=row.get('hipassEnabled',True);fuel=row.get('fuelEnabled',False)
    if type(enabled)!=bool or type(fuel)!=bool or not (enabled or fuel):raise ValueError('하이패스 또는 유류대카드를 선택하세요.')
    text(row.get('hipassUser',''),'실사용자',True)
    enum(row.get('classification'),CLASSES,'사용 분류',optional=True)
    if row.get('reviewStatus') not in (None,'draft','confirmed'):raise ValueError('확인 상태 오류')
    enum(row.get('distributionStatus'),STATUSES,'배부 상태',optional=True)
    domain.date_value(row.get('returnDate'),'회수일')
    if row.get('distributionStatus')=='회수완료' and not row.get('returnDate'):raise ValueError('회수완료는 실제 회수일이 필요합니다.')
    if enabled:
        enum(row.get('type'),('선불형','후불형'),'하이패스 구분')
        text(row.get('company',''),'하이패스 발급사',True);text(row.get('num',''),'하이패스 번호',True,80)
        for f in ('issueDate','expiryDate','returnDate'):domain.date_value(row.get(f),f,f!='returnDate')
        if row['expiryDate']<row['issueDate']:raise ValueError('하이패스 만료일이 발급일보다 빠릅니다.')
        if row.get('returnDate') and row['returnDate']<row['issueDate']:raise ValueError('회수일이 발급일보다 빠릅니다.')
    if fuel:
        card=row.get('fuelCard')
        if not isinstance(card,dict):raise ValueError('유류대카드 정보가 필요합니다.')
        for f in ('company','num'):text(card.get(f,''),'유류대 '+f,True,80 if f=='num' else 200)
        enum(card.get('paymentType'),('신용','체크'),'유류대 신용/체크')
        enum(card.get('usageScope'),('국내전용','해외겸용'),'유류대 사용 범위')
        enum(card.get('userType'),('지정','비지정'),'유류대 사용자 구분')
        if card['userType']=='지정':text(card.get('assignedUser',''),'유류대 지정 사용자',True)
        for f in ('issueDate','expiryDate'):domain.date_value(card.get(f),f,True)
        if card['expiryDate']<card['issueDate']:raise ValueError('유류대 만료일이 발급일보다 빠릅니다.')
        if row.get('returnDate') and row['returnDate']<card['issueDate']:raise ValueError('유류대 회수일이 발급일보다 빠릅니다.')

def normalize(data,group):
    modern='hipassEnabled' in data or 'fuelEnabled' in data
    row={f:text(data.get(f,''),f,limit=2000 if f=='reason' else 200) for f in COMMON+HIPASS}
    row.update(group=group,hipassEnabled=data.get('hipassEnabled',True),fuelEnabled=data.get('fuelEnabled',False))
    if modern:enum(row['classification'],CLASSES,'사용 분류')
    if row['fuelEnabled']:
        if not isinstance(data.get('fuelCard'),dict):raise ValueError('유류대카드 정보가 필요합니다.')
        row['fuelCard']={f:text(data['fuelCard'].get(f,''),'유류대 '+f) for f in FUEL}
    if not row['hipassEnabled']:
        for f in HIPASS:row[f]=''
    if 'distributionStatus' not in data:row.pop('distributionStatus',None)
    validate(row);return row

def numbers(row):
    values=[]
    if row.get('hipassEnabled',True):values.append(row.get('num',''))
    if row.get('fuelEnabled'):values.append(row.get('fuelCard',{}).get('num',''))
    return [re.sub(r'[\s-]','',x).casefold() for x in values]

def unique(rows):
    seen=set()
    for row in rows:
        for num in numbers(row):
            if not num or num in seen:raise ValueError('하이패스·유류대 카드번호가 중복됩니다.')
            seen.add(num)

def change(a,conn,state,data,user,scope,path):
    a.require_permission(user,'v_hipass_reg')
    rows=state.setdefault('hipass',[]);events=state.setdefault('hipassBox',[])
    if data.get('distributionStatus')=='회수완료' and data.get('returnDate','')>a.business_date():raise ValueError('실제 회수일은 오늘 이후일 수 없습니다.')
    if path.endswith('/register'):
        group=data.get('group') if scope=='ALL' else scope
        if group not in domain.BRANCHES:raise ValueError('지점 오류')
        row=normalize(data,group)
        row.update(id=max([int(x['id']) for x in rows if str(x.get('id','')).isdigit()]+[int(state.get('_next_hipass_id') or 100)])+1,
                   reviewStatus='draft',recordVersion=uuid.uuid4().hex,date=a.business_date(),createdBy=user,createdAt=a.now())
        state['_next_hipass_id']=row['id'];rows.append(row);unique(rows)
        event(events,None,row,'최초등록',user,a.now(),'신규 등록 · 확인 대기');return {'hipass':row}
    targets=[x for x in rows if str(x.get('id'))==str(data.get('id')) and x.get('group')==data.get('recordGroup')]
    if len(targets)!=1:raise ValueError('대상 묶음을 찾을 수 없습니다.')
    old=targets[0]
    if scope not in ('ALL',old['group']):raise PermissionError('다른 지점 자료입니다.')
    if data.get('expectedVersion')!=old.get('recordVersion'):raise a.StateConflict('자료가 변경되었습니다. 다시 열어 확인하세요.')
    if path.endswith('/confirm'):
        if old.get('reviewStatus')=='confirmed':raise ValueError('이미 확인된 자료입니다.')
        before=deepcopy(old);old.update(reviewStatus='confirmed',confirmedBy=user,confirmedAt=a.now(),recordVersion=uuid.uuid4().hex)
        event(events,before,old,'정보확인',user,a.now(),'입력 정보 미리보기 후 확인');return {'hipass':old}
    reason=text(data.get('changeReason',''),'수정·삭제 사유',True,1000)
    auth=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
    if not auth or not a.verify_password(auth[0],data.get('password','')):raise PermissionError('현재 로그인 계정의 비밀번호를 확인하세요.')
    if path.endswith('/delete'):
        rows.remove(old);event(events,old,None,'카드삭제',user,a.now(),reason);return {'deleted':old['id']}
    group=data.get('group') if scope=='ALL' else scope
    if group not in domain.BRANCHES:raise ValueError('지점 오류')
    new=normalize(data,group);new.update(id=old['id'],date=old.get('date',a.business_date()),createdAt=old.get('createdAt'),createdBy=old.get('createdBy'),reviewStatus='draft',recordVersion=uuid.uuid4().hex)
    if 'distributionStatus' not in data and old.get('distributionStatus'):new['distributionStatus']=old['distributionStatus'];validate(new)
    if new.get('distributionStatus')=='회수완료' and new.get('returnDate','')>a.business_date():raise ValueError('실제 회수일은 오늘 이후일 수 없습니다.')
    if all(new.get(k)==old.get(k) for k in COMMON+HIPASS+('group','hipassEnabled','fuelEnabled','fuelCard')):raise ValueError('변경한 내용이 없습니다.')
    rows[rows.index(old)]=new;unique(rows)
    event(events,old,new,'정보수정',user,a.now(),reason);return {'hipass':new}

def event(events,before,after,action,user,at,reason):
    groups={x['group'] for x in (before,after) if x};change_id=uuid.uuid4().hex
    for group in groups:
        visible_before=deepcopy(before) if before and before['group']==group else None
        visible_after=deepcopy(after) if after and after['group']==group else None
        row=visible_after or visible_before
        events.append({**deepcopy(row),'id':uuid.uuid4().hex,'recordId':row['id'],'action':action,'handler':user,'time':at,
                       'changeReason':reason,'changeId':change_id,'before':visible_before,'after':visible_after})

def selected(rows,scope,params):
    q=params.get('q',[''])[0][:200].casefold();group=params.get('group',[''])[0];category=params.get('classification',[''])[0]
    return [r for r in rows if scope in ('ALL',r.get('group')) and (not group or r.get('group')==group)
            and (not category or r.get('classification','')==category)
            and (not q or q in str(r).casefold())]

def workbook_rows(rows):
    headers=['묶음ID','소속지점','사용분류','실사용자','차량번호','카드종류','발급사','카드번호','선불/후불·신용/체크','사용범위','지정구분','지정사용자','발급일','만료일','회수일','불출지역','운행노선','등록사유','확인상태','확인자','확인일시']
    result=[]
    for r in rows:
        common=[r['id'],r['group'],r.get('classification') or '미분류',r.get('hipassUser',''),r.get('car','')]
        tail=[r.get('returnDate',''),r.get('issueArea',''),r.get('route',''),r.get('reason',''),{'draft':'확인대기','confirmed':'확인완료'}.get(r.get('reviewStatus'),'기존자료·확인미기록'),r.get('confirmedBy',''),r.get('confirmedAt','')]
        if r.get('hipassEnabled',True):result.append(common+['하이패스',r.get('company',''),r.get('num',''),r.get('type',''),'','','',r.get('issueDate',''),r.get('expiryDate','')]+tail)
        if r.get('fuelEnabled'):
            f=r['fuelCard'];result.append(common+['유류대',f['company'],f['num'],f['paymentType'],f['usageScope'],f['userType'],f.get('assignedUser',''),f['issueDate'],f['expiryDate']]+tail)
    return headers,result


def distribution_status(row,today):
    """Legacy inference is display-only; review and physical distribution are separate."""
    if row.get('distributionStatus') in STATUSES:return row['distributionStatus']
    if row.get('returnDate'):return '회수완료' if row['returnDate']<=today else '회수예정'
    if row.get('reviewStatus')=='draft':return '대기중'
    return '불출중' if row.get('hipassUser') else '대기중'

def history_context(event,records,events,today):
    """Resolve only stable scoped IDs, or one unambiguous legacy card number."""
    snap=event.get('after') or event.get('before') or event
    rid=event.get('recordId')
    if rid is not None:
        matches=[r for r in records if str(r.get('id'))==str(rid) and r.get('group')==event.get('group')]
        related=[e for e in events if str(e.get('recordId'))==str(rid) and e.get('group')==event.get('group')]
    else:
        nums=set(numbers(snap));nums.discard('')
        matches=[r for r in records if r.get('group')==event.get('group') and nums.intersection(numbers(r))] if nums else []
        related=[event]
    current=matches[0] if len(matches)==1 else None
    created=(current or {}).get('createdAt') or snap.get('createdAt') or (current or {}).get('date') or snap.get('date')
    if not created:
        original=next((e for e in related if e.get('action')=='최초등록'),None)
        created=original.get('time') if original else None
    if current:status=distribution_status(current,today)
    elif any(e.get('action')=='카드삭제' for e in related):status='삭제됨'
    elif any(e.get('action')=='정보수정' and e.get('before') and e.get('after') is None for e in related):status='이관됨'
    else:status='현재자료 없음' if rid is not None else '확인불가'
    return created or '미기록',status

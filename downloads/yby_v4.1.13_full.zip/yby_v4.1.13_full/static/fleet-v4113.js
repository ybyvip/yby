/* Hi-pass and fuel bundles. All mutations, confirmation and history are server-owned. */
const fleetUI={owner:null,editing:null,preview:null,openBranches:new Set()};
const fleetClasses=['임원','직원','직영승무원','업무용차량','기타'];
const fleetStates=['대기중','불출중','회수중','회수완료'];
const fleetLabels={distributionStatus:'배부 상태',group:'소속지점',classification:'사용 분류',hipassUser:'실사용자',car:'차량번호',returnDate:'회수일 / 회수 예정일',issueArea:'불출지역',route:'운행노선',reason:'등록·사용 사유',type:'선불/후불',company:'발급사',num:'카드번호',issueDate:'발급일',expiryDate:'만료일',paymentType:'신용/체크',usageScope:'사용 범위',userType:'지정 구분',assignedUser:'지정 사용자',cardAlias:'카드 특정명'};
function fleetEscape(value){return escapeHtml(String(value??''));}
function fleetSelect(id,label,options,value='',required=false){return `<div class="form-group"><label for="${id}">${label}</label><select id="${id}" ${required?'required':''}>${options.map(x=>`<option value="${fleetEscape(x)}" ${x===value?'selected':''}>${fleetEscape(x||'선택하세요')}</option>`).join('')}</select></div>`;}
function fleetInput(id,label,value='',type='text',required=false){return `<div class="form-group"><label for="${id}">${label}</label><input id="${id}" type="${type}" value="${fleetEscape(value)}" maxlength="${id.endsWith('Reason')?'2000':'200'}" ${required?'required':''}></div>`;}
function fleetFieldsHTML(prefix,row={}){
    const fuel=row.fuelCard||{},fuelPrefix=prefix==='regHipass'?'regFuel':'editFuel';
    const input=(key,type='text',required=false)=>fleetInput(prefix+(key==='hipassUser'?'User':key[0].toUpperCase()+key.slice(1)),fleetLabels[key],row[key]||'',type,required);
    const fuelInput=(key,type='text',required=false)=>fleetInput(fuelPrefix+key[0].toUpperCase()+key.slice(1),fleetLabels[key],fuel[key]||'',type,required);
    return `<fieldset class="fleet-choice"><legend>등록할 카드 선택</legend><label><input type="checkbox" id="${prefix}Enabled" ${row.hipassEnabled!==false?'checked':''} onchange="fleetToggleFields('${prefix}')">하이패스</label><label><input type="checkbox" id="${prefix}FuelEnabled" ${row.fuelEnabled?'checked':''} onchange="fleetToggleFields('${prefix}')">유류대카드</label></fieldset>
      <section class="fleet-section"><h3>공통 배부 정보</h3><div class="fleet-grid">${fleetSelect(prefix+'Group','소속지점',['본사','서울','인천','정봉','임원실'],row.group||(userScope==='ALL'?'본사':userScope),true)}${fleetSelect(prefix+'Classification','사용 분류',['',...fleetClasses],row.classification||'',true)}${input('hipassUser','text',true)}${input('car')}${fleetSelect(prefix+'DistributionStatus','배부 상태',fleetStates,row.distributionStatus||(row.id?(['회수예정','불출중'].includes(fleetStatus(row))?'불출중':fleetStatus(row)):'대기중'),true)}${input('returnDate','date')}${input('issueArea')}${input('route')}${input('reason')}</div></section>
      <fieldset class="fleet-section" id="${prefix}CardFields"><legend>하이패스 카드</legend><div class="fleet-grid">${fleetSelect(prefix+'Type','카드 구분',['선불형','후불형'],row.type||'선불형',true)}${input('company','text',true)}${input('num','text',true)}${fleetInput(prefix+'IssueDate','발급일',row.issueDate||(row.id&&row.hipassEnabled!==false?'':localDate()),'date',true)}${input('expiryDate','date',true)}</div></fieldset>
      <fieldset class="fleet-section" id="${prefix}FuelFields"><legend>유류대카드</legend><div class="fleet-grid">${fleetSelect(fuelPrefix+'PaymentType','신용/체크',['','신용','체크'],fuel.paymentType||'',true)}${fleetSelect(fuelPrefix+'UsageScope','사용 범위',['','국내전용','해외겸용'],fuel.usageScope||'',true)}${fuelInput('company','text',true)}${fuelInput('num','text',true)}${fleetSelect(fuelPrefix+'UserType','사용자 구분',['비지정','지정'],fuel.userType||'비지정')}${fuelInput('assignedUser')}${fleetInput(fuelPrefix+'IssueDate','발급일',fuel.issueDate||(row.fuelEnabled?'':localDate()),'date',true)}${fuelInput('expiryDate','date',true)}${fuelInput('cardAlias')}</div></fieldset>`;
}
function fleetToggleFields(prefix){
    const hp=document.getElementById(prefix+'Enabled'),fuel=document.getElementById(prefix+'FuelEnabled');if(!hp||!fuel)return;
    for(const [suffix,checked] of [['CardFields',hp.checked],['FuelFields',fuel.checked]]){const f=document.getElementById(prefix+suffix);f.hidden=!checked;f.disabled=!checked;}
    const group=document.getElementById(prefix+'Group');group.disabled=userScope!=='ALL';if(userScope!=='ALL'){group.value=userScope;group.disabled=true;}
}
function fleetCollect(prefix){
    const get=(key)=>document.getElementById(prefix+(key==='hipassUser'?'User':key[0].toUpperCase()+key.slice(1))).value.trim();
    const row={group:get('group'),classification:get('classification'),hipassEnabled:document.getElementById(prefix+'Enabled').checked,fuelEnabled:document.getElementById(prefix+'FuelEnabled').checked};
    for(const key of ['hipassUser','car','returnDate','distributionStatus','issueArea','route','reason','type','company','num','issueDate','expiryDate'])row[key]=get(key);
    if(row.fuelEnabled){const p=prefix==='regHipass'?'regFuel':'editFuel';row.fuelCard={};for(const key of ['paymentType','usageScope','company','num','userType','assignedUser','issueDate','expiryDate','cardAlias'])row.fuelCard[key]=document.getElementById(p+key[0].toUpperCase()+key.slice(1)).value.trim();}
    if(!row.hipassEnabled&&!row.fuelEnabled)throw Error('하이패스 또는 유류대카드를 선택하세요.');return row;
}
function fleetScoped(){return hipassData.filter(x=>userScope==='ALL'||x.group===userScope);}
function fleetStatus(row){
    if(fleetStates.includes(row.distributionStatus))return row.distributionStatus;
    if(row.returnDate)return row.returnDate<=localDate()?'회수완료':'회수예정';
    if(row.reviewStatus==='draft')return '대기중';
    return row.hipassUser?'불출중':'대기중';
}
function fleetReview(row){return row.reviewStatus==='confirmed'?'확인완료':row.reviewStatus==='draft'?'확인대기':'기존자료 · 확인미기록';}
function fleetCardsHTML(row){const cells=(title,card)=>`<div class="fleet-card-line"><strong>${title}</strong><span>${fleetEscape(card.company)} · ${fleetEscape(card.num)}</span><small>${fleetEscape(card.type||card.paymentType||'')} ${fleetEscape(card.usageScope||'')} · 발급 ${fleetEscape(card.issueDate||'미기록')} / 만료 ${fleetEscape(card.expiryDate||'미기록')}</small>${card.userType?'<small>'+fleetEscape(card.userType)+(card.assignedUser?' · '+fleetEscape(card.assignedUser):'')+(card.cardAlias?' · '+fleetEscape(card.cardAlias):'')+'</small>':''}</div>`;return (row.hipassEnabled!==false?cells('하이패스',row):'')+(row.fuelEnabled?cells('유류대카드',row.fuelCard):'');}
function fleetDocumentHTML(row){return `<article id="expenseDetailPrintArea" class="fleet-document"><h2>하이패스·유류대카드 등록 정보</h2><p>묶음 ${fleetEscape(row.id)} · ${fleetEscape(fleetReview(row))} · ${fleetEscape(fleetStatus(row))}</p><dl>${['group','classification','hipassUser','car','returnDate','distributionStatus','issueArea','route','reason'].map(k=>'<dt>'+fleetLabels[k]+'</dt><dd>'+fleetEscape(row[k]||'미기록')+'</dd>').join('')}</dl>${fleetCardsHTML(row)}</article>`;}
function fleetFind(id,group){return hipassData.find(x=>String(x.id)===String(id)&&x.group===group);}
function fleetRef(row){return {id:row.id,recordGroup:row.group,expectedVersion:row.recordVersion||null};}
function fleetButton(label,fn,cls='btn-secondary'){const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=label;b.onclick=fn;return b;}
function fleetFilterHTML(mode){return `<div class="fleet-filters"><label>소속지점<select id="fleet${mode}Group" onchange="fleetRenderAll()"><option value="">전체 지점</option>${['본사','서울','인천','정봉','임원실'].map(x=>'<option>'+x+'</option>').join('')}</select></label><label>사용 분류<select id="fleet${mode}Class" onchange="fleetRenderAll()"><option value="">전체 분류</option>${fleetClasses.map(x=>'<option>'+x+'</option>').join('')}</select></label><label>사용자·차량·카드번호 검색<input id="fleet${mode}Query" oninput="fleetRenderAll()" maxlength="200"></label><button type="button" class="btn-secondary" onclick="fleetExport('${mode}')">엑셀 다운로드</button></div>`;}
function fleetFiltered(mode,rows){const group=document.getElementById('fleet'+mode+'Group')?.value||'',category=document.getElementById('fleet'+mode+'Class')?.value||'',q=(document.getElementById('fleet'+mode+'Query')?.value||'').toLowerCase();return rows.filter(r=>(!group||r.group===group)&&(!category||r.classification===category)&&(!q||JSON.stringify(r).toLowerCase().includes(q)));}
function fleetTable(rows,bodyId,manage=false){
    const body=document.getElementById(bodyId);if(!body)return;body.replaceChildren();
    for(const row of rows){const tr=document.createElement('tr');tr.innerHTML=`<td>${fleetEscape(row.id)}</td><td>${fleetEscape(row.group)}<small>${fleetEscape(row.classification||'미분류')}</small></td><td>${fleetEscape(row.hipassUser)}<small>${fleetEscape(row.car||'차량 미기록')}</small></td><td>${fleetCardsHTML(row)}</td><td>${fleetEscape(row.issueArea||'')}<small>${fleetEscape(row.route||'')}</small></td><td>${fleetEscape(row.returnDate||'—')}<small>${fleetEscape(row.reason||'')}</small></td><td>${fleetEscape(fleetReview(row))}<small>${fleetEscape(fleetStatus(row))}</small></td><td class="fleet-actions"></td>`;
        const actions=tr.lastElementChild;actions.append(fleetButton(manage?'미리보기·확인':'상세 보기',()=>fleetPreview(row.id,row.group)));
        if(hasViewPermission('v_hipass_reg')){actions.append(fleetButton('수정',()=>editHiPass(row.id,row.group)));actions.append(fleetButton('삭제',()=>deleteHiPass(row.id,row.group)));}
        body.append(tr);
    }
    if(!rows.length){const tr=document.createElement('tr');tr.innerHTML='<td colspan="8" class="ledger-empty">조회된 자료가 없습니다.</td>';body.append(tr);}
}
function fleetRenderAll(){
    const rows=fleetScoped(),confirmed=rows.filter(x=>x.reviewStatus!=='draft');
    fleetTable(fleetFiltered('register',rows.filter(x=>x.reviewStatus==='draft')).slice().reverse(),'registeredHiPassTable',true);
    fleetTable(fleetFiltered('list',confirmed).slice().reverse(),'hipassBoxTable');
    const list=document.getElementById('fleetListCount');if(list)list.textContent=`조회 ${fleetFiltered('list',confirmed).length}묶음 · 확인대기 ${rows.filter(x=>x.reviewStatus==='draft').length}묶음 (리스트 제외)`;
    renderFleetStatus();renderFleetHistory();
}
function renderHiPassTable(){
    const mount=document.getElementById('fleetRegisterFields');if(!mount)return;
    if(fleetUI.owner!==currentUser||!mount.children.length){mount.innerHTML=fleetFieldsHTML('regHipass');fleetUI.owner=currentUser;fleetToggleFields('regHipass');}
    fleetToggleFields('regHipass');
    for(const [mode,id] of [['register','fleetRegisterFilters'],['list','fleetListFilters'],['status','fleetStatusFilters'],['history','fleetHistoryFilters']]){
        const el=document.getElementById(id);if(el&&!el.children.length)el.innerHTML=fleetFilterHTML(mode);
        const group=document.getElementById('fleet'+mode+'Group');if(group&&userScope!=='ALL'){group.value=userScope;group.disabled=true;}
    }
    fleetRenderAll();
}
function renderHiPassBoxTable(){fleetRenderAll();}
async function handleRegisterHiPass(e){e.preventDefault();try{const payload=fleetCollect('regHipass');const result=await businessOperation('/api/hipass/register',payload);e.target.reset();fleetToggleFields('regHipass');alert('등록되었습니다. 미리보기에서 입력 정보를 확인해 주세요.');fleetPreview(result.hipass.id,result.hipass.group);}catch(error){alert(error.message);}}
function fleetPreview(id,group){const row=fleetFind(id,group);if(!row)return;fleetUI.preview={...fleetRef(row)};document.getElementById('modalTitle').textContent='등록 정보 미리보기·확인';document.getElementById('modalBody').innerHTML=fleetDocumentHTML(row);const footer=document.getElementById('modalFooter');footer.replaceChildren(fleetButton('닫기',closeModal),fleetButton('인쇄 / PDF',()=>printExpenseDetailReport('하이패스_등록정보')));if(row.reviewStatus!=='confirmed'&&hasViewPermission('v_hipass_reg'))footer.append(fleetButton('정보 확인 · 리스트 반영',()=>fleetConfirm(), 'btn-primary'));document.getElementById('commonModal').style.display='flex';}
async function fleetConfirm(){try{await businessOperation('/api/hipass/confirm',fleetUI.preview);closeModal();if(hasViewPermission('v_hipass_box'))switchView('v_hipass_box',document.getElementById('nav_v_hipass_box'));alert('확인한 묶음이 하이패스 리스트에 반영되었습니다.');}catch(error){alert(error.message);}}
function editHiPass(id,group){const row=fleetFind(id,group);if(!row||!hasViewPermission('v_hipass_reg'))return;fleetUI.editing={...fleetRef(row)};document.getElementById('modalTitle').textContent='하이패스·유류대카드 전체 정보 수정';document.getElementById('modalBody').innerHTML=`<form id="fleetEditForm" onsubmit="fleetSaveEdit(event)">${fleetFieldsHTML('editHipass',row)}<section class="fleet-section"><h3>변경 확인</h3><div class="fleet-grid">${fleetInput('fleetChangeReason','수정 사유','','text',true)}${fleetInput('fleetPassword','현재 로그인 비밀번호','','password',true)}</div><p class="ledger-help">저장 후 다시 확인해야 리스트에 반영됩니다. 변경 전·후 정보가 이력에 보존됩니다.</p></section></form>`;document.getElementById('fleetPassword').autocomplete='current-password';fleetToggleFields('editHipass');document.getElementById('modalFooter').replaceChildren(fleetButton('취소',closeModal),fleetButton('변경 저장',()=>document.getElementById('fleetEditForm').requestSubmit(),'btn-primary'));document.getElementById('commonModal').style.display='flex';}
async function fleetSaveEdit(e){e.preventDefault();try{const payload={...fleetCollect('editHipass'),...fleetUI.editing,changeReason:document.getElementById('fleetChangeReason').value,password:document.getElementById('fleetPassword').value};const result=await businessOperation('/api/hipass/update',payload);document.getElementById('fleetPassword').value='';fleetPreview(result.hipass.id,result.hipass.group);alert('수정되었습니다. 변경 정보를 다시 확인하세요.');}catch(error){document.getElementById('fleetPassword').value='';alert(error.message);}}
function deleteHiPass(id,group){const row=fleetFind(id,group);if(!row||!hasViewPermission('v_hipass_reg'))return;const ref=fleetRef(row);document.getElementById('modalTitle').textContent='하이패스 묶음 삭제';document.getElementById('modalBody').innerHTML='<p>이 묶음의 하이패스·유류대카드를 함께 삭제합니다. 변경 이력은 보존됩니다.</p>'+fleetInput('fleetDeleteReason','삭제 사유','','text',true)+fleetInput('fleetDeletePassword','현재 로그인 비밀번호','','password',true);document.getElementById('fleetDeletePassword').autocomplete='current-password';document.getElementById('modalFooter').replaceChildren(fleetButton('취소',closeModal),fleetButton('삭제',async()=>{try{await businessOperation('/api/hipass/delete',{...ref,changeReason:document.getElementById('fleetDeleteReason').value,password:document.getElementById('fleetDeletePassword').value});closeModal();}catch(error){document.getElementById('fleetDeletePassword').value='';alert(error.message);}},'btn-danger'));document.getElementById('commonModal').style.display='flex';}
function renderFleetStatus(){
    const el=document.getElementById('fleetStatusContent');if(!el)return;
    const rows=fleetFiltered('status',fleetScoped()),done=rows.filter(x=>x.reviewStatus!=='draft');
    const focused=document.activeElement?.dataset.fleetBranch;
    el.innerHTML='<div class="fleet-status-metrics">'+[['등록 묶음',rows.length],['확인대기',rows.length-done.length],['불출중',done.filter(x=>fleetStatus(x)==='불출중').length],['회수중·완료',done.filter(x=>['회수중','회수완료'].includes(fleetStatus(x))).length],['하이패스 카드',done.filter(x=>x.hipassEnabled!==false).length],['유류대카드',done.filter(x=>x.fuelEnabled).length]].map(([label,count])=>'<div class="ledger-metric"><span>'+label+'</span><strong>'+count+'</strong></div>').join('')+'</div><p class="ledger-help fleet-status-help">카드 수량은 확인대기를 제외합니다. 지점을 눌러 펼치세요. 배부 상태와 입력 확인 상태는 별도로 관리합니다.</p><div class="branch-tree-container fleet-branches"></div>';
    const tree=el.querySelector('.fleet-branches');
    for(const group of [...new Set(rows.map(x=>x.group))]){
        const items=rows.filter(x=>x.group===group),open=fleetUI.openBranches.has(group),node=document.createElement('section');node.className='branch-node';
        const button=fleetButton('',()=>{});button.className='branch-header fleet-branch-toggle';button.dataset.fleetBranch=group;button.setAttribute('aria-expanded',String(open));
        const label=document.createElement('span');label.textContent=group+' · '+items.length+'묶음';const arrow=document.createElement('span');arrow.textContent=open?'▲ 접기':'▼ 펼치기';button.append(label,arrow);
        const content=document.createElement('div');content.className='branch-content'+(open?' open':'');content.id='fleetBranch'+tree.children.length;button.setAttribute('aria-controls',content.id);
        const grid=document.createElement('div');grid.className='card-grid fleet-status-cards';
        for(const row of items){
            const card=document.createElement('div');card.className='card-item fleet-status-card';
            card.innerHTML='<div class="fleet-card-top"><span class="card-tag">'+fleetEscape(row.classification||'미분류')+'</span><span class="ledger-progress '+(fleetStatus(row)==='회수완료'?'complete':'pending')+'">'+fleetEscape(fleetStatus(row))+'</span></div><h3>'+fleetEscape(row.hipassUser||'사용자 미기록')+' <small>'+fleetEscape(row.car||'차량 미기록')+'</small></h3>'+fleetCardsHTML(row)+(fleetHasExpired(row)?'<p class="ledger-help">만료된 카드 포함 · 만료일을 확인하세요.</p>':'')+'<p class="ledger-help">묶음 '+fleetEscape(row.id)+' · '+fleetEscape(fleetReview(row))+'</p>';
            card.append(fleetButton('상세 보기',()=>fleetPreview(row.id,row.group)));grid.append(card);
        }
        content.append(grid);node.append(button,content);tree.append(node);
        button.onclick=()=>{const value=button.getAttribute('aria-expanded')!=='true';button.setAttribute('aria-expanded',String(value));content.classList.toggle('open',value);arrow.textContent=value?'▲ 접기':'▼ 펼치기';value?fleetUI.openBranches.add(group):fleetUI.openBranches.delete(group);};
    }
    if(!rows.length)tree.innerHTML='<p class="ledger-empty">조회 조건에 맞는 자료가 없습니다.</p>';
    if(focused)[...tree.querySelectorAll('[data-fleet-branch]')].find(x=>x.dataset.fleetBranch===focused)?.focus({preventScroll:true});
}
function renderFleetHistory(){
    const body=document.getElementById('fleetHistoryTable');if(!body)return;body.replaceChildren();
    const rows=YbyLedger.newest(fleetFiltered('history',hipassBoxLogs.filter(x=>userScope==='ALL'||x.group===userScope)));
    for(const event of rows){
        const snap=event.after||event.before||event,context=fleetHistoryContext(event),tr=document.createElement('tr');
        tr.innerHTML=`<td>${fleetEscape(event.action)}<small>${fleetEscape(event.group)}</small></td><td>${fleetEscape(snap.hipassUser||'미기록')}<small>${fleetEscape(snap.car||'차량 미기록')}</small></td><td>${fleetNumberHTML(snap)}</td><td>${fleetEscape(formatServerTime(context.created))}<small>변경 ${fleetEscape(formatServerTime(event.time))}</small></td><td><span class="ledger-progress">${fleetEscape(context.status)}</span>${context.current?'<small>'+fleetEscape(fleetReview(context.current))+'</small>':''}</td><td>${fleetEscape(event.changeReason||event.reason||'기존 이력')}<small>처리자 ${fleetEscape(event.handler)}</small></td><td></td>`;
        tr.lastElementChild.append(fleetButton('변경 문서 열람',()=>fleetHistoryDocument(event)));body.append(tr);
    }
    if(!rows.length)body.innerHTML='<tr><td colspan="7" class="ledger-empty">변경 이력이 없습니다.</td></tr>';
}
function fleetHistoryDocument(event){
    const context=fleetHistoryContext(event),snap=event.after||event.before||event,hasSnapshots='before' in event;
    const fields=[['카드 구성',r=>[r.hipassEnabled!==false?'하이패스':'',r.fuelEnabled?'유류대카드':''].filter(Boolean).join(' + ')],...['group','classification','hipassUser','car','distributionStatus','returnDate','issueArea','route','reason'].map(k=>[fleetLabels[k],r=>r[k]]),...['type','company','num','issueDate','expiryDate'].map(k=>['하이패스 · '+fleetLabels[k],r=>r.hipassEnabled!==false?r[k]:'해당 없음']),...['company','num','paymentType','usageScope','userType','assignedUser','issueDate','expiryDate','cardAlias'].map(k=>['유류대 · '+fleetLabels[k],r=>r.fuelEnabled?r.fuelCard?.[k]:'해당 없음']),['입력 확인',r=>fleetReview(r)],['확인자',r=>r.confirmedBy],['확인일시',r=>r.confirmedAt?formatServerTime(r.confirmedAt):'']];
    const value=(row,read)=>row?(read(row)||'미기록'):'—';
    const rows=fields.map(([label,read])=>{const before=value(event.before,read),after=value(event.after,read),changed=before!==after;return hasSnapshots?'<tr'+(changed?' class="fleet-changed"':'')+'><th scope="row">'+label+'</th><td>'+fleetEscape(before)+'</td><td>'+fleetEscape(after)+(changed?'<span class="fleet-change-mark">변경</span>':'')+'</td></tr>':'<tr><th scope="row">'+label+'</th><td>'+fleetEscape(value(snap,read))+'</td></tr>';}).join('');
    document.getElementById('modalTitle').textContent='하이패스 변경 이력 문서';
    document.getElementById('modalBody').innerHTML=`<article id="expenseDetailPrintArea" class="fleet-change-document"><h2>${fleetEscape(event.action)} · 변경 문서</h2><table class="fleet-document-meta"><tbody><tr><th>문서번호</th><td colspan="3">${fleetEscape(event.id)}</td></tr><tr><th>소속 / 묶음</th><td>${fleetEscape(event.group)} / ${fleetEscape(event.recordId||context.current?.id||'미기록')}</td><th>처리자</th><td>${fleetEscape(event.handler)}</td></tr><tr><th>최초 등록</th><td>${fleetEscape(formatServerTime(context.created))}</td><th>변경 일시</th><td>${fleetEscape(formatServerTime(event.time))}</td></tr><tr><th>현재 상태</th><td colspan="3">${fleetEscape(context.status)}${context.current?' · '+fleetEscape(fleetReview(context.current)):''} <small>(현재 자료 기준)</small></td></tr><tr><th>변경 사유</th><td colspan="3">${fleetEscape(event.changeReason||event.reason||'미기록')}</td></tr></tbody></table><p class="ledger-help">${hasSnapshots?'아래 표는 처리 당시의 기록입니다. 바뀐 항목을 음영으로 구분합니다.':'이전 버전 이력은 당시 보관된 정보만 표시합니다. 변경 전 정보는 복원하지 않습니다.'}</p><table class="fleet-comparison"><thead><tr><th>항목</th>${hasSnapshots?'<th>변경 전</th><th>변경 후</th>':'<th>보관된 정보</th>'}</tr></thead><tbody>${rows}</tbody></table></article>`;
    document.getElementById('modalFooter').replaceChildren(fleetButton('닫기',closeModal),fleetButton('인쇄 / PDF',()=>printExpenseDetailReport('하이패스_변경이력')));document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}
async function fleetExport(mode){const params=new URLSearchParams({mode,group:document.getElementById('fleet'+mode+'Group')?.value||'',classification:document.getElementById('fleet'+mode+'Class')?.value||'',q:document.getElementById('fleet'+mode+'Query')?.value||''});try{const response=await fetch('/api/hipass/export?'+params);if(!response.ok){const error=await response.json();throw Error(error.message||'내보내기 실패');}const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='YBY_하이패스_'+mode+'.xlsx';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(error){alert(error.message);}}

function fleetNumberHTML(row){return (row.hipassEnabled!==false?'<span>하이패스 '+fleetEscape(row.num||'미기록')+'</span>':'')+(row.fuelEnabled?'<small>유류대 '+fleetEscape(row.fuelCard?.num||'미기록')+'</small>':'');}
function fleetNormalizedNumbers(row){return [row.hipassEnabled!==false?row.num:null,row.fuelEnabled?row.fuelCard?.num:null].filter(Boolean).map(x=>String(x).replace(/[\s-]/g,'').toLowerCase());}
function fleetHistoryContext(event){
    const snap=event.after||event.before||event,rid=event.recordId,known=rid!==undefined&&rid!==null;
    const numbers=fleetNormalizedNumbers(snap),records=fleetScoped();
    const matches=records.filter(r=>r.group===event.group&&(known?String(r.id)===String(rid):fleetNormalizedNumbers(r).some(n=>numbers.includes(n))));
    const current=matches.length===1?matches[0]:null;
    const related=known?hipassBoxLogs.filter(e=>e.group===event.group&&String(e.recordId)===String(rid)):[event];
    const original=related.find(e=>e.action==='최초등록');
    const created=current?.createdAt||snap.createdAt||current?.date||snap.date||original?.time||'미기록';
    const status=current?fleetStatus(current):related.some(e=>e.action==='카드삭제')?'삭제됨':related.some(e=>e.action==='정보수정'&&e.before&&e.after===null)?'이관됨':known?'현재자료 없음':'확인불가';
    return {created,status,current};
}

function fleetHasExpired(row){return [row.hipassEnabled!==false?row.expiryDate:null,row.fuelEnabled?row.fuelCard?.expiryDate:null].filter(Boolean).some(x=>x<localDate());}

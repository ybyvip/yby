"""Atomic business APIs, authorization, diagnostics and bounded HTTP service."""
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
from http.server import HTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
import ssl
import re
import json
import mimetypes
import os
from pathlib import Path
import secrets
import socket
import threading
import time
from types import SimpleNamespace
import uuid
from urllib.parse import parse_qs, urlparse
import backup_manager
import domain
import storage
import exports
import settlement_workflow
import external_documents
import fleet_cards
import settlement_report


class BoundedHTTPServer(HTTPServer):
    allow_reuse_address=os.name!='nt'
    def __init__(self,*args,**kwargs):
        self.pool=ThreadPoolExecutor(max_workers=16,thread_name_prefix='yby-http')
        self.slots=threading.BoundedSemaphore(32)
        super().__init__(*args,**kwargs)
    def server_bind(self):
        if os.name=='nt':self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()
    def process_request(self,request,address):
        if not self.slots.acquire(False):
            self.shutdown_request(request);return
        self.pool.submit(self.run_request,request,address)
    def run_request(self,request,address):
        try:self.finish_request(request,address)
        except (OSError,TimeoutError):pass
        except Exception:self.handle_error(request,address)
        finally:self.shutdown_request(request);self.slots.release()
    def server_close(self):
        super().server_close();self.pool.shutdown(wait=True)


class HTTPSWithRedirectServer(BoundedHTTPServer):
    """Serve TLS and redirect only plaintext navigation on the same application port."""
    def configure_tls(self,context,server_ip):
        self.tls_context=context
        self.redirect_hosts={'localhost','127.0.0.1',str(server_ip).lower(),socket.gethostname().lower().rstrip('.')}

    def run_request(self,request,address):
        connection=request
        try:
            request.settimeout(5)
            first=request.recv(1,socket.MSG_PEEK)
            if first==b'\x16':
                connection=self.tls_context.wrap_socket(request,server_side=True)
                connection.settimeout(30)
                self.finish_request(connection,address)
            elif first in (b'G',b'H',b'P',b'O',b'D',b'T',b'C'):
                request.settimeout(5)
                PlaintextNavigation(request,address,self)
        except (OSError,ssl.SSLError,TimeoutError):pass
        except Exception:self.handle_error(request,address)
        finally:self.shutdown_request(connection);self.slots.release()


class PlaintextNavigation(BaseHTTPRequestHandler):
    def log_message(self,*args):pass

    def do_GET(self):
        try:host=urlsplit('//'+self.headers.get('Host','')).hostname
        except ValueError:host=None
        if not host or host.lower().rstrip('.') not in self.server.redirect_hosts:
            self.send_error(400,'Use the configured YBY HTTPS address');return
        path=self.path if self.path.startswith('/') and not self.path.startswith('//') else '/'
        if any(ord(c)<32 for c in path):path='/'
        location=f'https://{host.lower().rstrip(".")}:{self.server.server_port}'+path
        body='HTTPS 로그인 화면으로 이동합니다.'.encode('utf-8')
        self.send_response(308)
        self.send_header('Location',location)
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Type','text/plain; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Connection','close');self.end_headers()
        if self.command!='HEAD':self.wfile.write(body)
        self.close_connection=True

    do_HEAD=do_GET

    def do_POST(self):
        # Do not parse, authenticate, or forward credentials sent on a plaintext connection.
        self.send_error(400,'Login requires HTTPS; open the YBY login shortcut')
        self.close_connection=True

    do_PUT=do_POST
    do_DELETE=do_POST
    do_OPTIONS=do_POST
    do_PATCH=do_POST


def register_server(g,server):
    marker=g['BASE_DIR']/'server.pid';temporary=marker.with_suffix('.pid.tmp')
    temporary.write_text(json.dumps({'pid':os.getpid(),'host':g['HOST'],'port':server.server_port,
                                    'app':str(g['BASE_DIR']/'app.py'),'data':str(g['DB_DIR']),
                                    'scheme':'https' if g['TLS_CERT'] else 'http'}),encoding='utf-8')
    os.replace(temporary,marker)


def diff(before,after):
    changes=[]
    for field in storage.TABLES:
        old={storage.key(x):x for x in before.get(field,[])}
        new={storage.key(x):x for x in after.get(field,[])}
        for key in old.keys()|new.keys():
            if old.get(key)==new.get(key):continue
            if field in ('chat','inbox'):details={'id':key,'change':'message changed'}
            else:
                safe=lambda x:{k:v for k,v in (x or {}).items() if k not in ('cardKey','attachments','phone','content')}
                details={'id':key,'before':safe(old.get(key)),'after':safe(new.get(key))}
            changes.append({'collection':field,**details})
    return changes


def attachment_allowed(g,meta,user):
    a=SimpleNamespace(**g)
    if meta.get('purpose')=='notice':
        with a.db() as conn:
            if not conn.execute('SELECT 1 FROM users WHERE username=? AND active=1',(user,)).fetchone():return False
        return any(notice.get('attachment',{}).get('id')==meta.get('id') for notice in a.get_state().get('notices',[]) if isinstance(notice,dict) and isinstance(notice.get('attachment'),dict))
    if meta.get('purpose')=='settlement':
        scope=a.user_scope(user)
        return scope=='ALL' or (scope==meta.get('group') and bool(a.permissions_for(user)&{'v_expense','v_expense_history'}))
    with a.db() as c:
        known={r[0] for r in c.execute('SELECT username FROM users WHERE active=1')}
    return user in known and (meta.get('sender')==user or meta.get('broadcast') is True or user in meta.get('recipients',[]))


def attachment_refs(a,items,user,group,retained=()):
    if not isinstance(items,list) or len(items)>5:raise ValueError('첨부파일은 최대 5개입니다.')
    allowed={x.get('id') for x in retained if isinstance(x,dict)};result=[];seen=set()
    for item in items:
        value=str(item.get('id','')) if isinstance(item,dict) else ''
        if len(value)!=32 or any(c not in '0123456789abcdef' for c in value):raise ValueError('첨부 식별자 오류')
        p=a.ATTACHMENT_DIR/(value+'.json')
        if not p.is_file() or not (a.ATTACHMENT_DIR/(value+'.bin')).is_file():raise ValueError('첨부파일을 찾을 수 없습니다.')
        meta=json.loads(p.read_text())
        if (meta.get('sender')!=user and value not in allowed) or meta.get('purpose')!='settlement' or meta.get('group')!=group:raise PermissionError('정산 첨부 소유자 또는 지점이 다릅니다.')
        if value in seen:raise ValueError('첨부파일이 중복되었습니다.')
        seen.add(value);result.append({'id':value,'name':meta['name']})
    return result


def transaction(handler,g,kind,data,user,mutate):
    a=SimpleNamespace(**g)
    request_id=data.get('requestId')
    if not isinstance(request_id,str) or not 8<=len(request_id)<=128:raise ValueError('중복 방지 requestId가 필요합니다.')
    fingerprint=hashlib.sha256(json.dumps({k:v for k,v in data.items() if k!='password'},sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    with a.LOCK,a.db() as conn:
        old=conn.execute('SELECT * FROM operation_receipts WHERE request_id=?',(request_id,)).fetchone()
        if old:
            result=json.loads(old['result_json'])
            if old['actor']!=user or old['kind']!=kind or result.pop('_fingerprint',None)!=fingerprint:raise a.StateConflict('같은 요청 ID에 다른 작업이 있습니다.')
            return handler.send_json(result)
        row=conn.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone()
        revision=row[0] if row else None
        if 'revision' not in data or data['revision']!=revision:raise a.StateConflict('자료가 변경되었습니다. 새로고침 후 다시 시도하세요.')
        current=storage.read(conn) or {};state=json.loads(json.dumps(current))
        result=mutate(state,conn)
        domain.validate(state,current,user,a.user_scope(user)=='ALL',trusted=True)
        a.backup('before_business')
        state['accounts']=a.account_metadata(conn)
        revision=a.persist_state(conn,state,user,commit=False)
        def redact(value):
            if isinstance(value,dict):return {k:redact(v) for k,v in value.items() if k!='cardKey'}
            if isinstance(value,list):return [redact(x) for x in value]
            return value
        result={'ok':True,'revision':revision,**redact(result)}
        conn.execute('INSERT INTO operation_receipts VALUES(?,?,?,?,?)',(request_id,user,kind,json.dumps({**result,'_fingerprint':fingerprint},ensure_ascii=False),a.now()))
        conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',(a.now(),user,kind,handler.client_address[0],json.dumps(diff(current,state),ensure_ascii=False)))
        conn.commit()
        a.write_latest_snapshot(state)
    return handler.send_json(result)


def get(h,g,path):
    if path not in ('/api/operations','/api/audit/search','/api/records','/api/admin/backup/download','/api/external-documents','/api/external-document','/api/report-prefill','/api/hipass/export'):return False
    a=SimpleNamespace(**g);user=h.session_user()
    if not user:h.send_json({'ok':False,'message':'로그인이 필요합니다.'},401);return True
    if getattr(h,'must_change_password',False):h.send_json({'ok':False,'message':'최초 비밀번호를 변경하세요.'},403);return True
    query=parse_qs(urlparse(h.path).query)
    if path=='/api/hipass/export':
        try:
            mode=query.get('mode',['list'])[0]
            allowed={'list':{'v_hipass_box','v_hipass_reg','v_hipass_status'},'register':{'v_hipass_reg'},'history':{'v_hipass_history','v_hipass_box','v_hipass_reg'},'status':{'v_hipass_status','v_hipass_reg','v_hipass_box'}}
            if mode not in allowed:raise ValueError('내보내기 종류 오류')
            if a.user_scope(user)!='ALL' and not a.permissions_for(user).intersection(allowed[mode]):raise PermissionError('하이패스 조회 권한이 없습니다.')
            state=a.get_state_for(user);rows=fleet_cards.selected(state.get('hipassBox' if mode=='history' else 'hipass',[]),a.user_scope(user),query)
            if mode=='list':rows=[x for x in rows if x.get('reviewStatus')!='draft']
            if mode=='register':rows=[x for x in rows if x.get('reviewStatus')=='draft']
            if mode=='history':
                headers=['이력ID','작업','변경일시','처리자','변경사유','최초등록일시','현재 배부상태']+fleet_cards.workbook_rows([])[0];values=[]
                for event in rows:
                    snap=event.get('after') or event.get('before') or event
                    created,status=fleet_cards.history_context(event,state.get('hipass',[]),state.get('hipassBox',[]),a.business_date())
                    for line in fleet_cards.workbook_rows([snap])[1]:values.append([event['id'],event.get('action',''),event.get('time',''),event.get('handler',''),event.get('changeReason',event.get('reason','')),created,status]+line)
            else:
                headers,values=fleet_cards.workbook_rows(rows);headers+=['배부상태']
                by_id={(str(x['id']),x['group']):x for x in rows}
                values=[line+[fleet_cards.distribution_status(by_id[(str(line[0]),line[1])],a.business_date())] for line in values]
            raw=exports.make_xlsx('하이패스 '+mode,headers,values)
            h.send_response(200);h.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');h.send_header('Content-Disposition','attachment; filename="yby_hipass_'+mode+'.xlsx"');h.send_header('Cache-Control','no-store');h.send_header('Content-Length',str(len(raw)));h.end_headers();h.wfile.write(raw)
        except PermissionError as error:h.send_json({'ok':False,'message':str(error)},403)
        except (ValueError,TypeError) as error:h.send_json({'ok':False,'message':str(error)},400)
        return True
    if path=='/api/report-prefill':
        try:
            a.require_permission(user,'v_report_write');a.require_permission(user,'v_card_rent')
            reference={k:query.get(k,[''])[0] for k in ('id','group','requester')}
            state=a.get_state_for(user);row=settlement_report.source(state,reference,a.user_scope(user))
            value=settlement_report.preview(row,state.get('history',[]));value.pop('sourceSnapshot',None)
            h.send_json({'ok':True,'draft':value})
        except PermissionError as error:h.send_json({'ok':False,'message':str(error)},403)
        except (ValueError,TypeError) as error:h.send_json({'ok':False,'message':str(error)},400)
        return True
    if path in ('/api/external-documents','/api/external-document'):
        try:
            a.require_permission(user,'v_card_rent')
            scope=a.user_scope(user);kind=query.get('kind',['settlement'])[0]
            if kind not in ('application','settlement'):raise ValueError('문서 종류 오류')
            card=None
            if query.get('cardId'):
                card=next((x for x in a.get_state_for(user).get('cards',[]) if str(x['id'])==query['cardId'][0]),None)
                if not card:raise PermissionError('카드 조회 권한이 없습니다.')
            with a.db() as conn:
                if path=='/api/external-document':
                    doc=external_documents.load(conn,query.get('key',[''])[0])
                    if scope not in ('ALL',doc['group']) or doc['kind']!=kind or (card and not external_documents.card_matches(doc,card)):raise PermissionError('외부 문서 조회 권한이 없습니다.')
                    bound=bool(conn.execute('SELECT 1 FROM external_document_bindings WHERE document_key=?',(doc['key'],)).fetchone())
                    value={'document':doc,'bound':bound}
                else:
                    offset=int(query.get('offset',['0'])[0]);offset=max(0,offset)
                    value=external_documents.listing(conn,scope,kind,card,query.get('q',[''])[0][:200],offset,query.get('status',['all'])[0])
            h.send_json({'ok':True,'oracleConnected':False,'pollSeconds':10,'checkedAt':a.now(),'message':'Oracle 접속·조회는 DB 구조 확인 후 연결합니다. 현재는 서버 수신함에 저장된 문서를 조회합니다.',**value})
        except PermissionError as error:h.send_json({'ok':False,'message':str(error)},403)
        except (ValueError,TypeError) as error:h.send_json({'ok':False,'message':str(error)},400)
        return True
    if path=='/api/records':
        field=query.get('collection',['cards'])[0]
        if field not in storage.TABLES:h.send_json({'ok':False,'message':'알 수 없는 목록'},400);return True
        state=a.get_state_for(user);rows=state.get(field,[])
        term=query.get('q',[''])[0].casefold()
        if term:rows=[x for x in rows if term in json.dumps(x,ensure_ascii=False).casefold()]
        try:offset=max(0,int(query.get('offset',['0'])[0]));limit=max(1,min(200,int(query.get('limit',['50'])[0])))
        except ValueError:h.send_json({'ok':False,'message':'페이지 값 오류'},400);return True
        h.send_json({'ok':True,'total':len(rows),'items':rows[offset:offset+limit]});return True
    if a.user_scope(user)!='ALL':h.send_json({'ok':False,'message':'관리자 권한 필요'},403);return True
    if path=='/api/admin/backup/download':
        token=query.get('token',[''])[0]
        binding=a.BACKUP_DOWNLOAD_TOKENS.get(token)
        if not binding or binding['user']!=user or binding['expires']<time.time():h.send_json({'ok':False,'message':'다운로드 승인이 만료되었습니다.'},403);return True
        a.BACKUP_DOWNLOAD_TOKENS.pop(token,None)
        file=a.BACKUP_DIR/binding['name']
        h.send_response(200);h.send_header('Content-Type','application/zip');h.send_header('Content-Length',str(file.stat().st_size));h.send_header('Content-Disposition','attachment; filename="'+file.name+'"');h.send_header('Cache-Control','no-store');h.end_headers()
        with file.open('rb') as stream:
            while chunk:=stream.read(65536):h.wfile.write(chunk)
        return True
    if path=='/api/operations':
        h.send_json({'ok':True,'warnings':a.OPERATION_WARNINGS,'backups':[{'name':p.name,'bytes':p.stat().st_size} for p in sorted(a.BACKUP_DIR.glob('*.zip'),reverse=True)],'version':a.APP_VERSION});return True
    term=query.get('q',[''])[0]
    with a.db() as c:
        rows=c.execute('SELECT * FROM audit_events WHERE username LIKE ? OR action LIKE ? OR details LIKE ? ORDER BY id DESC LIMIT 200',('%'+term+'%',)*3).fetchall()
    h.send_json({'ok':True,'events':[dict(x) for x in rows]});return True


def post(h,g,path,data):
    routes={'/api/hipass/update','/api/hipass/confirm','/api/hipass/delete','/api/hipass/register','/api/exports','/api/cards/register','/api/cards/rent','/api/cards/return','/api/expenses/submit','/api/expense-submit','/api/expenses/decision','/api/expenses/correct','/api/expenses/resubmit','/api/expenses/reopen-rejected','/api/notices/create','/api/notices/delete','/api/documents/submit','/api/documents/decision','/api/admin/backup','/api/attachments','/api/session/touch'}
    if path not in routes:return False
    a=SimpleNamespace(**g);user=h.session_user()
    try:
        if not user:raise PermissionError('로그인이 필요합니다.')
        if getattr(h,'must_change_password',False):raise PermissionError('최초 비밀번호를 변경하세요.')
        if path=='/api/exports':
            allowed={'v_card_history','v_expense_history','v_stats','v_card_reg','v_hipass_reg','v_report_box','v_card_rent','v_expense'}
            if a.user_scope(user)!='ALL' and not a.permissions_for(user).intersection(allowed):raise PermissionError('내보내기 권한이 없습니다.')
            raw=exports.make_xlsx(data.get('title','Report'),data.get('headers'),data.get('rows'))
            h.send_response(200);h.send_header('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');h.send_header('Content-Length',str(len(raw)));h.send_header('Cache-Control','no-store');h.end_headers();h.wfile.write(raw)
            a.audit(user,'XLSX_EXPORT',h.client_address[0],'rows='+str(len(data['rows'])));return True
        if path=='/api/session/touch':h.send_json({'ok':True});return True
        if path=='/api/admin/backup':
            if a.user_scope(user)!='ALL':raise PermissionError('관리자 권한 필요')
            with a.db() as c:row=c.execute('SELECT password_hash FROM users WHERE username=?',(user,)).fetchone()
            if not a.verify_password(row[0],data.get('password','')):raise PermissionError('현재 관리자 비밀번호를 확인하세요.')
            with a.LOCK:
                a.backup('manual');name=max(a.BACKUP_DIR.glob('*_manual.zip'),key=lambda p:p.stat().st_mtime).name
                for token,value in list(a.BACKUP_DOWNLOAD_TOKENS.items()):
                    if value['expires']<time.time():a.BACKUP_DOWNLOAD_TOKENS.pop(token,None)
                token=secrets.token_urlsafe(32);a.BACKUP_DOWNLOAD_TOKENS[token]={'name':name,'user':user,'expires':time.time()+60}
            h.send_json({'ok':True,'message':'전체 백업 완료','download':'/api/admin/backup/download?token='+token});return True
        if path=='/api/attachments':
            raw=base64.b64decode(data.get('content',''),validate=True)
            if not raw or len(raw)>a.MAX_ATTACHMENT_BYTES:raise ValueError('파일 크기는 1바이트~20MB입니다.')
            name=Path(str(data.get('name','file')).replace('\\','/')).name.replace('\r','_').replace('\n','_')[:180]
            if not name:raise ValueError('파일 이름이 필요합니다.')
            settlement=data.get('purpose')=='settlement';notice=data.get('purpose')=='notice';group=data.get('group','')
            broadcast=data.get('broadcast') is True
            if notice:
                if a.user_scope(user)!='ALL':raise PermissionError('최고관리자만 공지 첨부를 등록할 수 있습니다.')
                broadcast=True;group='';recipients=[]
            elif settlement:
                a.require_permission(user,'v_expense')
                if group not in domain.BRANCHES or a.user_scope(user) not in (group,'ALL'):raise PermissionError('정산 지점 권한 없음')
                if broadcast:raise PermissionError('정산 증빙의 전체 공개는 허용되지 않습니다.')
                recipients=[]
            else:
                with a.db() as c:known={r[0] for r in c.execute('SELECT username FROM users WHERE active=1')}
                recipients=data.get('recipients',[])
                if not isinstance(recipients,list) or any(x not in known for x in recipients):raise ValueError('수신자 오류')
            identity=uuid.uuid4().hex
            meta={'id':identity,'name':name,'sender':user,'recipients':recipients,'broadcast':broadcast,'purpose':'notice' if notice else ('settlement' if settlement else 'chat'),'group':group,'mime':mimetypes.guess_type(name)[0] or 'application/octet-stream','created_at':a.now()}
            with a.LOCK:
                if sum(p.stat().st_size for p in a.ATTACHMENT_DIR.glob('*.bin'))+len(raw)>2*1024**3:raise ValueError('첨부 저장 용량 2GB 제한입니다. 백업 후 관리자가 정리하세요.')
                payload=a.ATTACHMENT_DIR/(identity+'.bin');metadata=a.ATTACHMENT_DIR/(identity+'.json')
                try:payload.write_bytes(raw);metadata.write_text(json.dumps(meta,ensure_ascii=False));os.chmod(payload,0o600);os.chmod(metadata,0o600)
                except BaseException:payload.unlink(missing_ok=True);metadata.unlink(missing_ok=True);raise
            h.send_json({'ok':True,'attachment_id':identity,'name':name});return True
        # Legacy expense endpoint accepts the old transport but uses shared validation.
        if path=='/api/expense-submit':
            with a.db() as c:row=c.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone()
            data={**data,'requestId':data.get('requestId',uuid.uuid4().hex),'revision':data.get('revision',row[0] if row else None)}
        scope=a.user_scope(user)
        def mutate(state,conn):
            cards=state.setdefault('cards',[])
            if path in ('/api/notices/create','/api/notices/delete'):
                if scope!='ALL':raise PermissionError('최고관리자만 공지사항을 관리할 수 있습니다.')
                notices=state.setdefault('notices',[])
                if path.endswith('/delete'):
                    selected=next((item for item in notices if str(item.get('id'))==str(data.get('id'))),None)
                    if selected is None:raise ValueError('공지사항을 찾을 수 없습니다.')
                    notices.remove(selected);return {'deleted':selected['id']}
                title=data.get('title');body=data.get('text')
                if not isinstance(title,str) or not 1<=len(title.strip())<=120 or not isinstance(body,str) or not 1<=len(body.strip())<=200000:raise ValueError('공지 제목(1~120자)과 본문이 필요합니다.')
                ref=data.get('attachment');attachment=None
                if ref is not None:
                    identity=ref.get('id','') if isinstance(ref,dict) else ''
                    if not isinstance(identity,str) or not re.fullmatch('[0-9a-f]{32}',identity):raise ValueError('공지 첨부 식별자 오류')
                    meta_path=a.ATTACHMENT_DIR/(identity+'.json');file_path=a.ATTACHMENT_DIR/(identity+'.bin')
                    if not meta_path.is_file() or not file_path.is_file():raise ValueError('업로드한 공지 첨부파일이 없습니다.')
                    meta=json.loads(meta_path.read_text())
                    if meta.get('purpose')!='notice' or meta.get('sender')!=user:raise PermissionError('본인이 공지용으로 업로드한 첨부만 연결할 수 있습니다.')
                    attachment={'id':identity,'name':meta['name']}
                ids=[int(item['id']) for item in notices if str(item.get('id','')).isdigit()]
                row={'id':max(ids+[int(time.time()*1000)])+1,'title':title.strip(),'text':body.strip(),'attachment':attachment,'author':user,'createdAt':a.now()}
                notices.insert(0,row);return {'notice':row}
            if path in ('/api/expenses/correct','/api/expenses/resubmit','/api/expenses/reopen-rejected'):
                return settlement_workflow.change(a,state,data,user,scope,path,lambda items,actor,group,retained:attachment_refs(a,items,actor,group,retained))
            if path.startswith('/api/hipass/'):
                return fleet_cards.change(a,conn,state,data,user,scope,path)
            if path=='/api/cards/register':
                a.require_permission(user,'v_card_reg')
                group=data.get('group') if scope=='ALL' else scope
                if group not in domain.BRANCHES:raise ValueError('카드 지점 오류')
                ids=[int(x.get('id',0)) for x in cards if str(x.get('id','')).isdigit()]
                new_id=max(ids+[int(state.get('_next_card_id') or 0)])+1;state['_next_card_id']=new_id
                row={k:data.get(k,'') for k in ('num','company','userType','assignedUser','issueDate','expiryDate','cardAlias','paymentType','usageScope')}
                row.update(id=new_id,group=group,status='available',dept='',user='',purpose='',rentDate='',dueDate='')
                cards.append(row);return {'card':row}
            if path.startswith('/api/cards/'):
                a.require_permission(user,'v_card_rent')
                card=next((c for c in cards if str(c.get('id'))==str(data.get('cardId'))),None)
                if not card:raise ValueError('카드가 없습니다.')
                if scope not in ('ALL',card['group']):raise PermissionError('다른 지점 카드입니다.')
                history=state.setdefault('history',[])
                event_id=max([int(x.get('id',0)) for x in history if str(x.get('id','')).isdigit()]+[0])+1
                returned_expense=None
                if path.endswith('/rent'):
                    if card['status']!='available':raise a.StateConflict('이미 불출된 카드입니다.')
                    external=external_documents.resolve(conn,data,'application',card)
                    card.update({f:data.get(f,'') for f in ('dept','user','purpose','dueDate')});card.update(status='rented',rentDate=a.business_date())
                    application_date=data.get('applicationDate',a.business_date());domain.date_value(application_date,'사용신청일',True)
                    applicant=external_documents.short(data.get('applicantName',card['user']),'신청자명',True)
                    if application_date>card['dueDate']:raise ValueError('사용신청일 이후의 반납예정일이 필요합니다.')
                    card.update(applicationDate=application_date,applicantName=applicant,**external_documents.source_fields(external))
                    if external:
                        card['sourceAdjusted']=any(card.get(k,'')!=external.get(k,'') for k in ('applicationDate','applicantName','user','dept','dueDate')) or re.sub(r'^\[[^\]]*\]\s*','',card['purpose'])!=external['purpose']
                    if external is None:
                        card.pop('sourceRef',None);card.pop('sourceAdjusted',None)
                    if card.get('expiryDate') and card['expiryDate']<a.business_date():raise ValueError('만료된 카드입니다.')
                    if card.get('userType')=='지정' and card.get('assignedUser')!=card.get('user'):raise PermissionError('지정 사용자만 사용할 수 있는 카드입니다.')
                    card['rentalEventId']=event_id
                    external_documents.bind(conn,external,{'group':card['group'],'rentalEventId':event_id},user,a.now())
                    event_type='불출'
                else:
                    if card['status']!='rented':raise a.StateConflict('대여 중인 카드가 아닙니다.')
                    if not isinstance(data.get('used'),bool):raise ValueError('사용 여부가 필요합니다.')
                    external=external_documents.resolve(conn,data,'settlement',card)
                    if external and not data['used']:raise ValueError('외부 정산서를 선택한 경우 사용함으로 반납하세요.')
                    if data['used']:
                        returned_expense=submit_expense(state,data.get('expense'),card)
                        returned_expense.update(**external_documents.source_fields(external))
                        if external:
                            returned_expense['externalApplicantName']=external['applicantName']
                            returned_expense['sourceAdjusted']=any(returned_expense.get(k,'')!=external.get(k,'') for k in ('user','dept','purpose','amount','lineItems'))
                        returned_expense['returnEventId']=event_id
                        if card.get('rentalEventId') is not None:returned_expense['rentalEventId']=card['rentalEventId']
                        external_documents.bind(conn,external,{name:returned_expense[name] for name in ('id','group','requester')},user,a.now())
                    event_type='반납'
                event={'id':event_id,'group':card['group'],'type':event_type,'handler':user,'time':a.now(),'cardNum':card['num'],'cardCompany':card.get('company',''),'rentDate':card.get('rentDate'),'returnDate':a.business_date() if event_type=='반납' else '', 'dueDate':card.get('dueDate'),'dept':card.get('dept'),'user':card.get('user'),'purpose':card.get('purpose'),'used':data.get('used')}
                if card.get('rentalEventId') is not None:event['rentalEventId']=card['rentalEventId']
                for name in ('applicationDate','applicantName','entrySource','sourceRef','sourceAdjusted'):
                    if name in card:event[name]=card[name]
                if event_type=='반납' and returned_expense:
                    event['settlementSource']=returned_expense['entrySource']
                    if returned_expense.get('sourceRef'):event['settlementSourceRef']=returned_expense['sourceRef']
                if returned_expense:event['expenseRef']={name:returned_expense[name] for name in ('id','group','requester')}
                history.append(event)
                if event_type=='반납':
                    card.update(status='available',dept='',user='',purpose='',rentDate='',dueDate='')
                    card.pop('rentalEventId',None)
                    for name in ('applicationDate','applicantName','entrySource','sourceRef','sourceAdjusted'):card.pop(name,None)
                return {'card':card,**({'expenseRef':{k:returned_expense[k] for k in ('id','group','requester')}} if returned_expense else {})}
            if path in ('/api/expenses/submit','/api/expense-submit'):return {'expense':submit_expense(state,data.get('expense'))}
            if path=='/api/expenses/decision':
                if scope!='ALL':raise PermissionError('최고관리자만 결재할 수 있습니다.')
                pending=state.setdefault('expense',[])
                row=next((x for x in pending if str(x.get('id'))==str(data.get('id')) and x.get('group')==data.get('group') and x.get('requester','')==data.get('requester','')),None)
                if not row:raise ValueError('대기 정산을 찾을 수 없습니다.')
                if row.get('status')!='승인대기':raise ValueError('재보고 대기 건은 수정하여 재보고한 뒤 결재하세요.')
                if data.get('decision') not in ('approve','reject'):raise ValueError('결재 종류 오류')
                domain.expense(row,cards)
                yes=data['decision']=='approve'
                reason=str(data.get('reason','')).strip()
                if len(reason)>1000 or (not yes and row.get('reapproval') and not reason):raise ValueError('반려 사유를 1~1000자로 입력하세요.')
                settlement_workflow.message(row,'approve' if yes else 'reject',user,a.now(),reason or '승인 완료')
                row.update(status='승인완료' if yes else '반려됨');row.update({('approvedBy' if yes else 'rejectedBy'):user,('approvedAt' if yes else 'rejectedAt'):a.now(),'decisionReason':str(data.get('reason',''))[:1000], 'selfApproved':yes and user in (row.get('requester'),row.get('resubmittedBy')),'selfDecision':user in (row.get('requester'),row.get('resubmittedBy'))})
                state.setdefault('expenseHistory',[]).append(row);pending.remove(row);return {'expense':row}
            if path=='/api/documents/submit':
                a.require_permission(user,'v_report_write')
                group=data.get('group') if scope=='ALL' else scope
                if group not in domain.BRANCHES:raise ValueError('기안 지점을 선택하세요.')
                reviewer=data.get('reviewer','');approver=data.get('approver','')
                with a.db() as c:known=a.account_metadata(c)
                if approver not in known or known[approver]['scope']!='ALL':raise ValueError('최고관리자를 최종 승인자로 지정하세요.')
                if reviewer and reviewer!=user and (reviewer not in known or known[reviewer]['scope'] not in (group,'ALL') or (known[reviewer]['scope']!='ALL' and 'v_report_box' not in known[reviewer]['permissions'])):raise ValueError('검토자 권한이 올바르지 않습니다.')
                for f in ('title','content'):
                    if not isinstance(data.get(f),str) or not data[f].strip():raise ValueError('기안 제목과 내용이 필요합니다.')
                row={'id':'REP-'+uuid.uuid4().hex,'group':group,'author':user,'title':data['title'],'content':data['content'],'type':str(data.get('type','일반')),'date':a.now(),'status':'pending_review' if reviewer else 'pending','reviewer':reviewer,'approver':approver,'line':(reviewer+' → ' if reviewer else '')+approver,'decisions':[]}
                if reviewer==user:
                    row['status']='pending';row['selfReviewed']=True
                    row['decisions'].append({'stage':'pending_review','actor':user,'time':row['date'],'decision':'approve','reason':'기안 상신 시 본인 검토 완료','selfDecision':True})
                if data.get('sourceExpenseRef') is not None:
                    a.require_permission(user,'v_card_rent')
                    origin=settlement_report.source(state,data['sourceExpenseRef'],scope)
                    if origin['group']!=group:raise ValueError('보고서와 원본 정산의 지점이 다릅니다.')
                    row['sourceExpenseRef']={k:origin[k] for k in ('id','group','requester')}
                    row['sourceExpenseStatus']=origin.get('status','');row['sourceExpenseSnapshot']=json.loads(json.dumps(origin))
                state.setdefault('reports',[]).insert(0,row);return {'document':row}
            if path=='/api/documents/decision':
                row=next((x for x in state.get('reports',[]) if x.get('id')==data.get('id')),None)
                if not row:raise ValueError('문서가 없습니다.')
                if scope not in ('ALL',row.get('group')):raise PermissionError('다른 지점 문서입니다.')
                stage=row.get('status');assigned=row.get('reviewer') if stage=='pending_review' else row.get('approver')
                if stage not in ('pending_review','pending') or (assigned and assigned!=user) or (not assigned and scope!='ALL'):raise PermissionError('현재 결재자가 아닙니다.')
                if stage=='pending' and scope!='ALL':raise PermissionError('최고관리자만 최종 결재할 수 있습니다.')
                if scope!='ALL':a.require_permission(user,'v_report_box')
                decision=data.get('decision')
                if decision not in ('approve','reject'):raise ValueError('결재 종류 오류')
                row['status']='rejected' if decision=='reject' else ('pending' if stage=='pending_review' else 'approved')
                row.setdefault('decisions',[]).append({'stage':stage,'actor':user,'time':a.now(),'decision':decision,'reason':str(data.get('reason',''))[:1000],'selfDecision':row['author']==user})
                if stage=='pending':row.update(selfDecision=row['author']==user,selfApproved=decision=='approve' and row['author']==user)
                return {'document':row}
            raise ValueError('지원하지 않는 작업')
        def submit_expense(state,value,card=None):
            a.require_permission(user,'v_expense')
            if not isinstance(value,dict):raise ValueError('정산 형식 오류')
            allowed=('date','cardNum','group','user','dept','merchant','purpose','amount','category','attendees','note','attachments','lineItems')
            row={key:value[key] for key in allowed if key in value};row['returnSource']=card is not None;row.update(id=uuid.uuid4().hex,status='승인대기',requester=user,requestedAt=a.now())
            for f in ('approvedBy','approvedAt','rejectedBy','rejectedAt'):row.pop(f,None)
            if card:row.update(cardNum=card['num'],group=card['group'])
            row['entrySource']='YBY'
            if card:
                for name in ('applicationDate','applicantName'): 
                    if name in card:row[name]=card[name]
                row['rentalEntrySource']=card.get('entrySource','LEGACY')
                if card.get('sourceRef'):row['rentalSourceRef']=card['sourceRef']
            if scope not in ('ALL',row.get('group')):raise PermissionError('다른 지점 정산입니다.')
            domain.prepare_expense(row)
            domain.expense(row,state.get('cards',[]))
            registered=next(c for c in state['cards'] if c['num']==row['cardNum'] and c['group']==row['group'])
            row['cardId']=registered['id'];row['cardCompany']=registered.get('company','')
            row['attachments']=attachment_refs(a,row.get('attachments',[]),user,row['group'])
            state.setdefault('expense',[]).append(row);return row
        transaction(h,g,path,data,user,mutate)
    except PermissionError as e:h.send_json({'ok':False,'message':str(e)},403)
    except a.StateConflict as e:h.send_json({'ok':False,'message':str(e)},409)
    except (ValueError,TypeError,KeyError) as e:h.send_json({'ok':False,'message':str(e)},400)
    except Exception:
        import logging
        logging.exception('Business operation failed')
        h.send_json({'ok':False,'message':'작업을 완료하지 못했습니다. 입력을 유지하고 관리자에게 문의하세요.'},500)
    return True

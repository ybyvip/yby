"""Actual new corporate classifications and fleet bundle end-to-end UI."""
from pathlib import Path
import importlib.util,json,os,sys
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4113-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=f.app
    with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg']),));conn.commit()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);errors=[];dialogs=[]
        def login(name,password):
            page=browser.new_page(viewport={'width':1600,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
            def dialog(d):dialogs.append(d.message);d.accept()
            page.on('dialog',dialog);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function('(name)=>currentUser===name&&!loginInFlight',arg=name);page.evaluate('stopLiveSync()');return page
        page=login('admin','Admin-test-pass!');assert page.evaluate("()=>{const t=document.createElement('template');t.innerHTML=fleetFieldsHTML('editHipass',{id:151,hipassEnabled:true,issueDate:''});return t.content.querySelector('#editHipassIssueDate').value}")=='';page.click('#nav_v_card_reg');page.select_option('#regCardGroup','서울');page.select_option('#regCardPaymentType','체크');page.select_option('#regCardUsageScope','해외겸용')
        for key,value in {'regCardCompany':'시험카드사','regCardNum':'CORP-4112','regCardIssueDate':'2026-01-01','regCardExpiryDate':'2099-01-01'}.items():page.fill('#'+key,value)
        page.locator('#v_card_reg button[type=submit]').click();page.wait_for_function('()=>cardsData.some(c=>c.num==="CORP-4112")');assert '체크' in page.inner_text('#registeredCardTable') and '해외겸용' in page.inner_text('#registeredCardTable')
        page.get_by_role('button',name='수정',exact=True).click();page.select_option('#editCardPaymentType','신용');page.select_option('#editCardUsageScope','국내전용');page.locator('#modalFooter button').filter(has_text='저장').click();page.wait_for_selector('#commonModal',state='hidden');assert a.get_state()['cards'][0]['paymentType']=='신용'
        page.click('#nav_v_hipass_reg');assert '하이패스 관리' in page.inner_text('#nav_v_hipass_reg');page.check('#regHipassFuelEnabled');page.select_option('#regHipassGroup','서울');page.select_option('#regHipassClassification','직영승무원');page.select_option('#regHipassDistributionStatus','불출중')
        fields={'regHipassCompany':'시험 도로공사','regHipassNum':'HP-4112','regHipassUser':'시험 사용자','regHipassCar':'시험차량-01','regHipassIssueDate':'2026-01-01','regHipassExpiryDate':'2099-01-01','regHipassIssueArea':'서울','regHipassRoute':'서울-청주','regHipassReason':'업무 배부','regFuelCompany':'시험 유류카드사','regFuelNum':'FUEL-4112','regFuelAssignedUser':'시험 사용자','regFuelIssueDate':'2026-01-01','regFuelExpiryDate':'2099-01-01','regFuelCardAlias':'노선 주유카드'}
        for key,value in fields.items():page.fill('#'+key,value)
        page.select_option('#regFuelPaymentType','신용');page.select_option('#regFuelUsageScope','국내전용');page.select_option('#regFuelUserType','지정')
        for width in [1600,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});metrics=page.locator('#fleetRegisterFields').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert metrics['sw']<=metrics['w']+1,(width,metrics)
        page.set_viewport_size({'width':1600,'height':1100});page.locator('#fleetRegisterForm').screenshot(path=str(screens/'registration.png'))
        page.locator('#fleetRegisterForm button[type=submit]').click();page.wait_for_function('()=>hipassData.length===1');expect(page.locator('#commonModal')).to_be_visible()
        assert 'HP-4112' in page.inner_text('#modalBody') and 'FUEL-4112' in page.inner_text('#modalBody');assert a.get_state()['hipass'][0]['reviewStatus']=='draft'
        page.locator('#modalFooter button').filter(has_text='닫기').click();page.click('#nav_v_hipass_box');assert 'HP-4112' not in page.inner_text('#hipassBoxTable')
        page.click('#nav_v_hipass_reg');page.locator('#registeredHiPassTable button').filter(has_text='미리보기').click();page.locator('#modalFooter button').filter(has_text='정보 확인').click();page.wait_for_function('()=>hipassData[0].reviewStatus==="confirmed"')
        expect(page.locator('#v_hipass_box')).to_have_class('view-panel active');assert 'HP-4112' not in page.inner_text('#registeredHiPassTable');assert 'HP-4112' in page.inner_text('#hipassBoxTable') and 'FUEL-4112' in page.inner_text('#hipassBoxTable')
        assert page.locator('#hipassBoxTable tr').count()==1
        page.locator('#v_hipass_box').screenshot(path=str(screens/'grouped_list.png'))
        with page.expect_download() as d:page.evaluate("fleetExport('list')")
        with ZipFile(d.value.path()) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();assert 'HP-4112' in xml and 'FUEL-4112' in xml and '확인완료' in xml
        page.locator('#hipassBoxTable button').filter(has_text='수정').click()
        assert page.is_checked('#editHipassEnabled') and page.is_checked('#editHipassFuelEnabled');assert page.input_value('#editFuelNum')=='FUEL-4112'
        page.select_option('#editHipassDistributionStatus','회수중');page.fill('#editHipassCar','수정차량-02');page.fill('#editFuelCompany','수정 발급사');page.fill('#fleetChangeReason','차량 및 카드사 정정');page.fill('#fleetPassword','incorrect');page.locator('#modalFooter button').filter(has_text='변경 저장').click()
        page.wait_for_function('()=>document.getElementById("fleetPassword").value===""');assert a.get_state()['hipass'][0]['car']=='시험차량-01'
        page.fill('#fleetPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.wait_for_function('()=>hipassData[0].car==="수정차량-02"');assert 'HP-4112' not in page.inner_text('#hipassBoxTable') and 'HP-4112' in page.inner_text('#registeredHiPassTable');assert a.get_state()['hipass'][0]['reviewStatus']=='draft'
        expect(page.locator('#modalBody')).to_contain_text('수정 발급사');page.locator('#modalFooter button').filter(has_text='정보 확인').click();page.wait_for_function('()=>hipassData[0].reviewStatus==="confirmed"')
        page.click('#nav_v_hipass_status');page.locator('.fleet-branch-toggle').click();expect(page.locator('#fleetStatusContent')).to_contain_text('수정차량-02');expect(page.locator('#fleetStatusContent')).to_contain_text('직영승무원');assert page.locator('.fleet-branch-toggle').get_attribute('aria-expanded')=='true';page.evaluate('fleetRenderAll()');assert page.locator('.fleet-branch-toggle').get_attribute('aria-expanded')=='true';page.locator('.fleet-branch-toggle').press('Enter');assert page.locator('.fleet-branch-toggle').get_attribute('aria-expanded')=='false';page.locator('.fleet-branch-toggle').press('Enter');assert len(set(page.locator('.fleet-status-metrics .ledger-metric').evaluate_all('(els)=>els.map(x=>x.getBoundingClientRect().top)')))==1;page.locator('#v_hipass_status').screenshot(path=str(screens/'status.png'))
        page.click('#nav_v_hipass_history');page.locator('#fleetHistoryTable tr').filter(has_text='정보수정').get_by_role('button',name='변경 문서 열람').click();assert '시험차량-01' in page.inner_text('#modalBody') and '수정차량-02' in page.inner_text('#modalBody') and '차량 및 카드사 정정' in page.inner_text('#modalBody')
        assert page.locator('.fleet-comparison thead th').all_text_contents()==['항목','변경 전','변경 후'];assert page.locator('.fleet-changed').count()>=3;assert '회수중' in page.inner_text('.fleet-document-meta');assert '미기록' not in page.inner_text('.fleet-document-meta');page.locator('.modal-card').screenshot(path=str(screens/'history_document.png'));page.evaluate('document.body.classList.add("print-expense-detail")');page.emulate_media(media='print');page.pdf(path=str(screens/'history_document.pdf'),format='A4',print_background=True);page.emulate_media(media='screen');page.evaluate('document.body.classList.remove("print-expense-detail");closeModal()')
        with page.expect_download() as d:page.evaluate("fleetExport('history')")
        with ZipFile(d.value.path()) as z:assert '차량 및 카드사 정정' in z.read('xl/worksheets/sheet1.xml').decode()
        page.click('#nav_v_dashboard');expect(page.locator('#dashFuelCount')).to_have_text('1개');page.locator('[aria-label="유류대카드 상세 보기"]').click();expect(page.locator('#modalBody')).to_contain_text('FUEL-4112');expect(page.locator('#modalBody')).to_contain_text('회수중');page.evaluate('closeModal()')
        page.evaluate('openShortcutSettingModal()');assert page.locator('input[name=shortcutChk]').count()==page.evaluate('allViewIds.length');assert page.locator('input[name=shortcutChk]:disabled').count()==0
        page.locator('input[name=shortcutChk]').evaluate_all('(els)=>els.forEach(x=>x.checked=true)');page.get_by_role('button',name='저장하기',exact=True).click();page.wait_for_selector('#commonModal',state='hidden');assert page.locator('#userQuickShortcutsGrid button').count()==17
        assert len(a.get_state()['shortcuts']['admin'])==17
        page.locator('#userQuickShortcutsGrid button').filter(has_text='하이패스 등록·변경 이력').click();expect(page.locator('#v_hipass_history')).to_have_class('view-panel active')
        page.click('#nav_v_expense_history');assert page.locator('#expenseHistorySummary .ledger-metric strong').first.evaluate('(e)=>getComputedStyle(e).fontSize')=='17px';page.locator('#expenseHistorySummary').screenshot(path=str(screens/'compact_summary.png'))
        page.click('#nav_v_dashboard');page.locator('#v_dashboard').screenshot(path=str(screens/'dashboard.png'))
        # A failed shortcut save stays open and preserves server settings.
        page.evaluate('openShortcutSettingModal()');page.locator('input[name=shortcutChk][value=v_admin]').uncheck();before=list(a.get_state()['shortcuts']['admin'])
        page.route('**/api/state',lambda route:route.fulfill(status=500,content_type='application/json',body='{"ok":false,"message":"시험 저장 실패"}') if route.request.method=='POST' else route.continue_())
        page.get_by_role('button',name='저장하기',exact=True).click();page.wait_for_function('()=>stateSavePending===0');expect(page.locator('#commonModal')).to_be_visible();assert a.get_state()['shortcuts']['admin']==before;page.unroute('**/api/state');page.evaluate('closeModal()')
        # Branch can manage own data, sees aliases, cannot inspect foreign records.
        branch=login('branch','Branch-test-pass!');branch.click('#nav_v_hipass_status');branch.locator('.fleet-branch-toggle').click();assert '수정차량-02' in branch.inner_text('#fleetStatusContent');branch.click('#nav_v_hipass_history');assert '차량 및 카드사 정정' in branch.inner_text('#fleetHistoryTable')
        branch.click('#nav_v_hipass_reg');assert branch.locator('#regHipassGroup').is_disabled() and branch.input_value('#regHipassGroup')=='서울'
        # Registration-only grant includes the confirmed list, without widening mutation privileges.
        assert branch.evaluate("hasViewPermission('v_hipass_box')");branch.click('#nav_v_hipass_box');assert branch.locator('#hipassBoxTable button').filter(has_text='수정').count()==1
        branch.click('#nav_v_hipass_reg');branch.evaluate('fleetPreview(hipassData[0].id,hipassData[0].group)');branch.evaluate('closeModal()');assert 'HP-4112' not in branch.inner_text('#registeredHiPassTable')
        branch.click('#nav_v_hipass_box');branch.locator('#hipassBoxTable button').filter(has_text='삭제').click();branch.fill('#fleetDeleteReason','회수 후 폐기');branch.fill('#fleetDeletePassword','wrong');branch.locator('#modalFooter button').filter(has_text='삭제').click();branch.wait_for_function('()=>document.getElementById("fleetDeletePassword").value===""');assert len(a.get_state()['hipass'])==1
        branch.fill('#fleetDeletePassword','Branch-test-pass!');branch.locator('#modalFooter button').filter(has_text='삭제').click();branch.wait_for_function('()=>hipassData.length===0');assert not a.get_state()['hipass']
        branch.click('#nav_v_hipass_history');assert '삭제됨' in branch.inner_text('#fleetHistoryTable');branch.locator('#fleetHistoryTable tr').filter(has_text='카드삭제').get_by_role('button').click();expect(branch.locator('.fleet-comparison')).to_contain_text('FUEL-4112');branch.evaluate('closeModal()')
        branch.evaluate("switchView('v_hipass_reg',document.getElementById('nav_v_hipass_reg'));openShortcutSettingModal()");assert branch.locator('input[name=shortcutChk][value=v_admin]').is_disabled();assert not branch.locator('input[name=shortcutChk][value=v_hipass_box]').is_disabled();branch.evaluate('closeModal()')
        with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_box']),));conn.commit()
        viewer=login('readonly','Branch-test-pass!');viewer.click('#nav_v_hipass_box');assert viewer.locator('#hipassBoxTable button').filter(has_text='수정').count()==0
        # Status and input widths are usable on narrow displays; six desktop metrics remain one row.
        for width in [1600,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});page.evaluate("switchView('v_hipass_status',document.getElementById('nav_v_hipass_status'))")
            measure=page.locator('#fleetStatusContent').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert measure['sw']<=measure['w']+1,(width,measure)
            if width>=768:assert len(set(page.locator('.fleet-status-metrics .ledger-metric').evaluate_all('(els)=>els.map(x=>x.getBoundingClientRect().top)')))==1
        print('PASS: draft-only registration -> confirmed list transition; list edit/reconfirm and password/reason delete; current deleted status with original two-card document preserved; registration-only and read-only permissions')
        print('PASS: six desktop metrics on one row; keyboard accordion and refresh preserves expansion; compact form and 320px status fit; side-by-side highlighted before/after table and PDF; current status separate from snapshot')
        print('PASS: scoped fuel dashboard drilldown; all 17 shortcuts selectable and persisted, permission restrictions, failed save retains settings; compact on-screen settlement summary')
        assert not errors,errors
        print('PASS: corporate credit/debit and domestic/international register/edit/list persisted; fleet names and five classifications visible')
        print('PASS: separate Hi-pass and fuel inputs -> one draft bundle -> preview/confirm -> one grouped list row; real two-card XLSX; 1600/1024/768/390/320px fit')
        print('PASS: full edit fields, failed password preserves server data, correct password/reason resets confirmation; reconfirm -> regional status -> before/after audit document/export; branch scope and aliases; no JS errors')
        browser.close()
finally:f.SecurityTests.tearDownClass()

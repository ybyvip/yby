"""Compact fleet workflow: explicit status, current history, exports and read scopes."""
import copy,json,unittest
from io import BytesIO
from zipfile import ZipFile
import test_v4112 as baseline
import fleet_cards

class FleetRefreshTests(baseline.FleetTests):
    # Reuse fixture helpers, but do not duplicate the prior suite's test cases.
    pass
for name in dir(baseline.FleetTests):
    if name.startswith('test_'):setattr(FleetRefreshTests,name,None)

class RefreshTests(FleetRefreshTests):
    def test_distribution_states_and_return_completion_validation(self):
        self.assertEqual(self.op('register',self.payload(distributionStatus='없는 상태'))[0],400)
        self.assertEqual(self.op('register',self.payload(distributionStatus='회수완료'))[0],400)
        self.assertEqual(self.op('register',self.payload(distributionStatus='회수완료',returnDate='2099-01-01'))[0],400)
        row=self.register(distributionStatus='대기중');self.assertEqual(row['distributionStatus'],'대기중')
        row=self.confirm(row)[1]['hipass']
        for state in ('불출중','회수중','회수완료'):
            status,result,_=self.update(row,distributionStatus=state,returnDate=self.a.business_date() if state=='회수완료' else '')
            self.assertEqual(status,200,result);row=result['hipass'];self.assertEqual(row['distributionStatus'],state)
            row=self.confirm(row)[1]['hipass']
        self.assertEqual(fleet_cards.distribution_status(row,self.a.business_date()),'회수완료')
        self.assertEqual(self.update(row,returnDate='2099-01-01')[0],400)
    def test_old_client_update_preserves_explicit_distribution_state(self):
        row=self.register(distributionStatus='회수중');row=self.confirm(row)[1]['hipass']
        status,value,_=self.update(row,car='새 차량');self.assertEqual(status,200,value);self.assertEqual(value['hipass']['distributionStatus'],'회수중')
    def test_display_only_legacy_status_inference_does_not_rewrite_old_record(self):
        base={'hipassUser':'기존 사용자'};before=copy.deepcopy(base)
        self.assertEqual(fleet_cards.distribution_status(base,'2026-10-20'),'불출중');self.assertEqual(base,before)
        self.assertEqual(fleet_cards.distribution_status({**base,'reviewStatus':'draft'},'2026-10-20'),'대기중')
        self.assertEqual(fleet_cards.distribution_status({**base,'returnDate':'2099-01-01'},'2026-10-20'),'회수예정')
        self.assertEqual(fleet_cards.distribution_status({**base,'returnDate':'2026-01-01'},'2026-10-20'),'회수완료')
    def test_confirmed_rows_leave_registration_export_and_reappear_after_edit(self):
        row=self.register();row=self.confirm(row)[1]['hipass']
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertNotIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
        with ZipFile(BytesIO(self.export('list')[1])) as z:self.assertIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
        self.assertEqual(self.update(row,car='수정 차량')[0],200)
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
        with ZipFile(BytesIO(self.export('list')[1])) as z:self.assertNotIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
    def test_history_resolves_first_registration_and_current_status_not_old_snapshot(self):
        row=self.register(distributionStatus='불출중');event=self.a.get_state()['hipassBox'][0];created=row['createdAt']
        row=self.confirm(row)[1]['hipass'];status,value,_=self.update(row,distributionStatus='회수중');self.assertEqual(status,200,value)
        state=self.a.get_state();self.assertEqual(fleet_cards.history_context(event,state['hipass'],state['hipassBox'],self.a.business_date()),(created,'회수중'))
        with ZipFile(BytesIO(self.export('history')[1])) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('최초등록일시',xml);self.assertIn('현재 배부상태',xml);self.assertIn('회수중',xml);self.assertIn('FUEL-001',xml)
        row=value['hipass'];self.assertEqual(self.op('delete',{**self.ref(row),'password':'Branch-test-pass!','changeReason':'폐기'})[0],200)
        state=self.a.get_state();self.assertEqual(fleet_cards.history_context(event,state['hipass'],state['hipassBox'],self.a.business_date()),(created,'삭제됨'))
    def test_history_unknown_and_transfer_are_not_mislabelled_as_deleted(self):
        legacy={'id':1,'group':'서울','num':'UNKNOWN','action':'정보수정'}
        self.assertEqual(fleet_cards.history_context(legacy,[],[legacy],'2026-10-20'),('미기록','확인불가'))
        row=self.register();event=self.a.get_state()['hipassBox'][0]
        status,value,_=self.op('update',{**self.payload(group='인천'),**self.ref(row),'password':'Admin-test-pass!','changeReason':'이관'},self.c.admin);self.assertEqual(status,200,value)
        state=self.c.state(self.c.branch)['state'];self.assertEqual(fleet_cards.history_context(event,state['hipass'],state['hipassBox'],self.a.business_date())[1],'이관됨')
        self.assertNotIn('인천',json.dumps(state['hipassBox'],ensure_ascii=False))
    def test_history_only_can_read_current_own_status_but_cannot_mutate(self):
        row=self.register(distributionStatus='회수중')
        self.op('register',self.payload(group='인천',num='FOREIGN',fuelEnabled=False),self.c.admin)
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_history']),));conn.commit()
        cookie=self.c.login('readonly','Branch-test-pass!');state=self.c.state(cookie)['state']
        self.assertEqual(len(state['hipass']),1);self.assertEqual(state['hipass'][0]['distributionStatus'],'회수중');self.assertNotIn('FOREIGN',json.dumps(state))
        self.assertEqual(self.op('delete',{**self.ref(row),'password':'Branch-test-pass!','changeReason':'시도'},cookie)[0],403)
        self.assertEqual(self.export('history',cookie=cookie)[0],200)
    def test_dashboard_fuel_summary_is_scoped_and_details_are_permission_filtered(self):
        self.register();self.op('register',self.payload(group='인천',num='OTHER',fuelCard={**self.payload()['fuelCard'],'num':'OTHER-FUEL'}),self.c.admin)
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_dashboard']),));conn.commit()
        cookie=self.c.login('readonly','Branch-test-pass!');state=self.c.state(cookie)['state']
        self.assertEqual(state['dashboardSummary']['fuel'],1);self.assertEqual(state['dashboardSummary']['hipass'],1);self.assertEqual(state['hipass'],[])
        self.assertEqual(self.export('list',cookie=cookie)[0],403)
    def test_register_only_can_confirm_read_list_and_edit_delete_after_confirmation(self):
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg']),));conn.commit()
        row=self.register();row=self.confirm(row)[1]['hipass'];self.assertEqual(self.export('list')[0],200)
        self.assertEqual(self.update(row,car='리스트 수정')[0],200)
    def test_scoped_shortcuts_persist_more_than_four_without_mutating_other_users(self):
        own=['v_dashboard','v_card_rent','v_hipass_reg','v_hipass_box','v_hipass_status','v_hipass_history']
        self.assertEqual(self.c.save({'shortcuts':{'branch':own}},self.c.branch)[0],200)
        self.assertEqual(self.c.state(self.c.branch)['state']['shortcuts']['branch'],own)

if __name__=='__main__':unittest.main()

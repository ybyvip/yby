"""Actual new corporate classifications and fleet bundle end-to-end UI."""
from pathlib import Path
import importlib.util,json,os,sys
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('fixture',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby-v4112-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
    c.setUp();a=f.app
    with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg','v_hipass_box']),));conn.commit()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);errors=[];dialogs=[]
        def login(name,password):
            page=browser.new_page(viewport={'width':1600,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
            def dialog(d):dialogs.append(d.message);d.accept()
            page.on('dialog',dialog);page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
            page.goto(f'http://127.0.0.1:{c.server.server_port}/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',password);page.press('#loginPasswordInput','Enter');page.wait_for_function('(name)=>currentUser===name&&!loginInFlight',arg=name);page.evaluate('stopLiveSync()');return page
        page=login('admin','Admin-test-pass!');page.click('#nav_v_card_reg');page.select_option('#regCardGroup','서울');page.select_option('#regCardPaymentType','체크');page.select_option('#regCardUsageScope','해외겸용')
        for key,value in {'regCardCompany':'시험카드사','regCardNum':'CORP-4112','regCardIssueDate':'2026-01-01','regCardExpiryDate':'2099-01-01'}.items():page.fill('#'+key,value)
        page.locator('#v_card_reg button[type=submit]').click();page.wait_for_function('()=>cardsData.some(c=>c.num==="CORP-4112")');assert '체크' in page.inner_text('#registeredCardTable') and '해외겸용' in page.inner_text('#registeredCardTable')
        page.get_by_role('button',name='수정',exact=True).click();page.select_option('#editCardPaymentType','신용');page.select_option('#editCardUsageScope','국내전용');page.locator('#modalFooter button').filter(has_text='저장').click();page.wait_for_selector('#commonModal',state='hidden');assert a.get_state()['cards'][0]['paymentType']=='신용'
        page.click('#nav_v_hipass_reg');assert '하이패스 관리' in page.inner_text('#nav_v_hipass_reg');page.check('#regHipassFuelEnabled');page.select_option('#regHipassGroup','서울');page.select_option('#regHipassClassification','직영승무원')
        fields={'regHipassCompany':'시험 도로공사','regHipassNum':'HP-4112','regHipassUser':'시험 사용자','regHipassCar':'시험차량-01','regHipassIssueDate':'2026-01-01','regHipassExpiryDate':'2099-01-01','regHipassIssueArea':'서울','regHipassRoute':'서울-청주','regHipassReason':'업무 배부','regFuelCompany':'시험 유류카드사','regFuelNum':'FUEL-4112','regFuelAssignedUser':'시험 사용자','regFuelIssueDate':'2026-01-01','regFuelExpiryDate':'2099-01-01','regFuelCardAlias':'노선 주유카드'}
        for key,value in fields.items():page.fill('#'+key,value)
        page.select_option('#regFuelPaymentType','신용');page.select_option('#regFuelUsageScope','국내전용');page.select_option('#regFuelUserType','지정')
        for width in [1600,1024,768,390,320]:
            page.set_viewport_size({'width':width,'height':1100});metrics=page.locator('#fleetRegisterFields').evaluate('(e)=>({w:e.clientWidth,sw:e.scrollWidth})');assert metrics['sw']<=metrics['w']+1,(width,metrics)
        page.set_viewport_size({'width':1600,'height':1100});page.locator('#fleetRegisterForm').screenshot(path=str(screens/'registration.png'))
        page.locator('#fleetRegisterForm button[type=submit]').click();page.wait_for_function('()=>hipassData.length===1');expect(page.locator('#commonModal')).to_be_visible()
        assert 'HP-4112' in page.inner_text('#modalBody') and 'FUEL-4112' in page.inner_text('#modalBody');assert a.get_state()['hipass'][0]['reviewStatus']=='draft'
        page.locator('#modalFooter button').filter(has_text='닫기').click();page.click('#nav_v_hipass_box');assert 'HP-4112' not in page.inner_text('#hipassBoxTable')
        page.click('#nav_v_hipass_reg');page.locator('#registeredHiPassTable button').filter(has_text='미리보기').click();page.locator('#modalFooter button').filter(has_text='정보 확인').click();page.wait_for_function('()=>hipassData[0].reviewStatus==="confirmed"')
        expect(page.locator('#v_hipass_box')).to_have_class('view-panel active');assert 'HP-4112' in page.inner_text('#hipassBoxTable') and 'FUEL-4112' in page.inner_text('#hipassBoxTable')
        assert page.locator('#hipassBoxTable tr').count()==1
        page.locator('#v_hipass_box').screenshot(path=str(screens/'grouped_list.png'))
        with page.expect_download() as d:page.evaluate("fleetExport('list')")
        with ZipFile(d.value.path()) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();assert 'HP-4112' in xml and 'FUEL-4112' in xml and '확인완료' in xml
        page.click('#nav_v_hipass_reg');page.locator('#registeredHiPassTable button').filter(has_text='수정').click()
        assert page.is_checked('#editHipassEnabled') and page.is_checked('#editHipassFuelEnabled');assert page.input_value('#editFuelNum')=='FUEL-4112'
        page.fill('#editHipassCar','수정차량-02');page.fill('#editFuelCompany','수정 발급사');page.fill('#fleetChangeReason','차량 및 카드사 정정');page.fill('#fleetPassword','incorrect');page.locator('#modalFooter button').filter(has_text='변경 저장').click()
        page.wait_for_function('()=>document.getElementById("fleetPassword").value===""');assert a.get_state()['hipass'][0]['car']=='시험차량-01'
        page.fill('#fleetPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='변경 저장').click();page.wait_for_function('()=>hipassData[0].car==="수정차량-02"');assert a.get_state()['hipass'][0]['reviewStatus']=='draft'
        expect(page.locator('#modalBody')).to_contain_text('수정 발급사');page.locator('#modalFooter button').filter(has_text='정보 확인').click();page.wait_for_function('()=>hipassData[0].reviewStatus==="confirmed"')
        page.click('#nav_v_hipass_status');expect(page.locator('#fleetStatusContent')).to_contain_text('수정차량-02');expect(page.locator('#fleetStatusContent')).to_contain_text('직영승무원');page.locator('#v_hipass_status').screenshot(path=str(screens/'status.png'))
        page.click('#nav_v_hipass_history');page.locator('#fleetHistoryTable tr').filter(has_text='정보수정').get_by_role('button',name='변경 문서 열람').click();assert '시험차량-01' in page.inner_text('#modalBody') and '수정차량-02' in page.inner_text('#modalBody') and '차량 및 카드사 정정' in page.inner_text('#modalBody')
        page.locator('.modal-card').screenshot(path=str(screens/'history_document.png'));page.evaluate('document.body.classList.add("print-expense-detail")');page.emulate_media(media='print');page.pdf(path=str(screens/'history_document.pdf'),format='A4',print_background=True);page.emulate_media(media='screen');page.evaluate('document.body.classList.remove("print-expense-detail");closeModal()')
        with page.expect_download() as d:page.evaluate("fleetExport('history')")
        with ZipFile(d.value.path()) as z:assert '차량 및 카드사 정정' in z.read('xl/worksheets/sheet1.xml').decode()
        # Branch can manage own data, sees aliases, cannot inspect foreign records.
        branch=login('branch','Branch-test-pass!');branch.click('#nav_v_hipass_status');assert '수정차량-02' in branch.inner_text('#fleetStatusContent');branch.click('#nav_v_hipass_history');assert '차량 및 카드사 정정' in branch.inner_text('#fleetHistoryTable')
        branch.click('#nav_v_hipass_reg');assert branch.locator('#regHipassGroup').is_disabled() and branch.input_value('#regHipassGroup')=='서울'
        assert not errors,errors
        print('PASS: corporate credit/debit and domestic/international register/edit/list persisted; fleet names and five classifications visible')
        print('PASS: separate Hi-pass and fuel inputs -> one draft bundle -> preview/confirm -> one grouped list row; real two-card XLSX; 1600/1024/768/390/320px fit')
        print('PASS: full edit fields, failed password preserves server data, correct password/reason resets confirmation; reconfirm -> regional status -> before/after audit document/export; branch scope and aliases; no JS errors')
        browser.close()
finally:f.SecurityTests.tearDownClass()

"""Fleet bundle lifecycle, authoritative audit, exports and backward compatibility."""
import copy,json,sqlite3,unittest
from unittest import mock
from zipfile import ZipFile
from io import BytesIO
from urllib.parse import urlencode
import test_v4 as workflow

class FleetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):workflow.V4Tests.setUpClass()
    @classmethod
    def tearDownClass(cls):workflow.V4Tests.tearDownClass()
    def setUp(self):
        self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg','v_hipass_box']),));conn.commit()
    def payload(self,**extra):return {'group':'서울','classification':'직원','hipassEnabled':True,'fuelEnabled':True,'hipassUser':'사용자','car':'시험차량','type':'선불형','company':'도로공사','num':'HP-001','issueDate':'2026-01-01','expiryDate':'2099-01-01','returnDate':'','reason':'업무 배부','issueArea':'서울','route':'서울-청주','fuelCard':{'company':'시험카드사','num':'FUEL-001','paymentType':'신용','usageScope':'국내전용','userType':'지정','assignedUser':'사용자','issueDate':'2026-01-01','expiryDate':'2099-01-01','cardAlias':'업무 주유'},**extra}
    def op(self,action,payload,cookie=None):return self.w.operation('/api/hipass/'+action,payload,cookie)
    def register(self,**extra):
        status,value,_=self.op('register',self.payload(**extra));self.assertEqual(status,200,value);return value['hipass']
    def ref(self,row):return {'id':row['id'],'recordGroup':row['group'],'expectedVersion':row.get('recordVersion')}
    def confirm(self,row):return self.op('confirm',self.ref(row))
    def update(self,row,**extra):return self.op('update',{**self.payload(),**self.ref(row),'changeReason':'배부정보 정정','password':'Branch-test-pass!',**extra})
    def export(self,mode='list',cookie=None,**params):return self.c.request('/api/hipass/export?'+urlencode({'mode':mode,**params}),cookie=cookie or self.c.branch)
    def test_registration_is_one_bundle_two_cards_and_preview_confirmation_is_explicit(self):
        row=self.register();state=self.a.get_state();self.assertEqual(len(state['hipass']),1);self.assertEqual(row['reviewStatus'],'draft');self.assertEqual(row['fuelCard']['num'],'FUEL-001')
        self.assertEqual(state['hipassBox'][0]['after']['id'],row['id']);self.assertIsNone(state['hipassBox'][0]['before'])
        with ZipFile(BytesIO(self.export()[1])) as z:self.assertNotIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
        status,value,_=self.confirm(row);self.assertEqual(status,200,value);self.assertEqual(value['hipass']['confirmedBy'],'branch')
        with ZipFile(BytesIO(self.export()[1])) as z:
            xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('HP-001',xml);self.assertIn('FUEL-001',xml);self.assertIn('직원',xml)
    def test_full_update_requires_password_reason_and_invalidates_confirmation(self):
        row=self.register();row=self.confirm(row)[1]['hipass']
        self.assertEqual(self.update(row,password='bad')[0],403);self.assertEqual(self.update(row,changeReason='')[0],400)
        status,value,_=self.update(row,num='HP-NEW',company='새 발급사',hipassUser='다른 사용자',car='새차량',classification='직영승무원',type='후불형')
        self.assertEqual(status,200,value);new=value['hipass'];self.assertEqual(new['reviewStatus'],'draft');self.assertEqual(new['num'],'HP-NEW')
        event=self.a.get_state()['hipassBox'][-1];self.assertEqual(event['before']['num'],'HP-001');self.assertEqual(event['after']['car'],'새차량');self.assertEqual(event['changeReason'],'배부정보 정정');self.assertNotIn('password',json.dumps(event))
    def test_generic_state_cannot_bypass_update_reauthentication_or_forge_history(self):
        self.register();state=self.a.get_state();rows=copy.deepcopy(state['hipass']);rows[0]['car']='forged'
        for cookie in (self.c.branch,self.c.admin):
            self.assertEqual(self.c.save({'hipass':rows},cookie)[0],403)
            history=copy.deepcopy(state['hipassBox']);history[0]['action']='forged'
            self.assertEqual(self.c.save({'hipassBox':history},cookie)[0],403)
            self.assertEqual(self.a.get_state()['hipassBox'],state['hipassBox'])
    def test_unique_numbers_include_fuel_and_normalized_duplicates(self):
        self.register();self.assertEqual(self.op('register',self.payload(num='H-P001'))[0],400)
        p=self.payload(num='HP-002');p['fuelCard']['num']='F U E L-001';self.assertEqual(self.op('register',p)[0],400)
        p=self.payload(num='HP-002');p['fuelCard']['num']='HP-002';self.assertEqual(self.op('register',p)[0],400)
        self.assertEqual(len(self.a.get_state()['hipass']),1)
    def test_fuel_only_and_hipass_only_are_supported_without_fake_card_numbers(self):
        row=self.register(hipassEnabled=False);self.assertEqual(row['num'],'');self.assertEqual(row['fuelCard']['num'],'FUEL-001')
        row=self.register(num='HP-ONLY',fuelEnabled=False);self.assertNotIn('fuelCard',row)
        self.assertEqual(self.op('register',self.payload(hipassEnabled=False,fuelEnabled=False))[0],400)
    def test_fuel_dates_categories_and_classification_validate(self):
        for change in [{'classification':'잘못된분류'},{'returnDate':'2025-01-01'},{'expiryDate':'2025-01-01'}]:self.assertEqual(self.op('register',self.payload(**change))[0],400)
        for field,value in [('paymentType','invalid'),('usageScope','invalid'),('assignedUser',''),('expiryDate','2025-01-01')]:
            p=self.payload();p['fuelCard'][field]=value;self.assertEqual(self.op('register',p)[0],400)
        self.assertFalse(self.a.get_state().get('hipass'))
    def test_branch_registration_is_scoped_and_foreign_update_confirm_delete_are_blocked(self):
        row=self.register(group='인천');self.assertEqual(row['group'],'서울')
        status,value,_=self.op('register',self.payload(group='인천',num='OTHER',fuelEnabled=False),self.c.admin);self.assertEqual(status,200)
        foreign=value['hipass']
        for action in ('confirm','update','delete'):
            value={**self.payload(),**self.ref(foreign),'password':'Branch-test-pass!','changeReason':'시도'};self.assertEqual(self.op(action,value)[0],403)
        with ZipFile(BytesIO(self.export('register')[1])) as z:self.assertNotIn('OTHER',z.read('xl/worksheets/sheet1.xml').decode())
    def test_stale_version_and_duplicate_confirmation_do_not_make_new_events(self):
        row=self.register();new=self.confirm(row)[1]['hipass'];count=len(self.a.get_state()['hipassBox'])
        self.assertEqual(self.update(row)[0],409);self.assertEqual(self.confirm(new)[0],400);self.assertEqual(len(self.a.get_state()['hipassBox']),count)
    def test_delete_requires_password_and_reason_and_preserves_documents(self):
        row=self.register();self.assertEqual(self.op('delete',{**self.ref(row),'password':'bad','changeReason':'삭제'})[0],403)
        self.assertEqual(self.op('delete',{**self.ref(row),'password':'Branch-test-pass!','changeReason':'회수 후 폐기'})[0],200)
        state=self.a.get_state();self.assertFalse(state['hipass']);self.assertIsNone(state['hipassBox'][-1]['after']);self.assertEqual(state['hipassBox'][-1]['before']['fuelCard']['num'],'FUEL-001')
    def test_admin_branch_transfer_does_not_leak_other_branch_snapshots(self):
        row=self.register();status,value,_=self.op('update',{**self.payload(group='인천'),**self.ref(row),'password':'Admin-test-pass!','changeReason':'지점 이관'},self.c.admin);self.assertEqual(status,200,value)
        own=self.c.state(self.c.branch)['state'];self.assertFalse(own['hipass']);events=own['hipassBox'];last=events[-1];self.assertIsNone(last['after']);self.assertEqual(last['before']['group'],'서울')
    def test_failed_save_rolls_back_bundle_and_audit(self):
        row=self.register();before=copy.deepcopy(self.a.get_state())
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated save failure')):self.assertEqual(self.update(row,car='수정')[0],500)
        self.assertEqual(self.a.get_state(),before)
    def test_export_read_only_permissions_filters_and_real_xlsx(self):
        row=self.register();self.confirm(row)
        with self.a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_box']),));conn.commit()
        viewer=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.export(cookie=viewer)[0],200)
        self.assertEqual(self.op('confirm',self.ref(row),viewer)[0],403)
        with ZipFile(BytesIO(self.export(classification='임원')[1])) as z:self.assertNotIn('FUEL-001',z.read('xl/worksheets/sheet1.xml').decode())
        self.assertEqual(self.c.request('/api/hipass/export')[0],401)
    def test_legacy_registration_and_records_remain_explicitly_unclassified(self):
        p={k:v for k,v in self.payload(fuelEnabled=False).items() if k not in ('hipassEnabled','fuelEnabled','classification','fuelCard')}
        status,value,_=self.op('register',p);self.assertEqual(status,200,value);self.assertEqual(value['hipass']['classification'],'');self.assertEqual(value['hipass']['reviewStatus'],'draft')
    def test_corporate_card_credit_debit_and_usage_scope_validate_and_persist(self):
        status,value,_=self.w.operation('/api/cards/register',{'num':'NEW-CORP','company':'카드사','group':'서울','paymentType':'체크','usageScope':'해외겸용'},self.c.admin)
        self.assertEqual(status,200);self.assertEqual(value['card']['paymentType'],'체크');self.assertEqual(value['card']['usageScope'],'해외겸용')
        cards=self.a.get_state()['cards'];cards[-1]['paymentType']='invalid';self.assertEqual(self.c.save({'cards':cards},self.c.admin)[0],400)
    def test_full_backup_preserves_bundles_and_change_snapshots(self):
        import backup_manager,tempfile
        from pathlib import Path
        row=self.register();self.update(row,car='다른차량')
        with tempfile.TemporaryDirectory() as d:
            archive=Path(d)/'backup.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive);target=Path(d)/'restored';backup_manager.restore(archive,target)
            with sqlite3.connect(target/self.a.DB_PATH.name) as conn:
                self.assertEqual(conn.execute('SELECT COUNT(*) FROM hipass_cards').fetchone()[0],1);self.assertEqual(conn.execute('SELECT COUNT(*) FROM hipass_events').fetchone()[0],2)
    def test_unrelated_branch_save_with_own_fleet_echo_preserves_global_order(self):
        self.register()
        self.assertEqual(self.op('register',self.payload(group='인천',num='FOREIGN',fuelEnabled=False),self.c.admin)[0],200)
        before=copy.deepcopy(self.a.get_state()['hipass']);scoped=self.c.state(self.c.branch)['state']
        self.assertEqual(self.c.save({'hipass':scoped['hipass'],'hipassBox':scoped['hipassBox']},self.c.branch)[0],200)
        self.assertEqual(self.a.get_state()['hipass'],before)

if __name__=='__main__':unittest.main()

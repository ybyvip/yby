"""Home/company isolation and pre-update recovery artifact regression checks."""
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('home_workflow', ROOT / 'dev_tools/workflow.py')
workflow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(workflow)


class HomeWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / '가정 개발 폴더'
        self.root.mkdir()
        self.patcher = patch.object(workflow, 'ROOT', self.root)
        self.patcher.start()
        self.addCleanup(self.patcher.stop)

    def test_inherited_company_overrides_never_reach_home(self):
        with patch.dict(os.environ, {'V3_DATA_DIR': '/company/data', 'V3_TLS_KEY': '/company/key',
                                     'V4_LAN_SERVER_IP': '10.10.0.121', 'OTHER_SETTING': 'kept'}):
            env = workflow.home_env()
        self.assertEqual(env['V3_DATA_DIR'], str(self.root / 'data'))
        self.assertEqual(env['V3_HOST'], '127.0.0.1')
        self.assertEqual(env['V3_PORT'], '5100')
        self.assertNotIn('V3_TLS_KEY', env)
        self.assertNotIn('V4_LAN_SERVER_IP', env)
        self.assertEqual(env['OTHER_SETTING'], 'kept')

    def test_private_or_external_paths_cannot_enter_company_package(self):
        for name in ['../app.py', '/app.py', 'data/private.txt', 'data/corporate_card_system.db',
                     'certificates/root-ca.cer', '.env', 'private.key', 'lan_settings.json',
                     'server.pid', 'backups/test.txt', 'C:/private.txt', 'tools/../../data.db']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                workflow.safe_program_path(name)

    def test_allowed_code_and_harmless_data_readme(self):
        (self.root / 'app.py').write_text('test = 1')
        (self.root / 'data').mkdir()
        (self.root / 'data/README_데이터파일위치.txt').write_text('readme')
        self.assertEqual(workflow.safe_program_path('app.py'), self.root / 'app.py')
        self.assertTrue(workflow.safe_program_path('data/README_데이터파일위치.txt').is_file())

    @unittest.skipIf(os.name == 'nt', 'Windows symlink creation can require extra privilege')
    def test_symlink_cannot_export_outside_file(self):
        outside = self.root.parent / 'secret.py'
        outside.write_text('secret = 1')
        (self.root / 'linked.py').symlink_to(outside)
        with self.assertRaises(ValueError):
            workflow.safe_program_path('linked.py')

    def test_new_source_requires_explicit_registration_and_private_data_is_ignored(self):
        (self.root / 'dev_tools').mkdir()
        files = ['app.py', 'dev_tools/package_files.json', 'dev_tools/EXTRA_FILES.txt']
        (self.root / 'app.py').write_text('value = 1')
        (self.root / 'dev_tools/package_files.json').write_text(json.dumps({'files': files}))
        extra = self.root / 'dev_tools/EXTRA_FILES.txt'
        extra.write_text('# no extra\n')
        (self.root / 'data').mkdir()
        (self.root / 'data/private.db').write_bytes(b'private')
        self.assertEqual(set(workflow.selected_files()[0]), set(files))
        (self.root / 'new_feature.py').write_text('value = 2')
        with self.assertRaisesRegex(ValueError, 'EXTRA_FILES'):
            workflow.selected_files()
        extra.write_text('new_feature.py\n')
        self.assertIn('new_feature.py', workflow.selected_files()[0])

    def test_snapshot_keeps_old_program_database_receipts_certificate_and_keys(self):
        target = self.root / 'company'
        (target / 'data/attachments').mkdir(parents=True)
        database = target / 'data/corporate_card_system.db'
        with sqlite3.connect(database) as conn:
            conn.execute('CREATE TABLE example (value TEXT)')
            conn.execute("INSERT INTO example VALUES ('company-only')")
        (target / 'app.py').write_text('old_version = True')
        (target / 'data/attachments/receipt.bin').write_bytes(b'company-receipt')
        (target / 'data/admin_password_vault.key').write_bytes(b'company-key')
        (target / 'certificates').mkdir()
        (target / 'certificates/server.key').write_bytes(b'company-tls-key')
        (target / 'lan_settings.json').write_text('{"port": 5000}')
        (target / 'server.pid').write_text('obsolete')
        (target / 'data.runtime.lock').write_bytes(b'')
        before = workflow.digest(database)
        archive = workflow.snapshot_runtime(target, self.root / 'backup')
        self.assertEqual(workflow.digest(database), before)
        with zipfile.ZipFile(archive) as z:
            self.assertIsNone(z.testzip())
            manifest = json.loads(z.read('SNAPSHOT_MANIFEST.json'))
            for name, sha in manifest['files'].items():
                self.assertEqual(workflow.hashlib.sha256(z.read(name)).hexdigest(), sha)
            self.assertEqual(z.read('app/data/attachments/receipt.bin'), b'company-receipt')
            self.assertEqual(z.read('app/certificates/server.key'), b'company-tls-key')
            self.assertEqual(z.read('app/data/admin_password_vault.key'), b'company-key')
            self.assertNotIn('app/server.pid', z.namelist())
            self.assertNotIn('app/data.runtime.lock', z.namelist())

    def test_corrupt_company_database_blocks_backup_and_update(self):
        target = self.root / 'company'
        (target / 'data').mkdir(parents=True)
        (target / 'data/corporate_card_system.db').write_bytes(b'not a database')
        with self.assertRaises(sqlite3.DatabaseError):
            workflow.snapshot_runtime(target, self.root / 'backup')
        self.assertEqual(list((self.root / 'backup').glob('*.zip')), [])


if __name__ == '__main__':
    unittest.main()

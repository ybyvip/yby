"""Isolated home development and data-free, tested company deployment packages."""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.request
import webbrowser
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PORT = 5100
VERSION = '4.1.1'
URL = f'http://127.0.0.1:{PORT}/'
FORBIDDEN = {'data', 'certificates', 'LAN_CLIENT', 'backups', 'logs', 'dist',
             'program_backups', '__pycache__', '.git', '.venv', 'node_modules'}
PRIVATE_SUFFIXES = {'.db', '.sqlite', '.sqlite3', '.key', '.pem', '.cer', '.pfx', '.p12',
                    '.log', '.lock', '.pyc', '.zip', '.env'}
PRIVATE_NAMES = {'server.pid', 'lan_settings.json', 'source_data_imports.json',
                 'state.json', 'state_latest.json', 'MANIFEST.json', 'BUILD_INFO.json'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def clean_env():
    # Inherited company data/TLS/session overrides must never reach home mode.
    env = {k: v for k, v in os.environ.items() if not k.startswith(('V3_', 'V4_'))}
    env.update(PYTHONUTF8='1', PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1')
    return env


def home_env():
    return dict(clean_env(), V3_DATA_DIR=str(ROOT / 'data'), V3_PORT=str(PORT),
                V3_HOST='127.0.0.1', V3_AUTO_BROWSER='0')


def root_imports():
    sys.path.insert(0, str(ROOT))


def home_start(no_browser=False):
    print('가정용 개발 폴더: ' + str(ROOT), flush=True)
    print('가정용 시험 자료: ' + str(ROOT / 'data'), flush=True)
    print('로그인 주소: ' + URL, flush=True)
    print('최초 실행 창의 [최초 임시 비밀번호] admin 값을 사용하세요.', flush=True)
    print('이 창은 유지하세요. 종료: Ctrl+C / 수정 반영: 종료 후 다시 시작', flush=True)
    args = [sys.executable, '-u', str(ROOT / 'run_ready.py'), '--local', '--port', str(PORT)]
    if no_browser:
        args.append('--no-browser')
    return subprocess.call(args, cwd=ROOT, env=home_env())


def home_login(no_browser=False):
    # Do not mistake an unrelated listener for the app in this development folder.
    root_imports()
    import active_runtime
    info = active_runtime.probe(ROOT)
    if not info or int(info['port']) != PORT or info['scheme'] != 'http':
        raise RuntimeError('이 폴더의 가정용 서버가 실행 중이 아닙니다. 먼저 HOME_START.bat를 실행하세요.')
    print('확인된 가정용 서버: ' + URL)
    if not no_browser:
        webbrowser.open(URL, new=1)
    return 0


def home_reset():
    root_imports()
    from db_lock import DatabaseLock
    # Prevent a running home server and reset from writing at the same time.
    with DatabaseLock(ROOT / 'data'):
        if not (ROOT / 'data/corporate_card_system.db').is_file():
            raise RuntimeError('먼저 HOME_START.bat로 최초 실행한 뒤 서버를 종료하세요.')
        print('집의 시험용 admin 비밀번호만 재설정합니다. 서버가 종료되어 있어야 합니다.')
        return subprocess.call([sys.executable, str(ROOT / 'reset_admin.py')], cwd=ROOT, env=home_env())


def safe_program_path(name):
    if not isinstance(name, str) or not name or '\\' in name or ':' in name:
        raise ValueError('잘못된 프로그램 경로: ' + str(name))
    parts = PurePosixPath(name).parts
    if PurePosixPath(name).is_absolute() or '..' in parts or not parts:
        raise ValueError('폴더 밖의 경로는 포함할 수 없습니다: ' + name)
    # The existing, harmless data readme is the only permitted data member.
    readme = name == 'data/README_데이터파일위치.txt'
    if (not readme and (FORBIDDEN.intersection(parts) or Path(name).suffix.lower() in PRIVATE_SUFFIXES)) or Path(name).name in PRIVATE_NAMES:
        raise ValueError('업무 자료·실행 정보·인증서는 배포할 수 없습니다: ' + name)
    if any(part.startswith('.env') or part.endswith('.runtime.lock') for part in parts):
        raise ValueError('실행 환경 파일은 배포할 수 없습니다: ' + name)
    source = ROOT / name
    if any(p.is_symlink() for p in [source, *source.parents] if p.is_relative_to(ROOT)):
        raise ValueError('연결된 파일은 배포할 수 없습니다: ' + name)
    if not source.resolve().is_relative_to(ROOT) or not source.is_file():
        raise ValueError('배포할 파일이 없습니다: ' + name)
    return source


def selected_files():
    baseline = json.loads((ROOT / 'dev_tools/package_files.json').read_text(encoding='utf-8'))
    files = set(baseline['files'])
    additions = ROOT / 'dev_tools/EXTRA_FILES.txt'
    if additions.exists():
        files.update(line.strip() for line in additions.read_text(encoding='utf-8-sig').splitlines()
                     if line.strip() and not line.lstrip().startswith('#'))
    for name in files:
        safe_program_path(name)
    # Newly added application code/assets must be deliberately listed, not silently lost.
    candidates = list(ROOT.glob('*.py'))
    for folder in ('templates', 'static', 'tests', 'tools', 'dev_tools'):
        candidates.extend((ROOT / folder).rglob('*'))
    unknown = []
    for path in candidates:
        name = path.relative_to(ROOT).as_posix()
        if not path.is_file() or name in files or FORBIDDEN.intersection(path.relative_to(ROOT).parts):
            continue
        if path.suffix.lower() in PRIVATE_SUFFIXES:
            continue
        unknown.append(name)
    if unknown:
        raise ValueError('새 소스 파일을 dev_tools/EXTRA_FILES.txt에 한 줄씩 등록하세요: ' + ', '.join(sorted(unknown)))
    return sorted(files), baseline


def export_company():
    names, baseline = selected_files()
    root_imports()
    from db_lock import DatabaseLock
    destination = ROOT / 'dist'
    destination.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    label = 'YBY_COMPANY_UPDATE_4_1_1_' + stamp
    output = destination / (label + '.zip')
    test_log = destination / (label + '_tests.txt')
    # Snapshot the actual code, then test exactly the bytes to be packaged.
    with DatabaseLock(ROOT / '.package-build'):
        with tempfile.TemporaryDirectory(prefix='.build-', dir=destination) as temp:
            stage = Path(temp) / label
            stage.mkdir()
            for name in names:
                target = stage / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(safe_program_path(name), target)
                if target.suffix == '.py':
                    compile(target.read_bytes(), name, 'exec')
            print('시험용 임시 폴더에서 전체 자동 검증을 실행합니다. 완료 전에는 ZIP을 만들지 않습니다.', flush=True)
            with test_log.open('w', encoding='utf-8') as log:
                result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
                                        cwd=stage, env=clean_env(), stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                print(test_log.read_text(encoding='utf-8')[-8000:])
                raise RuntimeError('검증 실패: 회사 배포 ZIP을 만들지 않았습니다. 결과: ' + str(test_log))
            # unittest can report success for zero tests; refuse that outcome.
            report = test_log.read_text(encoding='utf-8')
            import re
            count = re.search(r'Ran (\d+) tests? in ', report)
            outcome = re.search(r'^OK(?: \(skipped=(\d+)\))?$', report, re.MULTILINE)
            skipped = int(outcome.group(1) or 0) if outcome else 0
            if not count or not outcome or int(count.group(1)) - skipped < 158:
                raise RuntimeError('전체 158개 이상의 테스트 완료를 확인하지 못했습니다: ' + str(test_log))
            files = {name: digest(stage / name) for name in names}
            # Detect tests that accidentally changed staged program files.
            for name in names:
                if digest(stage / name) != digest(ROOT / name):
                    raise RuntimeError('검증 도중 소스가 바뀌었습니다. 편집을 멈추고 다시 빌드하세요: ' + name)
            changed = [name for name, sha in files.items() if baseline.get('hashes', {}).get(name) != sha]
            info = {'version': VERSION, 'build': stamp, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
                    'tests_run': int(count.group(1)), 'tests_skipped': skipped,
                    'tests_passed': int(count.group(1)) - skipped, 'tests_sha256': digest(test_log),
                    'changed_files': changed, 'contains_home_data': False,
                    'note': '자동 테스트 통과는 회사 Windows/브라우저/업무 검증을 대체하지 않습니다.'}
            (stage / 'BUILD_INFO.json').write_text(json.dumps(info, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            files['BUILD_INFO.json'] = digest(stage / 'BUILD_INFO.json')
            (stage / 'MANIFEST.json').write_text(json.dumps({'version': VERSION, 'files': files}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            temporary = Path(temp) / 'release.zip'
            with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as archive:
                for name in [*files, 'MANIFEST.json']:
                    archive.write(stage / name, label + '/' + name)
            with zipfile.ZipFile(temporary) as archive:
                if archive.testzip():
                    raise RuntimeError('ZIP 무결성 검사 실패')
            os.replace(temporary, output)
    checksum = output.with_suffix('.zip.sha256')
    checksum.write_text(digest(output) + '  ' + output.name + '\n', encoding='ascii')
    print('PASS: ' + str(info['tests_passed']) + ' tests / skipped: ' + str(skipped) + ' / ZIP CRC / MANIFEST SHA-256', flush=True)
    print('회사에 가져갈 ZIP: ' + str(output), flush=True)
    print('무결성 확인 파일: ' + str(checksum), flush=True)
    print('집의 DB·첨부·계정·비밀번호·인증서는 포함하지 않았습니다.', flush=True)
    print('회사에서 별도 폴더에 압축 해제 → 기존 서버 Ctrl+C → APPLY_COMPANY_UPDATE.bat', flush=True)
    if os.name == 'nt':
        os.startfile(destination)
    return 0


def verify_company_source():
    root_imports()
    import windows_bootstrap
    names = windows_bootstrap.source_files(ROOT)
    # Never let the bootstrap import home DB, certificates, or LAN settings.
    forbidden = ['data/corporate_card_system.db', 'certificates', 'lan_settings.json', 'LAN_CLIENT', 'server.pid']
    if any((ROOT / name).exists() for name in forbidden):
        raise RuntimeError('이 폴더에 시험자료/인증서/실행 기록이 있습니다. dist의 새 회사 배포 ZIP을 새 폴더에 압축 해제하세요.')
    for name in names:
        safe_program_path(name) if name != 'BUILD_INFO.json' else None
    return names


def snapshot_runtime(target, destination):
    """Caller holds the data lock. Archive old code, DB, receipts, keys and certs."""
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    destination.mkdir(parents=True, exist_ok=True)
    output = destination / ('runtime_before_update_' + stamp + '.zip')
    database = target / 'data/corporate_card_system.db'
    if not database.is_file():
        raise RuntimeError('기존 회사 업무 DB가 없습니다. 새 설치는 RUN_LAN_WINDOWS.bat를 사용하세요.')
    with closing(sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)) as conn:
        if conn.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise RuntimeError('기존 업무 DB 무결성 확인 실패: 업데이트를 중단했습니다.')
    entries = []
    for directory, dirs, files in os.walk(target, followlinks=False):
        dirs[:] = [name for name in dirs if name != '__pycache__']
        for name in [*dirs, *files]:
            path = Path(directory) / name
            if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
                raise RuntimeError('실행 폴더의 연결 경로는 백업할 수 없습니다: ' + str(path))
        for name in files:
            path = Path(directory) / name
            if name == 'server.pid' or name.endswith(('.runtime.lock', '.pyc')):
                continue
            entries.append(path)
    with tempfile.TemporaryDirectory(prefix='.backup-', dir=destination) as temp:
        pending = Path(temp) / output.name
        hashes = {}
        with zipfile.ZipFile(pending, 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in entries:
                name = 'app/' + path.relative_to(target).as_posix()
                hashes[name] = digest(path)
                archive.write(path, name)
            archive.writestr('SNAPSHOT_MANIFEST.json', json.dumps({'files': hashes}, ensure_ascii=False, indent=2))
        with zipfile.ZipFile(pending) as archive:
            if archive.testzip():
                raise RuntimeError('업데이트 전 백업 ZIP 손상')
            for name, sha in hashes.items():
                with archive.open(name) as stream:
                    h = hashlib.sha256()
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        h.update(block)
                    if h.hexdigest() != sha:
                        raise RuntimeError('업데이트 전 백업 검증 실패: ' + name)
        os.replace(pending, output)
    output.with_suffix('.zip.sha256').write_text(digest(output) + '  ' + output.name + '\n', encoding='ascii')
    print('검증된 업데이트 전 전체 실행폴더 백업: ' + str(output), flush=True)
    return output


def company_update(backup_only=False):
    if os.name != 'nt':
        raise RuntimeError('회사 적용은 기존 서버의 Windows 사용자 계정으로 실행하세요.')
    verify_company_source()
    local = os.environ.get('LOCALAPPDATA')
    if not local:
        raise RuntimeError('LOCALAPPDATA가 없습니다.')
    target = Path(local).resolve() / 'YBY/app'
    if target == ROOT or target.is_relative_to(ROOT) or ROOT.is_relative_to(target):
        raise RuntimeError('실행 폴더 밖의 새 폴더에 압축 해제하세요.')
    root_imports()
    from db_lock import DatabaseLock
    import active_runtime
    import process_identity
    if active_runtime.probe(target):
        raise RuntimeError('기존 서버 창에서 Ctrl+C로 먼저 종료하세요. 실행 중인 서버를 업데이트하지 않았습니다.')
    marker = target / 'server.pid'
    if marker.exists():
        meta = json.loads(marker.read_text(encoding='utf-8'))
        if process_identity.owns_app(meta['pid'], target / 'app.py'):
            raise RuntimeError('기존 서버 프로세스가 남아 있습니다. 기존 서버를 정상 종료하세요.')
    with DatabaseLock(target / '.launch'):
        with DatabaseLock(target / 'data'):
            snapshot_runtime(target, target.parent / 'pre_update_backups')
        if backup_only:
            return 0
        print('기존 회사 자료·계정·인증서를 유지하며 프로그램을 업데이트합니다.', flush=True)
        import windows_bootstrap
        windows_bootstrap.prepare_runtime(ROOT, target)
        print('업데이트 완료. 회사 사내망 서버를 시작합니다.', flush=True)
        # Hold the startup lock throughout startup; let the server acquire data lock itself.
        return subprocess.call([sys.executable, '-u', str(target / 'run_ready.py'), '--lan'], cwd=target, env=clean_env())


def main():
    if sys.version_info < (3, 11):
        raise RuntimeError('Python 3.11 이상을 설치하세요.')
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['home-start', 'home-login', 'home-reset', 'export', 'company-update', 'company-backup'])
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if args.action == 'home-start':
        return home_start(args.no_browser)
    if args.action == 'home-login':
        return home_login(args.no_browser)
    if args.action == 'home-reset':
        return home_reset()
    if args.action == 'export':
        return export_company()
    return company_update(backup_only=args.action == 'company-backup')


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(0)
    except Exception as error:
        print('\n[중단] ' + str(error), file=sys.stderr, flush=True)
        raise SystemExit(1)

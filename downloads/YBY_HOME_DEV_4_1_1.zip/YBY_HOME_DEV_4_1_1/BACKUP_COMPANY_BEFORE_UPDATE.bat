@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상을 설치하세요. https://www.python.org/downloads/windows/
pause
exit /b 1
:use_py
py -3 "%~dp0dev_tools\workflow.py" company-backup %*
goto finished
:use_python
python "%~dp0dev_tools\workflow.py" company-backup %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo 작업이 완료되지 않았습니다. 위의 오류 안내를 확인하세요.
pause
exit /b %RESULT%

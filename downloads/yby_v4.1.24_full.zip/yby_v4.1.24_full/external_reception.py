"""Revision-aware review receipts, independent from financial application bindings."""
import json
import external_documents as docs

def initialize(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS external_document_receipts(document_key TEXT NOT NULL,revision INTEGER NOT NULL,actor TEXT NOT NULL,received_at TEXT NOT NULL,PRIMARY KEY(document_key,revision))')

def received(conn,doc):return bool(conn.execute('SELECT 1 FROM external_document_receipts WHERE document_key=? AND revision=?',(doc['key'],doc['revision'])).fetchone())

def acknowledge(conn,doc,user,at):
    cursor=conn.execute('INSERT OR IGNORE INTO external_document_receipts VALUES(?,?,?,?)',(doc['key'],doc['revision'],user,at))
    return bool(cursor.rowcount)

def eligible(conn,doc):
    bound=conn.execute('SELECT target_ref FROM external_document_bindings WHERE document_key=?',(doc['key'],)).fetchone()
    if bound and json.loads(bound[0]).get('target',{}).get('historicalImport'):return False
    return not doc['withdrawn'] and not conn.execute('SELECT 1 FROM external_document_bindings WHERE document_key=? AND use_kind=?',(doc['key'],'settlement')).fetchone() and not conn.execute('SELECT 1 FROM external_document_matches WHERE application_key=? OR settlement_key=?',(doc['key'],doc['key'])).fetchone()

def receive(a,conn,data,user,scope):
    kind=data.get('kind')
    if kind not in ('application','settlement'):raise ValueError('문서 종류 오류')
    mode=data.get('selection');rows=[]
    if mode=='all':
        sql='SELECT payload FROM external_documents WHERE kind=?';args=[kind]
        if scope!='ALL':sql+=' AND branch=?';args.append(scope)
        rows=[json.loads(r[0]) for r in conn.execute(sql,args)]
        rows=[doc for doc in rows if eligible(conn,doc) and not received(conn,doc)]
        if len(rows)>5000:raise ValueError('전체 수신은 최대 5,000건입니다. 나누어 수신하세요.')
    elif mode=='selected':
        selected=data.get('documents')
        if not isinstance(selected,list) or not 1<=len(selected)<=5000:raise ValueError('수신할 자료를 선택하세요.')
        seen=set()
        for ref in selected:
            if not isinstance(ref,dict):raise ValueError('선택 문서 형식 오류')
            doc=docs.load(conn,ref.get('key'))
            if doc['kind']!=kind or scope not in ('ALL',doc['group']):raise PermissionError('다른 지점·종류의 자료입니다.')
            if type(ref.get('revision'))!=int or ref['revision']!=doc['revision']:raise ValueError('문서가 갱신되었습니다. 다시 확인하세요.')
            if doc['key'] in seen:raise ValueError('문서 중복 선택')
            if not eligible(conn,doc):raise ValueError('이미 매칭·적용되었거나 회수된 자료입니다.')
            seen.add(doc['key']);rows.append(doc)
    else:raise ValueError('전체 또는 개별 수신을 선택하세요.')
    count=sum(acknowledge(conn,row,user,a.now()) for row in rows)
    return {'received':count,'duplicates':len(rows)-count,'kind':kind}

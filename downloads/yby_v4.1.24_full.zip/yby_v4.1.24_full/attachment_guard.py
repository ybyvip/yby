"""Conservative document types/signatures; antivirus/EDR remains a company control."""
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,BadZipFile
import io
ALLOWED={'.pdf','.png','.jpg','.jpeg','.gif','.webp','.txt','.csv','.xlsx','.docx','.pptx','.xls','.doc','.ppt','.hwp','.hwpx','.zip'}
DANGEROUS={'.exe','.dll','.com','.bat','.cmd','.ps1','.vbs','.js','.jse','.scr','.msi','.hta','.lnk','.url','.html','.htm','.svg','.jar','.py','.reg'}
def validate(name,raw):
    suffix=Path(name).suffix.lower()
    if suffix not in ALLOWED:raise ValueError('허용하지 않는 첨부 형식입니다. PDF·이미지·Office·한글·텍스트 문서를 사용하세요.')
    if suffix in ('.pdf',) and not raw.startswith(b'%PDF'):raise ValueError('PDF 파일 내용과 확장자가 다릅니다.')
    signatures={'.png':b'\x89PNG\r\n\x1a\n','.jpg':b'\xff\xd8\xff','.jpeg':b'\xff\xd8\xff','.gif':b'GIF'}
    if suffix in signatures and not raw.startswith(signatures[suffix]):raise ValueError('이미지 파일 내용과 확장자가 다릅니다.')
    if suffix=='.webp' and not (raw.startswith(b'RIFF') and raw[8:12]==b'WEBP'):raise ValueError('WebP 형식 오류')
    if suffix in ('.txt','.csv'):
        if b'\x00' in raw:raise ValueError('텍스트 문서에 이진 데이터가 있습니다.')
    if suffix in ('.xls','.doc','.ppt','.hwp') and not raw.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'):raise ValueError('문서 파일 내용과 확장자가 다릅니다. 원본 프로그램에서 다시 저장하세요.')
    if suffix in ('.zip','.xlsx','.docx','.pptx','.hwpx'):
        try:
            with ZipFile(io.BytesIO(raw)) as z:
                entries=z.infolist()
                if len(entries)>3000 or sum(x.file_size for x in entries)>100*1024**2:raise ValueError('압축 문서의 크기·파일 수 제한을 초과했습니다.')
                for x in entries:
                    p=PurePosixPath(x.filename.replace('\\','/'))
                    if p.is_absolute() or '..' in p.parts or ':' in x.filename or x.flag_bits&1 or (x.external_attr>>16)&0o170000==0o120000:raise ValueError('안전하지 않은 압축 문서입니다.')
                    if p.suffix.lower() in DANGEROUS or 'vbaproject' in x.filename.lower() or p.suffix.lower() in ('.zip','.7z','.rar'):raise ValueError('실행 파일·매크로·중첩 압축은 첨부할 수 없습니다.')
                expected={'.xlsx':'xl/workbook.xml','.docx':'word/document.xml','.pptx':'ppt/presentation.xml','.hwpx':'mimetype'}.get(suffix)
                if expected and expected not in z.namelist():raise ValueError('문서 확장자와 내부 형식이 다릅니다.')
                if z.testzip():raise ValueError('손상된 압축 문서입니다.')
        except BadZipFile as e:raise ValueError('압축 문서 형식을 읽을 수 없습니다.') from e

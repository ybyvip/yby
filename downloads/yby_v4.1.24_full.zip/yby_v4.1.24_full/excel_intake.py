"""Bounded XLSX review/import. No macros, links or formulas are executed."""
import base64,hashlib,io,json,posixpath,re
from datetime import date,datetime,timedelta
from decimal import Decimal,InvalidOperation
from xml.etree import ElementTree as ET
from zipfile import ZipFile,BadZipFile
import domain,external_documents as docs
N={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
MAX_ROWS=2000
HEADERS={'카드번호(뒤4)':'last4','카드끝4자리':'last4','사용자':'user','실사용자':'user','은행명':'bank','카드사':'bank','부서명':'dept','부서':'dept','목적':'category','사용목적':'purpose','사용금액':'amount','합계금액':'amount','지급일':'issueDate','불출일':'issueDate','예정일':'dueDate','반납예정일':'dueDate','반납일':'returnDate','사용신청일':'applicationDate','신청자':'applicant','소속지점':'group','지점':'group','외부행ID':'sourceId','사용횟수':'sourceUseCount','순번':'number','직급':'position','사용기간':'sourcePeriod','전표':'voucherStatus','정리':'filingStatus','처리확인':'confirmationStatus','불출':'sourceIssueStatus','관리':'sourceManagementStatus','총분출횟수':'sourceTotalIssueCount'}

def initialize(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS excel_import_rows(record_key TEXT PRIMARY KEY,branch TEXT NOT NULL,content_hash TEXT NOT NULL,payload TEXT NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL)')

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def xml(raw):
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():raise ValueError('지원하지 않는 XML 선언입니다.')
    return ET.fromstring(raw)

def workbook(data):
    name=data.get('filename','')
    if not isinstance(name,str) or not name.lower().endswith('.xlsx'):raise ValueError('.xlsx 파일을 선택하세요. .xls는 Excel에서 xlsx로 저장하세요.')
    encoded=data.get('content')
    if not isinstance(encoded,str) or len(encoded)>1400000:raise ValueError('엑셀 파일은 최대 1MB입니다.')
    try:raw=base64.b64decode(encoded,validate=True)
    except (ValueError,TypeError):raise ValueError('엑셀 파일 전송 오류')
    if len(raw)>1024*1024:raise ValueError('엑셀 파일은 최대 1MB입니다.')
    try:
        with ZipFile(io.BytesIO(raw)) as z:
            entries=z.infolist();names=[i.filename for i in entries]
            if len(entries)>3000 or sum(i.file_size for i in entries)>20*1024*1024 or len(names)!=len(set(names)) or any(i.flag_bits&1 for i in entries):raise ValueError('엑셀 압축 크기·구조 제한을 초과했습니다.')
            if any('vbaproject' in n.lower() for n in names):raise ValueError('매크로 포함 파일은 지원하지 않습니다.')
            wb=xml(z.read('xl/workbook.xml'));epoch1904=wb.find('x:workbookPr',N);epoch1904=epoch1904 is not None and epoch1904.get('date1904') in ('1','true')
            sheets=wb.findall('x:sheets/x:sheet',N)
            if not sheets:raise ValueError('엑셀 시트가 없습니다.')
            selected=data.get('sheet') or sheets[0].get('name');sheet=next((s for s in sheets if s.get('name')==selected),None)
            if sheet is None:raise ValueError('시트를 찾을 수 없습니다.')
            rels=xml(z.read('xl/_rels/workbook.xml.rels'));rid=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            rel=next((r for r in rels if r.get('Id')==rid and r.get('Type','').endswith('/worksheet')),None)
            if rel is None or rel.get('TargetMode')=='External':raise ValueError('외부 시트는 읽지 않습니다.')
            target=rel.get('Target','');target=target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
            if not re.fullmatch(r'xl/worksheets/[^/]+\.xml',target):raise ValueError('지원하지 않는 시트 경로입니다.')
            strings=[]
            if 'xl/sharedStrings.xml' in names:
                strings=[''.join(t.text or '' for t in item.findall('.//x:t',N)) for item in xml(z.read('xl/sharedStrings.xml')).findall('x:si',N)]
                if len(strings)>100000:raise ValueError('엑셀 문자열 개수 제한')
            rows=[];cells=0
            for element in xml(z.read(target)).findall('x:sheetData/x:row',N):
                row={};missing=set()
                for cell in element.findall('x:c',N):
                    cells+=1
                    if cells>150000:raise ValueError('엑셀 셀 개수 제한')
                    ref=cell.get('r','');m=re.fullmatch(r'([A-Z]{1,3})([0-9]{1,7})',ref)
                    if not m:raise ValueError('셀 주소 오류')
                    value=cell.find('x:v',N);text=value.text if value is not None and value.text is not None else ''
                    if cell.get('t')=='s':text=strings[int(text)]
                    elif cell.get('t')=='inlineStr':text=''.join(t.text or '' for t in cell.findall('.//x:t',N))
                    if len(text)>4000:raise ValueError('셀 문자열은 최대 4,000자입니다.')
                    if cell.find('x:f',N) is not None and not text:missing.add(m[1])
                    row[m[1]]=text.strip()
                rows.append((int(element.get('r','0')),row,missing))
            mapping=None;header_row=0;result=[]
            for number,row,missing in rows:
                possible={col:HEADERS[value.replace(' ','')] for col,value in row.items() if value.replace(' ','') in HEADERS}
                if mapping is None:
                    if {'last4','user','issueDate'}.issubset(possible.values()):
                        if len(possible.values())!=len(set(possible.values())):raise ValueError('같은 의미의 제목 열이 중복되었습니다.')
                        mapping=possible;header_row=number
                    continue
                values={field:row.get(col,'') for col,field in mapping.items()}
                if not any(values.get(k) for k in ('last4','user','issueDate','purpose','amount')):continue
                if len(result)>=MAX_ROWS:raise ValueError('한 번에 최대 2,000행입니다. 파일을 나눠 업로드하세요.')
                values['_missingFormula']=[field for col,field in mapping.items() if col in missing];result.append((number,values))
            if mapping is None:raise ValueError('카드번호(뒤4)·사용자·지급일 제목 행을 찾을 수 없습니다.')
            if not result:raise ValueError('업로드할 업무 행이 없습니다.')
            return {'sheet':selected,'sheets':[s.get('name') for s in sheets],'headerRow':header_row,'fileHash':hashlib.sha256(raw).hexdigest(),'rows':result,'epoch1904':epoch1904}
    except (BadZipFile,KeyError,IndexError,ET.ParseError,OverflowError) as exc:raise ValueError('엑셀 파일 구조를 읽을 수 없습니다. Excel에서 다시 저장하세요.') from exc

def number(text,label,optional=False):
    if text=='':
        if optional:return None
        raise ValueError(label+'이 필요합니다.')
    try:n=Decimal(str(text).replace(',','').replace('원','').strip())
    except InvalidOperation:raise ValueError(label+'은 정수여야 합니다.')
    if not n.is_finite() or n!=n.to_integral_value() or not 0<=n<=10**12:raise ValueError(label+'은 0~1조의 정수여야 합니다.')
    return int(n)

def day(text,label,epoch1904=False,required=False):
    if not text:
        if required:raise ValueError(label+'이 필요합니다.')
        return ''
    try:
        if re.fullmatch(r'\d{4}[-./]\d{1,2}[-./]\d{1,2}',text):
            y,m,d=map(int,re.split(r'[-./]',text));return date(y,m,d).isoformat()
        serial=Decimal(text)
        if not serial.is_finite() or serial<1 or serial>200000 or (not epoch1904 and int(serial)==60):raise ValueError
        base=date(1904,1,1) if epoch1904 else date(1899,12,30) if serial>=61 else date(1899,12,31)
        return (base+timedelta(days=int(serial))).isoformat()
    except (ValueError,InvalidOperation,OverflowError):raise ValueError(label+' 날짜를 확인하세요.')

def normalized(values,group,epoch):
    if group not in domain.BRANCHES:raise ValueError('소속 지점을 선택하세요.')
    for field in values.get('_missingFormula',[]):
        if field in ('last4','issueDate','dueDate','returnDate','amount','applicationDate'):raise ValueError('수식 결과가 없는 '+field+' 셀입니다. Excel에서 계산 후 저장하세요.')
    suffix=number(values.get('last4',''),'카드 끝자리')
    if suffix>9999:raise ValueError('카드 끝자리는 4자리입니다.')
    user=docs.short(values.get('user',''),'사용자',True)
    issue=day(values.get('issueDate',''),'지급일',epoch,True);due=day(values.get('dueDate',''),'반납예정일',epoch) or issue
    application=day(values.get('applicationDate',''),'신청일',epoch) or issue
    returned=day(values.get('returnDate',''),'반납일',epoch)
    if due<issue or application>issue or returned and returned<issue:raise ValueError('신청일·지급일·예정일·반납일의 선후를 확인하세요.')
    amount=number(values.get('amount',''),'사용금액',True)
    purpose=docs.short(values.get('purpose','') or values.get('category',''),'사용목적',True,2000)
    return {'group':group,'last4':f'{suffix:04}','user':user,'applicant':docs.short(values.get('applicant','') or user,'신청자',True),'dept':docs.short(values.get('dept',''),'부서'),'bank':docs.short(values.get('bank',''),'은행명'),'category':docs.short(values.get('category','') or '합계','목적'),'purpose':purpose,'issueDate':issue,'applicationDate':application,'dueDate':due,'returnDate':returned,'amount':amount,'sourceUseCount':number(values.get('sourceUseCount',''),'원본 사용횟수',True),'sourceId':docs.short(values.get('sourceId',''),'외부행ID'), 'assumptions':{'applicationDateFromIssue':not values.get('applicationDate'),'applicantFromUser':not values.get('applicant'),'dueDateFromIssue':not values.get('dueDate')}}

def row_key(row):
    basis=['sourceId',row['group'],row['sourceId']] if row['sourceId'] else [row[k] for k in ('group','bank','last4','user','dept','issueDate','purpose')]
    return digest(['EXCEL-ROW',basis])

def preview(a,conn,state,data,user,scope):
    book=workbook(data);overrides=data.get('overrides',[])
    if not isinstance(overrides,list) or len(overrides)>MAX_ROWS:raise ValueError('행별 수정 개수 오류')
    changes={}
    for item in overrides:
        if not isinstance(item,dict) or type(item.get('rowNumber'))!=int or item['rowNumber'] in changes:raise ValueError('행별 수정 번호 오류')
        changes[item['rowNumber']]=item
    rows=[];seen={}
    for index,values in book['rows']:
        override=changes.get(index,{})
        result={'rowNumber':index,'group':override.get('group',values.get('group') or data.get('defaultGroup') or (scope if scope!='ALL' else '')),'cardLast4':values.get('last4',''),'user':values.get('user',''),'amount':values.get('amount',''),'warnings':[],'status':'ready','candidates':[]}
        try:
            if scope not in ('ALL',result['group']):raise PermissionError('다른 지점으로 업로드할 수 없습니다.')
            row=normalized(values,result['group'],book['epoch1904']);identity=row_key(row);fingerprint=digest(row)
            result.update(row,cardLast4=row['last4'],rowKey=identity,contentHash=fingerprint)
            result['sourceReferences']={k:docs.short(values.get(k,''),k,False,200) for k in ('number','position','sourcePeriod','voucherStatus','filingStatus','confirmationStatus','sourceIssueStatus','sourceManagementStatus','sourceTotalIssueCount')}
            candidates=[c for c in state.get('cards',[]) if c.get('group')==row['group'] and re.sub(r'\D','',c.get('num',''))[-4:]==row['last4']]
            result['candidates']=[{'id':c['id'],'label':str(c.get('company',''))+' · '+str(c.get('num',''))+' · '+str(c.get('cardAlias',''))} for c in candidates]
            chosen=next((c for c in candidates if str(c['id'])==str(override.get('cardId'))),None)
            if not override.get('cardId') and len(candidates)==1:chosen=candidates[0]
            if override.get('cardId') and not chosen:raise ValueError('선택한 카드가 현재 지점·끝자리와 다릅니다. 다시 선택하세요.')
            result.update(cardId=chosen['id'] if chosen else None,cardNum=chosen['num'] if chosen else '',cardLinkStatus='selected' if chosen else 'unregistered' if not candidates else 'ambiguous')
            fingerprint=digest(row);result['contentHash']=fingerprint
            if not chosen:result['warnings'].append('카드 등록 전 수신 가능 · 실제 불출 전에 전체 카드번호를 확인하세요.' if not candidates else '끝자리 중복 · 수신 후 실제 불출 시 사용할 카드를 확인하세요.')
            if any(row['assumptions'].values()):result['warnings'].append('신청일/신청자/예정일 누락 항목은 지급일·사용자로 대체했습니다. 확인하세요.')
            if row['amount'] is None:result['warnings'].append('금액 없음: 신청서만 생성, 정산 미수신')
            elif row['amount']==0:result['warnings'].append('0원: 신청서만 생성, 미사용 여부는 반납 시 확인')
            else:result['warnings'].append('세부 거래 없음: 합계 1건으로 표시하며 YBY 승인은 별도입니다.')
            if not row['returnDate']:result['warnings'].append('원본 반납일 없음: 반납 미확인')
            old=conn.execute('SELECT content_hash,payload FROM excel_import_rows WHERE record_key=?',(identity,)).fetchone()
            if old:
                hashes={fingerprint}
                # V4.1.16 included its then-selected full card in the import hash.
                # Inspect the saved snapshot, not today's catalog or new selection.
                try:
                    original=docs.load(conn,json.loads(old[1])['applicationKey'])
                    if original.get('selectedCardNum'):hashes.add(digest({**row,'selectedCardNum':original['selectedCardNum']}))
                except (ValueError,KeyError,TypeError,json.JSONDecodeError):pass
                same=old[0] in hashes
                result['status']='duplicate' if same else 'conflict'
                result['warnings'].append('이미 수신한 행 · 기존 연결 유지' if same else '기존 수신 행과 내용이 다릅니다. 기존 내역을 먼저 확인하세요.')
            if identity in seen:result['status']='duplicate' if seen[identity]==fingerprint else 'conflict';result['warnings'].append('파일 안에서 같은 행 식별정보가 반복됩니다. 별도 건이면 외부행ID를 구분하세요.')
            seen[identity]=fingerprint
        except (ValueError,PermissionError) as error:result.update(status='error',error=str(error))
        rows.append(result)
    return {k:v for k,v in book.items() if k not in ('rows','epoch1904')}|{'rows':rows,'counts':{status:sum(row['status']==status for row in rows) for status in ('ready','duplicate','conflict','error')}}

def commit(a,conn,state,data,user,scope):
    if data.get('confirmed') is not True:raise ValueError('미리보기·지점·카드·합계금액을 확인하세요.')
    selection=data.get('selectedRows')
    if not isinstance(selection,list) or not 1<=len(selection)<=MAX_ROWS or any(type(i)!=int for i in selection) or len(selection)!=len(set(selection)):raise ValueError('업로드할 행을 선택하세요.')
    review=preview(a,conn,state,data,user,scope)
    if review['fileHash']!=data.get('fileHash'):raise ValueError('파일이 변경되었습니다. 다시 미리보기 하세요.')
    selected=[r for r in review['rows'] if r['rowNumber'] in selection]
    if len(selected)!=len(selection):raise ValueError('선택 행 번호를 다시 확인하세요.')
    if any(r['status'] not in ('ready','duplicate') for r in selected):raise ValueError('선택 행에 오류 또는 기존 자료 충돌이 있습니다. 다시 미리보기 하세요.')
    count=0;duplicate=0;applications=0;settlements=0
    for row in selected:
        if row['status']=='duplicate':duplicate+=1;continue
        identity=row['rowKey'];common={'source':'EXCEL','documentId':identity,'documentNo':'엑셀-'+identity[:12],'group':row['group'],'revision':1,'applicantName':row['applicant'],'user':row['user'],'dept':row['dept'],'purpose':'['+row['category']+'] '+row['purpose'],'approvalStatus':'엑셀 수신 · YBY 결재 별도','cardLast4':row['last4'],'originRowKey':identity,'originRowLabel':review['sheet']+' '+str(row['rowNumber'])+'행','selectedCardId':str(row['cardId']) if row['cardId'] is not None else '','selectedCardNum':row['cardNum'],'sourceUseCount':row['sourceUseCount'],'sourceReturnDate':row['returnDate'],'sourceIssueDate':row['issueDate'],'sourceDueDate':row['dueDate'],'sourceBank':row['bank'],'sourceAmount':row['amount'],'sourceAssumptions':row['assumptions'],'sourceReferences':row['sourceReferences'],'totalOnly':True,'note':'엑셀 합계 자료. 원본 반납일 '+(row['returnDate'] or '미기재')+'. 세부 거래 내역이 없으며 지급일 기준 신청 정보는 확인이 필요합니다.'}
        app=docs.stage(conn,{**common,'kind':'application','documentNo':common['documentNo']+'-신청','applicationDate':row['applicationDate'],'dueDate':row['dueDate']});applications+=1
        settlement=None
        if row['amount'] is not None and row['amount']>0:
            settlement=docs.stage(conn,{**common,'kind':'settlement','documentNo':common['documentNo']+'-정산','lineItems':[{'date':row['issueDate'],'category':row['category'],'merchant':'원본 미기재','description':row['purpose']+' (엑셀 합계)','note':'합계 금액만 수신, 개별 사용 횟수는 원본 참고','quantity':1,'unitPrice':row['amount'],'amount':row['amount']}]});settlements+=1
        stored={k:row[k] for k in ('group','last4','user','dept','issueDate','returnDate','amount','sourceUseCount')};stored.update(applicationKey=app,settlementKey=settlement,fileHash=review['fileHash'],sheet=review['sheet'],rowNumber=row['rowNumber'],warnings=row['warnings'],cardLinkStatus=row['cardLinkStatus'])
        conn.execute('INSERT INTO excel_import_rows VALUES(?,?,?,?,?,?)',(identity,row['group'],row['contentHash'],json.dumps(stored,ensure_ascii=False),user,a.now()));count+=1
    return {'importedRows':count,'duplicateRows':duplicate,'applications':applications,'settlements':settlements,'pendingCards':sum(r.get('cardLinkStatus') in ('unregistered','ambiguous') and r['status']=='ready' for r in selected),'message':'수신 대기 자료로 저장했습니다. 실제 불출·반납·결재는 자동 처리하지 않습니다.'}

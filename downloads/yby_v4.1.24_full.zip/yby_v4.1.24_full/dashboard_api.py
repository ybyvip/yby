"""Permission-scoped dashboard activity, per-user read cursors and aggregate details."""
import hashlib,json
from types import SimpleNamespace
GET={'/api/dashboard/activity','/api/dashboard/details'}
POST={'/api/dashboard/seen','/api/dashboard/preferences'}
def initialize(c):c.execute('CREATE TABLE IF NOT EXISTS dashboard_users(username TEXT PRIMARY KEY,seen_json TEXT NOT NULL,preferences_json TEXT NOT NULL)')
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def settings(c,user):
 initialize(c);row=c.execute('SELECT seen_json,preferences_json FROM dashboard_users WHERE username=?',(user,)).fetchone()
 return (json.loads(row[0]),json.loads(row[1])) if row else ({},{'notices':True,'shortcuts':True})
def events(a,user,state):
 visible=a.get_state_for(user,state);perms=a.permissions_for(user);admin=a.user_scope(user)=='ALL';rows=[];by_view={}
 def add(view,kind,row,label,time=None):
  if not admin and view not in perms and not (view=='v_notices') and not (view in ('v_hipass_history','v_hipass_box') and bool(perms&{'v_hipass_reg','v_hipass_box'})):return
  safe={'id':str(row.get('id','')),'group':row.get('group',''),'view':view,'kind':kind,'title':label,'time':str(time or row.get('updatedAt') or row.get('approvedAt') or row.get('requestedAt') or row.get('time') or row.get('date') or row.get('createdAt') or ''),'status':str(row.get('status') or row.get('action') or row.get('managementStatus') or '')}
  # Detect business changes without exposing content, account secrets or attachment metadata.
  version=digest({k:v for k,v in row.items() if k not in ('cardKey','passwordHash')});by_view.setdefault(view,[]).append([safe['id'],safe['group'],version]);rows.append(safe)
 for row in visible.get('notices',[]):add('v_notices','공지',row,row.get('title') or '공지사항')
 for row in visible.get('rentalDrafts',[]):add('v_card_rent','불출예정',row,(row.get('user') or '사용자')+' · '+row.get('status','대기'))
 for row in visible.get('history',[]):add('v_card_history','불출·반납',row,row.get('type','이력')+' · '+str(row.get('user','')))
 for row in visible.get('expense',[]):add('v_expense','정산·결재',row,str(row.get('user',''))+' · '+row.get('status',''))
 for row in visible.get('expenseHistory',[]):add('v_expense_history','정산이력',row,str(row.get('user',''))+' · '+row.get('status',''))
 for row in visible.get('cards',[]):
  if row.get('managementHistory'):
   event=row['managementHistory'][-1];add('v_card_reg','카드 관리',row,(row.get('cardAlias') or row.get('company','카드'))+' · '+row.get('managementStatus','정상'),event.get('time'))
 for row in visible.get('hipass',[]):add('v_hipass_box','하이패스 배부',row,str(row.get('hipassUser',''))+' · '+str(row.get('distributionStatus','')))
 for row in visible.get('hipassBox',[]):add('v_hipass_history','하이패스',row,row.get('action','변경')+' · '+str((row.get('after') or row.get('before') or {}).get('hipassUser','')))
 for row in visible.get('complaint',[]):add('v_complaint','민원·고충',row,row.get('title','민원'))
 for row in visible.get('reports',[]):add('v_report_box' if admin or 'v_report_box' in perms else 'v_report_write','보고서',row,row.get('title','보고서'))
 for view in ('v_notices','v_card_rent','v_card_history','v_card_reg','v_expense','v_expense_history','v_hipass_history','v_hipass_box','v_complaint','v_report_box','v_report_write'):
  if admin or view in perms or view=='v_notices' or (view in ('v_hipass_history','v_hipass_box') and perms&{'v_hipass_reg','v_hipass_box'}):by_view.setdefault(view,[])
 return sorted(rows,key=lambda x:(x['time'],x['id']),reverse=True),{v:digest(sorted(values)) for v,values in by_view.items()}
def activity(a,c,user,state,revision):
 seen,prefs=settings(c,user);rows,versions=events(a,user,state)
 # Establish a first-use baseline; later logins retain each user's unacknowledged changes.
 first=not c.execute('SELECT 1 FROM dashboard_users WHERE username=?',(user,)).fetchone()
 if first:seen=dict(versions);c.execute('INSERT INTO dashboard_users VALUES(?,?,?)',(user,json.dumps(seen),json.dumps(prefs)))
 unread={v:seen.get(v)!=value for v,value in versions.items()}
 return dict(ok=True,revision=revision,items=rows[:100],digests=versions,unread=unread,preferences=prefs)
def details(a,user,state):
 scope=a.user_scope(user);perms=a.permissions_for(user);admin=scope=='ALL'
 if not admin and not perms&{'v_dashboard','v_card_reg','v_card_status','v_stats'}:raise PermissionError('대시보드 상세 조회 권한이 없습니다.')
 scoped=lambda k:[r for r in state.get(k,[]) if isinstance(r,dict) and (admin or r.get('group')==scope)]
 cards=[r for r in scoped('cards') if not r.get('archived')];groups=sorted({r['group'] for r in scoped('cards')}|({r['group'] for r in scoped('history')} if admin or perms&{'v_dashboard','v_stats','v_card_history','v_card_rent'} else set())|({scope} if not admin else set()))
 branches=[]
 for group in groups:
  group_cards=[r for r in cards if r['group']==group];history=[r for r in scoped('history') if r['group']==group] if admin or perms&{'v_dashboard','v_stats','v_card_history','v_card_rent'} else []
  branches.append({'group':group,'cards':len(group_cards),'available':sum(r.get('status')=='available' and r.get('managementStatus','정상')=='정상' and (not r.get('expiryDate') or r['expiryDate']>=a.business_date()) for r in group_cards),'rented':sum(r.get('status')=='rented' for r in group_cards),'abnormal':sum(r.get('managementStatus','정상')!='정상' for r in group_cards),'uses':sum(r.get('type')=='불출' and not r.get('voidedReturn') for r in history)})
 # Aggregate-only permission must not reveal card identities or incident content.
 card_read=admin or bool(perms&{'v_card_reg','v_card_status','v_card_rent','v_expense','v_stats','v_business_review'})
 abnormal=[{'id':r['id'],'group':r['group'],'company':r.get('company',''),'last4':str(r.get('num',''))[-4:],'status':r.get('managementStatus'),'user':r.get('user','')} for r in cards if r.get('managementStatus','정상')!='정상'] if card_read else None
 return dict(ok=True,branches=branches,abnormal=abnormal)
def get(h,g,path):
 if path not in GET:return False
 a=SimpleNamespace(**g)
 try:
  user=h.session_user()
  if not user:h.send_json({'ok':False,'message':'로그인이 필요합니다.'},401);return True
  if getattr(h,'must_change_password',False):raise PermissionError('비밀번호를 먼저 변경하세요.')
  with a.LOCK,a.db() as c:
   state=a.storage.read(c) or {};row=c.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone();revision=row[0] if row else None
   result=activity(a,c,user,state,revision) if path.endswith('/activity') else details(a,user,state);c.commit()
  h.send_json(result)
 except PermissionError as e:h.send_json({'ok':False,'message':str(e)},403)
 return True
def post(h,g,path,data):
 if path not in POST:return False
 a=SimpleNamespace(**g)
 try:
  user=h.session_user()
  if not user:raise PermissionError('로그인이 필요합니다.')
  if getattr(h,'must_change_password',False):raise PermissionError('비밀번호를 먼저 변경하세요.')
  with a.LOCK,a.db() as c:
   seen,prefs=settings(c,user)
   if path.endswith('/preferences'):
    if set(data)!={'notices','shortcuts'} or any(type(v)!=bool for v in data.values()):raise ValueError('표시 설정 형식을 확인하세요.')
    prefs=data
   else:
    state=a.storage.read(c) or {};_,versions=events(a,user,state);view=data.get('view');row=c.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone()
    if view not in versions:raise PermissionError('확인 가능한 메뉴가 아닙니다.')
    if data.get('digest')!=versions[view] or data.get('revision')!=(row[0] if row else None):raise a.StateConflict('표시한 자료 이후 변경이 있습니다. 갱신 후 확인하세요.')
    seen[view]=versions[view]
   c.execute('INSERT INTO dashboard_users VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET seen_json=excluded.seen_json,preferences_json=excluded.preferences_json',(user,json.dumps(seen),json.dumps(prefs)));c.commit()
  h.send_json({'ok':True,'preferences':prefs})
 except PermissionError as e:h.send_json({'ok':False,'message':str(e)},403)
 except a.StateConflict as e:h.send_json({'ok':False,'message':str(e)},409)
 except (TypeError,ValueError) as e:h.send_json({'ok':False,'message':str(e)},400)
 return True

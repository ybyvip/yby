@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상이 필요합니다.
pause
exit /b 1
:use_py
py -3 -m pip install --user --only-binary=:all: cryptography==50.0.0
if errorlevel 1 goto failed
py -3 -c "from cryptography.hazmat.primitives.ciphers import Cipher; print('PASS: backup encryption ready')"
goto done
:use_python
python -m pip install --user --only-binary=:all: cryptography==50.0.0
if errorlevel 1 goto failed
python -c "from cryptography.hazmat.primitives.ciphers import Cipher; print('PASS: backup encryption ready')"
goto done
:failed
echo 암호화 지원을 설치하지 못했습니다. 회사의 인터넷/패키지 설치 정책을 IT 담당자에게 확인하세요.
pause
exit /b 1
:done
echo 암호화 백업을 사용할 수 있습니다. 프로그램을 다시 시작하세요.
pause

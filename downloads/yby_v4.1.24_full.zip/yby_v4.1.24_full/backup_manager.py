"""Verified, bounded, optionally encrypted offline-restorable backups."""
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,sqlite3,tempfile
from contextlib import closing
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,ZIP_DEFLATED
import backup_crypto
MAX_TOTAL_BYTES=8*1024**3
MAX_ARCHIVE_BYTES=MAX_TOTAL_BYTES+128*1024**2
MAX_FILES=100000

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()

def check_space(parent,needed):
    if shutil.disk_usage(parent).free<needed+64*1024**2:raise ValueError('백업/복원 임시 공간이 부족합니다. 저장 공간을 확보하세요.')

def inventory(db):
    with closing(sqlite3.connect(str(db))) as c:
        tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        counts={t:c.execute('SELECT COUNT(*) FROM "'+t+'"').fetchone()[0] for t in ('users','rental_drafts','business_cards','card_events','expense_ledger','hipass_cards','hipass_events','external_documents','external_document_matches','external_match_events','excel_import_rows','operation_receipts','business_reviews','company_settings') if t in tables}
    return counts

def create(db_path,attachments,output,version='4.1.24',password=None,recovery_dir=None):
    db_path,attachments,output=map(Path,(db_path,attachments,output))
    if db_path.is_symlink() or not db_path.is_file():raise ValueError('실제 업무 DB가 없습니다. 빈 DB를 만들어 백업하지 않았습니다.')
    output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists():raise ValueError('같은 이름의 백업이 이미 있습니다. 새 파일 이름을 사용하세요.')
    if recovery_dir and password is None:raise ValueError('접속 환경·개인키 포함 백업은 암호화가 필수입니다.')
    if password is not None:backup_crypto.password(password)
    sources=[db_path]
    if attachments.exists():
        if attachments.is_symlink() or any(p.is_symlink() for p in attachments.rglob('*')):raise ValueError('첨부 폴더의 심볼릭 링크를 먼저 정리하세요.')
        sources.extend(p for p in attachments.rglob('*') if p.is_file())
    total=sum(p.stat().st_size for p in sources)
    if total>MAX_TOTAL_BYTES-16*1024**2 or len(sources)>MAX_FILES-20:raise ValueError('백업/복원 공통 8GB·100,000파일 제한을 초과했습니다.')
    check_space(output.parent,total*(3 if password is not None else 2))
    with tempfile.TemporaryDirectory(dir=output.parent) as t:
        stage=Path(t);data=stage/'data';data.mkdir()
        with closing(sqlite3.connect(db_path)) as source,closing(sqlite3.connect(data/db_path.name)) as dest:
            source.backup(dest)
            if dest.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('백업 DB 무결성 검사 실패')
        if attachments.exists():shutil.copytree(attachments,data/'attachments')
        for name in ('password_display.key','admin_password_vault.key'):
            key=db_path.parent/name
            if key.is_symlink():raise ValueError('백업 키 심볼릭 링크 금지')
            if key.exists():shutil.copy2(key,data/key.name)
        if recovery_dir:
            src=Path(recovery_dir)
            if any(p.is_symlink() for p in src.rglob('*')):raise ValueError('복구 자료 심볼릭 링크 금지')
            shutil.copytree(src,stage/'recovery')
        files={p.relative_to(stage).as_posix():digest(p) for p in stage.rglob('*') if p.is_file()}
        if sum(p.stat().st_size for p in stage.rglob('*') if p.is_file())>MAX_TOTAL_BYTES-1024**2:raise ValueError('백업/복원 공통 크기 제한을 초과했습니다.')
        manifest={'version':version,'format':2,'database':db_path.name,'created_at':datetime.now(timezone.utc).isoformat(),'files':files,'inventory':inventory(data/db_path.name),'recoveryIncluded':bool(recovery_dir),'credentialPortability':'Windows DPAPI 암호문은 다른 Windows 사용자에서 열리지 않을 수 있습니다. 계정 비밀번호 해시와 업무 자료는 복원됩니다.'}
        (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        archive=stage/'archive.zip'
        with ZipFile(archive,'w',ZIP_DEFLATED) as z:
            for name in sorted(files):z.write(stage/name,name)
            z.write(stage/'manifest.json','manifest.json')
        if not recovery_dir:
            with tempfile.TemporaryDirectory(dir=stage) as checked:verify(archive,checked)
        candidate=archive
        if password is not None:
            candidate=stage/'encrypted.ybybackup';backup_crypto.encrypt(archive,candidate,password)
            with tempfile.TemporaryDirectory(dir=stage) as checked:verify(candidate,checked,password)
        os.replace(candidate,output);os.chmod(output,0o600)
    return output

def safe_name(name):
    p=PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name or str(p)!=name.rstrip('/'):raise ValueError('안전하지 않은 백업 경로입니다.')
    if any(part.rstrip(' .')!=part or re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?',part,re.I) for part in p.parts):raise ValueError('Windows에서 안전하지 않은 백업 경로입니다.')
    if name!='manifest.json' and p.parts[0] not in ('data','recovery'):raise ValueError('지원하지 않는 백업 파일 경로입니다.')
    return p

def verify(archive,stage,password=None):
    archive=Path(archive);stage=Path(stage)
    if archive.stat().st_size>MAX_ARCHIVE_BYTES:raise ValueError('백업 압축 파일 크기 제한 초과')
    with tempfile.TemporaryDirectory(dir=stage.parent) as temporary:
        selected=archive
        is_encrypted=backup_crypto.encrypted(archive)
        if is_encrypted:
            if password is None:raise ValueError('암호화 백업 암호가 필요합니다.')
            selected=Path(temporary)/'verified.zip';check_space(stage.parent,archive.stat().st_size*2);backup_crypto.decrypt(archive,selected,password,MAX_ARCHIVE_BYTES)
        with ZipFile(selected) as z:
            names=set();folded=set();total=0
            for item in z.infolist():
                safe_name(item.filename);total+=item.file_size
                if item.filename in names or item.filename.casefold() in folded or (item.external_attr>>16)&0o170000==0o120000 or item.flag_bits&1:raise ValueError('안전하지 않은 백업 경로/압축 형식입니다.')
                names.add(item.filename);folded.add(item.filename.casefold())
            if total>MAX_TOTAL_BYTES or len(names)>MAX_FILES:raise ValueError('백업/복원 공통 크기·파일 수 제한 초과')
            if any(n.startswith('recovery/') for n in names) and not is_encrypted:raise ValueError('접속 환경 포함 백업은 암호화가 필수입니다.')
            check_space(stage.parent,total)
            if z.testzip():raise ValueError('백업 ZIP 손상')
            if z.getinfo('manifest.json').file_size>16*1024**2:raise ValueError('백업 매니페스트 크기 제한')
            manifest=json.loads(z.read('manifest.json'))
            if not isinstance(manifest.get('files'),dict):raise ValueError('백업 매니페스트 형식 오류')
            original_files=manifest['files']
            if any(not isinstance(n,str) for n in original_files):raise ValueError('백업 파일 이름 형식 오류')
            if manifest.get('format',1)==1:
                normalized={n.replace('\\','/'):v for n,v in original_files.items()}
                if len(normalized)!=len(original_files):raise ValueError('백업 경로 중복')
                manifest['files']=normalized
            actual={n for n in names if n!='manifest.json' and not n.endswith('/')}
            if actual!=set(manifest['files']):raise ValueError('백업 파일 목록 불일치')
            for name,dig in manifest['files'].items():
                safe_name(name)
                if not isinstance(dig,str) or len(dig)!=64:raise ValueError('잘못된 체크섬')
            z.extractall(stage)
        for name,dig in manifest['files'].items():
            if digest(stage/name)!=dig:raise ValueError('백업 체크섬 불일치: '+name)
        dbname=manifest['database']
        if Path(dbname).name!=dbname or '/' in dbname or '\\' in dbname:raise ValueError('잘못된 DB 이름')
        with closing(sqlite3.connect((stage/'data'/dbname).resolve().as_uri()+'?mode=ro',uri=True)) as c:
            if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('복원 DB 무결성 실패')
    return manifest

def restore(archive,data_dir,password=None):
    data_dir=Path(data_dir).resolve();data_dir.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=data_dir.parent) as t:
        stage=Path(t);manifest=verify(archive,stage,password);original=None
        with closing(sqlite3.connect((stage/'data'/manifest['database']).resolve().as_uri()+'?mode=ro',uri=True)) as check:
            tables={r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'system_state' not in tables:raise ValueError('YBY 업무 DB가 아닙니다. 기존 자료를 교체하지 않았습니다.')
            schema=(check.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0] or 0) if 'schema_versions' in tables else 0
            import storage
            if schema>storage.SCHEMA_VERSION:raise ValueError('더 최신 프로그램의 DB입니다. 해당 버전으로 복원하세요. 기존 자료를 교체하지 않았습니다.')
        if data_dir.exists():
            original=data_dir.parent/('data_before_restore_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f'));os.replace(data_dir,original)
        try:os.replace(stage/'data',data_dir)
        except BaseException:
            if original is not None:os.replace(original,data_dir)
            raise
    return {'restored':str(data_dir),'preserved_original':str(original) if original else None,'version':manifest['version'],'inventory':manifest.get('inventory',{}),'recoveryIncluded':manifest.get('recoveryIncluded',False),'notice':'업무 자료 복원 완료. 인증서/서버 IP/CA 신뢰 복구는 별도 점검하세요. 기존 실행 파일은 교체하지 않았습니다.'}

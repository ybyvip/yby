"""Windows-guided offline verification/backup/restore without command-line secrets."""
from pathlib import Path
import getpass,json,os,shutil,sys,tempfile
import backup_crypto,backup_manager,windows_bootstrap,certificate_permissions
from db_lock import DatabaseLock
SOURCE=Path(__file__).resolve().parent

def choose_file():
    try:
        import tkinter as tk
        from tkinter.filedialog import askopenfilename
        root=tk.Tk();root.withdraw();value=askopenfilename(title='YBY 백업 파일 선택',filetypes=[('YBY 백업','*.ybybackup *.zip'),('모든 파일','*.*')]);root.destroy()
        if not value:raise ValueError('파일 선택을 취소했습니다.')
        return Path(value)
    except ImportError:return Path(input('백업 파일 전체 경로: ').strip().strip('"'))

def main():
    os.umask(0o077)
    print('YBY V4.1.21 백업·복구 도우미')
    print('1. 파일 검증 / 2. 암호화 전체백업 / 3. 업무 자료 복원')
    action=input('번호: ').strip()
    if action not in ('1','2','3'):raise ValueError('1~3을 선택하세요.')
    archive=None;secret=None
    if action in ('1','3'):
        archive=choose_file()
        if backup_crypto.encrypted(archive):secret=getpass.getpass('백업 암호: ')
        with tempfile.TemporaryDirectory() as temp:
            manifest=backup_manager.verify(archive,temp,secret)
        print('PASS: 파일·DB 무결성 검증');print(json.dumps({'version':manifest['version'],'inventory':manifest.get('inventory',{}),'recoveryIncluded':manifest.get('recoveryIncluded',False)},ensure_ascii=False,indent=2))
        if action=='1':return
    target=Path(os.environ['LOCALAPPDATA'])/'YBY/app' if os.name=='nt' else SOURCE
    print('실제 자료 폴더:',target/'data');print('복원 전에 서버 실행창에서 Ctrl+C로 정상 종료하세요. 잠금 파일을 삭제하지 마세요.')
    # prepare_runtime verifies source hashes and refuses a running database. It does not start a server.
    if target!=SOURCE:windows_bootstrap.prepare_runtime(SOURCE,target)
    with DatabaseLock(target/'data'):
        if action=='2':
            if not backup_crypto.available():raise ValueError('INSTALL_BACKUP_ENCRYPTION.bat를 먼저 실행하세요.')
            secret=getpass.getpass('새 백업 암호 (12~128자): ')
            if secret!=getpass.getpass('새 백업 암호 확인: '):raise ValueError('백업 암호가 다릅니다.')
            folder=target/'backups';folder.mkdir(exist_ok=True)
            from datetime import datetime,timezone
            output=folder/('offline_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'.ybybackup')
            backup_manager.create(target/'data/corporate_card_system.db',target/'data/attachments',output,password=secret)
            print('PASS: 암호화·복호 검증 완료:',output);return
        print('기존 data 폴더는 data_before_restore_시각 폴더로 보존합니다. 현재 프로그램 파일은 덮어쓰지 않습니다.')
        if input('업무 자료를 복원하려면 정확히 복원 을 입력: ').strip()!='복원':raise ValueError('복원을 취소했습니다. 기존 자료를 변경하지 않았습니다.')
        result=backup_manager.restore(archive,target/'data',secret);print(json.dumps(result,ensure_ascii=False,indent=2))
        if manifest.get('recoveryIncluded'):
            from datetime import datetime,timezone
            recovery_target=target/('recovery_review_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S'))
            with tempfile.TemporaryDirectory(dir=target) as temp:
                backup_manager.verify(archive,temp,secret);shutil.copytree(Path(temp)/'recovery',recovery_target)
            certificate_permissions.protect(recovery_target)
            print('접속 환경 검토 폴더:',recovery_target)
            print('Windows CA PFX는 현재 사용자/개인 저장소에 가져오고, 인증서·LAN 설정은 RECOVERY_GUIDE_KO.md 순서로 복구하세요. 프로그램이 인증서를 자동 교체하지 않았습니다.')
        print('RUN_LAN_WINDOWS.bat 실행 후 계정·건수·금액·첨부·CA/IP를 확인하세요. 새 PC에서는 접속 주소가 달라질 수 있습니다.')

if __name__=='__main__':
    try:main()
    except Exception as error:print('작업 중단:',type(error).__name__,str(error));raise SystemExit(1)

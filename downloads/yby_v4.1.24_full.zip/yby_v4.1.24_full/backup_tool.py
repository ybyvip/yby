"""Offline full backup/verification/restore; never overwrite existing data blindly."""
import argparse
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import backup_manager
import backup_crypto
import getpass
from db_lock import DatabaseLock

ROOT=Path(__file__).resolve().parent


def ensure_stopped():
    marker=ROOT/'server.pid'
    if marker.exists():
        meta=json.loads(marker.read_text())
        with socket.socket() as s:
            s.settimeout(1)
            if s.connect_ex(('127.0.0.1' if meta['host']=='0.0.0.0' else meta['host'],int(meta['port'])))==0:raise RuntimeError('서버를 먼저 종료하세요.')
    # Also guard the documented port if an older launcher has no marker.
    with socket.socket() as s:
        s.settimeout(1)
        if s.connect_ex(('127.0.0.1',int(os.environ.get('V3_PORT','5000'))))==0:raise RuntimeError('서버를 먼저 종료하세요.')


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser(description='V4 전체 백업·검증·복원 도구')
    p.add_argument('action',choices=['create','verify','restore','extract-recovery'])
    p.add_argument('--encrypt',action='store_true')
    p.add_argument('--output-dir',type=Path)
    p.add_argument('archive',type=Path)
    p.add_argument('--data-dir',type=Path,default=Path(os.environ.get('V3_DATA_DIR',str(ROOT/'data'))))
    args=p.parse_args()
    args.password=getpass.getpass('백업 암호 (파일과 별도 보관): ') if args.encrypt or (args.action!='create' and backup_crypto.encrypted(args.archive)) else None
    if args.action=='extract-recovery':
        if not args.output_dir or args.output_dir.exists():raise ValueError('새 빈 복구 자료 경로를 --output-dir로 지정하세요.')
        with tempfile.TemporaryDirectory() as t:
            manifest=backup_manager.verify(args.archive,t,args.password)
            recovery=Path(t)/'recovery'
            if not recovery.is_dir():raise ValueError('접속 환경이 포함된 복구 백업이 아닙니다.')
            import shutil
            shutil.copytree(recovery,args.output_dir)
        print('접속 환경을 별도 경로에 추출했습니다. 기존 인증서·IP·운영 자료는 교체하지 않았습니다:',args.output_dir);return
    if args.action=='verify':
        with tempfile.TemporaryDirectory() as t:manifest=backup_manager.verify(args.archive,t,args.password)
        print('백업 검증 완료:',manifest['version'],len(manifest['files']),'files');return
    ensure_stopped()
    with DatabaseLock(args.data_dir):
        run_maintenance(args)

def run_maintenance(args):
    if args.action=='create':
        db=args.data_dir/'corporate_card_system.db'
        if not db.is_file():raise ValueError('업무 DB가 없습니다.')
        print('전체 백업 완료:',backup_manager.create(db,args.data_dir/'attachments',args.archive,password=args.password))
    else:print(json.dumps(backup_manager.restore(args.archive,args.data_dir,args.password),ensure_ascii=False,indent=2))


if __name__=='__main__':
    try:main()
    except Exception as e:print('오류:',e,file=sys.stderr);raise SystemExit(1)

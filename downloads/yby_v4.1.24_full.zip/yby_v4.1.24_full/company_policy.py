"""DB-backed branch master and explicit company security/approval choices."""
import json,re
DEFAULT_BRANCHES=['본사','서울','인천','정봉','임원실','광주']
DEFAULT={'branches':DEFAULT_BRANCHES,'passwordDisplayEnabled':False,'allowSelfApproval':True,'requireSelfApprovalReason':True,'revokeOnAdminReset':True,'publicAccountList':True}

def initialize(conn):conn.execute('CREATE TABLE IF NOT EXISTS company_settings(name TEXT PRIMARY KEY,payload TEXT NOT NULL)')
def get(conn):
    initialize(conn);row=conn.execute("SELECT payload FROM company_settings WHERE name='policy'").fetchone()
    return {**DEFAULT,**(json.loads(row[0]) if row else {})}

def change(conn,data,user,at,state):
    before=get(conn);value={**before}
    for key in DEFAULT:
        if key not in data:continue
        if key=='branches':
            names=data[key]
            if not isinstance(names,list) or not 1<=len(names)<=50 or any(not isinstance(n,str) or not re.fullmatch(r'[가-힣A-Za-z0-9][가-힣A-Za-z0-9 _.-]{0,29}',n) or n!=n.strip() or n=='ALL' for n in names) or len(names)!=len(set(names)):raise ValueError('지점은 중복 없이 1~50개, 1~30자 이름으로 입력하세요.')
            if '본사' not in names:raise ValueError('기본 본사 지점은 보존해야 합니다.')
            used={r.get('group') for rows in state.values() if isinstance(rows,list) for r in rows if isinstance(r,dict) and r.get('group')}
            used.update(r[0] for r in conn.execute("SELECT scope FROM users WHERE scope!='ALL'"))
            for table in ('external_documents','external_document_matches','excel_import_rows'):
                columns={r[1] for r in conn.execute('PRAGMA table_info('+table+')')}
                if 'branch' in columns:used.update(r[0] for r in conn.execute('SELECT DISTINCT branch FROM '+table))
            if used-set(names):raise ValueError('기존 계정·업무 자료에서 사용하는 지점은 삭제할 수 없습니다: '+', '.join(sorted(used-set(names))))
            value[key]=list(names)
        else:
            if type(data[key])!=bool:raise ValueError('정책 선택 형식 오류')
            value[key]=data[key]
    reason=data.get('reason','')
    if not isinstance(reason,str) or not 3<=len(reason.strip())<=500:raise ValueError('정책 변경 사유를 3~500자로 입력하세요.')
    conn.execute("INSERT INTO company_settings VALUES('policy',?) ON CONFLICT(name) DO UPDATE SET payload=excluded.payload",(json.dumps({**value,'updatedBy':user,'updatedAt':at},ensure_ascii=False),))
    conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',(at,user,'COMPANY_POLICY_CHANGE','',json.dumps({'before':before,'after':value,'reason':reason},ensure_ascii=False)))
    return value

"""Backup retention, encrypted secondary copies, recovery drills and status."""
import base64,json,os,shutil,subprocess,tempfile,threading,time
from datetime import datetime,timezone
from pathlib import Path
import backup_manager as manager
import backup_crypto
import password_vault
DEFAULT={'enabled':False,'destination':'','keepCount':14,'keepDays':30,'intervalHours':24}

def paths(a):return a.BACKUP_DIR/'backup_policy.json',a.BACKUP_DIR/'backup_status.json'
def atomic(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if path.is_symlink():raise ValueError('백업 설정 심볼릭 링크 금지')
    fd,temporary=tempfile.mkstemp(prefix='.yby-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
        os.replace(temporary,path)
    finally:Path(temporary).unlink(missing_ok=True)

def read(path,default):
    if not Path(path).exists():return dict(default)
    if Path(path).is_symlink():raise ValueError('백업 설정 심볼릭 링크 금지')
    return json.loads(Path(path).read_text(encoding='utf-8'))
def policy(a):return {**DEFAULT,**read(paths(a)[0],{})}
def state(a):return read(paths(a)[1],{})
def update_state(a,**values):atomic(paths(a)[1],{**state(a),**values})

def store_secret(a,secret):
    backup_crypto.password(secret);raw=secret.encode();path=a.BACKUP_DIR/'.secondary-secret'
    if os.name=='nt':encoded='dpapi:'+base64.b64encode(password_vault._dpapi(raw)).decode()
    else:encoded='fernet:'+password_vault._fernet(a.BACKUP_DIR,True).encrypt(raw).decode()
    atomic(path,{'value':encoded})
def load_secret(a):
    value=read(a.BACKUP_DIR/'.secondary-secret',{})['value'];kind,raw=value.split(':',1)
    if kind=='dpapi' and os.name=='nt':return password_vault._dpapi(base64.b64decode(raw),True).decode()
    if kind=='fernet' and os.name!='nt':return password_vault._fernet(a.BACKUP_DIR).decrypt(raw.encode()).decode()
    raise ValueError('별도 보관 암호를 현재 서버 사용자로 다시 설정하세요.')

def destination(a,value):
    if not isinstance(value,str) or not value.strip():raise ValueError('별도 보관 폴더의 전체 경로가 필요합니다.')
    p=Path(value.strip()).expanduser()
    if not p.is_absolute() or p==p.anchor:raise ValueError('별도 보관은 절대 경로로 지정하세요.')
    p=p.resolve()
    if p==Path(p.anchor):raise ValueError('드라이브 최상위 폴더를 지정하지 마세요.')
    for root in (a.BASE_DIR,a.DB_PATH.parent,a.BACKUP_DIR):
        root=Path(root).resolve()
        if p==root or p.is_relative_to(root):raise ValueError('프로그램·업무 자료·로컬 백업 폴더 밖의 별도 폴더를 선택하세요.')
    return p

def configure(a,data,user):
    existing=policy(a);new={**existing}
    for field,lo,hi in [('keepCount',2,100),('keepDays',1,365),('intervalHours',1,168)]:
        value=data.get(field,existing[field])
        if type(value)!=int or not lo<=value<=hi:raise ValueError(field+' 범위 오류')
        new[field]=value
    if type(data.get('enabled',False))!=bool:raise ValueError('별도 보관 설정 오류')
    new['enabled']=data.get('enabled',False)
    if new['enabled']:
        if not backup_crypto.available():raise ValueError('암호화 지원 설치가 필요합니다. INSTALL_BACKUP_ENCRYPTION.bat를 실행하세요.')
        target=destination(a,data.get('destination',existing['destination']));target.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.yby-write-check-',dir=target) as t:(Path(t)/'probe').write_bytes(b'YBY')
        new['destination']=str(target)
        secret=data.get('backupPassword','')
        if secret:store_secret(a,secret)
        else:load_secret(a)
    new['updatedAt']=a.now();new['updatedBy']=user;atomic(paths(a)[0],new)
    return new

def prune_local(a):
    cfg=policy(a);now=time.time()
    groups=[]
    for p in a.BACKUP_DIR.glob('corporate_card_system_*.zip'):
        if p.is_symlink() or any(x in p.stem for x in ('manual','upgrade','reset','test')):continue
        groups.append(p)
    groups.sort(key=lambda p:p.stat().st_mtime,reverse=True)
    removed=0
    for index,p in enumerate(groups):
        if index<2 or (index<cfg['keepCount'] and now-p.stat().st_mtime<=cfg['keepDays']*86400):continue
        # Only files created by our backup writer with a manifest are retention candidates.
        from zipfile import ZipFile
        try:
            with ZipFile(p) as z:info=json.loads(z.read('manifest.json'))
            if info.get('database')!=a.DB_PATH.name:continue
            p.unlink();p.with_suffix('.db').unlink(missing_ok=True);removed+=1
        except (OSError,ValueError,KeyError):continue
    return removed

def prune_secondary(folder,cfg):
    metas=[]
    for p in folder.glob('yby_secondary_*.json'):
        if p.is_symlink():continue
        try:
            value=json.loads(p.read_text());file=folder/value['name']
            if value.get('owner')!='YBY' or file.parent!=folder or not file.name.startswith('yby_secondary_') or file.suffix!='.ybybackup' or file.is_symlink() or not file.is_file():continue
            metas.append((p,file,value))
        except (OSError,ValueError,KeyError):continue
    metas.sort(key=lambda x:x[1].stat().st_mtime,reverse=True)
    for index,(meta,file,value) in enumerate(metas):
        if index<2 or (index<cfg['keepCount'] and time.time()-file.stat().st_mtime<=cfg['keepDays']*86400):continue
        if manager.digest(file)==value.get('sha256'):file.unlink();meta.unlink()

def after_backup(a,archive):
    update_state(a,lastLocalSuccess=a.now(),lastLocalFile=archive.name,lastLocalBytes=archive.stat().st_size)
    cfg=policy(a)
    try:
        if cfg['enabled']:
            folder=destination(a,cfg['destination']);folder.mkdir(parents=True,exist_ok=True)
            manager.check_space(folder,archive.stat().st_size*2)
            final=folder/('yby_secondary_'+archive.stem+'.ybybackup')
            secret=load_secret(a)
            with tempfile.TemporaryDirectory(prefix='.yby-copy-',dir=folder) as t:
                candidate=Path(t)/'encrypted';backup_crypto.encrypt(archive,candidate,secret)
                with tempfile.TemporaryDirectory(dir=a.BACKUP_DIR) as checked:manager.verify(candidate,checked,secret)
                sha=manager.digest(candidate);os.replace(candidate,final)
            atomic(final.with_suffix('.json'),{'owner':'YBY','name':final.name,'sha256':sha,'createdAt':a.now()})
            update_state(a,lastSecondarySuccess=a.now(),lastSecondaryFile=final.name,lastSecondaryDestination=str(folder),lastError='')
            prune_secondary(folder,cfg)
        prune_local(a)
        update_state(a,lastError='')
    except Exception as error:
        update_state(a,lastError='별도 보관/보존 처리 실패: '+type(error).__name__,lastFailure=a.now())
        a.OPERATION_WARNINGS.append('별도 백업 보관에 실패했습니다. 백업·복구 관리에서 경로·암호·용량을 확인하세요.');del a.OPERATION_WARNINGS[:-20]

def status(a):
    cfg=policy(a);current=state(a);free=shutil.disk_usage(a.BACKUP_DIR).free;warnings=[]
    if free<1024**3:warnings.append('로컬 여유 공간이 1GB 미만입니다.')
    if not cfg['enabled']:warnings.append('암호화된 별도 보관이 설정되지 않았습니다.')
    if cfg['enabled'] and (not current.get('lastSecondarySuccess') or current.get('lastSecondaryDestination')!=cfg['destination']):warnings.append('현재 별도 보관 폴더의 성공 기록이 없습니다. 설정 저장으로 첫 보관을 검증하세요.')
    if cfg['enabled'] and current.get('lastSecondarySuccess') and time.time()-datetime.fromisoformat(current['lastSecondarySuccess']).timestamp()>cfg['intervalHours']*5400:warnings.append('별도 보관의 최근 성공 시각을 확인하세요.')
    if current.get('lastError'):warnings.append(current['lastError'])
    last=max([x for x in (current.get('lastLocalSuccess'),current.get('lastProtectedSuccess')) if x],default=None)
    if not last or time.time()-datetime.fromisoformat(last).timestamp()>cfg['intervalHours']*3600*1.5:warnings.append('최근 성공 백업을 확인하세요.')
    files=sorted([p for p in a.BACKUP_DIR.iterdir() if p.suffix in ('.zip','.ybybackup') and p.is_file() and not p.is_symlink()],key=lambda p:p.stat().st_mtime,reverse=True)[:100]
    return {'policy':cfg,'state':current,'warnings':warnings,'freeBytes':free,'cryptoAvailable':backup_crypto.available(),'maxBackupBytes':manager.MAX_TOTAL_BYTES,'files':[{'name':p.name,'bytes':p.stat().st_size,'modifiedAt':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat(),'encrypted':backup_crypto.encrypted(p)} for p in files],'limitations':['별도 폴더가 다른 물리 장치인지 IT 담당자가 확인하세요.','자동 백업은 서버가 실행 중일 때만 동작합니다.','DB/첨부 복구와 인증서·서버 IP 복구는 구분합니다.']}

def drill(a,name,secret=None):
    if not isinstance(name,str) or Path(name).name!=name or '\\' in name:raise ValueError('백업 파일 이름 오류')
    archive=a.BACKUP_DIR/name
    if archive.is_symlink() or not archive.is_file() or archive.suffix not in ('.zip','.ybybackup'):raise ValueError('서버 백업 목록에서 파일을 선택하세요.')
    with tempfile.TemporaryDirectory(prefix='yby-restore-drill-',dir=a.BACKUP_DIR) as t:
        root=Path(t)
        (root/'checked').mkdir();manifest=manager.verify(archive,root/'checked',secret)
        restored=manager.restore(archive,root/'restored',secret)
        if manager.inventory(root/'checked/data'/manifest['database'])!=manager.inventory(root/'restored'/manifest['database']):raise ValueError('복구 건수 불일치')
        result={'file':name,'checkedAt':a.now(),'inventory':restored['inventory'],'recoveryIncluded':manifest.get('recoveryIncluded',False),'note':'별도 임시 폴더 복원·DB/파일 해시 확인 완료. 운영 자료와 인증서 저장소는 변경하지 않았습니다. 새 회사 PC 실기 검증은 별도로 필요합니다.'}
    update_state(a,lastDrill=result);return result

def recovery_backup(a,target,secret):
    backup_crypto.password(secret)
    with tempfile.TemporaryDirectory(prefix='.yby-recovery-',dir=a.BACKUP_DIR) as t:
        root=Path(t);settings=a.BASE_DIR/'lan_settings.json';certs=a.BASE_DIR/'certificates'
        if settings.is_file():shutil.copy2(settings,root/'lan_settings.json')
        atomic(root/'backup-policy-public.json',policy(a))
        if certs.exists():
            if certs.is_symlink() or any(p.is_symlink() for p in certs.rglob('*')):raise ValueError('인증서 심볼릭 링크 금지')
            shutil.copytree(certs,root/'certificates')
        if os.name=='nt' and settings.exists():
            info=json.loads(settings.read_text(encoding='utf-8'));thumb=info.get('root_thumbprint')
            if thumb:
                command="$ErrorActionPreference='Stop';$r=[Console]::In.ReadToEnd()|ConvertFrom-Json;$p=ConvertTo-SecureString $r.password -AsPlainText -Force;$c=Get-Item -LiteralPath ('Cert:\\CurrentUser\\My\\'+$r.thumb);Export-PfxCertificate -Cert $c -FilePath $r.output -Password $p|Out-Null"
                result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',command],input=json.dumps({'password':secret,'thumb':thumb,'output':str(root/'root-ca.pfx')}),text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
                if result.returncode:raise ValueError('서버 CA 개인키 내보내기를 완료하지 못했습니다. 인증서 저장소/회사 정책을 IT 담당자가 확인하세요.')
        atomic(root/'RECOVERY_INFO.json',{'version':a.APP_VERSION,'createdAt':a.now(),'windowsCaPfxIncluded':(root/'root-ca.pfx').exists(),'notice':'새 PC에서는 프로그램 설치, DB/첨부 복원, 서버 IP 설정, 인증서/CA 개인키 복구 및 클라이언트 신뢰 확인을 별도로 수행하세요. DPAPI 표시 암호는 다른 사용자에서 열리지 않을 수 있으나 로그인 해시 계정은 복원됩니다.'})
        return manager.create(a.DB_PATH,a.ATTACHMENT_DIR,target,a.APP_VERSION,password=secret,recovery_dir=root)

def start_scheduler(a):
    stop=threading.Event()
    def worker():
        while not stop.wait(60):
            try:
                cfg=policy(a);current=state(a);last=current.get('lastLocalSuccess')
                retry=bool(current.get('lastError') and current.get('lastFailure') and time.time()-datetime.fromisoformat(current['lastFailure']).timestamp()>=900)
                if not retry and last and time.time()-datetime.fromisoformat(last).timestamp()<cfg['intervalHours']*3600:continue
                with a.LOCK:a.backup('scheduled')
            except Exception:
                a.OPERATION_WARNINGS.append('예약 백업 실패: 백업·복구 관리에서 상태를 확인하세요.');del a.OPERATION_WARNINGS[:-20]
    threading.Thread(target=worker,name='yby-backup-scheduler',daemon=True).start();return stop

"""Read-only settlement-to-report draft. Submission remains a separate action."""
from copy import deepcopy
import hashlib,json
def fingerprint(row):return hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def source(state,reference,scope):
    if not isinstance(reference,dict) or any(not isinstance(reference.get(k),(str,int)) or isinstance(reference.get(k),bool) for k in ('id','group','requester')):
        raise ValueError('정산 원본 식별 정보가 필요합니다.')
    rows=[r for field in ('expense','expenseHistory') for r in state.get(field,[])
          if all(str(r.get(k,''))==str(reference[k]) for k in ('id','group','requester'))]
    if len(rows)!=1:raise ValueError('정산 원본을 하나로 확인할 수 없습니다.')
    row=rows[0]
    if scope not in ('ALL',row['group']):raise PermissionError('다른 지점의 정산입니다.')
    if not row.get('returnSource'):raise ValueError('반납 사용정산 자료를 선택하세요.')
    return row

def preview(row,history=()):
    label=lambda k:str(row.get(k,'') or '미기록')
    ref={k:row[k] for k in ('id','group','requester')}
    lines=row.get('lineItems') or [{'date':row.get('date'),'category':row.get('category'),'merchant':row.get('merchant'),'description':row.get('purpose'),'quantity':1,'unitPrice':row.get('amount',0),'amount':row.get('amount',0)}]
    def event(field):
        key=row.get(field)
        matches=[r for r in history if key is not None and str(r.get('id'))==str(key) and r.get('group')==row['group'] and r.get('cardNum')==row.get('cardNum')]
        return matches[0] if len(matches)==1 else {}
    issue,returned=event('rentalEventId'),event('returnEventId')
    text=['법인카드 사용 결과 보고','', '1. 신청·불출·반납 정보',
          '지점: '+label('group')+' / 부서: '+label('dept'),
          '카드: '+label('cardNum')+' / 실제 사용자: '+label('user'),
          '신청자: '+label('applicantName')+' / 사용신청일: '+label('applicationDate'),
          '불출일: '+str(issue.get('rentDate') or '미기록')+' / 반납예정일: '+str(issue.get('dueDate') or '미기록'),
          '반납일: '+str(returned.get('returnDate') or '미기록')+' / 사용일: '+label('date'),
          '정산 신청일: '+label('requestedAt'),
          '정산 문서번호: '+label('id')+' / 정산 신청 계정: '+label('requester'),
          '정산 결재 상태(복사 시점): '+label('status'),'', '2. 사용 목적 및 결과',label('purpose'),
          '참석자 / 동행자: '+label('attendees'),'', '3. 건별 세부 정산 명세']
    for i,line in enumerate(lines,1):
        text.append(f"{i}. {line.get('date','')} | {line.get('category','')} | {line.get('merchant','')} | {line.get('description','')} | 수량 {line.get('quantity',1)} × 단가 {int(line.get('unitPrice',0)):,}원 = {int(line.get('amount',0)):,}원"+(' | '+str(line['note']) if line.get('note') else ''))
    text.extend([f"합계: {int(row.get('amount',0)):,}원",'', '4. 비고 및 증빙',label('note')])
    if row.get('sourceRef'):text.append('외부 정산서: '+str(row['sourceRef'].get('documentNo',''))+' / 외부 결재(연결 시점): '+str(row['sourceRef'].get('approvalStatus','미확인')))
    files=[str(x.get('name','첨부파일')) for x in row.get('attachments',[]) if isinstance(x,dict)]
    text.append('원본 정산 증빙: '+(', '.join(files) if files else '없음'))
    text.append('증빙 파일은 원본 정산에서 확인하세요. 보고서에는 파일명만 복사됩니다.')
    text.append('이 보고서는 정산 자료를 복사한 별도 기안입니다. 정산 결재와 보고서 결재는 독립적으로 진행됩니다.')
    return {'group':row['group'],'type':'출장보고' if '출장' in label('purpose') else '일반기안',
            'title':f"법인카드 사용 결과 보고 — {label('user')} ({label('date')})",'content':'\n'.join(text),
            'sourceFingerprint':fingerprint(row),'sourceExpenseRef':ref,'sourceStatus':row.get('status',''),'sourceSnapshot':deepcopy(row)}

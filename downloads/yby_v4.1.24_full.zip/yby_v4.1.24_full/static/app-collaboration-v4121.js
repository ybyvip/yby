/* YBY V4.1.21 collaboration screen module; global compatibility preserved. */
let chatAttachedFile = null;
let chatPreviewUrl = null;
let activeChatThread = 'ALL';
let chatSelectedRecipients = [];
let chatPickerSelection = new Set();
let chatFormatState = {bold:false, blur:false, opacity:.78};
let detachedChatWindows = new Map();
let messageNotificationBaselineReady = false;
const seenChatNotificationIds = new Set();
const seenInboxNotificationIds = new Set();
const pendingChatNotifications = [];
function seedMessageNotificationBaseline() {
    seenChatNotificationIds.clear();seenInboxNotificationIds.clear();
    chatMessagesList.forEach((m,i)=>seenChatNotificationIds.add(String(m.id||`${m.sender||''}|${m.time||''}|${i}`)));
    inboxMessages.forEach((m,i)=>seenInboxNotificationIds.add(String(m.id||m.messageId||i)));
    messageNotificationBaselineReady=true;
}
function showChatNotification(message,key) {
    if(document.hidden&&(!('Notification' in window)||Notification.permission!=='granted')){pendingChatNotifications.push({message,key});return;}
    const stack=document.getElementById('chatNotificationStack');if(!stack)return;
    const card=document.createElement('div');card.className='chat-notification';
    const icon=document.createElement('div');icon.className='chat-notification-icon';icon.textContent=message.file?'📎':'✉';
    const content=document.createElement('div');content.className='chat-notification-content';
    const title=document.createElement('strong');title.textContent=message.sender==='시스템'?'새 알림':'새 메시지가 도착했습니다';
    const summary=document.createElement('span');summary.textContent=`${message.sender||'직원'} 님${message.file?'이 파일을 보냈습니다.':'이 메시지를 보냈습니다.'}`;
    const open=document.createElement('button');open.type='button';open.textContent='대화 열기';open.onclick=()=>{toggleChatPanel(true);setActiveChatThread(key||'ALL');card.remove();};
    content.append(title,summary,open);
    const close=document.createElement('button');close.type='button';close.className='chat-notification-close';close.setAttribute('aria-label','알림 닫기');close.textContent='×';close.onclick=()=>card.remove();
    card.append(icon,content,close);stack.prepend(card);
    while(stack.children.length>5)stack.lastElementChild.remove();
    setTimeout(()=>card.remove(),9000);
    if('Notification' in window&&Notification.permission==='granted'&&(document.hidden||!document.querySelector('.chat-area')?.classList.contains('open'))){
        try{const native=new Notification('메신저 · 새 메시지',{body:summary.textContent,tag:'sys-chat-'+String(message.id||Date.now())});native.onclick=()=>{window.focus();toggleChatPanel(true);setActiveChatThread(key||'ALL');native.close();};}catch(_){ }
    }
}
function notifyIncomingFromServerState(state) {
    if(!currentUser||!state)return;
    if(!messageNotificationBaselineReady){seedMessageNotificationBaseline();return;}
    const announcements=[],batchSeen=new Set();
    (Array.isArray(state.chat)?state.chat:[]).forEach((m,i)=>{
        const id=String(m.id||`${m.sender||''}|${m.time||''}|${i}`);if(seenChatNotificationIds.has(id))return;seenChatNotificationIds.add(id);
        if(!m.sender||m.sender===currentUser)return;
        const recipients=chatRecipients(m);
        const isForUser=m.dm?recipients.includes(currentUser):(m.recipient==='ALL'||recipients.includes(currentUser));
        if(!isForUser)return;
        const key=m.dm?chatConversationKey(m):'ALL';batchSeen.add(id);announcements.push({message:m,key,id});
    });
    (Array.isArray(state.inbox)?state.inbox:[]).forEach((item,i)=>{
        const inboxId=String(item.id||item.messageId||i);if(seenInboxNotificationIds.has(inboxId))return;seenInboxNotificationIds.add(inboxId);
        if(item.recipient!==currentUser||!item.sender||item.sender===currentUser)return;
        const id=String(item.messageId||inboxId.split(':')[0]);if(batchSeen.has(id))return;
        const people=[currentUser,item.sender].sort();announcements.push({message:item,key:'DM|'+people.join('|'),id});batchSeen.add(id);
    });
    announcements.slice(-5).forEach(item=>showChatNotification(item.message,item.key));
}
function enableChatNotifications() {
    if(!('Notification' in window)){showChatNotification({id:'permission',sender:'알림 설정',text:'이 브라우저는 바탕화면 알림을 지원하지 않습니다.'},'ALL');return;}
    if(Notification.permission==='granted'){showChatNotification({id:'permission',sender:'알림 설정',text:'바탕화면 알림이 켜져 있습니다.'},'ALL');return;}
    if(Notification.permission==='denied'){alert('브라우저에서 이 사이트의 알림이 차단되어 있습니다. 주소창 왼쪽의 사이트 권한에서 알림을 허용해 주세요.');return;}
    Notification.requestPermission().then(permission=>showChatNotification({id:'permission-'+Date.now(),sender:'알림 설정',text:permission==='granted'?'바탕화면 알림을 켰습니다.':'화면 내 알림은 계속 표시됩니다.'},'ALL'));
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&pendingChatNotifications.length){pendingChatNotifications.splice(0).forEach(item=>showChatNotification(item.message,item.key));}});
function chatPreferenceKey(kind) { return 'sys_chat_' + kind + '_' + (currentUser || 'guest'); }
function readChatPreference(kind) { try { const value=JSON.parse(sessionStorage.getItem(chatPreferenceKey(kind))||'[]'); return Array.isArray(value)?value:[]; } catch(_) { return []; } }
function writeChatPreference(kind, value) { try { sessionStorage.setItem(chatPreferenceKey(kind), JSON.stringify(value)); } catch(_) {} }
function setActiveChatThread(key) {
    activeChatThread=key || 'ALL';
    const hidden=readChatPreference('closed').filter(x=>x!==activeChatThread); writeChatPreference('closed',hidden);
    markChatThreadRead(activeChatThread);
    const title=document.getElementById('chatConversationTitle');
    if(title) title.textContent=chatConversationTitle(activeChatThread);
    renderChatMessages(); renderConversationList(); updateChatFormatButtons();
}
function toggleChatFormat(type) {
    if(!Object.prototype.hasOwnProperty.call(chatFormatState,type)) return;
    chatFormatState[type]=!chatFormatState[type]; updateChatFormatButtons();
    document.getElementById('chatBlurOptions')?.classList.toggle('visible',!!chatFormatState.blur);
    syncChatPrivacyControls();
    const area=document.getElementById('chatMessages');if(area)applyChatPrivacy(area,chatFormatState);
}
function updateChatFormatButtons() {
    const bold=document.getElementById('chatBoldToggle'), blur=document.getElementById('chatBlurToggle');
    if(bold){bold.classList.toggle('active',!!chatFormatState.bold);bold.setAttribute('aria-pressed',String(!!chatFormatState.bold));}
    if(blur){blur.classList.toggle('active',!!chatFormatState.blur);blur.setAttribute('aria-pressed',String(!!chatFormatState.blur));blur.textContent=chatFormatState.blur?'◌ 흐림 해제':'◌ 화면 흐리게';}
    document.getElementById('chatBlurOptions')?.classList.toggle('visible',!!chatFormatState.blur);
    const level=document.getElementById('chatBlurLevel'), value=document.getElementById('chatBlurLevelValue');
    const opacity=Math.round((Number(chatFormatState.opacity)||.78)*100);
    if(level) level.value=opacity;if(value)value.textContent=opacity+'%';
    syncChatPrivacyControls();
}
function updateChatBlurSettings() {
    const level=document.getElementById('chatBlurLevel');
    if(level)chatFormatState.opacity=Math.max(.2,Math.min(1,(Number(level.value)||78)/100));
    const value=document.getElementById('chatBlurLevelValue');if(value)value.textContent=Math.round(chatFormatState.opacity*100)+'%';
    syncChatPrivacyControls();
    const area=document.getElementById('chatMessages');if(area)applyChatPrivacy(area,chatFormatState);
}
function updateChatPrivacyOpacity(value) {
    chatFormatState.opacity=Math.max(.2,Math.min(1,(Number(value)||78)/100));
    const pct=Math.round(chatFormatState.opacity*100);
    const inner=document.getElementById('chatPrivacyOpacity'), label=document.getElementById('chatPrivacyOpacityValue');
    if(inner)inner.value=pct;if(label)label.textContent=pct+'%';
    const outer=document.getElementById('chatBlurLevel'), outerLabel=document.getElementById('chatBlurLevelValue');
    if(outer)outer.value=pct;if(outerLabel)outerLabel.textContent=pct+'%';
    const area=document.getElementById('chatMessages');if(area)applyChatPrivacy(area,chatFormatState);
}
function syncChatPrivacyControls() {
    const lock=!!chatFormatState.bold, blur=!!chatFormatState.blur;
    const title=document.getElementById('chatPrivacyTitle'), desc=document.getElementById('chatPrivacyDescription');
    const password=document.getElementById('chatPrivacyPassword'), error=document.getElementById('chatPrivacyError'), range=document.getElementById('chatPrivacyRange'), button=document.querySelector('#chatPrivacyCover .chat-privacy-card button');
    if(title)title.textContent=lock?'메신저 화면 잠금':'메신저 화면 흐림';
    if(desc)desc.textContent=lock?'현재 로그인 계정의 비밀번호를 입력하면 보호가 해제됩니다.':'가림 농도를 조절해 화면 내용을 숨길 수 있습니다.';
    if(password)password.style.display=lock?'block':'none';
    if(error)error.textContent='';
    if(range)range.style.display=(lock||blur)?'flex':'none';
    if(button)button.textContent=lock?'비밀번호로 해제':'흐림 해제';
    const val=Math.round((Number(chatFormatState.opacity)||.78)*100), slider=document.getElementById('chatPrivacyOpacity'), label=document.getElementById('chatPrivacyOpacityValue');
    if(slider)slider.value=val;if(label)label.textContent=val+'%';
}
function applyChatPrivacy(area,state) {
    if(!area)return;
    const panel=area.id==='chatMessages'?document.querySelector('.chat-area'):area.ownerDocument.body;
    if(!panel)return;
    panel.classList.toggle('privacy-blur',!!state.blur);panel.classList.toggle('privacy-bold',!!state.bold);
    const strength=Math.max(.2,Math.min(1,Number(state.opacity)||.78));
    panel.style.setProperty('--chat-cover-opacity',String(strength));
    panel.style.setProperty('--chat-blur-px',(strength*12).toFixed(2)+'px');
    const cover=panel.querySelector(area.id==='chatMessages'?'#chatPrivacyCover':'#detachedPrivacyCover');if(cover)cover.setAttribute('aria-hidden',String(!state.bold));
    panel.setAttribute('aria-label',state.bold?'메신저 화면 잠금':state.blur?'메신저 내용 흐림 '+Math.round(strength*100)+'%':'메신저 대화');
}
async function verifyCurrentLoginPassword(password) {
    const response=await fetch('/api/verify-current-password',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({password})});
    const result=await response.json().catch(()=>({}));
    return {ok:response.ok&&!!result.ok,message:result.message||'비밀번호 확인에 실패했습니다.'};
}
async function clearChatPrivacy() {
    if(chatFormatState.bold) {
        const input=document.getElementById('chatPrivacyPassword'), error=document.getElementById('chatPrivacyError'), password=input?.value||'';
        if(!password){if(error)error.textContent='로그인 비밀번호를 입력해 주세요.';input?.focus();return;}
        try { const result=await verifyCurrentLoginPassword(password);if(!result.ok){if(error)error.textContent=result.message;input.value='';input.focus();return;} }
        catch(_){if(error)error.textContent='서버에 연결할 수 없습니다. 연결을 확인해 주세요.';return;}
    }
    chatFormatState.bold=false;chatFormatState.blur=false;
    const input=document.getElementById('chatPrivacyPassword');if(input)input.value='';
    const area=document.getElementById('chatMessages');if(area)applyChatPrivacy(area,chatFormatState);
    document.getElementById('chatBlurOptions')?.classList.remove('visible');updateChatFormatButtons();
}
function handleChatFileSelect(input) {
    if(input.files && input.files[0]) {
        if(chatPreviewUrl){URL.revokeObjectURL(chatPreviewUrl);chatPreviewUrl=null;}
        chatAttachedFile = input.files[0];
        let prev = document.getElementById("chatFilePreview");
        document.getElementById("chatFileName").innerText = `📎 ${chatAttachedFile.name}`;
        const preview=document.getElementById('chatSelectedImagePreview');
        if(preview&&chatAttachedFile.type.startsWith('image/')){chatPreviewUrl=URL.createObjectURL(chatAttachedFile);preview.src=chatPreviewUrl;preview.alt=chatAttachedFile.name;preview.style.display='inline-block';}
        else if(preview){preview.removeAttribute('src');preview.style.display='none';}
        prev.style.display = "flex";
    }
}
function clearChatFile() {
    chatAttachedFile = null;
    if(chatPreviewUrl){URL.revokeObjectURL(chatPreviewUrl);chatPreviewUrl=null;}
    const preview=document.getElementById('chatSelectedImagePreview');if(preview){preview.removeAttribute('src');preview.style.display='none';}
    document.getElementById("chatFilePreview").style.display = "none";
    document.getElementById("chatFileInput").value = "";
}

function updateChatRecipients() {
    if(!document.getElementById('chatRecipientOptions')) return;
    chatSelectedRecipients=chatSelectedRecipients.filter(acc=>acc!==currentUser&&accountsData[acc]);
    chatPickerSelection=new Set(Array.from(chatPickerSelection).filter(acc=>acc!==currentUser&&accountsData[acc]));
    renderChatRecipientOptions(); renderChatRecipientChips(); updateRecipientHint(); renderConversationList();
}
function toggleChatRecipientPicker(force) {
    const panel=document.getElementById('chatRecipientPickerPanel'); if(!panel)return;
    panel.style.display=typeof force==='boolean'?(force?'block':'none'):(panel.style.display==='none'?'block':'none');
    if(panel.style.display==='block'){renderChatRecipientOptions();document.getElementById('chatRecipientSearch')?.focus();}
}
function renderChatRecipientOptions() {
    const box=document.getElementById('chatRecipientOptions'); if(!box)return;
    const query=(document.getElementById('chatRecipientSearch')?.value||'').trim().toLocaleLowerCase(); box.innerHTML='';
    const names=Object.keys(accountsData||{}).filter(acc=>acc!==currentUser&&acc.toLocaleLowerCase().includes(query)).sort((a,b)=>a.localeCompare(b,'ko'));
    if(!names.length){const empty=document.createElement('div');empty.style.cssText='padding:8px;color:#64748b;font-size:10px';empty.textContent='선택할 상대가 없습니다.';box.appendChild(empty);return;}
    names.forEach(name=>{const label=document.createElement('label');label.className='chat-recipient-option';const check=document.createElement('input');check.type='checkbox';check.checked=chatPickerSelection.has(name);check.addEventListener('change',()=>{if(check.checked)chatPickerSelection.add(name);else chatPickerSelection.delete(name);});const text=document.createElement('span');text.textContent=name;label.append(check,text);box.appendChild(label);});
}
function renderChatRecipientChips() {
    const box=document.getElementById('chatRecipientChips'); if(!box) return;
    box.innerHTML='';
    chatSelectedRecipients.forEach(name=>{
        const chip=document.createElement('span'); chip.className='chat-chip'; chip.textContent=name+' ';
        const remove=document.createElement('button'); remove.type='button'; remove.textContent='×'; remove.title=name+' 제외'; remove.style.cssText='border:0;background:none;color:inherit;cursor:pointer;padding:0 0 0 3px;';
        remove.addEventListener('click',()=>{chatSelectedRecipients=chatSelectedRecipients.filter(x=>x!==name);renderChatRecipientChips();updateRecipientHint();});
        chip.appendChild(remove); box.appendChild(chip);
    });
}
function addChatRecipient() {
    const selected=Array.from(chatPickerSelection).filter(name=>name!==currentUser&&accountsData[name]);
    if(!selected.length) { alert('추가할 대화 상대를 체크해 주세요.'); return; }
    chatSelectedRecipients=Array.from(new Set([...chatSelectedRecipients,...selected]));
    chatPickerSelection.clear(); renderChatRecipientOptions(); renderChatRecipientChips(); updateRecipientHint(); toggleChatRecipientPicker(false);
}
function updateRecipientHint() {
    const hint=document.getElementById('chatRecipientHint'); if(!hint) return;
    hint.textContent=chatSelectedRecipients.length===0?'상대를 선택하고 대화 시작을 누르세요.':(chatSelectedRecipients.length===1?'1:1 대화 상대: '+chatSelectedRecipients[0]:'그룹 대화 · '+chatSelectedRecipients.length+'명 선택됨');
}
function startChatConversation() {
    const recipients=Array.from(new Set(chatSelectedRecipients)).filter(x=>x!==currentUser&&accountsData[x]);
    if(!recipients.length) { alert('대화 상대를 한 명 이상 추가해 주세요.'); return; }
    const key='DM|'+Array.from(new Set([currentUser,...recipients])).sort().join('|');
    setActiveChatThread(key); toggleChatPanel(true);
}
function openDirectMemoModal() {
    const recipients=Array.from(new Set(chatSelectedRecipients)).filter(x=>x!==currentUser&&accountsData[x]);
    if(!recipients.length){alert('쪽지를 보낼 상대를 한 명 이상 추가해 주세요.');return;}
    document.getElementById('modalTitle').textContent='쪽지 보내기';
    document.getElementById('modalBody').innerHTML=`<div style="display:grid;gap:12px"><div style="padding:10px 12px;border-radius:10px;background:#eff6ff;color:#1e3a8a;font-size:12px"><strong>받는 사람</strong><div style="margin-top:5px">${recipients.map(escapeHtml).join(', ')}</div></div><label style="font-size:12px;font-weight:700;color:#334155">쪽지 내용<textarea id="directMemoText" rows="6" placeholder="전달할 내용을 입력하세요" style="display:block;width:100%;margin-top:6px;padding:10px;border:1px solid #cbd5e1;border-radius:9px;resize:vertical"></textarea></label><label style="font-size:12px;font-weight:700;color:#334155">첨부파일 <input id="directMemoFile" type="file" style="display:block;width:100%;margin-top:6px"></label><small style="color:#64748b">최대 20MB · 쪽지는 선택한 상대의 쪽지함과 대화 기록에 함께 저장됩니다.</small></div>`;
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">취소</button><button id="directMemoSend" class="btn-primary" onclick="sendDirectMemo()">쪽지 전달</button>';
    document.getElementById('commonModal').style.display='flex';
    setTimeout(()=>document.getElementById('directMemoText')?.focus(),50);
}
async function sendDirectMemo() {
    const recipients=Array.from(new Set(chatSelectedRecipients)).filter(x=>x!==currentUser&&accountsData[x]);
    const text=(document.getElementById('directMemoText')?.value||'').trim(), file=document.getElementById('directMemoFile')?.files?.[0]||null;
    if(!recipients.length){alert('받는 사람을 확인해 주세요.');return;}
    if(!text&&!file){alert('쪽지 내용이나 첨부파일을 입력해 주세요.');return;}
    const button=document.getElementById('directMemoSend');if(button){button.disabled=true;button.textContent='전달 중…';}
    try {
        let attachmentId=null, attachmentName=null, attachmentMime='';
        if(file){
            if(file.size>20*1024*1024)throw new Error('첨부파일은 20MB 이하만 보낼 수 있습니다.');
            const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
            const upload=await fetch('/api/attachments',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({name:file.name,content:btoa(binary),recipients,broadcast:false})});
            const result=await upload.json().catch(()=>({}));if(!upload.ok||!result.ok)throw new Error(result.message||'첨부파일 업로드에 실패했습니다.');
            attachmentId=result.attachment_id;attachmentName=result.name;attachmentMime=file.type||'';
        }
        const time=new Date().toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
        const id=Date.now()+'-'+Math.random().toString(36).slice(2,9);
        const message={id,sender:currentUser,recipient:recipients.length===1?recipients[0]:'GROUP',recipients,text,file:attachmentName,attachment_id:attachmentId,attachment_mime:attachmentMime,time,dm:true,note:true};
        chatMessagesList.push(message);
        recipients.forEach(recipient=>inboxMessages.push({id:id+':'+recipient,messageId:id,sender:currentUser,recipient,text,file:attachmentName,attachment_id:attachmentId,attachment_mime:attachmentMime,time,read:false,note:true}));
        await saveData();closeModal();renderConversationList();updateInboxCount();
        alert(`${recipients.length}명에게 쪽지를 전달했습니다.`);
    } catch(error){alert(error.message||'쪽지를 전달하지 못했습니다.');if(button){button.disabled=false;button.textContent='쪽지 전달';}}
}
function saveCurrentConversation(keyOverride) {
    const key=keyOverride||activeChatThread||'ALL';
    const messages=chatMessagesList.filter(m=>chatConversationKey(m)===key);
    if(!messages.length){alert('저장할 대화 내용이 없습니다.');return;}
    const lines=[chatConversationTitle(key),'저장 시각: '+new Date().toLocaleString('ko-KR'),'-'.repeat(48),...messages.map(m=>`[${m.time||''}] ${m.sender||''}\n${m.text||''}${m.file?'\n[첨부파일] '+m.file+(m.attachment_id?' · 서버에서 열기: '+location.origin+'/api/attachments/'+m.attachment_id:''):''}`)];
    const blob=new Blob(['\ufeff'+lines.join('\n\n')],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='대화내역_'+new Date().toISOString().slice(0,10)+'.txt';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function endChatConversation(keyOverride) {
    if(keyOverride) {
        const win=detachedChatWindows.get(keyOverride);
        if(win&&!win.closed) win.close();
        detachedChatWindows.delete(keyOverride);
        return;
    }
    if(!activeChatThread || activeChatThread==='ALL') { alert('종료할 개별 대화를 먼저 선택해 주세요.'); return; }
    // Close the open view only. Keep the conversation in the list and preserve its history.
    activeChatThread='ALL'; renderConversationList(); renderChatMessages();
}
function toggleChatMute(key) {
    key=key||activeChatThread; if(!key||key==='ALL') { alert('조용히 설정할 개별 대화를 선택해 주세요.'); return; }
    const muted=readChatPreference('muted');
    if(muted.includes(key)) writeChatPreference('muted',muted.filter(x=>x!==key)); else writeChatPreference('muted',[...muted,key]);
    renderConversationList(); updateInboxCount();
}
async function markChatThreadRead(key) {
    if(!key||key==='ALL') return;
    const messageThreads=new Map(chatMessagesList.map(m=>[String(m.id),chatConversationKey(m)])); let changed=false;
    inboxMessages.forEach(item=>{const id=String(item.messageId||String(item.id||'').split(':')[0]);if(item.recipient===currentUser&&!item.read&&messageThreads.get(id)===key){item.read=true;changed=true;}});
    if(changed){updateInboxCount();await saveData();}
}

async function sendChatMessage(overrideText, targetThread, formatOverride, fileOverride) {
    const detached=!!targetThread;
    const input = document.getElementById('chatInput');
    const txt = (typeof overrideText==='string'?overrideText:(input?input.value:'')).trim();
    const thread=targetThread||activeChatThread||'ALL';
    const selectedFile=fileOverride||(detached?null:chatAttachedFile);
    const isBroadcast=thread==='ALL';
    const recipients=isBroadcast?[]:thread.slice(3).split('|').filter(x=>x&&x!==currentUser);
    if(!isBroadcast && recipients.length===0) { alert('대화 상대를 선택하거나 새 대화를 시작해 주세요.'); return; }
    if(!txt && !selectedFile) return;
    const sendButton = document.getElementById('chatSendButton');
    if(sendButton) sendButton.disabled = true;
    try {
        let attachmentId = null;
        let attachmentName = null;
        let attachmentMime = '';
        if(selectedFile) {
            if(selectedFile.size > 20 * 1024 * 1024) throw new Error('첨부파일은 20MB 이하만 보낼 수 있습니다.');
            const bytes = new Uint8Array(await selectedFile.arrayBuffer());
            let binary = '';
            const chunk = 0x8000;
            for(let i=0;i<bytes.length;i+=chunk) binary += String.fromCharCode(...bytes.subarray(i, i+chunk));
            const upload = await fetch('/api/attachments', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:selectedFile.name,content:btoa(binary),recipients,broadcast:isBroadcast})});
            const uploadData = await upload.json();
            if(!upload.ok || !uploadData.ok) throw new Error(uploadData.message || '첨부파일 업로드에 실패했습니다.');
            attachmentId = uploadData.attachment_id; attachmentName = uploadData.name;
            attachmentMime = selectedFile.type || '';
        }
        const timeStr = new Date().toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
        const msgId = Date.now() + '-' + Math.random().toString(36).slice(2, 9);
        const msgObj = {id:msgId,sender:currentUser,recipient:isBroadcast?'ALL':(recipients.length===1?recipients[0]:'GROUP'),recipients,text:txt,file:attachmentName,attachment_id:attachmentId,attachment_mime:attachmentMime,time:timeStr,dm:!isBroadcast};
        chatMessagesList.push(msgObj);
        recipients.forEach(recipient => inboxMessages.push({id:msgId+':'+recipient,messageId:msgId,sender:currentUser,recipient,text:txt,file:attachmentName,attachment_id:attachmentId,time:timeStr,read:false}));
        if(!detached) { if(input) input.value=''; clearChatFile(); }
        await saveData();
        renderConversationList();
        if(!detached) activeChatThread=chatConversationKey(msgObj);
        if(!detached&&input&&typeof overrideText==='string') input.value='';
        renderChatMessages(); updateInboxCount();
    } catch(error) { alert(error.message || '메시지를 보내지 못했습니다.'); }
    finally { if(sendButton) sendButton.disabled=false; }
}

function chatRecipients(message) {
    if(Array.isArray(message.recipients)) return message.recipients;
    return message.recipient && message.recipient !== 'ALL' && message.recipient !== 'GROUP' ? [message.recipient] : [];
}
function chatConversationKey(message) {
    if(!message.dm) return 'ALL';
    const participants = Array.from(new Set([message.sender, ...chatRecipients(message)].filter(Boolean))).sort();
    return 'DM|' + participants.join('|');
}
function chatConversationTitle(key) {
    if(key === 'ALL') return '📢 전체 공지';
    const people = key.slice(3).split('|').filter(name => name && name !== currentUser);
    if(people.length === 1) return '💬 ' + people[0] + ' · 1:1';
    return '👥 ' + people.join(', ') + ' · 그룹';
}
function chatImageMarkup(message) {
    if(!message.attachment_id) return '';
    const mime=String(message.attachment_mime||'').toLowerCase();
    const looksLikeImage=mime.startsWith('image/')||/\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(message.file||'');
    if(!looksLikeImage) return '';
    const url='/api/attachments/'+encodeURIComponent(message.attachment_id);
    return '<a target="_blank" rel="noopener" href="'+url+'"><img class="chat-attachment-image" loading="lazy" src="'+url+'" alt="'+escapeHtml(message.file||'첨부 이미지')+'"></a>';
}
function renderConversationList() {
    const list=document.getElementById('chatThreadList'); if(!list) return;
    const keys=[]; const seen=new Set(); const closed=new Set(readChatPreference('closed')); const muted=new Set(readChatPreference('muted'));
    for(let i=chatMessagesList.length-1;i>=0;i--) {
        const message=chatMessagesList[i];
        const key=chatConversationKey(message);
        if(key==='ALL' || key.indexOf('DM|')===0 && key.slice(3).split('|').includes(currentUser)) {
            if(!seen.has(key)&&!closed.has(key)){seen.add(key);keys.push(key);}
        }
    }
    if(activeChatThread!=='ALL'&&!closed.has(activeChatThread)&&!seen.has(activeChatThread)) { seen.add(activeChatThread); keys.unshift(activeChatThread); }
    if(!seen.has('ALL')) keys.push('ALL');
    list.innerHTML='';
    keys.forEach(key=>{
        const last=chatMessagesList.slice().reverse().find(m=>chatConversationKey(m)===key);
        const unread=key==='ALL'?0:inboxMessages.filter(i=>i.recipient===currentUser&&!i.read&&chatConversationKey({sender:i.sender,recipients:[currentUser],dm:true})===key).length;
        const row=document.createElement('div'); row.className='chat-thread-row'+(activeChatThread===key?' active':'');
        const open=document.createElement('button'); open.type='button'; open.className='chat-thread-open'; open.title=chatConversationTitle(key);
        const title=document.createElement('strong'); title.textContent=(muted.has(key)?'🔕 ':'')+chatConversationTitle(key)+(unread?'  · '+unread:'');
        const detached=detachedChatWindows.get(key);const preview=document.createElement('small'); preview.textContent=detached&&!detached.closed?'별도 창에서 대화 중':(last?((last.sender===currentUser?'나: ':last.sender+': ')+(last.text|| (last.file?'📎 첨부파일':''))):'새 대화');
        open.append(title,preview); open.addEventListener('click',()=>setActiveChatThread(key)); row.appendChild(open);
        if(key!=='ALL') {
            const mute=document.createElement('button'); mute.type='button'; mute.className='chat-thread-action'; mute.title=muted.has(key)?'알림 켜기':'조용히'; mute.textContent=muted.has(key)?'🔕':'🔔'; mute.addEventListener('click',()=>toggleChatMute(key)); row.appendChild(mute);
            const popout=document.createElement('button'); popout.type='button'; popout.className='chat-thread-action'; popout.title='별도 창에서 대화'; popout.textContent='↗'; popout.addEventListener('click',()=>openChatDetached(key)); row.appendChild(popout);
            const close=document.createElement('button'); close.type='button'; close.className='chat-thread-action'; close.title='대화 종료'; close.textContent='×'; close.addEventListener('click',()=>{if(activeChatThread===key) activeChatThread='ALL';const c=readChatPreference('closed');writeChatPreference('closed',[...new Set([...c,key])]);renderConversationList();renderChatMessages();}); row.appendChild(close);
        }
        list.appendChild(row);
    });
    if(activeChatThread!=='ALL'&&!keys.includes(activeChatThread)) activeChatThread='ALL';
    const title=document.getElementById('chatConversationTitle'); if(title) title.textContent=chatConversationTitle(activeChatThread);
}
function renderChatMessages() {
    let area = document.getElementById("chatMessages");
    if(!area) return;
    renderConversationList();
    const selectedThread = activeChatThread || 'ALL';
    markChatThreadRead(selectedThread);
    area.innerHTML = "";
    const detached=detachedChatWindows.get(selectedThread);
    if(detached&&!detached.closed) {
        area.classList.remove('privacy-blur','privacy-bold');area.style.removeProperty('--chat-blur-px');
        const note=document.createElement('div');note.style.cssText='margin:auto;max-width:280px;padding:22px;text-align:center;border:1px solid #cbd5e1;border-radius:14px;background:linear-gradient(145deg,#fff,#f1f5f9);box-shadow:0 10px 28px #0f172a18;color:#334155;';
        note.innerHTML='<div style="font-size:28px;margin-bottom:8px">🗔</div><strong style="display:block;color:#0f172a">별도 대화창에서 열려 있습니다</strong><div style="font-size:11px;line-height:1.6;margin:7px 0 12px;color:#64748b">개인 대화 내용은 이 화면에 표시되지 않습니다.</div>';
        const focus=document.createElement('button');focus.type='button';focus.textContent='대화창으로 이동';focus.style.cssText='border:0;border-radius:7px;background:#2563eb;color:white;padding:7px 12px;font-weight:700;cursor:pointer';focus.onclick=()=>detached.focus();note.appendChild(focus);area.appendChild(note);
        for(const [key,win] of detachedChatWindows){if(win.closed)detachedChatWindows.delete(key);else renderDetachedChat(win.document,key);}
        return;
    }
    applyChatPrivacy(area,chatFormatState);
    chatMessagesList.forEach(m => {
        if(chatConversationKey(m) !== selectedThread) return;
        let recipients = chatRecipients(m);
        let isMine = m.sender === currentUser;
        let dmLabel = '';
        if(m.dm) dmLabel = m.note ? '(전달 쪽지)' : (recipients.length > 1 ? '(그룹 대화 · ' + recipients.length + '명)' : '(1:1 대화)');
        let div = document.createElement("div");
        div.className = "msg-box " + (isMine ? 'msg-right' : 'msg-left');
        div.innerHTML = '<div style="font-size:10px;font-weight:bold;margin-bottom:2px;color:' + (isMine ? '#1e3a8a' : '#475569') + '">' +
            escapeHtml(m.sender) + ' ' + dmLabel + '</div><div class="msg-text">' + escapeHtml(m.text) + '</div>' +
            (m.file ? '<div style="font-size:11px;margin-top:6px;padding:7px 8px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;color:#1d4ed8;"><b>📎 파일이 첨부되었습니다</b><br><span>' + escapeHtml(m.file) + '</span>' + chatImageMarkup(m) + (m.attachment_id ? ' <a target="_blank" rel="noopener" href="/api/attachments/' + encodeURIComponent(m.attachment_id) + '" style="color:#1d4ed8;font-weight:bold;">열기</a> <a href="/api/attachments/' + encodeURIComponent(m.attachment_id) + '" download="' + escapeHtml(m.file) + '" style="color:#1d4ed8;font-weight:bold;margin-left:6px;">저장</a>' : '<br><small>이전 메시지의 파일 내용은 보관되어 있지 않습니다.</small>') + '</div>' : '') +
            '<div style="font-size:9px;text-align:right;color:#94a3b8;margin-top:4px;">' + escapeHtml(m.time) + '</div>';
        area.appendChild(div);
    });
    area.scrollTop = area.scrollHeight;
    const muteBtn=document.querySelector('.chat-format-toolbar button[onclick="toggleChatMute()"]');
    if(muteBtn) muteBtn.textContent=readChatPreference('muted').includes(activeChatThread)?'🔔 알림 켜기':'🔕 조용히';
    for(const [key,win] of detachedChatWindows){if(win.closed)detachedChatWindows.delete(key);else renderDetachedChat(win.document,key);}
}

function renderDetachedChat(doc, threadKey) {
    if(!doc||!doc.getElementById('detachedChatMessages')) return;
    const title=doc.getElementById('detachedChatTitle'); if(title) title.textContent=chatConversationTitle(threadKey);
    const area=doc.getElementById('detachedChatMessages'); area.innerHTML='';
    chatMessagesList.filter(m=>chatConversationKey(m)===threadKey).forEach(m=>{
        const box=doc.createElement('div'), body=doc.createElement('div');
        box.style.cssText='max-width:85%;margin:6px 0;padding:9px 11px;border-radius:12px;align-self:'+(m.sender===currentUser?'flex-end':'flex-start')+';box-shadow:0 1px 3px #0002;border:1px solid '+(m.sender===currentUser?'#bfdbfe':'#e2e8f0');
        box.style.backgroundColor=m.sender===currentUser?'#dbeafe':'white';
        const sender=doc.createElement('div');sender.textContent=(m.sender||'')+(m.time?' · '+m.time:'');sender.style.cssText='font-size:11px;color:#64748b;margin-bottom:4px;font-weight:600';box.appendChild(sender);
        body.textContent=m.text||'';body.style.whiteSpace='pre-wrap';body.style.overflowWrap='anywhere';
        box.appendChild(body);
        if(m.file){const file=doc.createElement('div');file.style.cssText='margin-top:6px;font-size:12px';file.textContent='📎 '+m.file;
            if(m.attachment_id){const href='/api/attachments/'+encodeURIComponent(m.attachment_id);if(String(m.attachment_mime||'').startsWith('image/')||/\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(m.file||'')){const image=doc.createElement('img');image.src=href;image.alt=m.file;image.style.cssText='display:block;max-width:240px;max-height:220px;object-fit:contain;margin-top:6px;border:1px solid #cbd5e1;border-radius:7px';file.appendChild(image);}const open=doc.createElement('a');open.href=href;open.target='_blank';open.rel='noopener';open.textContent=' 열기';const save=doc.createElement('a');save.href=href;save.download=m.file;save.textContent=' 저장';file.append(open,save);}
            box.appendChild(file);
        }
        area.appendChild(box);
    }); area.scrollTop=area.scrollHeight;
    const state=doc.defaultView.popupPrivacyState||{bold:false,blur:false,opacity:.78};applyChatPrivacy(area,state);const blurButton=doc.getElementById('popBlur');if(blurButton){blurButton.textContent=state.blur?'◌ 흐림 해제':'◌ 화면 흐리게';blurButton.setAttribute('aria-pressed',String(!!state.blur));}const lockButton=doc.getElementById('popBold');if(lockButton)lockButton.setAttribute('aria-pressed',String(!!state.bold));const password=doc.getElementById('popPrivacyPassword'),err=doc.getElementById('popPrivacyError'),range=doc.getElementById('popPrivacyRangeWrap'),privacyTitle=doc.getElementById('popPrivacyTitle'),desc=doc.getElementById('popPrivacyDescription'),unlock=doc.getElementById('popReveal');if(password)password.style.display=state.bold?'block':'none';if(range)range.style.display=(state.bold||state.blur)?'flex':'none';if(privacyTitle)privacyTitle.textContent=state.bold?'메신저 화면 잠금':'메신저 화면 흐림';if(desc)desc.textContent=state.bold?'현재 로그인 계정의 비밀번호를 입력하면 보호가 해제됩니다.':'가림 농도를 조절해 화면 내용을 숨길 수 있습니다.';if(unlock)unlock.textContent=state.bold?'비밀번호로 해제':'흐림 해제';const pct=Math.round((Number(state.opacity)||.78)*100);if(doc.getElementById('popPrivacyRange'))doc.getElementById('popPrivacyRange').value=pct;if(doc.getElementById('popPrivacyPct'))doc.getElementById('popPrivacyPct').textContent=pct+'%';if(doc.getElementById('popBlurLevel'))doc.getElementById('popBlurLevel').value=pct;if(doc.getElementById('popBlurValue'))doc.getElementById('popBlurValue').textContent=pct+'%';
}
function openChatDetached(threadKey) {
    const key=threadKey||activeChatThread;
    if(!key||key==='ALL'){alert('별도 창으로 열 대화 상대를 먼저 선택해 주세요.');return;}
    const existing=detachedChatWindows.get(key);if(existing&&!existing.closed){existing.focus();return;}
    const w=window.open('','_blank','width=820,height=720,resizable=yes,scrollbars=yes');
    if(!w){alert('브라우저에서 팝업이 차단되었습니다. 이 사이트의 팝업을 허용해 주세요.');return;}
    detachedChatWindows.set(key,w);
    w.document.open(); w.document.write('<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>메신저 대화</title><style>*{box-sizing:border-box}body{margin:0;font:14px Arial,sans-serif;color:#0f172a;background:#f1f5f9}header{padding:13px 16px;background:#0f172a;color:white;font-weight:bold}main{height:calc(100vh - 48px);display:flex;flex-direction:column}h3{font-size:15px;margin:0;padding:12px 16px;background:white;border-bottom:1px solid #dbe3ef}#detachedChatMessages{position:relative;flex:1;min-height:0;overflow:auto;padding:14px;display:flex;flex-direction:column}.toolbar,.composer{padding:10px 12px;background:white;border-top:1px solid #dbe3ef;display:flex;align-items:center;gap:8px;flex-wrap:wrap}.composer textarea{flex:1;min-width:180px;height:50px;padding:9px;border:1px solid #cbd5e1;border-radius:8px;resize:vertical}.toolbar button,.composer button{padding:8px 11px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;cursor:pointer}.toolbar button.active{background:#dbeafe;border-color:#60a5fa;color:#1d4ed8}.composer button.primary{background:#2563eb;color:white;border-color:#2563eb}.toolbar input[type=range]{width:105px}</style><header>💬 '+escapeHtml(currentUser)+' · 별도 대화창</header><main><h3 id="detachedChatTitle"></h3><div id="detachedChatMessages"></div><div class="toolbar"><button id="popBold">🔒 화면 보호</button><button id="popBlur">◌ 화면 흐리게</button><label>흐림 농도 <input id="popBlurLevel" type="range" min="20" max="100" value="78"></label><span id="popBlurValue">78%</span><button id="popSave">대화 저장</button><button id="popEnd">이 창 닫기</button></div><div class="composer"><input id="popFile" type="file" hidden><button id="popAttach">📎 첨부</button><textarea id="detachedChatInput" placeholder="메시지 입력"></textarea><button id="popSend" class="primary">전송</button></div></main></html>'); w.document.close();
    w.popupPrivacyState={bold:false,blur:false,opacity:.78};
    const d=w.document,input=d.getElementById('detachedChatInput'),fileInput=d.getElementById('popFile');
    const privacyStyle=d.createElement('style');privacyStyle.textContent='body{position:relative}body.privacy-blur:not(.privacy-bold) #detachedChatTitle,body.privacy-blur:not(.privacy-bold) #detachedChatMessages,body.privacy-blur:not(.privacy-bold) #detachedChatInput{filter:blur(var(--chat-blur-px,8px))}#detachedPrivacyCover{position:fixed;inset:0;z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;background:rgba(30,41,59,var(--chat-cover-opacity,.78));backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)}body.privacy-bold #detachedPrivacyCover{display:flex}body.privacy-bold #detachedPrivacyCover{background:rgba(2,6,23,var(--chat-cover-opacity,.96));backdrop-filter:blur(12px) brightness(.08);-webkit-backdrop-filter:blur(12px) brightness(.08)}#detachedPrivacyCard{width:min(360px,100%);padding:23px;text-align:center;color:#e2e8f0;background:#0f172af5;border:1px solid #64748b;border-radius:18px;box-shadow:0 24px 70px #0008}#detachedPrivacyCard input[type=password]{width:100%;padding:10px;border:1px solid #64748b;border-radius:8px;margin:0 0 7px}#popPrivacyError{min-height:16px;color:#fca5a5;font-size:11px}';d.head.appendChild(privacyStyle);
    const privacyCover=d.createElement('div');privacyCover.id='detachedPrivacyCover';privacyCover.innerHTML='<div id="detachedPrivacyCard"><div style="font-size:34px;margin-bottom:9px">🔒</div><strong id="popPrivacyTitle" style="display:block;color:white;font-size:17px">메신저 화면 보호 중</strong><p id="popPrivacyDescription" style="font-size:12px;line-height:1.7;color:#cbd5e1;margin:9px 0 14px">대화 제목, 내용, 첨부자료와 작성 도구가 모두 가려져 있습니다.</p><label id="popPrivacyRangeWrap" style="display:flex;gap:8px;align-items:center;font-size:11px;margin:10px 0">가림 농도<input id="popPrivacyRange" type="range" min="20" max="100" value="78" style="flex:1"><span id="popPrivacyPct">78%</span></label><input id="popPrivacyPassword" type="password" autocomplete="current-password" placeholder="로그인 비밀번호"><div id="popPrivacyError"></div><button id="popReveal" style="border:0;border-radius:9px;padding:9px 15px;background:#bfdbfe;color:#0f172a;font-weight:700;cursor:pointer">비밀번호로 해제</button></div>';d.body.appendChild(privacyCover);
    d.getElementById('popBold').onclick=()=>{d.getElementById('popPrivacyError').textContent='';w.popupPrivacyState.bold=!w.popupPrivacyState.bold;d.getElementById('popBold').classList.toggle('active',w.popupPrivacyState.bold);renderDetachedChat(d,key);};
    d.getElementById('popBlur').onclick=()=>{w.popupPrivacyState.blur=!w.popupPrivacyState.blur;d.getElementById('popBlur').classList.toggle('active',w.popupPrivacyState.blur);renderDetachedChat(d,key);};
    d.getElementById('popBlurLevel').oninput=e=>{w.popupPrivacyState.opacity=Number(e.target.value)/100;d.getElementById('popBlurValue').textContent=e.target.value+'%';renderDetachedChat(d,key);};
    d.getElementById('popPrivacyRange').oninput=e=>{w.popupPrivacyState.opacity=Number(e.target.value)/100;d.getElementById('popPrivacyPct').textContent=e.target.value+'%';d.getElementById('popBlurLevel').value=e.target.value;d.getElementById('popBlurValue').textContent=e.target.value+'%';renderDetachedChat(d,key);};
    d.getElementById('popReveal').onclick=async()=>{const state=w.popupPrivacyState,err=d.getElementById('popPrivacyError');if(state.bold){const password=d.getElementById('popPrivacyPassword').value;if(!password){err.textContent='로그인 비밀번호를 입력해 주세요.';d.getElementById('popPrivacyPassword').focus();return;}try{const result=await verifyCurrentLoginPassword(password);if(!result.ok){err.textContent=result.message;d.getElementById('popPrivacyPassword').value='';return;}}catch(_){err.textContent='서버에 연결할 수 없습니다.';return;}}state.bold=false;state.blur=false;d.getElementById('popPrivacyPassword').value='';d.getElementById('popBold').classList.remove('active');d.getElementById('popBlur').classList.remove('active');renderDetachedChat(d,key);};
    d.getElementById('popAttach').onclick=()=>fileInput.click();
    d.getElementById('popSend').onclick=async()=>{const f=fileInput.files&&fileInput.files[0]||null;await sendChatMessage(input.value,key,null,f);input.value='';if(f)fileInput.value='';};
    input.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();d.getElementById('popSend').click();}};
    d.getElementById('popSave').onclick=()=>saveCurrentConversation(key);
    d.getElementById('popEnd').onclick=()=>endChatConversation(key);
    w.onbeforeunload=()=>{detachedChatWindows.delete(key);setTimeout(()=>renderChatMessages(),0);};
    renderDetachedChat(d,key);renderChatMessages();w.setInterval(()=>{if(!w.closed)renderDetachedChat(d,key);},1000);
}

function toggleChatPanel(forceOpen) {
    const panel=document.querySelector('.chat-area');
    if(!panel) return;
    const open=typeof forceOpen==='boolean'?forceOpen:!panel.classList.contains('open');
    panel.classList.toggle('open',open);
    panel.style.display=open?'flex':'none';
    const button=document.getElementById('chatPanelToggle');
    if(button) button.innerHTML=(open?'💬 메신저 닫기':'💬 메신저 열기')+' <span id="unreadInboxCount" style="font-weight:bold;">'+countUnreadChat()+'</span>';
}

function countUnreadChat() {
    const muted=readChatPreference('muted');
    return inboxMessages.filter(i=>{
        if(i.recipient!==currentUser||i.read) return false;
        return !muted.some(key=>key.startsWith('DM|')&&key.split('|').includes(currentUser)&&key.split('|').includes(i.sender));
    }).length;
}
function updateInboxCount() {
    let unread = countUnreadChat();
    let badge = document.getElementById("unreadInboxCount");
    if(badge) badge.innerText = unread;
}

async function openInboxModal() {
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = `${currentUser}님의 수신 쪽지함`;
    let myInbox = inboxMessages.filter(i => i.recipient === currentUser);

    let html = "";
    if(myInbox.length === 0) {
        html = `<div style="color:#64748b; text-align:center; padding:20px;">수신된 1:1 쪽지가 없습니다.</div>`;
    } else {
        myInbox.forEach(msg => {
            if(!msg.read) msg.read = true;
            html += `<div style="background:#f8fafc; padding:10px; border-radius:6px; border:1px solid #cbd5e1; margin-bottom:8px; font-size:12px;">
                <b>보낸사람: ${escapeHtml(msg.sender)}</b> (${escapeHtml(msg.time)})${escapeHtml(msg.note ? ' · 전달 쪽지' : '')}<br>
                <div style="margin-top:4px;">${escapeHtml(msg.text)}</div>
                ${msg.file ? `<div style="margin-top:6px;padding:7px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;color:#1d4ed8;">📎 ${escapeHtml(msg.file)} ${msg.attachment_id ? `<a target="_blank" rel="noopener" href="/api/attachments/${escapeHtml(encodeURIComponent(msg.attachment_id))}">열기</a> <a href="/api/attachments/${escapeHtml(encodeURIComponent(msg.attachment_id))}" download="${escapeHtml(msg.file)}">저장</a>` : '<small>(이전 메시지 첨부파일은 복구할 수 없습니다.)</small>'}</div>` : ''}
            </div>`;
        });
        await saveData();
        updateInboxCount();
    }

    modalBody.innerHTML = html;
    modalFooter.innerHTML = `<button class="btn-secondary" onclick="closeModal()">닫기</button>`;
    document.getElementById("commonModal").style.display = "flex";
}

window.ybyModulesReady=true;

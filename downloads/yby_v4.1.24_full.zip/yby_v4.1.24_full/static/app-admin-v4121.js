/* YBY V4.1.21 admin screen module; global compatibility preserved. */
function renderAdminPermissions() {
    let tbody = document.getElementById("permissionTable");
    let logBox = document.getElementById("auditLogBox");
    if(!tbody) return;
    if(userScope!=="ALL"){tbody.replaceChildren();clearCredentialView();return;}
    tbody.innerHTML = "";

    Object.keys(accountsData).forEach(acc => {
        let info = accountsData[acc];
        let tr = document.createElement("tr");
        let perms = info.permissions;

        let checkboxesHtml = allViewIds.filter(vId=>!['v_backup_ops','v_company_policy'].includes(vId)).map(vId => {
            let checked = info.scope==='ALL'||perms.includes(vId) ? 'checked' : '';const disabled=info.scope==='ALL'?'disabled':'';
            let labelName=permissionLabel24(vId);
            return `<label style="font-size:11px; margin-right:6px; display:inline-block;"><input type="checkbox" class="permission-checkbox" value="${escapeHtml(vId)}" ${escapeHtml(checked)} ${disabled}> ${escapeHtml(labelName)}</label>`;
        }).join('');

        tr.innerHTML = `
            <td><b>${escapeHtml(acc)}</b></td>
            <td><span class="card-tag tag-${escapeHtml(info.scope === 'ALL' ? '본사' : info.scope)}">${escapeHtml(info.scope)}</span></td>
            <td style="min-width:185px"><label style="display:block;font-size:10px;color:#64748b">현재 비밀번호 (회사 정책에 따라 열람 제한)<input class="latest-account-password" type="password" readonly autocomplete="off" style="display:block;width:170px;padding:5px;font-size:12px;background:#f8fafc"></label><small class="password-updated-info" style="display:block;color:#64748b;font-size:10px;margin:4px 0"></small><label style="display:block;font-size:10px;color:#64748b">새 비밀번호<input type="password" class="account-password" autocomplete="new-password" value="" placeholder="변경할 때만 입력 (10~128자)" style="display:block;width:170px;padding:5px;font-size:12px"></label></td>
            <td style="text-align:left; max-width:400px;">${checkboxesHtml}</td>
            <td>
                <button class="btn-success" style="padding:4px 8px;" onclick="saveAccountPerms(${jsArg(acc)})">저장</button> <button class="btn-secondary" onclick="revokeAccountSessions(${jsArg(acc)})">접속 종료</button>
                ${acc !== 'admin' ? `<button class="btn-danger" style="padding:4px 8px;" onclick="deleteAccount(${jsArg(acc)})">삭제</button>` : ''}
            </td>
        `;
        tr.dataset.accountName=acc;
        const latest=adminPasswordRows[acc]||{};
        const input=tr.querySelector('.latest-account-password');input.value=latest.latestPassword??'';
        input.placeholder=latest.passwordDisplayStatus==='available'?'암호화 보관 · 보기 버튼 사용':'새 버전 로그인/변경 후 확인 가능';
        const reveal=document.createElement('button');reveal.type='button';reveal.className='btn-secondary';reveal.textContent='현재 비밀번호 보기';reveal.onclick=()=>openPasswordReveal(acc);input.parentElement.appendChild(reveal);
        tr.querySelector('.password-updated-info').textContent=latest.passwordUpdatedAt?`${latest.passwordUpdatedAt} · ${latest.passwordUpdatedBy||''}`:'필요한 경우 새 임시 비밀번호로 재설정하세요.';
        if(acc==='admin'){const edit=tr.querySelector('.account-password');edit.disabled=true;edit.placeholder='상단 비밀번호 변경 버튼 이용';}
        tbody.appendChild(tr);
    });

    const inactiveSection=document.getElementById('inactiveAccountsSection');
    const inactiveTbody=document.getElementById('inactiveAccountTable');
    if(inactiveSection&&inactiveTbody){
        inactiveTbody.innerHTML='';
        inactiveSection.style.display=inactiveAccountRows.length?'block':'none';
        inactiveAccountRows.forEach(account=>{
            const row=document.createElement('tr');
            row.innerHTML=`<td>${escapeHtml(account.username)}</td><td>${escapeHtml(account.scope||'')}</td><td></td>`;
            const button=document.createElement('button');button.className='btn-success';button.textContent='복구';
            button.addEventListener('click',()=>restoreAccount(account.username));row.cells[2].appendChild(button);inactiveTbody.appendChild(row);
        });
    }

    if(logBox) {
        logBox.innerHTML = auditLogs.map(escapeHtml).join("<br>");
    }
    renderAccountHistory();renderPasswordHistory();
}

let credentialViewTimer=null,credentialViewSerial=0;
function clearCredentialView(){credentialViewSerial++;clearTimeout(credentialViewTimer);credentialViewTimer=null;document.querySelectorAll('[data-credential-secret]').forEach(input=>input.value='');}
window.addEventListener('pagehide',clearCredentialView);
window.addEventListener('blur',clearCredentialView);
function openPasswordReveal(username){
    clearCredentialView();if(userScope!=='ALL')return;
    document.getElementById('modalTitle').textContent='현재 비밀번호 확인';
    document.getElementById('modalBody').innerHTML='<p>최고관리자 재인증 후 30초 동안 표시합니다. 조회 시각과 대상은 감사 기록에 남습니다.</p><label>현재 관리자 비밀번호<input id="passwordRevealAdmin" type="password" autocomplete="current-password"></label><p id="passwordRevealError" style="color:#b91c1c"></p>';
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button>';
    const button=document.createElement('button');button.className='btn-primary';button.textContent='재인증하고 보기';button.onclick=()=>revealAccountPassword(username);document.getElementById('modalFooter').appendChild(button);
    document.getElementById('commonModal').style.display='flex';document.getElementById('passwordRevealAdmin').focus();
}
async function revealAccountPassword(username){
    const input=document.getElementById('passwordRevealAdmin'),error=document.getElementById('passwordRevealError'),requestUser=currentUser,requestSerial=credentialViewSerial;
    try{
        const r=await fetch('/api/admin/password-reveal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,adminPassword:input.value})});
        const d=await r.json();if(currentUser!==requestUser||userScope!=='ALL'||requestSerial!==credentialViewSerial||document.getElementById('passwordRevealAdmin')!==input)return;if(!r.ok||!d.ok)throw new Error(d.message||'비밀번호 조회 실패');
        input.value='';document.getElementById('modalBody').innerHTML='<p id="credentialViewTarget"></p><label>현재 비밀번호<input type="text" readonly data-credential-secret id="revealedAccountPassword" autocomplete="off"></label><p id="credentialViewExpiry">30초 후 또는 창을 벗어나면 표시를 지웁니다.</p>';
        document.getElementById('credentialViewTarget').textContent=username+' 계정';document.getElementById('revealedAccountPassword').value=d.password;
        document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button>';
        credentialViewTimer=setTimeout(()=>{clearCredentialView();const note=document.getElementById('credentialViewExpiry');if(note)note.textContent='표시 시간이 종료되었습니다. 다시 보려면 재인증하세요.';},30000);
    }catch(e){if(error)error.textContent=e.message;}finally{if(input)input.value='';}
}
async function revokeAccountSessions(username){
    if(!confirm(username+' 계정의 모든 접속을 종료하시겠습니까?'))return;
    try{const r=await fetch('/api/admin/account-sessions/revoke',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})});const d=await r.json();if(!r.ok)throw new Error(d.message);if(d.reloginRequired)await handleLogout();else alert('선택한 계정의 접속만 종료했습니다.');}catch(e){alert(e.message);}
}
function renderPasswordHistory(){
    const body=document.getElementById('passwordHistoryTable');if(!body)return;body.replaceChildren();if(userScope!=='ALL')return;
    const query=(document.getElementById('passwordHistorySearch')?.value||'').trim().toLocaleLowerCase();
    const rows=accountHistoryRows.filter(x=>x.passwordChanged&&[x.target,x.actor,x.time].join(' ').toLocaleLowerCase().includes(query));
    for(const entry of rows){const tr=document.createElement('tr');for(const text of [formatServerTime(entry.time),entry.target,entry.actor,entry.action==='PASSWORD_CHANGE'?'본인 변경':entry.action==='ACCOUNT_CREATE'?'최초 발급':'관리자 재설정',entry.ip||'-']){const td=document.createElement('td');td.textContent=text;tr.appendChild(td);}body.appendChild(tr);}
    if(!rows.length){const tr=document.createElement('tr');const td=document.createElement('td');td.colSpan=5;td.textContent='표시할 비밀번호 변경 기록이 없습니다.';tr.appendChild(td);body.appendChild(tr);}
}

function accountHistorySummary(entry){
    const before=entry.before||{},after=entry.after||{},parts=[];
    if(entry.passwordChanged)parts.push('비밀번호 변경 (비밀번호 값은 이력에 기록하지 않음)');
    if(before.scope!==undefined&&before.scope!==after.scope)parts.push(`지점: ${before.scope} → ${after.scope}`);
    const old=new Set(before.permissions||[]),current=new Set(after.permissions||[]);
    const added=[...current].filter(x=>!old.has(x)),removed=[...old].filter(x=>!current.has(x));
    if(added.length)parts.push('권한 추가: '+added.join(', '));if(removed.length)parts.push('권한 제거: '+removed.join(', '));
    if(before.active!==undefined&&before.active!==after.active)parts.push(after.active?'계정 활성화':'계정 비활성화');
    if(!parts.length)parts.push(entry.action==='ACCOUNT_CREATE'?'계정 생성':'이전 기록 또는 계정 설정 변경');
    return parts.join(' / ');
}
function renderAccountHistory(){
    const body=document.getElementById('accountHistoryTable');if(!body)return;
    body.replaceChildren();if(userScope!=='ALL')return;
    const query=(document.getElementById('accountHistorySearch')?.value||'').trim().toLocaleLowerCase();
    const labels={ACCOUNT_CREATE:'계정 생성',ACCOUNT_UPDATE:'계정 설정 변경',ACCOUNT_PASSWORD_RESET:'관리자 비밀번호 수정',ACCOUNT_PERMISSIONS_CHANGE:'권한 수정',PASSWORD_CHANGE:'본인 비밀번호 변경',ADMIN_LOCAL_RESET:'관리자 복구',ACCOUNT_DEACTIVATED:'계정 삭제',ACCOUNT_RESTORED:'계정 복구'};
    let count=0;
    for(const entry of accountHistoryRows){
        const values=[formatServerTime(entry.time),entry.actor,entry.target,labels[entry.action]||entry.action,accountHistorySummary(entry),entry.ip||'-'];
        if(query&&!values.join(' ').toLocaleLowerCase().includes(query))continue;
        const row=document.createElement('tr');for(const value of values){const cell=document.createElement('td');cell.textContent=value??'';cell.style.fontSize='11px';row.appendChild(cell);}body.appendChild(row);count++;
    }
    if(!count){const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=6;cell.textContent=accountHistoryLoaded?'표시할 변경 이력이 없습니다.':'서버에서 변경 이력을 불러오는 중입니다.';row.appendChild(cell);body.appendChild(row);}
    const counter=document.getElementById('accountHistoryCount');if(counter)counter.textContent=`${count}건 / 최근 ${accountHistoryRows.length}건`;
}
async function loadAdminAccountDirectory(){
    if(userScope!=='ALL')return;
    const requestUser=currentUser,requestSerial=++adminDirectorySerial;
    try{
        const [response,historyResponse]=await Promise.all([fetch('/api/admin/accounts',{cache:'no-store'}),fetch('/api/admin/account-history',{cache:'no-store'})]);
        const [data,history]=await Promise.all([response.json(),historyResponse.json()]);
        if(currentUser!==requestUser||userScope!=='ALL'||requestSerial!==adminDirectorySerial)return;
        if(!response.ok||!data.ok||!Array.isArray(data.accounts))throw new Error(data.message||'계정 목록 조회 실패');
        if(!historyResponse.ok||!history.ok)throw new Error(history.message||'변경 이력 조회 실패');
        inactiveAccountRows=[];adminPasswordRows=Object.create(null);
        const canonical=Object.create(null);
        data.accounts.forEach(account=>{
            if(account.active){
                const current=accountsData[account.username]||{};
                canonical[account.username]={...current,scope:account.scope,permissions:account.permissions||[],lastLogin:account.lastLogin||'기록 없음',ip:account.ip||''};
                adminPasswordRows[account.username]={latestPassword:account.latestPassword,passwordUpdatedAt:account.passwordUpdatedAt,passwordUpdatedBy:account.passwordUpdatedBy,passwordDisplayStatus:account.passwordDisplayStatus};
            }else if(account.username!=='admin')inactiveAccountRows.push(account);
        });
        accountsData=canonical;accountHistoryRows=history.entries||[];accountHistoryLoaded=true;
        renderAdminPermissions();renderLoginUserSelect();
    }catch(error){
        console.error('관리자 계정·이력 조회 실패:',error);
        const counter=document.getElementById('accountHistoryCount');if(counter)counter.textContent='조회 실패: '+error.message;
    }
}

async function restoreAccount(username){
    if(!confirm(`'${username}' 계정을 복구하시겠습니까? 기존 비밀번호가 다시 활성화됩니다.`))return;
    try{
        const response=await fetch('/api/admin/account-restore',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username})});
        const result=await response.json().catch(()=>({}));
        if(!response.ok||!result.ok)throw new Error(result.message||'계정 복구에 실패했습니다.');
        await loadServerState();await loadAdminAccountDirectory();
        alert(`'${username}' 계정을 복구했습니다. 기존 비밀번호로 로그인할 수 있습니다.`);
    }catch(error){alert(error.message||'계정 복구에 실패했습니다.');}
}

async function saveAccountPerms(acc) {
    const accountRow=Array.from(document.querySelectorAll('#permissionTable tr')).find(row=>row.dataset.accountName===acc);
    if(!accountRow)return;
    const password=accountRow.querySelector('.account-password').value;
    const permissions=Array.from(accountRow.querySelectorAll('.permission-checkbox:checked')).map(c=>c.value);
    try{
        const r=await fetch('/api/admin/account-update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:acc,scope:accountsData[acc].scope,permissions,password})});
        const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'계정 저장 실패');
        if(d.reloginRequired){await handleLogout();alert('본인 권한이 변경되었습니다. 다시 로그인하세요.');return;}
        await loadServerState();await loadAdminAccountDirectory();
        alert(password?'저장했습니다. 현재 접속은 유지되며 다음 로그인에는 새 비밀번호를 사용하고 최초 변경해야 합니다.':'접속을 유지하면서 권한을 적용했습니다.');
    }catch(e){alert(e.message);}
}

function openAddAccountModal() {
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = "신규 담당자 계정 추가";
    modalBody.innerHTML = `
        <div class="form-group"><label>계정명 (이름)</label><input type="text" id="newAccName" placeholder="예: 부산담당자"></div>
        <div class="form-group"><label>초기 비밀번호</label><input type="password" id="newAccPw" minlength="10" maxlength="128" autocomplete="new-password" placeholder="10~128자 임시 비밀번호"></div>
        <div class="form-group"><label>소속 지점 (Scope)</label>
            <select id="newAccScope" onchange="document.getElementById('adminReauthBox').hidden=this.value!=='ALL'"><option value="본사">본사</option><option value="서울">서울</option><option value="인천">인천</option><option value="정봉">정봉</option><option value="임원실">임원실</option><option value="광주">광주</option><option value="ALL">ALL · 전 지점 최고관리자</option></select>
        </div><div id="adminReauthBox" hidden><label>전체 관리자 권한 부여 확인: 현재 관리자 비밀번호<input id="newAdminPassword" type="password" autocomplete="current-password"></label></div>
    `;
    modalFooter.innerHTML = `
        <button class="btn-success" onclick="createNewAccount()">등록하기</button>
        <button class="btn-secondary" onclick="closeModal()">닫기</button>
    `;
    document.getElementById("commonModal").style.display = "flex";
}

async function createNewAccount() {
    const username=document.getElementById('newAccName').value.trim();
    const password=document.getElementById('newAccPw').value;
    const scope=document.getElementById('newAccScope').value;
    const permissions=['v_dashboard','v_card_status','v_card_rent','v_expense','v_expense_history','v_stats','v_complaint'];
    try{
        const r=await fetch('/api/admin/account-create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password,scope,permissions,adminPassword:document.getElementById('newAdminPassword')?.value||''})});
        const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'계정 생성 실패');
        closeModal();await loadServerState();await loadAdminAccountDirectory();alert('계정을 생성했습니다. 최초 로그인 후 임시 비밀번호 변경이 필요합니다.');
    }catch(e){alert(e.message);}
}

async function deleteAccount(acc) {
    if(confirm(`정말 '${acc}' 계정을 삭제하시겠습니까?`)) {
        try{
            const response=await fetch('/api/admin/account-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:acc})});
            const result=await response.json().catch(()=>({}));
            if(!response.ok||!result.ok)throw new Error(result.message||'계정 삭제를 서버에 저장하지 못했습니다.');
            delete accountsData[acc];let nowStr=localDateTime(true);auditLogs.unshift(`[${nowStr}] 계정 '${acc}' 삭제됨.`);
            await loadServerState();await loadAdminAccountDirectory();renderAdminPermissions();renderLoginUserSelect();
        }catch(error){alert(error.message||'계정 삭제에 실패했습니다.');}
    }
}

function closeModal(){clearCredentialView();document.getElementById('commonModal').querySelectorAll('input[type=password]').forEach(x=>x.value='');document.getElementById('commonModal').style.display='none';if(modalReturnFocus?.isConnected)modalReturnFocus.focus();}
let modalReturnFocus=null;
const accessibleModal=document.getElementById('commonModal');accessibleModal.setAttribute('role','dialog');accessibleModal.setAttribute('aria-modal','true');accessibleModal.setAttribute('aria-labelledby','modalTitle');
new MutationObserver(()=>{if(accessibleModal.style.display==='flex'){modalReturnFocus=document.activeElement;accessibleModal.querySelector('input,textarea,select,button')?.focus();}}).observe(accessibleModal,{attributes:true,attributeFilter:['style']});
accessibleModal.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();return;}if(e.key==='Tab'){const items=Array.from(accessibleModal.querySelectorAll('button,input,textarea,select,[tabindex="0"]')).filter(x=>!x.disabled&&x.offsetParent!==null);if(!items.length)return;const first=items[0],last=items[items.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});

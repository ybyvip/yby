/* Hi-pass and fuel bundles. All mutations, confirmation and history are server-owned. */
const fleetUI={owner:null,editing:null,preview:null,openBranches:new Set()};
const fleetClasses=['임원','직원','직영승무원','업무용차량','기타'];
const fleetStates=['대기중','불출중','회수중','회수완료'];
const fleetLabels={distributionStatus:'배부 상태',group:'소속지점',classification:'사용 분류',hipassUser:'실사용자',car:'차량번호',returnDate:'회수일 / 회수 예정일',issueArea:'불출지역',route:'운행노선',reason:'등록·사용 사유',type:'선불/후불',company:'발급사',num:'카드번호',issueDate:'발급일',expiryDate:'만료일',paymentType:'신용/체크',usageScope:'사용 범위',userType:'지정 구분',assignedUser:'지정 사용자',cardAlias:'카드 특정명'};
function fleetEscape(value){return escapeHtml(String(value??''));}
function fleetSelect(id,label,options,value='',required=false){return `<div class="form-group"><label for="${id}">${label}</label><select id="${id}" ${required?'required':''}>${options.map(x=>`<option value="${fleetEscape(x)}" ${x===value?'selected':''}>${fleetEscape(x||'선택하세요')}</option>`).join('')}</select></div>`;}
function fleetInput(id,label,value='',type='text',required=false){return `<div class="form-group"><label for="${id}">${label}</label><input id="${id}" type="${type}" value="${fleetEscape(value)}" maxlength="${id.endsWith('Reason')?'2000':'200'}" ${required?'required':''}></div>`;}
function fleetFieldsHTML(prefix,row={}){
    const fuel=row.fuelCard||{},fuelPrefix=prefix==='regHipass'?'regFuel':'editFuel';
    const input=(key,type='text',required=false)=>fleetInput(prefix+(key==='hipassUser'?'User':key[0].toUpperCase()+key.slice(1)),fleetLabels[key],row[key]||'',type,required);
    const fuelInput=(key,type='text',required=false)=>fleetInput(fuelPrefix+key[0].toUpperCase()+key.slice(1),fleetLabels[key],fuel[key]||'',type,required);
    return `<fieldset class="fleet-choice"><legend>등록할 카드 선택</legend><label><input type="checkbox" id="${prefix}Enabled" ${row.hipassEnabled!==false?'checked':''} onchange="fleetToggleFields('${prefix}')">하이패스</label><label><input type="checkbox" id="${prefix}FuelEnabled" ${row.fuelEnabled?'checked':''} onchange="fleetToggleFields('${prefix}')">유류대카드</label></fieldset>
      <section class="fleet-section"><h3>공통 배부 정보</h3><div class="fleet-grid">${fleetSelect(prefix+'Group','소속지점',BRANCHES,row.group||(userScope==='ALL'?'본사':userScope),true)}${fleetSelect(prefix+'Classification','사용 분류',['',...fleetClasses],row.classification||'',true)}${input('hipassUser','text',true)}${input('car')}${fleetSelect(prefix+'DistributionStatus','배부 상태',fleetAllowedStates(row),fleetStatus(row)==='회수예정'?'회수중':fleetStatus(row),true)}${input('returnDate','date')}${input('issueArea')}${input('route')}${input('reason')}</div></section>
      <fieldset class="fleet-section" id="${prefix}CardFields"><legend>하이패스 카드</legend><div class="fleet-grid">${fleetSelect(prefix+'Type','카드 구분',['선불형','후불형'],row.type||'선불형',true)}${input('company','text',true)}${input('num','text',true)}${fleetInput(prefix+'IssueDate','발급일',row.issueDate||(row.id&&row.hipassEnabled!==false?'':localDate()),'date',true)}${input('expiryDate','date',true)}</div></fieldset>
      <fieldset class="fleet-section" id="${prefix}FuelFields"><legend>유류대카드</legend><div class="fleet-grid">${fleetSelect(fuelPrefix+'PaymentType','신용/체크',['','신용','체크'],fuel.paymentType||'',true)}${fleetSelect(fuelPrefix+'UsageScope','사용 범위',['','국내전용','해외겸용'],fuel.usageScope||'',true)}${fuelInput('company','text',true)}${fuelInput('num','text',true)}${fleetSelect(fuelPrefix+'UserType','사용자 구분',['비지정','지정'],fuel.userType||'비지정')}${fuelInput('assignedUser')}${fleetInput(fuelPrefix+'IssueDate','발급일',fuel.issueDate||(row.fuelEnabled?'':localDate()),'date',true)}${fuelInput('expiryDate','date',true)}${fuelInput('cardAlias')}</div></fieldset>`;
}
function fleetToggleFields(prefix){
    const hp=document.getElementById(prefix+'Enabled'),fuel=document.getElementById(prefix+'FuelEnabled');if(!hp||!fuel)return;
    for(const [suffix,checked] of [['CardFields',hp.checked],['FuelFields',fuel.checked]]){const f=document.getElementById(prefix+suffix);f.hidden=!checked;f.disabled=!checked;}
    const group=document.getElementById(prefix+'Group');group.disabled=userScope!=='ALL';if(userScope!=='ALL'){group.value=userScope;group.disabled=true;}
}
function fleetCollect(prefix){
    const get=(key)=>document.getElementById(prefix+(key==='hipassUser'?'User':key[0].toUpperCase()+key.slice(1))).value.trim();
    const row={group:get('group'),classification:get('classification'),hipassEnabled:document.getElementById(prefix+'Enabled').checked,fuelEnabled:document.getElementById(prefix+'FuelEnabled').checked};
    for(const key of ['hipassUser','car','returnDate','distributionStatus','issueArea','route','reason','type','company','num','issueDate','expiryDate'])row[key]=get(key);
    if(row.fuelEnabled){const p=prefix==='regHipass'?'regFuel':'editFuel';row.fuelCard={};for(const key of ['paymentType','usageScope','company','num','userType','assignedUser','issueDate','expiryDate','cardAlias'])row.fuelCard[key]=document.getElementById(p+key[0].toUpperCase()+key.slice(1)).value.trim();}
    if(!row.hipassEnabled&&!row.fuelEnabled)throw Error('하이패스 또는 유류대카드를 선택하세요.');return row;
}
function fleetScoped(){return hipassData.filter(x=>userScope==='ALL'||x.group===userScope);}
function fleetStatus(row){
    if(fleetStates.includes(row.distributionStatus))return row.distributionStatus;
    if(row.returnDate)return row.returnDate<=localDate()?'회수완료':'회수예정';
    if(row.reviewStatus==='draft')return '대기중';
    return row.hipassUser?'불출중':'대기중';
}
function fleetReview(row){return row.reviewStatus==='confirmed'?'확인완료':row.reviewStatus==='draft'?'확인대기':'기존자료 · 확인미기록';}
function fleetCardsHTML(row,selection={hipass:true,fuel:true}){const cells=(title,card)=>`<div class="fleet-card-line"><strong>${title}</strong><span>${fleetEscape(card.company)} · ${fleetEscape(card.num)}</span><small>${fleetEscape(card.type||card.paymentType||'')} ${fleetEscape(card.usageScope||'')} · 발급 ${fleetEscape(card.issueDate||'미기록')} / 만료 ${fleetEscape(card.expiryDate||'미기록')}</small>${card.userType?'<small>'+fleetEscape(card.userType)+(card.assignedUser?' · '+fleetEscape(card.assignedUser):'')+(card.cardAlias?' · '+fleetEscape(card.cardAlias):'')+'</small>':''}</div>`;return (selection.hipass&&row.hipassEnabled!==false?cells('하이패스',row):'')+(selection.fuel&&row.fuelEnabled?cells('유류대카드',row.fuelCard):'');}
function fleetDocumentHTML(row){return `<article id="expenseDetailPrintArea" class="fleet-document"><h2>하이패스·유류대카드 등록 정보</h2><p>묶음 ${fleetEscape(row.id)} · ${fleetEscape(fleetReview(row))} · ${fleetEscape(fleetStatus(row))}</p><dl>${['group','classification','hipassUser','car','returnDate','distributionStatus','issueArea','route','reason'].map(k=>'<dt>'+fleetLabels[k]+'</dt><dd>'+fleetEscape(row[k]||'미기록')+'</dd>').join('')}</dl>${fleetCardsHTML(row)}${fleetPhysicalHistoryHTML(row)}</article>`;}
function fleetFind(id,group){return hipassData.find(x=>String(x.id)===String(id)&&x.group===group);}
function fleetRef(row){return {id:row.id,recordGroup:row.group,expectedVersion:row.recordVersion||null};}
function fleetButton(label,fn,cls='btn-secondary'){const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=label;b.onclick=fn;return b;}
function fleetFilterHTML(mode){return `<div class="fleet-filters"><label>소속지점<select id="fleet${mode}Group" onchange="fleetRenderAll()"><option value="">전체 지점</option>${BRANCHES.map(x=>'<option>'+x+'</option>').join('')}</select></label><label>사용 분류<select id="fleet${mode}Class" onchange="fleetRenderAll()"><option value="">전체 분류</option>${fleetClasses.map(x=>'<option>'+x+'</option>').join('')}</select></label><label>사용자·차량·카드번호 검색<input id="fleet${mode}Query" oninput="fleetRenderAll()" maxlength="200"></label><button type="button" class="btn-secondary" onclick="fleetExport('${mode}')">엑셀 다운로드</button></div>`;}
function fleetFiltered(mode,rows){if(mode==='list'){const selected=fleetListSelection24();rows=rows.filter(r=>selected.hipass&&r.hipassEnabled!==false||selected.fuel&&r.fuelEnabled);}const group=document.getElementById('fleet'+mode+'Group')?.value||'',category=document.getElementById('fleet'+mode+'Class')?.value||'',q=(document.getElementById('fleet'+mode+'Query')?.value||'').toLowerCase();return rows.filter(r=>(!group||r.group===group)&&(!category||r.classification===category)&&(!q||JSON.stringify(r).toLowerCase().includes(q)));}
function fleetTable(rows,bodyId,manage=false){
    const body=document.getElementById(bodyId);if(!body)return;body.replaceChildren();
    for(const row of rows){const tr=document.createElement('tr');tr.dataset.fleetId=row.id;tr.dataset.fleetGroup=row.group;
        tr.innerHTML=`<td>${fleetEscape(row.id)}</td><td>${fleetEscape(row.group)}<small>${fleetEscape(row.classification||'미분류')}</small></td><td>${fleetEscape(row.hipassUser||'작성 중')}<small>${fleetEscape(row.car||'차량 미기록')}</small></td><td>${fleetCardsHTML(row,bodyId==='hipassBoxTable'?fleetListSelection24():undefined)}</td><td>${fleetEscape(row.issueArea||'')}<small>${fleetEscape(row.route||'')}</small></td><td>${fleetEscape(row.returnDate||'—')}<small>${fleetEscape(row.reason||'')}</small></td><td><span class="ledger-progress">${fleetEscape(fleetStatus(row))}</span><small>${fleetEscape(fleetReview(row))}${row.draftType==='temporary'?' · 임시저장':''}</small></td><td class="fleet-actions"></td>`;
        const actions=tr.lastElementChild;actions.append(fleetButton('내용 확인',()=>fleetPreview(row.id,row.group)));
        if(hasViewPermission('v_hipass_reg')){
            actions.append(fleetButton(manage?'이어서 작성':'수정',()=>editHiPass(row.id,row.group)));
            if(['회수중','회수예정'].includes(fleetStatus(row)))actions.append(fleetButton('최종 회수',()=>fleetCompleteDialog(row.id,row.group),'btn-primary'));
            actions.append(fleetButton('삭제',()=>deleteHiPass(row.id,row.group)));
        }
        body.append(tr);
    }
    if(!rows.length)body.innerHTML='<tr><td colspan="8" class="ledger-empty">조회된 자료가 없습니다.</td></tr>';
}
function fleetRenderAll(){
    const rows=fleetScoped(),pending=rows.filter(fleetInWorklist),listed=rows.filter(x=>!fleetInWorklist(x));
    fleetTable(fleetFiltered('register',pending).slice().reverse(),'registeredHiPassTable',true);
    fleetTable(fleetFiltered('list',listed).slice().reverse(),'hipassBoxTable');
    const list=document.getElementById('fleetListCount');if(list)list.textContent=`리스트 ${fleetFiltered('list',listed).length}묶음 · 하단 업무대기 ${pending.length}묶음 (임시저장·대기·회수중)`;
    renderFleetStatus();renderFleetHistory();
}
function renderHiPassTable(){
    const mount=document.getElementById('fleetRegisterFields');if(!mount)return;
    if(fleetUI.owner!==currentUser||!mount.children.length){mount.innerHTML=fleetFieldsHTML('regHipass');fleetUI.owner=currentUser;fleetToggleFields('regHipass');}
    fleetToggleFields('regHipass');
    for(const [mode,id] of [['register','fleetRegisterFilters'],['list','fleetListFilters'],['status','fleetStatusFilters'],['history','fleetHistoryFilters']]){
        const el=document.getElementById(id);if(el&&!el.children.length)el.innerHTML=fleetFilterHTML(mode)+(mode==='list'?fleetListCheckboxes24():'');
        const group=document.getElementById('fleet'+mode+'Group');if(group&&userScope!=='ALL'){group.value=userScope;group.disabled=true;}
    }
    fleetRenderAll();
}
function renderHiPassBoxTable(){fleetRenderAll();}
async function handleRegisterHiPass(e){
    e.preventDefault();const mode=e.submitter?.dataset.saveMode||'ready';
    try{const payload={...fleetCollect('regHipass'),mode};const result=await businessOperation('/api/hipass/register',payload);e.target.reset();fleetToggleFields('regHipass');
        if(mode==='temporary'){alert('임시저장했습니다. 하단 업무대기 목록에서 이어서 작성하세요.');return;}
        fleetPreview(result.hipass.id,result.hipass.group);
    }catch(error){alert(error.message);}
}
function fleetPreview(id,group){
    const row=fleetFind(id,group);if(!row)return;fleetUI.preview={...fleetRef(row)};
    document.getElementById('modalTitle').textContent='등록 정보 확인';
    const canIssue=row.reviewStatus==='draft'&&row.draftType!=='temporary'&&fleetStatus(row)==='불출중';
    const help=row.draftType==='temporary'?'임시저장 자료입니다. 이어서 작성한 뒤 입력을 완료하세요.':fleetStatus(row)==='대기중'?'대기중 자료는 이 화면 하단에 보관합니다. 불출중으로 변경한 뒤 불출을 확정하세요.':['회수중','회수예정'].includes(fleetStatus(row))?'회수중 자료입니다. 실제 회수일을 확인한 뒤 최종 회수하세요.':canIssue?'내용을 확인한 뒤 불출을 확정하면 하이패스 리스트로 이동합니다.':'저장된 등록 정보입니다.';
    document.getElementById('modalBody').innerHTML='<p class="fleet-workflow-note">'+help+'</p>'+fleetDocumentHTML(row)+(canIssue?fleetCheckHTML(row,'fleetIssueCheck'):'');
    const footer=document.getElementById('modalFooter');footer.replaceChildren(fleetButton('닫기',closeModal),fleetButton('인쇄 / PDF',()=>printExpenseDetailReport('하이패스_등록정보')));
    if(hasViewPermission('v_hipass_reg')){
        if(canIssue)footer.append(fleetButton('정보 확인 · 불출 확정',fleetConfirm,'btn-primary'));
        else if(fleetInWorklist(row))footer.append(fleetButton('이어서 작성',()=>editHiPass(row.id,row.group),'btn-primary'));
        if(['회수중','회수예정'].includes(fleetStatus(row)))footer.append(fleetButton('최종 회수',()=>fleetCompleteDialog(row.id,row.group),'btn-primary'));
    }
    document.getElementById('commonModal').style.display='flex';
}
async function fleetConfirm(){try{await businessOperation('/api/hipass/confirm',{...fleetUI.preview,physicalChecks:fleetReadChecks('fleetIssueCheck')});closeModal();switchView('v_hipass_box',document.getElementById('nav_v_hipass_box'));alert('불출을 확정하여 하이패스 리스트에 반영했습니다.');}catch(error){alert(error.message);}}
function editHiPass(id,group){
    const row=fleetFind(id,group);if(!row||!hasViewPermission('v_hipass_reg'))return;fleetUI.editing={...fleetRef(row)};
    const temporary=!fleetWasIssued(row)&&['대기중','불출중'].includes(fleetStatus(row));
    document.getElementById('modalTitle').textContent='하이패스·유류대카드 입력·수정';
    document.getElementById('modalBody').innerHTML=`<form id="fleetEditForm" onsubmit="fleetSaveEdit(event)">${fleetFieldsHTML('editHipass',row)}<section class="fleet-section"><h3>저장 확인</h3><div class="fleet-grid">${fleetInput('fleetChangeReason','수정 사유','','text',true)}${fleetInput('fleetPassword','현재 로그인 비밀번호','','password',true)}</div><p class="ledger-help">대기중은 하단 보관, 불출중은 확인 후 리스트 반영, 회수중은 하단 최종 회수 대기입니다. 변경 전·후 기록은 보존합니다.</p></section><button id="fleetTempEditSubmit" type="submit" data-save-mode="temporary" formnovalidate hidden>임시저장</button></form>`;
    document.getElementById('fleetPassword').autocomplete='current-password';fleetToggleFields('editHipass');
    const footer=document.getElementById('modalFooter');footer.replaceChildren(fleetButton('취소',closeModal));
    if(temporary)footer.append(fleetButton('임시저장',()=>document.getElementById('fleetEditForm').requestSubmit(document.getElementById('fleetTempEditSubmit'))));
    footer.append(fleetButton('변경 저장',()=>document.getElementById('fleetEditForm').requestSubmit(),'btn-primary'));document.getElementById('commonModal').style.display='flex';
}
async function fleetSaveEdit(e){
    e.preventDefault();const mode=e.submitter?.dataset.saveMode||'ready';
    try{
        const payload={...fleetCollect('editHipass'),...fleetUI.editing,mode,changeReason:document.getElementById('fleetChangeReason').value||(mode==='temporary'?'임시 작성 보완':''),password:document.getElementById('fleetPassword').value};
        const result=await businessOperation('/api/hipass/update',payload);document.getElementById('fleetPassword').value='';
        if(mode==='temporary'||['회수중','회수예정'].includes(fleetStatus(result.hipass))){closeModal();switchView('v_hipass_reg',document.getElementById('nav_v_hipass_reg'));alert(mode==='temporary'?'임시저장했습니다. 하단에서 이어서 작성하세요.':'회수중으로 저장했습니다. 하단 목록에서 최종 회수하세요.');}
        else if(fleetStatus(result.hipass)==='회수완료'){closeModal();switchView('v_hipass_box',document.getElementById('nav_v_hipass_box'));alert('회수완료로 저장했습니다.');}
        else fleetPreview(result.hipass.id,result.hipass.group);
    }catch(error){const password=document.getElementById('fleetPassword');if(password)password.value='';alert(error.message);}
}
function deleteHiPass(id,group){const row=fleetFind(id,group);if(!row||!hasViewPermission('v_hipass_reg'))return;const ref=fleetRef(row);document.getElementById('modalTitle').textContent='하이패스 묶음 삭제';document.getElementById('modalBody').innerHTML='<p>이 묶음의 하이패스·유류대카드를 함께 삭제합니다. 변경 이력은 보존됩니다.</p>'+fleetInput('fleetDeleteReason','삭제 사유','','text',true)+fleetInput('fleetDeletePassword','현재 로그인 비밀번호','','password',true);document.getElementById('fleetDeletePassword').autocomplete='current-password';document.getElementById('modalFooter').replaceChildren(fleetButton('취소',closeModal),fleetButton('삭제',async()=>{try{await businessOperation('/api/hipass/delete',{...ref,changeReason:document.getElementById('fleetDeleteReason').value,password:document.getElementById('fleetDeletePassword').value});closeModal();}catch(error){document.getElementById('fleetDeletePassword').value='';alert(error.message);}},'btn-danger'));document.getElementById('commonModal').style.display='flex';}
function renderFleetStatus(){
    const el=document.getElementById('fleetStatusContent');if(!el)return;
    const rows=fleetFiltered('status',fleetScoped());
    const focused=document.activeElement?.dataset.fleetBranch;
    el.innerHTML='<div class="fleet-status-metrics"></div><p class="ledger-help fleet-status-help">지표를 누르면 상세 목록이 열립니다. 등록 묶음은 단독·동시 등록을 각각 1건으로 셉니다. 카드 수량은 번호가 입력된 전체 등록 자료 기준입니다.</p><div class="branch-tree-container fleet-branches"></div>';
    const metrics=el.querySelector('.fleet-status-metrics');for(const [key,label] of fleetMetricCatalog){const button=fleetButton('',()=>fleetOpenMetric(key));button.className='ledger-metric fleet-metric';button.dataset.fleetMetric=key;button.setAttribute('aria-label',label+' 상세내역');button.innerHTML='<span>'+label+'</span><strong>'+fleetMetricRows(rows,key).length+'</strong>';metrics.append(button);}
    const tree=el.querySelector('.fleet-branches');
    for(const group of [...new Set(rows.map(x=>x.group))]){
        const items=rows.filter(x=>x.group===group),open=fleetUI.openBranches.has(group),node=document.createElement('section');node.className='branch-node';
        const button=fleetButton('',()=>{});button.className='branch-header fleet-branch-toggle';button.dataset.fleetBranch=group;button.setAttribute('aria-expanded',String(open));
        const label=document.createElement('span');label.textContent=group+' · '+items.length+'묶음';const arrow=document.createElement('span');arrow.textContent=open?'▲ 접기':'▼ 펼치기';button.append(label,arrow);
        const content=document.createElement('div');content.className='branch-content'+(open?' open':'');content.id='fleetBranch'+tree.children.length;button.setAttribute('aria-controls',content.id);
        const grid=document.createElement('div');grid.className='card-grid fleet-status-cards';
        for(const row of items){
            const card=document.createElement('div');card.className='card-item fleet-status-card';
            card.innerHTML='<div class="fleet-card-top"><span class="card-tag">'+fleetEscape(row.classification||'미분류')+'</span><span class="ledger-progress '+(fleetStatus(row)==='회수완료'?'complete':'pending')+'">'+fleetEscape(fleetStatus(row))+'</span></div><h3>'+fleetEscape(row.hipassUser||'사용자 미기록')+' <small>'+fleetEscape(row.car||'차량 미기록')+'</small></h3>'+fleetCardsHTML(row)+(fleetHasExpired(row)?'<p class="ledger-help">만료된 카드 포함 · 만료일을 확인하세요.</p>':'')+'<p class="ledger-help">묶음 '+fleetEscape(row.id)+' · '+fleetEscape(fleetReview(row))+'</p>';
            card.append(fleetButton('상세 보기',()=>fleetPreview(row.id,row.group)));grid.append(card);
        }
        content.append(grid);node.append(button,content);tree.append(node);
        button.onclick=()=>{const value=button.getAttribute('aria-expanded')!=='true';button.setAttribute('aria-expanded',String(value));content.classList.toggle('open',value);arrow.textContent=value?'▲ 접기':'▼ 펼치기';value?fleetUI.openBranches.add(group):fleetUI.openBranches.delete(group);};
    }
    if(!rows.length)tree.innerHTML='<p class="ledger-empty">조회 조건에 맞는 자료가 없습니다.</p>';
    if(focused)[...tree.querySelectorAll('[data-fleet-branch]')].find(x=>x.dataset.fleetBranch===focused)?.focus({preventScroll:true});
}
function renderFleetHistory(){
    const body=document.getElementById('fleetHistoryTable');if(!body)return;body.replaceChildren();
    const rows=YbyLedger.newest(fleetFiltered('history',hipassBoxLogs.filter(x=>userScope==='ALL'||x.group===userScope)));
    for(const event of rows){
        const snap=event.after||event.before||event,context=fleetHistoryContext(event),tr=document.createElement('tr');tr.dataset.fleetEvent=event.id;tr.dataset.latest=String(context.latest);tr.dataset.progress=context.latest?(context.status==='대기중'?'waiting':context.status==='불출중'?'issued':'attention'):'complete';
        tr.innerHTML=`<td>${fleetEscape(context.sequence)}</td><td>${fleetEscape(event.action)}<small>${fleetEscape(event.group)}</small></td><td>${fleetEscape(snap.hipassUser||'미기록')}<small>${fleetEscape(snap.car||'차량 미기록')}</small></td><td>${fleetNumberHTML(snap)}</td><td>${fleetEscape(formatServerTime(context.created))}<small>변경 ${fleetEscape(formatServerTime(event.time))}</small></td><td><span class="ledger-progress ${context.latest?(context.status==='대기중'?'fleet-waiting':context.status==='불출중'?'fleet-issued':'pending'):'complete'}">${fleetEscape(context.status)}</span><small>${context.latest?'최종 이력 · 현재 상태':'과거 작업 완료'}</small></td><td>${fleetEscape(event.changeReason||event.reason||'기존 이력')}<small>처리자 ${fleetEscape(event.handler)}</small></td><td></td>`;
        tr.lastElementChild.append(fleetButton('변경 문서 열람',()=>fleetHistoryDocument(event)));body.append(tr);
    }
    if(!rows.length)body.innerHTML='<tr><td colspan="8" class="ledger-empty">변경 이력이 없습니다.</td></tr>';
}
function fleetHistoryDocument(event){
    const context=fleetHistoryContext(event),comparison=fleetComparisonEvent(event),snap=comparison.after||comparison.before||comparison,hasSnapshots='before' in comparison;
    const fields=[['카드 구성',r=>[r.hipassEnabled!==false?'하이패스':'',r.fuelEnabled?'유류대카드':''].filter(Boolean).join(' + ')],...['group','classification','hipassUser','car','distributionStatus','returnDate','issueArea','route','reason'].map(k=>[fleetLabels[k],r=>r[k]]),...['type','company','num','issueDate','expiryDate'].map(k=>['하이패스 · '+fleetLabels[k],r=>r.hipassEnabled!==false?r[k]:'해당 없음']),...['company','num','paymentType','usageScope','userType','assignedUser','issueDate','expiryDate','cardAlias'].map(k=>['유류대 · '+fleetLabels[k],r=>r.fuelEnabled?r.fuelCard?.[k]:'해당 없음']),['입력 확인',r=>fleetReview(r)],['확인자',r=>r.confirmedBy],['확인일시',r=>r.confirmedAt?formatServerTime(r.confirmedAt):'']];
    const value=(row,read)=>row?(read(row)||'미기록'):'—';
    const rows=fields.map(([label,read])=>{const before=value(comparison.before,read),after=value(comparison.after,read),changed=before!==after;return hasSnapshots?'<tr'+(changed?' class="fleet-changed"':'')+'><th scope="row">'+label+'</th><td>'+fleetEscape(before)+'</td><td>'+fleetEscape(after)+(changed?'<span class="fleet-change-mark">변경</span>':'')+'</td></tr>':'<tr><th scope="row">'+label+'</th><td>'+fleetEscape(value(snap,read))+'</td></tr>';}).join('');
    document.getElementById('modalTitle').textContent='하이패스 변경 이력 문서';
    document.getElementById('modalBody').innerHTML=`<article id="expenseDetailPrintArea" class="fleet-change-document"><h2>${fleetEscape(event.action)} · 변경 문서</h2><table class="fleet-document-meta"><tbody><tr><th>문서번호</th><td colspan="3">${fleetEscape(event.id)}</td></tr><tr><th>소속 / 묶음</th><td>${fleetEscape(event.group)} / ${fleetEscape(event.recordId||context.current?.id||'미기록')}</td><th>처리자</th><td>${fleetEscape(event.handler)}</td></tr><tr><th>최초 등록</th><td>${fleetEscape(formatServerTime(context.created))}</td><th>변경 일시</th><td>${fleetEscape(formatServerTime(event.time))}</td></tr><tr><th>${context.latest?'현재 상태':'작업 상태'}</th><td colspan="3">${fleetEscape(context.status)} <small>(${context.latest?'최종 이력 · 현재 자료 기준':'과거 작업 완료'})</small></td></tr><tr><th>변경 사유</th><td colspan="3">${fleetEscape(event.changeReason||event.reason||'미기록')}</td></tr></tbody></table><p class="ledger-help">${comparison!==event?'수정 후 확인 이력입니다. 연결된 정보수정 문서의 변경 전·후 입력값을 표시합니다. 수정 사유: '+fleetEscape(comparison.changeReason||'미기록')+' · 연결 문서 '+fleetEscape(comparison.id):hasSnapshots?'아래 표는 처리 당시의 기록입니다. 바뀐 입력값의 변경 전·후 양쪽을 음영으로 구분합니다.':'이전 버전 이력은 당시 보관된 정보만 표시합니다. 변경 전 정보는 복원하지 않습니다.'}</p><table class="fleet-comparison"><thead><tr><th>항목</th>${hasSnapshots?'<th>변경 전</th><th>변경 후</th>':'<th>보관된 정보</th>'}</tr></thead><tbody>${rows}</tbody></table></article>`;
    document.getElementById('modalFooter').replaceChildren(fleetButton('닫기',closeModal),fleetButton('인쇄 / PDF',()=>printExpenseDetailReport('하이패스_변경이력')));document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}
async function fleetExport(mode,metric=null){const params=new URLSearchParams({mode,group:document.getElementById('fleet'+mode+'Group')?.value||'',classification:document.getElementById('fleet'+mode+'Class')?.value||'',q:document.getElementById('fleet'+mode+'Query')?.value||''});if(metric)params.set('metric',metric);if(mode==='list'){const choice=fleetListSelection24();params.set('hipass',choice.hipass?'1':'0');params.set('fuel',choice.fuel?'1':'0');}try{const response=await fetch('/api/hipass/export?'+params);if(!response.ok){const error=await response.json();throw Error(error.message||'내보내기 실패');}const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='YBY_하이패스_'+mode+'.xlsx';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(error){alert(error.message);}}

function fleetNumberHTML(row){return (row.hipassEnabled!==false?'<span>하이패스 '+fleetEscape(row.num||'미기록')+'</span>':'')+(row.fuelEnabled?'<small>유류대 '+fleetEscape(row.fuelCard?.num||'미기록')+'</small>':'');}
function fleetNormalizedNumbers(row){return [row.hipassEnabled!==false?row.num:null,row.fuelEnabled?row.fuelCard?.num:null].filter(Boolean).map(x=>String(x).replace(/[\s-]/g,'').toLowerCase());}
function fleetHistoryContext(event){
    const snap=event.after||event.before||event,rid=event.recordId,known=rid!==undefined&&rid!==null;
    const numbers=fleetNormalizedNumbers(snap),records=fleetScoped(),all=hipassBoxLogs.filter(e=>userScope==='ALL'||e.group===userScope);
    const matches=records.filter(r=>r.group===event.group&&(known?String(r.id)===String(rid):fleetNormalizedNumbers(r).some(n=>numbers.includes(n))));
    const current=matches.length===1?matches[0]:null;
    const related=all.filter(e=>e.group===event.group&&(known?String(e.recordId)===String(rid):numbers.length?fleetNormalizedNumbers(e.after||e.before||e).some(n=>numbers.includes(n)):e.id===event.id));
    const original=related.find(e=>e.action==='최초등록'||e.action==='임시저장');
    const created=current?.createdAt||snap.createdAt||current?.date||snap.date||original?.time||'미기록';
    const currentStatus=current?fleetStatus(current):related.some(e=>e.action==='카드삭제')?'삭제됨':related.some(e=>e.action==='정보수정'&&e.before&&e.after===null)?'이관됨':known?'현재자료 없음':'확인불가';
    const latest=related.length>0&&related[related.length-1].id===event.id;
    const messages={'최초등록':'등록 완료','임시저장':'임시저장 완료','정보수정':'변경 완료','정보확인':'확인 완료','회수완료':'회수처리 완료','카드삭제':'삭제처리 완료'};
    return {created,status:latest?currentStatus:messages[event.action]||'처리 완료',current,latest,sequence:event.sequence||all.findIndex(e=>e.id===event.id)+1};
}
function fleetHasExpired(row){return [row.hipassEnabled!==false?row.expiryDate:null,row.fuelEnabled?row.fuelCard?.expiryDate:null].filter(Boolean).some(x=>x<localDate());}

const fleetMetricCatalog=[['issued','불출중'],['registered','등록 묶음'],['review','확인대기'],['recovery','회수중·완료'],['hipass','하이패스 카드'],['fuel','유류대카드']];
function fleetMetricRows(rows,key){return rows.filter(r=>({issued:()=>r.reviewStatus!=='draft'&&fleetStatus(r)==='불출중',registered:()=>true,review:()=>r.reviewStatus==='draft',recovery:()=>['회수중','회수예정','회수완료'].includes(fleetStatus(r)),hipass:()=>r.hipassEnabled!==false&&!!r.num?.trim(),fuel:()=>r.fuelEnabled&&!!r.fuelCard?.num?.trim()})[key]?.());}
function fleetInWorklist(row){return row.reviewStatus==='draft'||['대기중','회수중','회수예정'].includes(fleetStatus(row));}
function fleetWasIssued(row){return row.reviewStatus!=='draft'&&['불출중','회수중','회수완료','회수예정'].includes(fleetStatus(row))||hipassBoxLogs.some(e=>String(e.recordId)===String(row.id)&&e.group===row.group&&e.after?.reviewStatus==='confirmed'&&fleetStatus(e.after)==='불출중');}
function fleetAllowedStates(row){const state=fleetStatus(row);if(!row.id||!fleetWasIssued(row))return ['대기중','불출중'];return ({불출중:['불출중','회수중','회수완료'],회수중:['회수중','회수완료'],회수예정:['회수중','회수완료'],회수완료:['회수완료','대기중','불출중']})[state]||['대기중','불출중'];}
function fleetComparisonEvent(event){
    if(event.action!=='정보확인')return event;
    const version=event.before?.recordVersion;
    const source=hipassBoxLogs.find(e=>e.group===event.group&&String(e.recordId)===String(event.recordId)&&e.action==='정보수정'&&((event.documentChangeId&&e.id===event.documentChangeId)||(version&&e.after?.recordVersion===version)));
    return source||event;
}
function fleetOpenMetric(key){
    const base=fleetFiltered('status',fleetScoped()),rows=fleetMetricRows(base,key),label=fleetMetricCatalog.find(x=>x[0]===key)?.[1];if(!label)return;
    const both=rows.filter(r=>r.hipassEnabled!==false&&r.fuelEnabled).length,hp=rows.filter(r=>r.hipassEnabled!==false&&!r.fuelEnabled).length,fuel=rows.filter(r=>r.hipassEnabled===false&&r.fuelEnabled).length;
    const breakdown=key==='registered'?`하이패스 단독 ${hp} + 유류대 단독 ${fuel} + 두 카드 동시 등록 ${both} = 전체 ${rows.length}묶음. 같은 이름도 별도 등록이면 각각 1묶음입니다.`:'현재 지점·분류·검색 조건을 적용한 상세 목록입니다.';
    document.getElementById('modalTitle').textContent=label+' 상세내역';
    document.getElementById('modalBody').innerHTML=`<article id="expenseDetailPrintArea" class="fleet-change-document"><h2>${label} · ${rows.length}${['hipass','fuel'].includes(key)?'개':'묶음'}</h2><p class="ledger-help">${breakdown}</p><p class="ledger-help">조회 시각 ${fleetEscape(localDateTime(true))} · 임시저장도 등록 묶음에 포함합니다. 카드 수는 번호가 입력된 자료만 포함합니다.</p><div class="fleet-table-wrap"><table class="fleet-metric-table"><thead><tr><th>번호</th><th>묶음·소속</th><th>사용자·차량</th><th>카드번호</th><th>배부 상태</th><th>입력 확인</th></tr></thead><tbody>${rows.map((row,i)=>'<tr><td>'+(i+1)+'</td><td>'+fleetEscape(row.id)+' · '+fleetEscape(row.group)+'<small>'+fleetEscape(row.classification||'미분류')+'</small></td><td>'+fleetEscape(row.hipassUser||'작성 중')+'<small>'+fleetEscape(row.car||'차량 미기록')+'</small></td><td>'+fleetNumberHTML(key==='hipass'?{...row,fuelEnabled:false}:key==='fuel'?{...row,hipassEnabled:false}:row)+'</td><td>'+fleetEscape(fleetStatus(row))+'</td><td>'+fleetEscape(fleetReview(row))+(row.draftType==='temporary'?' · 임시저장':'')+'</td></tr>').join('')||'<tr><td colspan="6">해당 자료가 없습니다.</td></tr>'}</tbody></table></div></article>`;
    document.getElementById('modalFooter').replaceChildren(fleetButton('닫기',closeModal),fleetButton('엑셀 다운로드',()=>fleetExport('status',key)),fleetButton('인쇄 / PDF',()=>printExpenseDetailReport('하이패스_'+label)));
    document.getElementById('commonModal').style.display='flex';document.getElementById('modalBody').scrollTop=0;
}
function fleetCompleteDialog(id,group){
    const row=fleetFind(id,group);if(!row||!hasViewPermission('v_hipass_reg'))return;const ref=fleetRef(row);
    document.getElementById('modalTitle').textContent='최종 회수 확인';document.getElementById('modalBody').innerHTML='<p class="fleet-workflow-note">하이패스·유류대 묶음 전체의 실제 회수 여부를 확인하세요.</p>'+fleetCardsHTML(row)+'<form id="fleetCompleteForm">'+fleetInput('fleetReturnDate','실제 회수일',localDate(),'date',true)+fleetInput('fleetReturnReason','회수 확인 사유','','text',true)+fleetCheckHTML(row,'fleetReturnCheck')+fleetInput('fleetReturnPassword','현재 로그인 비밀번호','','password',true)+'</form>';
    document.getElementById('fleetReturnDate').max=localDate();document.getElementById('fleetReturnPassword').autocomplete='current-password';
    document.getElementById('fleetCompleteForm').onsubmit=async e=>{e.preventDefault();try{await businessOperation('/api/hipass/complete-return',{...ref,physicalChecks:fleetReadChecks('fleetReturnCheck'),returnDate:document.getElementById('fleetReturnDate').value,changeReason:document.getElementById('fleetReturnReason').value,password:document.getElementById('fleetReturnPassword').value});closeModal();switchView('v_hipass_box',document.getElementById('nav_v_hipass_box'));alert('최종 회수했습니다. 회수완료 자료는 하이패스 리스트에서 확인하세요.');}catch(error){document.getElementById('fleetReturnPassword').value='';alert(error.message);}};
    document.getElementById('modalFooter').replaceChildren(fleetButton('취소',closeModal),fleetButton('회수완료 처리',()=>document.getElementById('fleetCompleteForm').requestSubmit(),'btn-primary'));document.getElementById('commonModal').style.display='flex';
}

function fleetCheckHTML(row,prefix){return '<fieldset class="s-card"><legend>실물 확인</legend>'+sCheckbox(prefix+'holder','실사용자·차량/배부 대상을 확인했습니다.')+(row.hipassEnabled!==false?sCheckbox(prefix+'hipass','하이패스 실물 카드와 번호를 확인했습니다.'):'')+(row.fuelEnabled?sCheckbox(prefix+'fuel','유류대 실물 카드와 번호를 확인했습니다.'):'')+'</fieldset>';}
function fleetReadChecks(prefix){const checks={};for(const key of ['holder','hipass','fuel']){const el=document.getElementById(prefix+key);if(el)checks[key]=el.checked;}return checks;}

function fleetPhysicalHistoryHTML(row){return ['issuedChecks','returnChecks'].filter(k=>row[k]).map(k=>{const value=row[k];return '<section class="s-card"><h3>'+(k==='issuedChecks'?'불출':'회수')+' 실물 확인 기록</h3><p>'+fleetEscape(value.confirmedBy)+' · '+fleetEscape(formatServerTime(value.confirmedAt))+'</p><p>'+Object.entries(value.checks||{}).filter(([,v])=>v===true).map(([key])=>({holder:'실사용자·배부 대상',hipass:'하이패스 실물',fuel:'유류대 실물'})[key]||key).map(fleetEscape).join(' · ')+'</p></section>';}).join('');}

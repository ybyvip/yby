/* YBY V4.1.21 core screen module; global compatibility preserved. */
function updateHeaderClock() {
    const el=document.getElementById('headerClock');
    if(el) el.textContent='🕒 ' + new Date().toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
}
updateHeaderClock();
setInterval(updateHeaderClock,1000);

const initialAppMarkup=document.getElementById("appContainer").innerHTML;
let currentUser = null;
let userScope = null;
let statePollInFlight=false,statePollEpoch=0,lastHiddenPoll=0;
let serverStateRevision=null, liveSyncTimer=null, onlineUsers=[], stateSavePending=0, saveQueue=Promise.resolve(), serverSnapshot={};
let inactiveAccountRows=[];
let adminPasswordRows=Object.create(null), accountHistoryRows=[], accountHistoryLoaded=false, adminDirectorySerial=0;

const allViewIds = ['v_dashboard', 'v_card_status', 'v_card_rent', 'v_card_history', 'v_expense', 'v_external_match', 'v_expense_history', 'v_card_reg', 'v_hipass_status', 'v_hipass_history', 'v_hipass_reg', 'v_hipass_box', 'v_stats', 'v_complaint', 'v_admin', 'v_access_status', 'v_report_write', 'v_report_box','v_business_review','v_backup_ops','v_company_policy'];

const defaultAccounts = {
    "admin": { scope: "ALL", permissions: [...allViewIds], lastLogin: "2026-09-19 09:00:00", ip: "192.168.1.10 (Local)" },
    "본사 담당자 A": { scope: "본사", permissions: ['v_dashboard', 'v_card_status', 'v_card_rent', 'v_card_history', 'v_expense','v_expense_history', 'v_stats', 'v_complaint', 'v_report_write', 'v_report_box', 'v_hipass_reg', 'v_hipass_box', 'v_access_status'], lastLogin: "2026-09-19 09:15:22", ip: "192.168.1.15" },
    "서울 담당자": { scope: "서울", permissions: ['v_dashboard', 'v_card_status', 'v_card_rent', 'v_expense','v_expense_history', 'v_stats', 'v_complaint', 'v_report_write', 'v_report_box', 'v_hipass_reg', 'v_hipass_box', 'v_access_status'], lastLogin: "2026-09-19 08:50:10", ip: "192.168.2.11" },
    "인천 담당자": { scope: "인천", permissions: ['v_dashboard', 'v_card_status', 'v_card_rent', 'v_expense','v_expense_history', 'v_stats', 'v_complaint', 'v_report_write', 'v_report_box', 'v_hipass_reg', 'v_hipass_box'], lastLogin: "2026-09-17 14:22:15", ip: "192.168.3.5" },
    "정봉 담당자": { scope: "정봉", permissions: ['v_dashboard', 'v_card_status', 'v_card_rent', 'v_expense','v_expense_history', 'v_stats', 'v_report_write', 'v_report_box', 'v_hipass_reg', 'v_hipass_box'], lastLogin: "2026-09-10 11:05:00", ip: "192.168.4.8" },
    "임원실 담당자": { scope: "임원실", permissions: ['v_dashboard', 'v_card_status', 'v_card_history', 'v_expense','v_expense_history', 'v_stats', 'v_complaint', 'v_report_write', 'v_report_box', 'v_hipass_reg', 'v_hipass_box'], lastLogin: "2026-09-19 09:25:40", ip: "192.168.5.2" }
};

const defaultCards = [
    { id: 1, group: "본사", company: "신한카드", num: "1234-5678-9012-3456", status: "available", dept: "", user: "", purpose: "", rentDate: "", dueDate: "" },
    { id: 2, group: "본사", company: "국민카드", num: "9876-5432-1098-7654", status: "rented", dept: "재무팀", user: "김철수", purpose: "[출장, 결재] 연말 정산 출장 지원", rentDate: "2026-08-01", dueDate: "2026-09-01" },
    { id: 3, group: "서울", company: "우리카드", num: "1111-2222-3333-4444", status: "available", dept: "", user: "", purpose: "", rentDate: "", dueDate: "" },
    { id: 4, group: "인천", company: "하나카드", num: "5555-6666-7777-8888", status: "rented", dept: "물류팀", user: "박영희", purpose: "[업협, 지원] 인천항 물류센터 현장 점검", rentDate: "2026-08-10", dueDate: "2026-08-30" },
    { id: 5, group: "정봉", company: "현대카드", num: "4321-8765-4321-8765", status: "available", dept: "", user: "", purpose: "", rentDate: "", dueDate: "" },
    { id: 6, group: "임원실", company: "삼성카드", num: "0000-1111-2222-3333", status: "rented", dept: "비서실", user: "대표이사", purpose: "[접대, 결재] 주요 투자사 대표 오찬 간담회", rentDate: "2026-01-01", dueDate: "2026-12-31" }
];

const defaultHistory = [
    { id: 1, time: "2026-08-01 09:30", type: "불출", group: "본사", cardNum: "9876-5432-1098-7654", dept: "재무팀", user: "김철수", purpose: "[출장, 결재] 연말 정산 출장 지원", dueDate: "2026-09-01", handler: "본사 담당자 A" }
];

const defaultHipass = [
    { id: 101, type: "선불형", group: "본사", company: "한국도로공사", num: "HP-1000-1234", hipassUser: "김철수", car: "12가 3456", issueDate: "2026-01-10", returnDate: "", reason: "본사 출퇴근용 차량 지급", date: "2026-01-10" }
];

const defaultHipassBoxLogs = [
    { id: 1, time: "2026-01-10 09:00", action: "최초등록", group: "본사", type: "선불형", num: "HP-1000-1234", company: "한국도로공사", hipassUser: "김철수", car: "12가 3456", issueDate: "2026-01-10", returnDate: "", reason: "본사 출퇴근용 차량 지급", handler: "admin" }
];

const defaultExpense = [
    { id: 1, date: "2026-08-05", cardNum: "9876-5432-1098-7654", group: "본사", dept: "재무팀", user: "김철수", merchant: "OO주유소", purpose: "출장 유류비", amount: 50000, status: "승인완료" },
    { id: 2, date: "2026-08-12", cardNum: "5555-6666-7777-8888", group: "인천", dept: "물류팀", user: "박영희", merchant: "XX식당", purpose: "업무협의 간담회", amount: 85000, status: "승인대기" },
    { id: 3, date: "2026-07-10", cardNum: "9876-5432-1098-7654", group: "본사", dept: "재무팀", user: "김철수", merchant: "과거주유소", purpose: "지난달 출장", amount: 45000, status: "승인완료" }
];

const defaultComplaint = [
    { id: 1, category: "시설불편", group: "본사", title: "본사 지하 주차장 하이패스 인식 불량 건", author: "김철수", phone: "010-1234-5678", content: "지하 2층 진입 시 하이패스 단말기가 자주 먹통이 됩니다.", date: "2026-08-20 10:30", status: "처리중", file: null }
];

const defaultReports = [
    { id: 'REP-2026-001', date: '2026-09-01 10:30', type: '지출품의', title: '8월 하이패스 충전 및 카드 정산 건', author: '서울 담당자', line: '본사담당자 → 최고관리자', status: 'pending', content: '8월 기간 내 사용된 하이패스 및 법인카드 지출 내역 정산 승인 요청의 건.' }
];

// 새로운 기능 관련 초기 데이터 (공지사항 및 사용자별 바로가기)
const defaultNotices = [
    { id: 1, text: "[공지] 월말 법인카드 사용 정산 마감일 준수 안내 (매월 말일 18:00까지)" },
    { id: 2, text: "[안내] 하이패스 카드 불출 및 회수 내역 수시 업데이트 필수" },
    { id: 3, text: "[팁] 화면의 아무 곳이나 우클릭하시면 해당 위치에 구역별 메모를 자유롭게 남기실 수 있습니다." }
];

// 기본 빠른 바로가기 메뉴 후보군
const availableShortcuts = [
    {id:'v_business_review',label:'업무 점검 및 대사',class:'btn-primary'},
    {id:'v_backup_ops',label:'백업·복구 관리',class:'btn-primary'},
    {id:'v_company_policy',label:'회사 정책·지점 관리',class:'btn-primary'},
    {id: 'v_dashboard', label: '종합 현황 대시보드', class: 'btn-primary'},
    {id: 'v_card_status', label: '지역별 배부현황 및 대여현황', class: 'btn-primary'},
    {id: 'v_card_rent', label: '불출 및 반납 관리', class: 'btn-primary'},
    {id: 'v_card_history', label: '불출/반납 이력 대장', class: 'btn-primary'},
    {id: 'v_expense', label: '사용 정산 및 결재', class: 'btn-primary'},
    {id: 'v_external_match', label: '외부자료 매칭', class: 'btn-primary'},
    {id: 'v_expense_history', label: '사용정산 이력대장', class: 'btn-primary'},
    {id: 'v_card_reg', label: '법인카드 등록/수정/삭제', class: 'btn-primary'},
    {id: 'v_hipass_status', label: '하이패스 지역별 배부·사용현황', class: 'btn-primary'},
    {id: 'v_hipass_reg', label: '하이패스 관리', class: 'btn-primary'},
    {id: 'v_hipass_box', label: '하이패스 리스트', class: 'btn-primary'},
    {id: 'v_hipass_history', label: '하이패스 등록·변경 이력', class: 'btn-primary'},
    {id: 'v_stats', label: '통계 및 보고서', class: 'btn-primary'},
    {id: 'v_complaint', label: '민원 및 고충 게시판', class: 'btn-primary'},
    {id: 'v_admin', label: '권한 & 비밀번호 관리', class: 'btn-primary'},
    {id: 'v_access_status', label: '시스템 접속인원 현황', class: 'btn-primary'},
    {id: 'v_report_write', label: '보고서 작성 및 기안', class: 'btn-primary'},
    {id: 'v_report_box', label: '내부 보고서함', class: 'btn-primary'}
];

// ===== V2 안정화 공통 유틸리티 =====
const STORAGE_VERSION = 3;
const BRANCHES = ["본사", "서울", "인천", "정봉", "임원실","광주"];

function clearBusinessCache() {
    try { for(const key of Object.keys(localStorage)) if(key.startsWith('sys_')) localStorage.removeItem(key); } catch(_) {}
    try { sessionStorage.clear(); } catch(_) {}
}
clearBusinessCache();
function safeParse(key, fallback) { return fallback; }

function localDateTime(withSeconds=false){const parts=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date()).replace('T',' ');return withSeconds?parts:parts.slice(0,16);}
function localDate() { return localDateTime().slice(0,10); }
function nextNumericId(list, field="id", start=1) {
    const nums = list.map(x => Number(x?.[field])).filter(Number.isFinite);
    return nums.length ? Math.max(...nums) + 1 : start;
}
function jsArg(value){return escapeHtml(JSON.stringify(String(value??'')));}
function formatServerTime(value){if(!value)return '-';if(!/(Z|[+-]\d{2}:\d{2})$/.test(String(value)))return String(value);const date=new Date(value);return Number.isNaN(date.getTime())?String(value):new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',dateStyle:'short',timeStyle:'medium'}).format(date);}
function maskCardNumber(value){const digits=String(value||'').replace(/[^0-9]/g,'');return digits.length>=8?'••••-'+digits.slice(-4):String(value||'');}
function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
async function migrateAccountPasswords() {
    for(const account of Object.values(accountsData)){delete account.pw;delete account.passwordHash;}
}
function canManageBranch(group) { return userScope === "ALL" || group === userScope; }
function audit(message) {
    auditLogs.unshift(`[${localDateTime(true)}] ${message}`);
    if (auditLogs.length > 1000) auditLogs.length=1000;
}

// 로컬스토리지 연동 데이터 로드
let customMemos = safeParse('sys_memos', {});
let noticeData = safeParse('sys_notices', defaultNotices);
let userShortcuts = safeParse('sys_shortcuts', {}); // { username: [id1, id2, ...] }
let accountsData = safeParse('sys_accounts', defaultAccounts);
let cardsData = safeParse('sys_cards', defaultCards);
let cardHistoryData = safeParse('sys_history', defaultHistory);
let hipassData = safeParse('sys_hipass', defaultHipass);
let hipassBoxLogs = safeParse('sys_hipass_box', defaultHipassBoxLogs);
let expenseData = safeParse('sys_expense', defaultExpense);
let expenseHistoryData = safeParse('sys_expense_history', []);
let complaintData = safeParse('sys_complaint', defaultComplaint);
let reportList = safeParse('sys_reports', defaultReports);
let auditLogs = safeParse('sys_logs', ["2026-08-01 09:00 시스템 초기화 및 지점별 권한 구조 생성 완료"]);
let chatMessagesList = safeParse('sys_chat', [{ sender: "시스템", text: "법인카드 & 하이패스 통합 관리 시스템에 오신 것을 환영합니다.", time: "09:00", dm: false }]);
let inboxMessages = safeParse('sys_inbox', []);

let dashboardSummary=null;
let chartInstance1 = null;
let chartInstance2 = null;

function expenseRecordKey(ex){return [ex.group||'',ex.id??'',ex.requester||'',ex.requestedAt||ex.date||''].join('|');}
function normalizeFinalizedExpenses(){
    if(!Array.isArray(expenseData))expenseData=[];
    if(!Array.isArray(expenseHistoryData))expenseHistoryData=[];
    const known=new Set(expenseHistoryData.map(expenseRecordKey));
    const active=[];
    expenseData.forEach(ex=>{
        if(ex && (ex.status==='승인완료'||ex.status==='반려됨')){const key=expenseRecordKey(ex);if(!known.has(key)){expenseHistoryData.push({...ex});known.add(key);}}
        else if(ex)active.push(ex);
    });
    expenseData=active;
}
function cacheCurrentState(){}
function saveData(){
    const snapshot=JSON.parse(JSON.stringify({accounts:accountsData,cards:cardsData,history:cardHistoryData,hipass:hipassData,hipassBox:hipassBoxLogs,expense:expenseData,expenseHistory:expenseHistoryData,complaint:complaintData,reports:reportList,logs:auditLogs,chat:chatMessagesList,inbox:inboxMessages,memos:customMemos,notices:noticeData,shortcuts:userShortcuts}));
    if(!currentUser)return Promise.resolve();
    stateSavePending++;
    const operation=saveQueue.then(async()=>{
        const r=await fetch('/api/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({state:Object.fromEntries(Object.entries(snapshot).filter(([key,value])=>key!=='accounts'&&JSON.stringify(value)!==JSON.stringify(serverSnapshot[key]))),revision:serverStateRevision})});
        const d=await r.json().catch(()=>({}));
        if(!r.ok||!d.ok){
            await loadServerState(); initApp();
            throw new Error(d.message||`HTTP ${r.status} 저장 실패`);
        }
        serverStateRevision=d.revision;serverSnapshot=JSON.parse(JSON.stringify(snapshot));
    }).finally(()=>{stateSavePending=Math.max(0,stateSavePending-1);});
    saveQueue=operation.catch(e=>{console.error(e);alert(`서버 저장에 실패했습니다.\n\n${e.message||e}\n최신 자료를 확인한 후 다시 작업하세요.`);});
    // The queue recovers, but callers awaiting this operation receive failures.
    return operation;
}
function applyServerState(st){if(st.companyPolicy)applyCompanyPolicy(st.companyPolicy);serverSnapshot=JSON.parse(JSON.stringify(st));dashboardSummary=st.dashboardSummary||null;if(st.accounts)accountsData=st.accounts;if(st.cards)cardsData=st.cards;if(Array.isArray(st.history))cardHistoryData=st.history;if(Array.isArray(st.hipass))hipassData=st.hipass;if(Array.isArray(st.hipassBox))hipassBoxLogs=st.hipassBox;if(Array.isArray(st.expense))expenseData=st.expense;expenseHistoryData=Array.isArray(st.expenseHistory)?st.expenseHistory:[];normalizeFinalizedExpenses();if(Array.isArray(st.complaint))complaintData=st.complaint;if(Array.isArray(st.reports))reportList=st.reports;if(Array.isArray(st.logs))auditLogs=st.logs;if(Array.isArray(st.chat))chatMessagesList=st.chat;if(Array.isArray(st.inbox))inboxMessages=st.inbox;if(st.memos)customMemos=st.memos;if(Array.isArray(st.notices))noticeData=st.notices;if(st.shortcuts)userShortcuts=st.shortcuts;cacheCurrentState();}
async function pollServerState(){if(!currentUser||stateSavePending||statePollInFlight)return;if(document.hidden&&Date.now()-lastHiddenPoll<30000)return;lastHiddenPoll=Date.now();const pollUser=currentUser,pollRevision=serverStateRevision,epoch=statePollEpoch;statePollInFlight=true;try{const r=await fetch('/api/state',{cache:'no-store',headers:serverStateRevision?{'If-None-Match':serverStateRevision}:{}});if(r.status===401){await handleLogout();alert('로그인 세션이 만료되었습니다. 다시 로그인하세요.');return;}if(!r.ok)return;const d=await r.json();if(currentUser!==pollUser||epoch!==statePollEpoch||stateSavePending||pollRevision!==serverStateRevision)return;onlineUsers=Array.isArray(d.online_users)?d.online_users:[];if(d.unchanged){const count=document.getElementById('onlineCount');if(count)count.innerText=onlineUsers.length+'명';if(document.getElementById('v_access_status')?.classList.contains('active'))renderAccessStatus();return;}if(d.revision&&d.revision!==serverStateRevision&&d.state){notifyIncomingFromServerState(d.state);applyServerState(d.state);serverStateRevision=d.revision;applyUserPermissions();initApp();updateChatRecipients();renderChatMessages();updateInboxCount();if(userScope==='ALL')await loadAdminAccountDirectory();}const n=document.getElementById('onlineCount');if(n)n.innerText=onlineUsers.length+'명';if(document.getElementById('v_access_status')&&document.getElementById('v_access_status').classList.contains('active'))renderAccessStatus();}catch(e){console.warn('실시간 동기화 일시 중단:',e);}finally{if(epoch===statePollEpoch)statePollInFlight=false;}}
function startLiveSync(){toggleChatPanel(false);stopLiveSync();pollServerState();liveSyncTimer=setInterval(pollServerState,2000);}
function stopLiveSync(){statePollEpoch++;statePollInFlight=false;if(liveSyncTimer)clearInterval(liveSyncTimer);liveSyncTimer=null;}

async function loadServerState(){
    const r=await fetch('/api/state',{cache:'no-store'});
    const d=await r.json().catch(()=>({}));
    if(!r.ok||!d.ok)throw new Error(d.message||'서버 DB에 연결하지 못했습니다.');
    if(d.state)applyServerState(d.state);
    serverStateRevision=d.revision||null;onlineUsers=Array.isArray(d.online_users)?d.online_users:[];
    return true;
}

/* [핵심 완벽 수정] 마우스가 위치한 곳에 메모를 남기고 삭제가 정상 작동하는 로직 */
document.addEventListener('contextmenu', function(e) {
    let activePanel = document.querySelector('.view-panel.active');
    if(!activePanel) return;

    // 메인 콘텐츠 영역 내부 우클릭일 때만 작동
    let mainContentArea = document.getElementById('mainContentArea');
    if(mainContentArea && mainContentArea.contains(e.target)) {
        e.preventDefault();
        let rect = mainContentArea.getBoundingClientRect();
        let x = e.clientX - rect.left + mainContentArea.scrollLeft;
        let y = e.clientY - rect.top + mainContentArea.scrollTop;
        let panelId = activePanel.id;
        let memoId = 'memo_' + Date.now();

        let modalTitle = document.getElementById("modalTitle");
        let modalBody = document.getElementById("modalBody");
        let modalFooter = document.getElementById("modalFooter");

        modalTitle.innerText = "마우스 위치 구역 메모 남기기";
        modalBody.innerHTML = `
            <div style="font-size:12px; color:#64748b;">클릭하신 위치에 남길 메모 내용을 입력하세요.</div>
            <textarea id="newMemoText" style="width:100%; min-height:90px; padding:10px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;" placeholder="메모 내용 입력..."></textarea>
        `;
        modalFooter.innerHTML = `
            <button class="btn-primary" onclick="createMemoAtPosition(${jsArg(panelId)}, ${escapeHtml(Number(x))}, ${escapeHtml(Number(y))}, ${jsArg(memoId)})">저장하기</button>
            <button class="btn-secondary" onclick="closeModal()">닫기</button>
        `;
        document.getElementById("commonModal").style.display = "flex";
    }
});

async function createMemoAtPosition(panelId, x, y, memoId) {
    let txt = document.getElementById("newMemoText").value.trim();
    if(!txt) { alert("메모 내용을 입력해주세요."); return; }
    customMemos[memoId] = { text: txt, x: x, y: y, panelId: panelId };
    await saveData();
    closeModal();
    renderMemos();
}

function editOrDeleteMemo(memoId) {
    let m = customMemos[memoId];
    if(!m) return;
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = "메모 수정 및 삭제";
    modalBody.innerHTML = `
        <div style="font-size:12px; color:#64748b;">기존 메모를 수정하거나 삭제하실 수 있습니다.</div>
        <textarea id="editMemoText" style="width:100%; min-height:90px; padding:10px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">${escapeHtml(m.text)}</textarea>
    `;
    modalFooter.innerHTML = `
        <button class="btn-danger" onclick="deleteSpecificMemo(${jsArg(memoId)})">메모 삭제</button>
        <button class="btn-primary" onclick="updateSpecificMemo(${jsArg(memoId)})">수정 저장</button>
        <button class="btn-secondary" onclick="closeModal()">닫기</button>
    `;
    document.getElementById("commonModal").style.display = "flex";
}

async function updateSpecificMemo(memoId) {
    let txt = document.getElementById("editMemoText").value.trim();
    if(customMemos[memoId]) {
        customMemos[memoId].text = txt;
        await saveData();
        closeModal();
        renderMemos();
    }
}

async function deleteSpecificMemo(memoId) {
    delete customMemos[memoId];
    await saveData();
    closeModal();
    renderMemos();
}

function renderMemos() {
    document.querySelectorAll('.screen-memo-marker').forEach(el => el.remove());
    let activePanel = document.querySelector('.view-panel.active');
    if(!activePanel) return;
    let panelId = activePanel.id;

    for (let id in customMemos) {
        let m = customMemos[id];
        if (m.panelId === panelId) {
            let marker = document.createElement('div');
            marker.className = 'screen-memo-marker';
            marker.style.left = m.x + 'px';
            marker.style.top = m.y + 'px';
            marker.innerHTML = `📌 ${escapeHtml(m.text)}`;
            marker.onclick = (e) => {
                e.stopPropagation();
                editOrDeleteMemo(id);
            };
            activePanel.appendChild(marker);
        }
    }
}

/* 공지사항 관리 기능 모달 */
let noticeUploadCache=null;
function openNoticeManageModal() {
    noticeUploadCache=null;
    if(userScope!=='ALL'){alert('최고관리자만 공지사항을 등록하거나 삭제할 수 있습니다.');return;}
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = "공지사항 및 시스템 알림 관리";
    let html = `<div style="display:flex; flex-direction:column; gap:8px; margin-bottom:14px;">
        <input type="text" id="newNoticeTitle" placeholder="공지 제목" maxlength="120" style="padding:8px; border:1px solid #cbd5e1; border-radius:6px; font-size:12px;">
        <textarea id="newNoticeInput" placeholder="세부 공지 내용을 입력하세요." rows="4" style="padding:8px; border:1px solid #cbd5e1; border-radius:6px; font-size:12px;"></textarea>
        <label style="font-size:12px;">관련 파일 (최대 20MB) <input type="file" id="newNoticeFile"></label>
        <button class="btn-success" onclick="addNewNotice()">➕ 공지 등록</button>
    </div><hr style="border:0; border-top:1px solid #e2e8f0; margin:6px 0;">`;

    noticeData.forEach((n, idx) => {
        html += `<div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;background:#f8fafc; padding:10px; border-radius:6px; border:1px solid #e2e8f0; font-size:12px;">
            <span><b>${escapeHtml(n.title||'공지')}</b><br>${escapeHtml(n.text||'')}${n.attachment?.id?`<br><a target="_blank" rel="noopener" href="/api/attachments/${escapeHtml(encodeURIComponent(n.attachment.id))}">📎 ${escapeHtml(n.attachment.name||'첨부파일')}</a>`:''}</span>
            <button class="btn-danger" style="padding:2px 6px; font-size:10px;" onclick="deleteNotice(${escapeHtml(Number(n.id))})">삭제</button>
        </div>`;
    });

    modalBody.innerHTML = html;
    modalFooter.innerHTML = `<button class="btn-secondary" onclick="closeModal(); renderDashboardNotices();">닫기</button>`;
    document.getElementById("commonModal").style.display = "flex";
}

async function addNewNotice() {
    if(userScope!=='ALL'){alert('최고관리자만 공지사항을 등록할 수 있습니다.');return;}
    const title=document.getElementById('newNoticeTitle').value.trim(),txt=document.getElementById('newNoticeInput').value.trim(),file=document.getElementById('newNoticeFile').files?.[0];
    if(!title){alert('공지 제목을 입력해 주세요.');return;}if(!txt){alert('세부 공지 내용을 입력해 주세요.');return;}if(file&&file.size>20*1024*1024){alert('공지 첨부파일은 20MB 이하로 선택해 주세요.');return;}
    const button=document.querySelector('#modalBody .btn-success');if(button){button.disabled=true;button.textContent='등록 중...';}
    try{let attachment=null;if(file){if(noticeUploadCache?.file!==file)noticeUploadCache={file,attachment:await uploadNoticeAttachment(file)};attachment=noticeUploadCache.attachment;}await businessOperation('/api/notices/create',{title,text:txt,attachment});openNoticeManageModal();renderDashboardNotices();}
    catch(error){alert(`공지 저장에 실패했습니다.\n\n${error.message||error}`);if(button){button.disabled=false;button.textContent='➕ 공지 등록';}}
}

async function uploadNoticeAttachment(file){const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));const response=await fetch('/api/attachments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:file.name,content:btoa(binary),purpose:'notice',broadcast:true})});const result=await response.json().catch(()=>({}));if(!response.ok||!result.ok)throw new Error(result.message||`첨부파일 업로드 실패 (HTTP ${response.status})`);return{id:result.attachment_id,name:result.name};}

async function deleteNotice(id) {
    if(userScope!=='ALL'){alert('최고관리자만 공지사항을 삭제할 수 있습니다.');return;}
    try{await businessOperation('/api/notices/delete',{id});openNoticeManageModal();renderDashboardNotices();}catch(error){alert(error.message||'공지 삭제 실패');}
}

function renderDashboardNotices() {
    let listEl = document.getElementById("dashboardNoticeList");
    if(!listEl) return;
    const manageButton=document.querySelector('#v_dashboard button[onclick="openNoticeManageModal()"]');if(manageButton)manageButton.style.display=userScope==='ALL'?'':'none';
    listEl.innerHTML = "";
    noticeData.forEach(n => {
        let div = document.createElement("div");
        div.style.cssText = "padding: 10px; background: #f8fafc; border-radius: 6px; border: 1px solid #e2e8f0;";
        const title=document.createElement('button');title.type='button';title.textContent=n.title||'공지';title.title='클릭하여 공지 내용 보기';
        title.style.cssText='border:0;background:transparent;padding:0;color:#334155;font-size:13px;font-weight:600;text-align:left;cursor:pointer;text-decoration:underline;';
        title.addEventListener('click',()=>openNoticeDetail(n.id));
        div.appendChild(title);
        listEl.appendChild(div);
    });
}

function openNoticeDetail(id) {
    const notice=noticeData.find(item=>String(item.id)===String(id)); if(!notice)return;
    document.getElementById('modalTitle').textContent='공지사항';
    const attachment=notice.attachment?.id?`<div style="margin-top:18px;padding:12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:7px;">📎 첨부자료: <a target="_blank" rel="noopener" href="/api/attachments/${escapeHtml(encodeURIComponent(notice.attachment.id))}">${escapeHtml(notice.attachment.name||'파일 열기')}</a> · <a download href="/api/attachments/${escapeHtml(encodeURIComponent(notice.attachment.id))}?download=1">다운로드</a></div>`:'';
    document.getElementById('modalBody').innerHTML=`<article style="max-height:65vh;overflow:auto;padding:8px 4px;"><h2 style="margin:0 0 10px;color:#0f172a;font-size:20px;">${escapeHtml(notice.title||'공지')}</h2><div style="font-size:11px;color:#64748b;border-bottom:1px solid #e2e8f0;padding-bottom:10px;">작성자: ${escapeHtml(notice.author||'관리자')}　|　작성일: ${escapeHtml(notice.createdAt||'')}</div><div style="white-space:pre-wrap;line-height:1.8;padding:18px 8px;font-size:14px;color:#1e293b;">${escapeHtml(notice.text||'')}</div>${attachment}</article>`;
    document.getElementById('modalFooter').innerHTML='<button class="btn-secondary" onclick="closeModal()">닫기</button>';
    document.getElementById('commonModal').style.display='flex';
}

/* 맞춤형 빠른 바로가기 메뉴 설정 모달 */
function openShortcutSettingModal() {
    let modalTitle = document.getElementById("modalTitle");
    let modalBody = document.getElementById("modalBody");
    let modalFooter = document.getElementById("modalFooter");

    modalTitle.innerText = "빠른 바로가기 메뉴 커스텀 설정";
    let currentFavs = userShortcuts[currentUser] || ['v_card_rent', 'v_expense', 'v_stats', 'v_complaint'];

    let html = '<p class="ledger-help">모든 업무 화면을 선택할 수 있습니다. 현재 조회 권한이 없는 화면은 선택할 수 없습니다. 개수 제한은 없습니다.</p><div class="shortcut-options">';
    availableShortcuts.forEach(sc => {
        const allowed=hasViewPermission(sc.id),checked=allowed&&currentFavs.includes(sc.id);
        html += `<label class="shortcut-option ${allowed?'':'unavailable'}"><input type="checkbox" name="shortcutChk" value="${escapeHtml(sc.id)}" ${checked?'checked':''} ${allowed?'':'disabled'}> <span>${escapeHtml(sc.label)}${allowed?'':' <small>권한 없음</small>'}</span></label>`;
    });
    html+='</div>';
    modalBody.innerHTML = html;
    modalFooter.innerHTML = `
        <button class="btn-primary" onclick="saveUserShortcuts()">저장하기</button>
        <button class="btn-secondary" onclick="closeModal()">닫기</button>
    `;
    document.getElementById("commonModal").style.display = "flex";
}

async function saveUserShortcuts() {
    const selected=Array.from(document.querySelectorAll('input[name="shortcutChk"]:checked')).filter(c=>!c.disabled&&hasViewPermission(c.value)).map(c=>c.value);
    if(!selected.length){alert('최소 1개 이상의 메뉴를 선택해주세요.');return;}
    const previous=userShortcuts[currentUser];
    try{userShortcuts[currentUser]=selected;await saveData();closeModal();renderUserShortcuts();alert('바로가기 설정이 저장되었습니다.');}
    catch(error){userShortcuts[currentUser]=previous;alert('바로가기를 저장하지 못했습니다. '+error.message);}
}

function renderUserShortcuts() {
    let grid = document.getElementById("userQuickShortcutsGrid");
    if(!grid) return;
    grid.innerHTML = "";
    let favs = userShortcuts[currentUser] || ['v_card_rent', 'v_expense', 'v_stats', 'v_complaint'];
    favs.filter(fId=>hasViewPermission(fId)).forEach(fId => {
        let sc = availableShortcuts.find(s => s.id === fId);
        if(sc) {
            let btn = document.createElement("button");
            btn.className = sc.class;
            btn.innerText = sc.label;
            btn.onclick = async () => switchView(sc.id, document.getElementById(`nav_${sc.id}`));
            grid.appendChild(btn);
        }
    });
}

async function backupDataJSON() {
    const safeAccounts = {};
    Object.entries(accountsData).forEach(([name, info]) => {
        safeAccounts[name] = {
            scope: info.scope,
            permissions: Array.isArray(info.permissions) ? info.permissions : [],
            lastLogin: info.lastLogin || "기록 없음",
            ip: info.ip || ""
        };
    });
    const allData = {
        schemaVersion: STORAGE_VERSION, exportedAt: localDateTime(true),
        accounts: safeAccounts, cards: cardsData.map(({cardKey,...card})=>card), history: cardHistoryData,
        hipass: hipassData, hipassBox: hipassBoxLogs, expense: expenseData,
        expenseHistory: expenseHistoryData, complaint: complaintData, reports: reportList, logs: auditLogs,
        chat: chatMessagesList, inbox: inboxMessages, memos: customMemos,
        notices: noticeData, shortcuts: userShortcuts
    };
    const dataStr = "data:application/json;charset=utf-8," + encodeURIComponent(JSON.stringify(allData,null,2));
    const a=document.createElement("a"); a.href=dataStr;
    a.download=`법인카드_하이패스_백업_${localDate()}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    audit("전체 데이터 백업 파일 생성"); await saveData();
    alert("업무 자료 JSON 파일을 생성했습니다. 외부 수신 원본·첨부 실물·비밀번호는 포함되지 않습니다. 전체 보관·복원에는 시스템 관리의 전체 백업 만들기를 사용하세요.");
}

function restoreDataJSON(input){input.value='';alert('JSON 파일은 업무 자료 내보내기용입니다. 전체 복원은 서버를 종료하고 backup_tool.py restore 또는 운영 안내서의 복원 절차를 사용하세요. 기존 자료는 자동 보존됩니다.');}

// 로그인 화면은 외부 CDN(Chart.js/XLSX)이나 window.onload에 의존하지 않습니다.
// CDN이 차단/지연되어도 로그인 선택창과 로그인 버튼은 즉시 사용할 수 있어야 합니다.
function ensureAdminLoginFallback() {
    if (!accountsData || typeof accountsData !== 'object') accountsData = {};
    if (Object.keys(accountsData).length === 0) accountsData = JSON.parse(JSON.stringify(defaultAccounts));
    if (!accountsData.admin || typeof accountsData.admin !== 'object') {
        accountsData.admin = { scope: "ALL", permissions: [...allViewIds], lastLogin: "기록 없음", ip: "" };
    }
}

document.addEventListener('visibilitychange',()=>{if(!document.hidden&&currentUser&&liveSyncTimer)pollServerState();});

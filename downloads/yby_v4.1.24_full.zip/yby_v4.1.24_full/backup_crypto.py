"""Portable streaming AES-256-GCM backup encryption; no password/key in archive."""
import hashlib,json,os,struct
from pathlib import Path
MAGIC=b'YBYBACKUP1\n'
ROUNDS=600000
CHUNK=1024*1024

def available():
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher
        return True
    except ImportError:return False

def password(value):
    if not isinstance(value,str) or not 12<=len(value)<=128 or value.isspace():raise ValueError('백업 암호는 12~128자로 입력하세요. 복구할 때 같은 암호가 필요합니다.')
    return value

def encrypt(source,target,secret):
    from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
    password(secret);salt=os.urandom(32);iv=os.urandom(12)
    header=json.dumps({'format':1,'cipher':'AES-256-GCM','kdf':'PBKDF2-SHA256','rounds':ROUNDS,'salt':salt.hex(),'iv':iv.hex()},sort_keys=True,separators=(',',':')).encode()
    prefix=MAGIC+struct.pack('>I',len(header))+header
    key=hashlib.pbkdf2_hmac('sha256',secret.encode(),salt,ROUNDS,32)
    enc=Cipher(algorithms.AES(key),modes.GCM(iv)).encryptor();enc.authenticate_additional_data(prefix)
    with Path(source).open('rb') as src,Path(target).open('xb') as dest:
        os.chmod(target,0o600);dest.write(prefix)
        while raw:=src.read(CHUNK):dest.write(enc.update(raw))
        dest.write(enc.finalize());dest.write(enc.tag);dest.flush();os.fsync(dest.fileno())

def decrypt(source,target,secret,max_bytes):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
    password(secret)
    try:
        with Path(source).open('rb') as src:
            if src.read(len(MAGIC))!=MAGIC:raise ValueError('YBY 암호화 백업 형식이 아닙니다.')
            length=struct.unpack('>I',src.read(4))[0]
            if not 1<=length<=4096:raise ValueError('백업 헤더 오류')
            raw=src.read(length);info=json.loads(raw)
            if info.get('format')!=1 or info.get('cipher')!='AES-256-GCM' or info.get('kdf')!='PBKDF2-SHA256' or info.get('rounds')!=ROUNDS:raise ValueError('지원하지 않는 백업 암호화 형식입니다.')
            salt=bytes.fromhex(info['salt']);iv=bytes.fromhex(info['iv'])
            if len(salt)!=32 or len(iv)!=12:raise ValueError('백업 암호화 헤더 오류')
            start=src.tell();size=Path(source).stat().st_size;remaining=size-start-16
            if not 1<=remaining<=max_bytes:raise ValueError('암호화 백업 크기 제한 초과 또는 잘린 파일')
            src.seek(-16,2);tag=src.read(16);src.seek(start)
            key=hashlib.pbkdf2_hmac('sha256',secret.encode(),salt,ROUNDS,32)
            dec=Cipher(algorithms.AES(key),modes.GCM(iv,tag)).decryptor();dec.authenticate_additional_data(MAGIC+struct.pack('>I',length)+raw)
            with Path(target).open('xb') as dest:
                os.chmod(target,0o600)
                while remaining:
                    data=src.read(min(CHUNK,remaining))
                    if not data:raise ValueError('암호화 백업이 잘렸습니다.')
                    remaining-=len(data);dest.write(dec.update(data))
                dest.write(dec.finalize());dest.flush();os.fsync(dest.fileno())
    except (InvalidTag,KeyError,UnicodeError,json.JSONDecodeError,struct.error) as error:
        Path(target).unlink(missing_ok=True);raise ValueError('백업 암호가 다르거나 파일이 손상되었습니다. 기존 자료를 변경하지 않았습니다.') from error
    except BaseException:
        Path(target).unlink(missing_ok=True);raise

def encrypted(path):
    with Path(path).open('rb') as stream:return stream.read(len(MAGIC))==MAGIC

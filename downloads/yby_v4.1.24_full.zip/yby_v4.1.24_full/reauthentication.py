"""Shared session/account/IP reauthentication budget, separate from login throttling."""
import threading,time
LOCK=threading.Lock();FAILURES={}
class Limited(PermissionError):pass

def verify(a,user,value,ip=''):
    key=(str(a.DB_PATH),user,ip)
    with LOCK:
        now=time.time();attempts=[x for x in FAILURES.get(key,[]) if x>now-300]
        if len(attempts)>=5:raise Limited('비밀번호 확인 실패가 반복되었습니다. 5분 후 다시 시도하세요.')
        # Reserve before expensive verification so parallel requests share the budget.
        FAILURES[key]=attempts+[now]
        if len(FAILURES)>2000:
            for item in list(FAILURES)[:1000]:
                if not any(t>now-300 for t in FAILURES[item]):FAILURES.pop(item,None)
    with a.db() as conn:row=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
    ok=bool(row and a.verify_password(row[0],str(value or '')))
    if ok:
        with LOCK:FAILURES.pop(key,None)
        return
    a.audit(user,'REAUTHENTICATION_FAIL',ip)
    raise PermissionError('현재 로그인 비밀번호를 확인하세요.')

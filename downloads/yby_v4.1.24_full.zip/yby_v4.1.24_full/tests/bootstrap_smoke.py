"""Install from a read-only source, start relocated app and preserve original DB."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

SOURCE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(SOURCE))
import windows_bootstrap

def main():
    with tempfile.TemporaryDirectory(prefix='yby-permission-') as folder:
        source=Path(folder)/'바탕화면 원본';target=Path(folder)/'사용자 실행 폴더'
        shutil.copytree(SOURCE,source,ignore=shutil.ignore_patterns('__pycache__','data','logs','backups','certificates','LAN_CLIENT','lan_settings.json','*.runtime.lock','server.pid'))
        env={k:v for k,v in os.environ.items() if not k.startswith(('V3_','V4_'))}
        seed="import app; app.prepare_db(); c=app.db(); c.execute('UPDATE users SET password_hash=?,must_change_password=0 WHERE username=?',(app.phash('Bootstrap-test-pass!'),'admin')); c.commit(); c.close()"
        subprocess.run([sys.executable,'-c',seed],cwd=source,env=env,check=True,stdout=subprocess.DEVNULL)
        database=source/'data/corporate_card_system.db';before=hashlib.sha256(database.read_bytes()).hexdigest()
        for path in source.rglob('*'):path.chmod(0o555 if path.is_dir() else 0o444)
        source.chmod(0o555)
        process=None
        try:
            windows_bootstrap.prepare_runtime(source,target)
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
            log=Path(folder)/'private-console.log'
            with log.open('ab') as output:
                launch="from pathlib import Path; import sys, windows_bootstrap as b; raise SystemExit(b.run_windows(Path(sys.argv[1]),Path(sys.argv[2]),['--local','--port',sys.argv[3],'--no-browser']))"
                process=subprocess.Popen([sys.executable,'-c',launch,str(source),str(target),str(port)],cwd=SOURCE,env=env,stdout=output,stderr=subprocess.STDOUT)
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
            url=f'http://127.0.0.1:{port}'
            for _ in range(100):
                if process.poll() is not None:raise RuntimeError('Relocated startup failed; private console not printed')
                try:
                    with opener.open(url+'/health',timeout=2) as response:
                        if json.load(response)['version']==__import__('run_ready').VERSION:break
                except OSError:pass
                time.sleep(.1)
            else:raise RuntimeError('Relocated readiness timeout')
            marker=(target/'server.pid').read_bytes()
            duplicate=subprocess.run([sys.executable,'-c',launch,str(source),str(target),str(port)],cwd=SOURCE,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=20)
            assert duplicate.returncode==0,duplicate.stderr
            assert '이미 실행 중인 YBY' in duplicate.stdout
            assert (target/'server.pid').read_bytes()==marker
            request=urllib.request.Request(url+'/api/login',data=json.dumps({'username':'admin','password':'Bootstrap-test-pass!'}).encode(),headers={'Content-Type':'application/json'})
            with opener.open(request,timeout=10) as response:cookie=response.headers['Set-Cookie'].split(';')[0];assert json.load(response)['ok']
            request=urllib.request.Request(url+'/api/state',headers={'Cookie':cookie})
            with opener.open(request,timeout=10) as response:revision=json.load(response)['revision']
            payload={'num':'RELOCATED-TEST','group':'서울','company':'test','revision':revision,'requestId':'relocated-startup-register'}
            request=urllib.request.Request(url+'/api/cards/register',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Cookie':cookie})
            with opener.open(request,timeout=10) as response:assert json.load(response)['card']['num']=='RELOCATED-TEST'
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            subprocess.run([sys.executable,str(target/'stop_server.py')],cwd=target,env=env,check=True,stdout=subprocess.DEVNULL)
            process.wait(timeout=10);process=None
            windows_bootstrap.prepare_runtime(source,target)
            assert hashlib.sha256(database.read_bytes()).hexdigest()==before
            print('PASS: read-only Korean-path source -> writable runtime; actual bootstrap duplicate launch keeps same PID; original DB unchanged; actual startup/login/business save; repeated install keeps runtime data',flush=True)
        finally:
            if process is not None:
                if (target/'server.pid').exists():subprocess.run([sys.executable,str(target/'stop_server.py')],cwd=target,env=env,stdout=subprocess.DEVNULL)
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10)
            source.chmod(0o700)
            for path in source.rglob('*'):path.chmod(0o700 if path.is_dir() else 0o600)

if __name__=='__main__':main()

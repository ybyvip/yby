"""All filter cells have dropdowns, visible expense correction, layout choice and upload reset."""
from pathlib import Path
import importlib.util,os,sys,tempfile,json,base64,time
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import exports
spec=importlib.util.spec_from_file_location('f',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby4120-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
 c.setUp();a=f.app;assert c.save({'cards':[]},c.admin)[0]==200
 headers=['순번','은행명','카드번호(뒤4)','사용자','사용횟수','부서명','목적','사용목적','사용금액','지급일','예정일','반납일']
 rows=[[1,'시험은행','1111','사용자A',3,'부서A','출장','점검A',10000,'2026-10-01','2099-01-01','2026-10-02'],[2,'시험은행','1111','사용자B',1,'부서B','출장','점검B','', '2025-01-01','2099-01-01','']]
 with tempfile.TemporaryDirectory() as folder:
  file=Path(folder)/'업로드시험.xlsx';file.write_bytes(exports.make_xlsx('업무',headers,rows))
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];dialogs=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()));page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
   page.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>currentUser==="admin"&&!loginInFlight');page.evaluate('stopLiveSync()');page.click('#nav_v_external_match');page.locator('.excel-import summary').click();page.select_option('#excelDefaultGroup','서울');page.set_input_files('#excelUploadFile',str(file));page.click('#excelPreviewButton');expect(page.locator('.excel-row-ready')).to_have_count(2);pending_commit=[];page.route('**/api/external-excel/history-import',lambda r:pending_commit.append(r));page.click('#excelCommitButton');page.wait_for_function('()=>excelIntake.phase==="commit"');expect(page.locator('#excelResetButton')).to_be_disabled();page.evaluate('clearExcelSelection()');expect(page.locator('#excelIntakeStatus')).to_contain_text('저장 중');assert page.input_value('#excelUploadFile').endswith(file.name)
   for _ in range(50):
    if pending_commit:break
    page.wait_for_timeout(20)
   assert pending_commit;pending_commit[0].continue_();page.unroute('**/api/external-excel/history-import');expect(page.locator('#v_expense_history')).to_be_visible();expect(page.locator('#excelResetButton')).to_be_enabled()
   for kind,table,expected in [('expense','expenseHistoryTable',15),('card','cardHistoryTable',18)]:
    page.click('#nav_v_expense_history' if kind=='expense' else '#nav_v_card_history');root=page.locator('#'+table).locator('..');expect(root.locator('.ledger-filter-choice')).to_have_count(expected);expect(root.locator('.ledger-column-filters input')).to_have_count(expected)
    for index in range(expected):
     select=root.locator('.ledger-filter-choice').nth(index);values=select.locator('option').all();assert len(values)>1,(kind,index);value=values[1].get_attribute('value');select.select_option(value);assert page.locator('#'+table+' tr:not(:has(.ledger-empty))').count()>=1,(kind,index);select.select_option('')
    display=page.locator('#'+kind+'LedgerDisplayMode');expect(display).to_have_value('fit');wrap=page.locator('.expense-history-wrap' if kind=='expense' else '.card-history-wrap');assert wrap.evaluate('(e)=>e.scrollWidth<=e.clientWidth+1'),kind
    display.select_option('scroll');assert wrap.evaluate('(e)=>e.scrollWidth>e.clientWidth+100');wrap.evaluate('(e)=>e.scrollLeft=e.scrollWidth');assert wrap.evaluate('(e)=>e.scrollLeft>0');display.select_option('fit');assert wrap.evaluate('(e)=>e.scrollWidth<=e.clientWidth+1'),kind
   # Correction is accessible without scrolling to the rightmost column.
   page.click('#nav_v_expense_history');blank=page.locator('#expenseHistoryTable').locator('..').locator('.ledger-filter-choice').nth(10);blank.select_option(label='(빈값)');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);expect(page.locator('#expenseHistoryTable')).to_contain_text('사용자B');blank.select_option('');expect(page.locator('#expenseImportedCorrection')).to_be_in_viewport();pick=page.locator('#expenseImportedPick');option=pick.locator('option').filter(has_text='사용자B');pick.select_option(option.get_attribute('value'));expect(page.locator('#expenseImportedCorrectButton')).to_be_enabled();page.click('#expenseImportedCorrectButton');expect(page.locator('#modalTitle')).to_have_text('엑셀 이관 이력 수기 정정');page.select_option('#importCorrectUsed','false');page.fill('#importCorrectReturn','2025-01-02');page.fill('#importCorrectDept','정정부서');page.select_option('#importCorrectProgress','반납완료 · 미사용');page.fill('#importCorrectReason','상단 도구에서 정정');page.fill('#importCorrectPassword','Admin-test-pass!');page.click('#importCorrectSave');expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#expenseHistoryTable')).to_contain_text('정정부서');page.locator('#v_expense_history').screenshot(path=str(screens/'expense_fit.png'))
   # Dropdown exact matching separates 사용 from 미사용; ordinary typing remains supported.
   choices=page.locator('#expenseHistoryTable').locator('..').locator('.ledger-filter-choice');choices.nth(9).select_option(label='사용');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);expect(page.locator('#expenseHistoryTable')).to_contain_text('사용자A');choices.nth(9).select_option(label='미사용');expect(page.locator('#expenseHistoryTable')).to_contain_text('사용자B');choices.nth(9).select_option('')
   search=page.locator('#expenseHistoryTable').locator('..').locator('.ledger-column-filters input').nth(5);search.fill('부서A');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);search.fill('');choices.nth(5).select_option(label='사용자B 정정부서');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);page.evaluate('resetExpenseHistoryFilters()');assert page.locator('#expenseHistoryTable').locator('..').locator('.ledger-filter-choice').evaluate_all('(els)=>els.every(e=>e.value==="")')
   page.click('#nav_v_card_history');expect(page.locator('#cardHistoryTable tr')).to_have_count(4)
   for tr in page.locator('#cardHistoryTable tr').all():
    cells=tr.locator('td');kind=cells.nth(5).inner_text();progress=cells.nth(13).inner_text()
    if kind=='불출':assert progress.startswith('불출완료 · 반납 확인') and '미사용' not in progress and '정산완료' not in progress,progress
    elif '사용자B' in tr.inner_text():assert progress.startswith('반납완료 · 미사용'),progress
   page.locator('#v_card_history').screenshot(path=str(screens/'card_status.png'))
   with page.expect_download() as d:page.evaluate('exportHistoryExcel()')
   with ZipFile(d.value.path()) as z:xml=z.read('xl/worksheets/sheet1.xml').decode();assert '불출완료 · 반납 확인' in xml and '반납완료 · 미사용' in xml
   # Reset clears a reuploaded duplicate preview but preserves DB and completed receipt.
   before=a.get_state();page.click('#nav_v_external_match');page.set_input_files('#excelUploadFile',str(file));page.click('#excelPreviewButton');expect(page.locator('.excel-row-duplicate')).to_have_count(2);page.click('#excelResetButton');assert page.input_value('#excelUploadFile')=='';expect(page.locator('#excelPreviewArea')).to_be_empty();expect(page.locator('#excelCommitArea')).to_be_hidden();expect(page.locator('#excelIntakeStatus')).to_contain_text('초기화');assert a.get_state()==before;page.locator('.excel-import').screenshot(path=str(screens/'upload_reset.png'))
   # Pending previews are invalidated when reset; their response cannot repopulate the table.
   pending=[];page.route('**/api/external-excel/preview',lambda route:pending.append(route));page.set_input_files('#excelUploadFile',str(file));page.click('#excelPreviewButton');page.wait_for_function('()=>excelIntake.phase==="preview"');
   for _ in range(50):
    if pending:break
    page.wait_for_timeout(20)
   assert pending;page.click('#excelResetButton');pending[0].fulfill(status=200,content_type='application/json',body=json.dumps({'ok':True,'rows':[],'counts':{},'sheets':['업무'],'sheet':'업무'}));page.unroute('**/api/external-excel/preview');expect(page.locator('#excelPreviewArea')).to_be_empty();expect(page.locator('#excelPreviewButton')).to_be_enabled();assert page.evaluate('excelIntake.busy') is False
   # Display choice is retained across navigation, mobile fit is readable vertical cards, scroll stays selectable.
   for kind,view,wrapclass in [('expense','v_expense_history','.expense-history-wrap'),('card','v_card_history','.card-history-wrap')]:
    page.click('#nav_'+view);page.select_option('#'+kind+'LedgerDisplayMode','scroll');page.click('#nav_v_external_match');page.click('#nav_'+view);expect(page.locator('#'+kind+'LedgerDisplayMode')).to_have_value('scroll');page.select_option('#'+kind+'LedgerDisplayMode','fit')
    for width in (1920,1440,1024,768,390,320):
     page.set_viewport_size({'width':width,'height':1000});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(kind,width);assert page.locator(wrapclass).evaluate('(e)=>e.scrollWidth<=e.clientWidth+1'),(kind,width)
    page.set_viewport_size({'width':1440,'height':1000})
   # Dropdown choices follow the same own-branch scope as the ledger; readers do not get edit controls.
   foreign=rows[0].copy();foreign[3]='FOREIGN_PRIVATE';raw=exports.make_xlsx('업무',headers,[foreign]);payload={'filename':'scope.xlsx','content':base64.b64encode(raw).decode(),'defaultGroup':'인천','importMode':'history'};status,review,_=c.request('/api/external-excel/preview',payload,cookie=c.admin);assert status==200;status,_,_=c.request('/api/external-excel/history-import',{**payload,'fileHash':review['fileHash'],'selectedRows':[2],'confirmed':True,'requestId':str(time.time_ns()),'revision':c.state(c.admin)['revision']},cookie=c.admin);assert status==200
   with a.db() as conn:conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_history','v_expense_history']),'readonly'));conn.commit()
   reader=browser.new_page(viewport={'width':1440,'height':1000});reader.on('pageerror',lambda e:errors.append(str(e)));reader.on('dialog',lambda d:d.accept());reader.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'));reader.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');reader.fill('#loginUserSelect','readonly');reader.fill('#loginPasswordInput','Branch-test-pass!');reader.press('#loginPasswordInput','Enter');reader.wait_for_function('()=>currentUser==="readonly"&&!loginInFlight');reader.evaluate('stopLiveSync()');reader.click('#nav_v_expense_history');assert 'FOREIGN_PRIVATE' not in reader.locator('.ledger-filter-choice').all_inner_texts().__str__();expect(reader.locator('#expenseHistoryTable tr')).to_have_count(2);expect(reader.locator('#expenseImportedCorrection')).to_be_hidden()
   assert not errors,errors
   print('PASS: every expense15/history18 filter cell has actual dropdown choices; selection is exact, typing works, reset clears both, blank selection works, own-branch dropdowns exclude foreign records and readers cannot edit')
   print('PASS: visible top expense correction -> actual password-protected linked save; issue completion remains distinct from return/settlement status in table and real XLSX')
   print('PASS: fit/scroll both selectable and remembered; actual horizontal scrolling, fit within1920/1440/1024/768/390/320px with narrow-screen vertical records; no JS errors')
   print('PASS: reupload duplicate preview -> selection reset clears file/checks/preview without DB deletion, reset is blocked during commit; delayed preview after reset cannot reappear or leave UI busy')
   browser.close()
finally:f.SecurityTests.tearDownClass()

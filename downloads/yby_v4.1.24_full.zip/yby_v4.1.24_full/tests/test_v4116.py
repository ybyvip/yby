"""Review-first Excel source import, scoped receipts, dedup and matching queues."""
import base64,copy,io,json,sqlite3,unittest
from zipfile import ZipFile,ZIP_DEFLATED
from unittest import mock
from urllib.parse import urlencode
from types import SimpleNamespace
import exports,excel_intake,external_documents,external_reception
import test_v419 as fixture
class Base(fixture.IntakeTests):pass
for name in dir(fixture.IntakeTests):
    if name.startswith('test_'):setattr(Base,name,None)
HEADERS=['순번','은행명','카드번호(뒤4)','사용자','사용횟수','부서명','목적','사용목적','사용금액','지급일','예정일','반납일']
ROW=[1,'시험','5545','시험 사용자',3,'총무팀','출장','출장 회의',12000,'2026-10-01','2099-01-01','2026-10-02']
def upload(rows=None,headers=None):
    raw=exports.make_xlsx('업무',headers or HEADERS,rows if rows is not None else [ROW]);return {'filename':'자료.xlsx','content':base64.b64encode(raw).decode(),'defaultGroup':'서울'}
class ExcelTests(Base):
    def setUp(self):
        super().setUp()
        with self.a.db() as c:
            for table in ('excel_import_rows','external_document_receipts','external_document_matches','external_match_events'):c.execute('DELETE FROM '+table)
            c.commit()
    def preview(self,data=None,cookie=None):return self.c.request('/api/external-excel/preview',data or upload(),cookie=cookie or self.c.branch)
    def imported(self,data=None,cookie=None,**extra):
        payload=data or upload();status,value,_=self.preview(payload,cookie);self.assertEqual(status,200,value)
        return self.op('/api/external-excel/import',{**payload,'fileHash':value['fileHash'],'selectedRows':[r['rowNumber'] for r in value['rows'] if r['status']=='ready'],'confirmed':True,**extra},cookie or self.c.branch)
    def list(self,kind='application',**q):return self.c.request('/api/external-documents?'+urlencode({'kind':kind,**q}),cookie=self.c.branch)[1]
    def receive(self,kind='application',**extra):return self.op('/api/external-documents/receive',{'kind':kind,'selection':'all',**extra})
    def test_preview_is_readonly_and_total_is_one_line_with_explicit_assumptions(self):
        before=copy.deepcopy(self.a.get_state());status,value,_=self.preview();self.assertEqual(status,200,value);row=value['rows'][0];self.assertEqual(row['status'],'ready');self.assertEqual(row['amount'],12000);self.assertTrue(row['assumptions']['applicantFromUser']);self.assertEqual(row['sourceUseCount'],3);self.assertEqual(self.a.get_state(),before);self.assertEqual(self.list()['total'],0)
        self.assertEqual(self.imported()[0],200);app=self.list()['items'][0];settle=self.list('settlement')['items'][0];self.assertEqual(app['source'],'EXCEL');self.assertEqual(app['originRowKey'],settle['originRowKey']);self.assertEqual(app['cardLast4'],'5545');self.assertEqual(settle['amount'],12000)
        with self.a.db() as conn:document=external_documents.load(conn,settle['key']);self.assertEqual(len(document['lineItems']),1);self.assertEqual(document['sourceUseCount'],3)
        self.assertEqual(self.a.get_state()['cards'][0]['status'],'available');self.assertEqual(self.a.get_state()['expense'],[])
    def test_blank_or_zero_amount_never_creates_zero_expense_or_fabricates_settlement(self):
        for amount in ('',0):
            row=ROW.copy();row[8]=amount;row[3]+=' '+str(amount);status,value,_=self.imported(upload([row]));self.assertEqual(status,200,value);self.assertEqual(value['settlements'],0)
        self.assertEqual(self.list()['total'],2);self.assertEqual(self.list('settlement')['total'],0)
    def test_reupload_renamed_reordered_file_and_within_file_duplicates_are_skipped(self):
        row2=ROW.copy();row2[3]='두번째 사용자';data=upload([ROW,row2,ROW]);status,value,_=self.imported(data);self.assertEqual(status,200,value);self.assertEqual(value['importedRows'],2)
        repeated=upload([row2,ROW]);repeated['filename']='이름변경.xlsx';status,value,_=self.preview(repeated);self.assertEqual(value['counts']['duplicate'],2);self.assertEqual(self.list()['total'],2)
        self.receive();before=self.list(reception='received')['total'];self.assertEqual(self.receive()[1]['received'],0);self.assertEqual(self.list(reception='received')['total'],before)
    def test_changed_amount_is_conflict_not_an_overwrite(self):
        self.imported();changed=ROW.copy();changed[8]=99999;status,value,_=self.preview(upload([changed]));self.assertEqual(value['rows'][0]['status'],'conflict')
        self.assertEqual(self.op('/api/external-excel/import',{**upload([changed]),'fileHash':value['fileHash'],'selectedRows':[2],'confirmed':True})[0],400);self.assertEqual(self.list('settlement')['items'][0]['amount'],12000)
    def test_explicit_row_id_distinguishes_legitimate_same_day_same_purpose_events(self):
        data=upload([ROW+['A'],ROW+['B']],HEADERS+['외부행ID']);status,value,_=self.imported(data);self.assertEqual(status,200,value);self.assertEqual(value['applications'],2)
    def test_card_suffix_ambiguity_requires_choice_and_exact_full_card_is_enforced(self):
        cards=copy.deepcopy(self.a.get_state()['cards']);cards.append({'id':3,'num':'OTHER-5545','group':'서울','status':'available','company':'시험'});self.c.save({'cards':cards},self.c.admin)
        status,value,_=self.preview();self.assertEqual(value['rows'][0]['status'],'ready');self.assertEqual(value['rows'][0]['cardLinkStatus'],'ambiguous');self.assertEqual(len(value['rows'][0]['candidates']),2)
        data={**upload(),'overrides':[{'rowNumber':2,'cardId':3}]};self.assertEqual(self.imported(data)[0],200)
        with self.a.db() as conn:doc=external_documents.load(conn,self.list()['items'][0]['key'])
        self.assertFalse(external_documents.card_matches(doc,cards[0]));self.assertTrue(external_documents.card_matches(doc,cards[2]))
    def test_no_card_invalid_dates_negative_money_and_formula_missing_cache_are_flagged(self):
        for column,value in [(8,-1),(9,'2026-02-30'),(9,''),(10,'2026-01-01')]:
            row=ROW.copy();row[column]=value;status,preview,_=self.preview(upload([row]));self.assertEqual(status,200);self.assertEqual(preview['rows'][0]['status'],'error')
        raw=base64.b64decode(upload()['content']);buffer=io.BytesIO()
        with ZipFile(raw and io.BytesIO(raw)) as source,ZipFile(buffer,'w',ZIP_DEFLATED) as target:
            for name in source.namelist():
                content=source.read(name)
                if name=='xl/worksheets/sheet1.xml':content=content.replace(b'<c r="I2"><v>12000</v></c>',b'<c r="I2"><f>SUM(A1)</f></c>')
                target.writestr(name,content)
        data={**upload(),'content':base64.b64encode(buffer.getvalue()).decode()};self.assertEqual(self.preview(data)[1]['rows'][0]['status'],'error')
    def test_dates_excel_epoch_and_leading_zero_suffix(self):
        self.assertEqual(excel_intake.day('1','날짜'), '1900-01-01');self.assertEqual(excel_intake.day('1','날짜',True),'1904-01-02');self.assertEqual(excel_intake.day('46314','날짜'),'2026-10-19')
        with self.assertRaises(ValueError):excel_intake.day('60','날짜')
        self.assertEqual(excel_intake.normalized({'last4':'0077','user':'사용자','issueDate':'2026.10.1','purpose':'업무'},'서울',False)['last4'],'0077')
    def test_branch_scope_and_admin_per_row_group_are_server_checked(self):
        bad={**upload(),'defaultGroup':'인천'};self.assertEqual(self.preview(bad)[1]['rows'][0]['status'],'error')
        
        row=ROW.copy();row[2]='7777';payload={**upload([row]),'overrides':[{'rowNumber':2,'group':'인천','cardId':2}]};self.assertEqual(self.imported(payload,self.c.admin)[0],200);self.assertEqual(self.list()['total'],0)
    def test_anonymous_readonly_and_injected_normalized_document_are_rejected(self):
        self.assertEqual(self.c.request('/api/external-excel/preview',upload())[0],401);readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.preview(cookie=readonly)[0],403)
        status,value,_=self.preview();self.assertEqual(self.op('/api/external-excel/import',{'rows':[{'source':'EXCEL'}],'confirmed':True,'selectedRows':[2],'fileHash':value['fileHash']})[0],400)
    def test_confirmation_file_hash_and_selected_row_are_required(self):
        status,value,_=self.preview();base={**upload(),'fileHash':value['fileHash'],'selectedRows':[2],'confirmed':True}
        for change in ({'confirmed':False},{'fileHash':'fake'},{'selectedRows':[3]},{'selectedRows':[2,2]}):self.assertEqual(self.op('/api/external-excel/import',base|change)[0],400)
        self.assertEqual(self.list()['total'],0)
    def test_partial_selection_and_transaction_failure_never_leave_half_sources(self):
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('fixture failure')):self.assertEqual(self.imported()[0],500)
        self.assertEqual(self.list()['total'],0)
        row=ROW.copy();row[8]=-1;status,value,_=self.imported(upload([ROW,row]));self.assertEqual(status,200,value);self.assertEqual(value['importedRows'],1)
    def test_receipt_all_selected_idempotency_revision_scope_and_independent_sides(self):
        self.imported();self.assertEqual(self.list(reception='unreceived')['total'],1);self.assertEqual(self.list(reception='received')['total'],0)
        doc=self.list()['items'][0];self.assertEqual(self.receive(selection='selected',documents=[{'key':doc['key'],'revision':1}])[1]['received'],1);self.assertEqual(self.receive(selection='selected',documents=[{'key':doc['key'],'revision':1}])[1]['duplicates'],1)
        self.assertEqual(self.list('settlement',reception='unreceived')['total'],1)
        self.assertEqual(self.receive(selection='selected',documents=[{'key':doc['key'],'revision':2}])[0],400)
        foreign=self.stage(self.source(documentId='FOREIGN',group='인천'));self.assertEqual(self.receive(selection='selected',documents=[{'key':foreign,'revision':1}])[0],403)
    def test_matched_documents_are_excluded_from_new_queues_but_preserved_for_workflow(self):
        self.imported();app=self.list()['items'][0];settle=self.list('settlement')['items'][0]
        status,pair,_=self.op('/api/external-matches/create',{'applicationKey':app['key'],'settlementKey':settle['key'],'applicationRevision':1,'settlementRevision':1,'confirmed':True});self.assertEqual(status,200,pair)
        self.assertEqual(self.list(excludeMatched=1)['total'],0);self.assertEqual(self.list('settlement',excludeMatched=1)['total'],0);self.assertEqual(self.receive()[1]['received'],0);self.assertEqual(self.list()['total'],1)
        self.assertEqual(self.c.request('/api/external-matches',cookie=self.c.branch)[1]['total'],1)
    def test_excel_pair_must_share_original_row(self):
        other=ROW.copy();other[3]='다른 사용자';self.imported(upload([ROW,other]));apps=self.list()['items'];sets=self.list('settlement')['items'];app=apps[0];settle=next(d for d in sets if d['originRowKey']!=app['originRowKey'])
        self.assertEqual(self.op('/api/external-matches/create',{'applicationKey':app['key'],'settlementKey':settle['key'],'applicationRevision':1,'settlementRevision':1,'confirmed':True})[0],400)
    def test_source_duplicate_stage_does_not_refresh_timestamp_or_reopen_match(self):
        key=self.stage(self.source());self.receive()
        with self.a.db() as c:before=c.execute('SELECT received_at FROM external_documents WHERE document_key=?',(key,)).fetchone()[0]
        self.stage(self.source())
        with self.a.db() as c:self.assertEqual(c.execute('SELECT received_at FROM external_documents WHERE document_key=?',(key,)).fetchone()[0],before)
        self.assertEqual(self.receive()[1]['received'],0)
    def test_updated_source_revision_needs_new_receipt(self):
        self.stage(self.source());self.receive();self.stage(self.source(revision=2,purpose='갱신'))
        self.assertEqual(self.list(reception='unreceived')['total'],1);self.assertEqual(self.list(reception='received')['total'],0);self.assertEqual(self.receive()[1]['received'],1)
    def test_card_export_headers_data_width_scope_filters_and_no_key(self):
        cards=copy.deepcopy(self.a.get_state()['cards']);cards[0].update(paymentType='체크',usageScope='해외겸용',cardAlias='시험 별칭',cardKey='NEVER-EXPORT');state=self.a.get_state();state['cards']=cards
        with self.a.db() as c:self.a.persist_state(c,state,'fixture')
        with self.a.db() as c:c.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_reg']),));c.commit()
        cookie=self.c.login('branch','Branch-test-pass!');status,raw,_=self.c.request('/api/cards/export',cookie=cookie);self.assertEqual(status,200)
        with ZipFile(io.BytesIO(raw)) as z:text=z.read('xl/worksheets/sheet1.xml').decode()
        for value in ('신용/체크','사용 범위','시험 별칭','체크','해외겸용'):self.assertIn(value,text)
        for value in ('NEVER-EXPORT','TEST-7777'):self.assertNotIn(value,text)
    def test_full_backup_preserves_import_and_revision_receipts(self):
        import backup_manager,tempfile
        from pathlib import Path
        self.imported();self.receive()
        with tempfile.TemporaryDirectory() as folder:
            archive=Path(folder)/'full.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive);dest=Path(folder)/'restore';backup_manager.restore(archive,dest)
            with sqlite3.connect(dest/self.a.DB_PATH.name) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM excel_import_rows').fetchone()[0],1);self.assertEqual(c.execute('SELECT COUNT(*) FROM external_document_receipts').fetchone()[0],1);self.assertEqual(c.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],self.a.storage.SCHEMA_VERSION)
    def test_bad_archives_xls_and_row_count_limit(self):
        for change in ({'filename':'old.xls'},{'content':'bad'},{'content':base64.b64encode(b'notzip').decode()}):self.assertEqual(self.preview(upload()|change)[0],400)
        self.assertEqual(self.preview(upload([ROW]*2001))[0],400)
if __name__=='__main__':unittest.main()

"""Historical XLSX directly populates both ledgers, not active rentals or approvals."""
import copy,json,sqlite3,unittest
from unittest import mock
import test_v4116 as fixture
class Base(fixture.ExcelTests):pass
for name in dir(fixture.ExcelTests):
    if name.startswith('test_'):setattr(Base,name,None)
class HistoricalTests(Base):
    def historic_preview(self,data=None,cookie=None):return self.preview((data or fixture.upload())|{'importMode':'history'},cookie)
    def historic(self,data=None,cookie=None,**changes):
        data=(data or fixture.upload())|{'importMode':'history'};status,value,_=self.preview(data,cookie);self.assertEqual(status,200,value)
        return self.op('/api/external-excel/history-import',{**data,'fileHash':value['fileHash'],'selectedRows':[r['rowNumber'] for r in value['rows'] if r['status']=='ready'],'confirmed':True,**changes},cookie or self.c.branch)
    def test_direct_completed_row_creates_one_expense_two_events_preserves_dates_and_no_active_business(self):
        self.c.save({'cards':[]},self.c.admin);status,result,_=self.historic();self.assertEqual(status,200,result);self.assertEqual((result['ledgerRows'],result['issueEvents'],result['returnEvents']),(1,1,1))
        state=self.a.get_state();self.assertEqual(state['cards'],[]);self.assertEqual(state['expense'],[]);self.assertEqual(len(state['expenseHistory']),1);self.assertEqual(len(state['history']),2)
        ex=state['expenseHistory'][0];self.assertEqual(ex['status'],'이관완료');self.assertEqual(ex['amount'],12000);self.assertNotIn('approvedAt',ex);self.assertNotIn('approvedBy',ex);self.assertEqual(ex['cardNum'],'5545');self.assertEqual(ex['inputRoute'],'EXCEL_LEDGER');self.assertEqual(ex['date'],'2026-10-01');self.assertEqual(ex['returnDate'],'2026-10-02');self.assertEqual(state['history'][0]['time'],'2026-10-01');self.assertEqual(state['history'][1]['time'],'2026-10-02');self.assertEqual(state['history'][1]['rentalEventId'],state['history'][0]['id']);self.assertEqual(state['history'][1]['expenseRef']['id'],ex['id'])
    def test_four_rows_missing_money_and_return_remain_missing_not_zero_or_approved(self):
        rows=[]
        for i in range(4):
            row=fixture.ROW.copy();row[0]=i+1;row[3]+=' '+str(i);row[8]=225000 if i==2 else '';row[11]='' if i==3 else '2026-10-02';rows.append(row)
        status,value,_=self.historic(fixture.upload(rows));self.assertEqual(status,200,value);self.assertEqual((value['ledgerRows'],value['issueEvents'],value['returnEvents'],value['missingAmounts'],value['knownAmount']),(4,4,3,3,225000))
        state=self.a.get_state();self.assertEqual(sum(x['amount'] is None for x in state['expenseHistory']),3);self.assertEqual(sum(x['status']=='이관완료' for x in state['expenseHistory']),1);self.assertEqual(len(state['history']),7)
    def test_reupload_and_lost_response_retry_never_duplicate_ledgers(self):
        data=fixture.upload();status,preview,_=self.historic_preview(data);body={**data,'importMode':'history','fileHash':preview['fileHash'],'selectedRows':[2],'confirmed':True}
        first=self.op('/api/external-excel/history-import',body);self.assertEqual(first[0],200);second=self.op('/api/external-excel/history-import',body);self.assertEqual(second[1]['duplicateRows'],1);self.assertEqual(len(self.a.get_state()['expenseHistory']),1);self.assertEqual(len(self.a.get_state()['history']),2)
    def test_previous_unprocessed_source_converts_once_and_leaves_new_receiving_queue(self):
        self.imported();self.assertEqual(self.historic_preview()[1]['counts']['ready'],1);self.assertEqual(self.historic()[0],200);self.assertEqual(self.list(excludeMatched=1)['total'],0);self.assertEqual(self.list('settlement',excludeMatched=1)['total'],0);self.assertEqual(self.receive()[1]['received'],0)
        with self.a.db() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM external_documents').fetchone()[0],2);self.assertEqual(c.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],2)
    def test_previously_matched_unprocessed_source_becomes_locked_import_completed(self):
        self.imported();app=self.list()['items'][0];settle=self.list('settlement')['items'][0];self.op('/api/external-matches/create',{'applicationKey':app['key'],'settlementKey':settle['key'],'applicationRevision':1,'settlementRevision':1,'confirmed':True});self.assertEqual(self.historic()[0],200)
        pair=self.c.request('/api/external-matches',cookie=self.c.branch)[1]['items'][0];self.assertTrue(pair['locked']);self.assertEqual(pair['target']['label'],'이력대장 이관완료')
    def test_source_already_used_for_rental_cannot_be_imported_as_historical_duplicate(self):
        self.imported();app=self.list()['items'][0];self.rent(**self.selected(app['key']));status,preview,_=self.historic_preview();self.assertEqual(preview['counts']['conflict'],1);self.assertEqual(self.historic(selectedRows=[2])[0],400);self.assertEqual(len(self.a.get_state()['history']),1)
    def test_duplicate_rows_in_one_file_and_renamed_reordered_file_are_skipped(self):
        row2=fixture.ROW.copy();row2[3]='다른 사용자';data=fixture.upload([fixture.ROW,row2,fixture.ROW]);review=self.historic_preview(data)[1];self.assertEqual(review['counts']['ready'],2);self.assertEqual(review['counts']['duplicate'],1)
        result=self.historic(data,selectedRows=[2,3,4]);self.assertEqual(result[0],200,result);self.assertEqual(result[1]['importedRows'],2);self.assertEqual(result[1]['duplicateRows'],1);self.assertEqual(len(self.a.get_state()['expenseHistory']),2)
        repeat=fixture.upload([row2,fixture.ROW]);repeat['filename']='다른이름.xlsx';self.assertEqual(self.historic_preview(repeat)[1]['counts']['duplicate'],2)
    def test_changed_original_content_stays_conflict(self):
        self.historic();row=fixture.ROW.copy();row[8]=5555;self.assertEqual(self.historic_preview(fixture.upload([row]))[1]['counts']['conflict'],1)
    def test_wrong_scope_no_permission_anonymous_are_denied(self):
        self.assertEqual(self.historic_preview(fixture.upload()|{'defaultGroup':'인천'})[1]['counts']['error'],1)
        readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.historic_preview(cookie=readonly)[0],403);self.assertEqual(self.c.request('/api/external-excel/history-import',{})[0],401)
        with self.a.db() as conn:conn.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_history','v_expense_history']),'readonly'));conn.commit()
        self.assertEqual(self.op('/api/external-excel/history-import',{**fixture.upload(),'confirmed':True,'selectedRows':[2],'fileHash':'unused'},readonly)[0],403)
    def test_missing_confirmation_invalid_hash_selected_row_and_batch_failure_do_not_write(self):
        data=fixture.upload();review=self.historic_preview()[1];base={**data,'fileHash':review['fileHash'],'selectedRows':[2],'confirmed':True}
        for change in ({'confirmed':False},{'fileHash':'bad'},{'selectedRows':[999]},{'selectedRows':[2,2]}):self.assertEqual(self.op('/api/external-excel/history-import',base|change)[0],400)
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('fixture failed save')):self.assertEqual(self.historic()[0],500)
        self.assertEqual(self.a.get_state()['expenseHistory'],[])
        with self.a.db() as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM excel_import_rows').fetchone()[0],0)
    def test_ordinary_state_cannot_forge_or_edit_imported_history(self):
        self.historic();rows=copy.deepcopy(self.a.get_state()['expenseHistory']);rows[0]['amount']=88888;self.assertEqual(self.c.save({'expenseHistory':rows},self.c.admin)[0],403)
    def test_historical_events_do_not_change_an_already_rented_live_card(self):
        self.rent();before=copy.deepcopy(self.a.get_state()['cards']);self.historic();self.assertEqual(self.a.get_state()['cards'],before)
    def test_zero_amount_keeps_zero_and_has_no_fake_unit_price_or_approval(self):
        row=fixture.ROW.copy();row[8]=0;self.historic(fixture.upload([row]));ex=self.a.get_state()['expenseHistory'][0];self.assertEqual(ex['amount'],0);self.assertEqual(ex['status'],'금액0원');self.assertNotIn('lineItems',ex);self.assertNotIn('unitPrice',ex)
    def test_global_event_ids_do_not_collide_with_existing_history(self):
        self.rent();self.op('/api/cards/return',{'cardId':1,'used':False});old=copy.deepcopy(self.a.get_state()['history']);self.historic();events=self.a.get_state()['history'];self.assertEqual(events[:2],old);self.assertEqual(len({e['id'] for e in events}),4)
    def test_maximum_2000_row_batch_with_due_backup_completes_and_deduplicates(self):
        rows=[]
        for i in range(2000):
            row=fixture.ROW.copy();row[0]=i;row[3]='대량시험'+str(i);rows.append(row)
        self.a.LAST_FULL_BACKUP=0
        result=self.historic(fixture.upload(rows));self.assertEqual(result[0],200,result);self.assertEqual((result[1]['ledgerRows'],result[1]['issueEvents'],result[1]['returnEvents']),(2000,2000,2000));self.assertEqual(result[1]['knownAmount'],24000000)
        self.assertEqual(self.historic_preview(fixture.upload(rows))[1]['counts']['duplicate'],2000);self.assertEqual(len(self.a.get_state()['history']),4000)
    def test_full_backup_restores_direct_ledgers_and_duplicate_registry(self):
        import backup_manager,tempfile
        from pathlib import Path
        self.historic()
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)/'full.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,out);dest=Path(folder)/'restored';backup_manager.restore(out,dest)
            with sqlite3.connect(dest/self.a.DB_PATH.name) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM expense_ledger').fetchone()[0],1);self.assertEqual(c.execute('SELECT COUNT(*) FROM card_events').fetchone()[0],2);self.assertIn('historyRef',c.execute('SELECT payload FROM excel_import_rows').fetchone()[0])
if __name__=='__main__':unittest.main()

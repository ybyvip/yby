"""Upload completion, input-order ledgers, all column filters, linked audited corrections."""
from pathlib import Path
import importlib.util,os,sys,tempfile,json
from zipfile import ZipFile
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));import exports
spec=importlib.util.spec_from_file_location('f',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby4119-screens'));screens.mkdir(parents=True,exist_ok=True)
try:
 c.setUp();a=f.app;assert c.save({'cards':[]},c.admin)[0]==200
 headers=['순번','은행명','카드번호(뒤4)','사용자','사용횟수','부서명','목적','사용목적','사용금액','지급일','예정일','반납일']
 rows=[[1,'시험은행','1111','사용자A',3,'시험부서','출장','점검A',10000,'2026-10-19','2099-01-01','2026-10-19'],[2,'시험은행','1111','사용자B',1,'시험부서','출장','점검B',20000,'2025-01-01','2099-01-01','']]
 with tempfile.TemporaryDirectory() as folder:
  files=[]
  for i,row in enumerate(rows):
   path=Path(folder)/('시험'+str(i)+'.xlsx');path.write_bytes(exports.make_xlsx('업무',headers,[row]));files.append(path)
  with sync_playwright() as p:
   browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1920,'height':1200});errors=[];dialogs=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()));page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false,"loading":false}'))
   page.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');page.fill('#loginUserSelect','admin');page.fill('#loginPasswordInput','Admin-test-pass!');page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>currentUser==="admin"&&!loginInFlight');page.evaluate('stopLiveSync()')
   def upload(file):
    page.click('#nav_v_external_match');details=page.locator('.excel-import');
    if details.get_attribute('open') is None:details.locator('summary').click()
    page.select_option('#excelDefaultGroup','서울');page.set_input_files('#excelUploadFile',str(file));page.click('#excelPreviewButton');expect(page.locator('.excel-row-ready')).to_have_count(1);page.click('#excelCommitButton');expect(page.locator('#v_expense_history')).to_be_visible()
   upload(files[0]);batch1=a.get_state()['expenseHistory'][0]['importBatch'];upload(files[1]);batch2=a.get_state()['expenseHistory'][1]['importBatch'];assert batch1!=batch2
   expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);expect(page.locator('#expenseHistoryTable')).to_contain_text('사용자B');expect(page.locator('#expenseLedgerScope')).to_contain_text('이번 엑셀');assert page.locator('#expenseHistoryTable tr td').first.inner_text()=='2'
   page.click('#nav_v_external_match');assert page.locator('.excel-row-ready').count()==0;expect(page.locator('#excelPreviewArea')).to_contain_text('제거했습니다');page.click('#excelCommitButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('이미 업로드가 완료');assert any('이미 업로드가 완료' in x for x in dialogs);assert len(a.get_state()['expenseHistory'])==2
   page.click('#nav_v_expense_history');expect(page.locator('#expenseHistoryTable tr')).to_have_count(2);assert page.locator('#expenseHistoryTable tr td:first-child').all_text_contents()==['2','1'];assert page.locator('#expenseHistoryTable tr').first.locator('td').nth(3).inner_text()=='2025-01-01'
   assert page.locator('#expenseHistoryTable').evaluate('(e)=>e.previousElementSibling.querySelectorAll(".ledger-column-filters input").length')==15
   serial_input=page.locator('#expenseHistoryTable').locator('..').locator('.ledger-column-filters input').first;serial_input.fill('1');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);assert page.locator('#expenseHistoryTable td').first.inner_text()=='1';serial_input.fill('1~2');expect(page.locator('#expenseHistoryTable tr')).to_have_count(2);serial_input.fill('>=2');expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);serial_input.fill('')
   # Every visible column has a functional AND filter (specific sample value from each projection).
   values=page.evaluate("ledgerColumnValues('expense',expenseHistoryData[1])")
   for index,value in enumerate(values):
    token=str(value).split(' ')[0] if value else '-';input=page.locator('#expenseHistoryTable').locator('..').locator('.ledger-column-filters input').nth(index);input.fill(token);assert page.locator('#expenseHistoryTable tr').count()>=1,(index,token);input.fill('없는값ZZZ');expect(page.locator('#expenseHistoryTable tr')).to_have_count(0);input.fill('')
   page.evaluate("openExcelLedgerBatch('expense',"+json.dumps(batch2)+")");expect(page.locator('#expenseHistoryTable tr')).to_have_count(1);page.locator('#expenseHistoryTable button').filter(has_text='수기 정정').click();page.select_option('#importCorrectUsed','false');page.fill('#importCorrectReturn','2025-01-02');page.fill('#importCorrectDept','수정된부서');page.select_option('#importCorrectProgress','반납완료 · 미사용');page.fill('#importCorrectReason','원본 확인 정정');page.fill('#importCorrectPassword','wrong');page.click('#importCorrectSave');expect(page.locator('#importCorrectStatus')).to_contain_text('비밀번호');assert page.input_value('#importCorrectPassword')=='';page.fill('#importCorrectPassword','Admin-test-pass!');page.click('#importCorrectSave');expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#expenseHistoryTable')).to_contain_text('수정된부서');expect(page.locator('#expenseHistoryTable')).to_contain_text('2025-01-02');expect(page.locator('#expenseHistorySummary [data-metric=amount]')).to_contain_text('0원');page.locator('#v_expense_history').screenshot(path=str(screens/'expense_filters.png'))
   page.locator('#expenseHistoryTable button').filter(has_text='상세 보기').click();expect(page.locator('#modalBody')).to_contain_text('수기 정정 이력');expect(page.locator('#modalBody')).to_contain_text('원본 확인 정정');assert page.locator('.change-before').count()>=3;assert page.locator('.change-after').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')!=page.locator('.change-before').first.evaluate('(e)=>getComputedStyle(e).backgroundColor');page.locator('.modal-card').screenshot(path=str(screens/'correction_history.png'));page.evaluate('closeModal()')
   page.locator('#expenseHistoryImportResult button').filter(has_text='불출반납').click();expect(page.locator('#cardHistoryTable tr')).to_have_count(2);expect(page.locator('#cardHistoryTable')).to_contain_text('수정된부서');expect(page.locator('#cardHistoryTable')).to_contain_text('미사용');assert page.locator('#cardHistoryTable').evaluate('(e)=>e.previousElementSibling.querySelectorAll(".ledger-column-filters input").length')==18
   values=page.evaluate("ledgerColumnValues('card',cardHistoryData.at(-1),ledgerContext())")
   for index,value in enumerate(values):
    token=str(value).split(' ')[0] if value else '-';input=page.locator('#cardHistoryTable').locator('..').locator('.ledger-column-filters input').nth(index);input.fill(token);assert page.locator('#cardHistoryTable tr').count()>=1 and page.locator('#cardHistoryTable .ledger-empty').count()==0,(index,token);input.fill('')
   with page.expect_download() as download:page.evaluate('exportHistoryExcel()')
   with ZipFile(download.value.path()) as z:xml=z.read('xl/worksheets/sheet1.xml').decode();assert '작성기준일' in xml and '수정된부서' in xml and '사용자A' not in xml
   page.locator('#v_card_history').screenshot(path=str(screens/'card_filters.png'));page.click('#nav_v_card_history');expect(page.locator('#cardHistoryTable tr')).to_have_count(4);nums=page.locator('#cardHistoryTable tr td:first-child').all_text_contents();assert nums==['4','3','2','1'],nums
   for width in (1920,1440,1024,768,390,320):
    page.set_viewport_size({'width':width,'height':1200});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),width
   page.set_viewport_size({'width':1920,'height':1200});page.click('#nav_v_external_match');data=[]
   for i in range(3):
    row=rows[0].copy();row[3]='부분업로드'+str(i);data.append(row)
   partial=Path(folder)/'부분업로드.xlsx';partial.write_bytes(exports.make_xlsx('업무',headers,data+[rows[0]]));page.set_input_files('#excelUploadFile',str(partial));page.click('#excelPreviewButton');expect(page.locator('.excel-row-ready')).to_have_count(3);page.check('#excelSelectAll');page.uncheck('#excelSelectAll');page.locator('.excel-row-check').first.check();page.click('#excelCommitButton');expect(page.locator('#v_expense_history')).to_be_visible();page.click('#nav_v_external_match');expect(page.locator('.excel-row-ready')).to_have_count(2);expect(page.locator('.excel-row-duplicate')).to_have_count(0);page.click('#excelCommitButton');expect(page.locator('#v_expense_history')).to_be_visible();expect(page.locator('#expenseHistoryTable tr')).to_have_count(2);page.click('#nav_v_external_match');expect(page.locator('.excel-row-ready')).to_have_count(0);page.click('#excelCommitButton');expect(page.locator('#excelIntakeStatus')).to_contain_text('이미 업로드가 완료');assert len(a.get_state()['expenseHistory'])==5
   assert not errors,errors;assert not a.get_state()['cards'] and not a.get_state()['expense']
   print('PASS: two real uploads clear processed preview; repeat button gives already-completed notice and no duplicate writes, partial selection retains only unfinished rows; batch buttons show only respective import, normal navigation shows all')
   print('PASS: old use date imported later appears first by stored serial/created date; all 15 expense and 18 history column filters functional; batch XLSX exports exact filtered subset')
   print('PASS: password failure retained form/cleared password; correction updates both ledgers, adds exact return without card-number collision, unused excludes totals, original/audited colored before-after retained; no active business writes')
   print('PASS: no JS errors; 1920/1440/1024/768/390/320px document containment')
   browser.close()
finally:f.SecurityTests.tearDownClass()

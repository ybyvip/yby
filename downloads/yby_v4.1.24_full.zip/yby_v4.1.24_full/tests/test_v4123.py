"""V4.1.23 authoritative incidents/replacement, scoped documents and approved review."""
import base64,copy,json,sqlite3,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from unittest import mock
import test_security as f
import test_v4 as w
class Additions123Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):f.SecurityTests.setUpClass()
 @classmethod
 def tearDownClass(cls):f.SecurityTests.tearDownClass()
 def setUp(self):
  self.w=w.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_reg','v_card_rent','v_expense','v_stats','v_business_review','v_complaint','v_report_write','v_report_box','v_card_status']),));db.commit()
  with self.a.db() as db:
   state=self.a.get_state();state['accounts']=self.a.account_metadata(db);self.a.persist_state(db,state,'fixture')
 def op(self,path,data,cookie=None):return self.w.operation(path,data,cookie or self.c.branch)
 def incident(self,**extra):return dict(recognizedAt='2026-01-01T00:00:00+09:00',reporter='시험 제보자',receiver='시험 접수자',description='분실 사실 인지',actions='사용 정지 접수',**extra)
 def manage(self,**extra):return self.op('/api/cards/manage',{'cardId':1,'expectedVersion':self.a.get_state()['cards'][0].get('managementVersion',''),'managementStatus':'분실','reason':'분실 접수','incident':self.incident(),**extra})
 def replacement(self):return dict(company='새 카드사',num='REPLACEMENT-9999',userType='비지정',assignedUser='',issueDate='2026-01-01',expiryDate='2099-01-01',paymentType='신용',usageScope='국내전용',withdrawalAccount='시험계좌',limitAmount=500000)
 def replace(self,**extra):return self.op('/api/cards/replace',dict(cardId=1,expectedVersion=self.a.get_state()['cards'][0].get('managementVersion',''),reason='분실 재발급',replacement=self.replacement())|extra)
 def test_incident_information_required_and_saved_as_structured_history(self):
  self.assertEqual(self.manage(incident={})[0],400);result=self.manage();self.assertEqual(result[0],200,result);card=self.a.get_state()['cards'][0]
  self.assertEqual(card['incident']['reporter'],'시험 제보자');self.assertEqual(card['managementHistory'][0]['after']['incident']['actions'],'사용 정지 접수');self.assertEqual(card['status'],'available')
  before=copy.deepcopy(card['managementHistory']);self.assertEqual(self.manage(managementStatus='정상')[0],200);self.assertEqual(self.a.get_state()['cards'][0]['managementHistory'][:1],before)
 def test_invalid_time_and_foreign_or_unprivileged_incident_are_rejected(self):
  for time in ['2099-01-01T00:00:00Z','bad','2026-01-01T00:00:00']:
   incident=self.incident();incident['recognizedAt']=time;self.assertEqual(self.manage(incident=incident)[0],400)
  readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.op('/api/cards/manage',{'cardId':1,'managementStatus':'분실','reason':'시험','incident':self.incident()},readonly)[0],403)
 def test_replacement_preserves_original_and_links_both_cards(self):
  self.assertEqual(self.manage()[0],200);before=copy.deepcopy(self.a.get_state());result=self.replace();self.assertEqual(result[0],200,result);old,new=self.a.get_state()['cards']
  self.assertTrue(old['archived']);self.assertEqual(old['closingSnapshot']['incident'],before['cards'][0]['incident']);self.assertEqual(old['closingSnapshot']['num'],'TEST');self.assertEqual(old['replacedBy']['cardId'],new['id']);self.assertEqual(new['replaces']['cardId'],old['id']);self.assertEqual(new['status'],'available');self.assertEqual(self.a.get_state()['history'],before['history']);self.assertEqual(self.replace()[0],409)
 def test_replacement_duplicate_or_rented_card_has_no_partial_write(self):
  value=self.replacement();value['num']='TEST';before=copy.deepcopy(self.a.get_state());self.assertEqual(self.replace(replacement=value)[0],400);self.assertEqual(self.a.get_state(),before)
  self.assertEqual(self.w.rent()[0],200);before=copy.deepcopy(self.a.get_state());self.assertEqual(self.replace()[0],400);self.assertEqual(self.a.get_state(),before)
 def test_replacement_database_failure_rolls_back_both_sides(self):
  before=copy.deepcopy(self.a.get_state())
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated replacement failure')):self.assertEqual(self.replace()[0],500)
  self.assertEqual(self.a.get_state(),before)
 def test_concurrent_replacement_has_one_winner(self):
  revision=self.c.state(self.c.branch)['revision'];base={'cardId':1,'expectedVersion':'','reason':'대체','replacement':self.replacement(),'revision':revision}
  def run(index):return self.c.request('/api/cards/replace',{**base,'requestId':'replacement-race-'+str(index)},self.c.branch)[0]
  with ThreadPoolExecutor(2) as pool:statuses=list(pool.map(run,[1,2]))
  self.assertEqual(sorted(statuses),[200,409]);self.assertEqual(len(self.a.get_state()['cards']),2)
 def test_dashboard_only_permission_gets_scoped_abnormal_counts(self):
  self.manage()
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_dashboard']),));db.commit()
  cookie=self.c.login('readonly','Branch-test-pass!');state=self.c.state(cookie)['state'];self.assertEqual(state['cards'],[]);self.assertEqual(state['dashboardSummary']['abnormalCards'],1)
  self.replace();state=self.c.state(cookie)['state'];self.assertEqual(state['dashboardSummary']['cards'],1);self.assertEqual(state['dashboardSummary']['abnormalCards'],0)
 def upload(self,purpose='report',**extra):return self.c.request('/api/attachments',{'purpose':purpose,'group':'서울','name':'첨부문서.txt','content':base64.b64encode('시험 문서'.encode()).decode(),**extra},self.c.branch)
 def test_complaint_submission_attachments_are_atomic_and_idempotent(self):
  uploaded=self.upload('complaint');self.assertEqual(uploaded[0],200,uploaded);body=dict(group='서울',category='일반문의',phone='010-TEST',title='시험 민원',content='시험 민원 내용',attachments=[{'id':uploaded[1]['attachment_id']}],requestId='complaint-repeat-123',revision=self.c.state(self.c.branch)['revision'])
  first=self.c.request('/api/complaints/submit',body,self.c.branch);second=self.c.request('/api/complaints/submit',body,self.c.branch);self.assertEqual(first[0],200,first);self.assertEqual(first[1],second[1]);self.assertEqual(len(self.a.get_state()['complaint']),1);self.assertEqual(first[1]['complaint']['author'],'branch')
 def test_document_attachment_scope_permissions_and_purpose_are_enforced(self):
  upload=self.upload();ref={'id':upload[1]['attachment_id']};payload=dict(group='서울',title='기안시험',content='본문',reviewer='',approver='admin',attachments=[ref]);result=self.op('/api/documents/submit',payload);self.assertEqual(result[0],200,result)
  url='/api/attachments/'+ref['id'];self.assertEqual(self.c.request(url,cookie=self.c.branch)[0],200);readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.c.request(url,cookie=readonly)[0],403)
  with self.a.db() as db:db.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_report_box','v_complaint']),));db.commit()
  self.assertEqual(self.c.request(url,cookie=readonly)[0],403)
  invalid=self.op('/api/complaints/submit',dict(group='서울',title='잘못된 첨부',content='본문',phone='test',category='일반문의',attachments=[ref]));self.assertEqual(invalid[0],403);self.assertEqual(self.a.get_state()['complaint'],[])
  self.assertEqual(self.upload(broadcast=True)[0],403)
 def test_complaint_write_failure_preserves_state_and_uploaded_file(self):
  uploaded=self.upload('complaint');before=copy.deepcopy(self.a.get_state())
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('simulated complaint failure')):self.assertEqual(self.op('/api/complaints/submit',dict(group='서울',title='민원',content='본문',phone='test',category='일반문의',attachments=[{'id':uploaded[1]['attachment_id']}]))[0],500)
  self.assertEqual(self.a.get_state(),before);self.assertTrue((self.a.ATTACHMENT_DIR/(uploaded[1]['attachment_id']+'.bin')).exists())
 def seed_approved(self,**extra):
  row=dict(id=10,group='서울',requester='branch',user='시험 사용자',dept='시험부서',cardNum='TEST',date='2026-10-01',amount=1000,status='승인완료',approvedBy='admin',approvedAt='2026-10-02T00:00:00Z',attachments=[],**extra)
  with self.a.db() as db:
   state=self.a.get_state();state['expenseHistory']=[row];self.a.persist_state(db,state,'fixture')
  return row
 def review(self):return self.c.request('/api/business-review?period=2026-10',cookie=self.c.branch)[1]
 def ack(self,v,target,**extra):return self.op('/api/business-review/acknowledge',dict(period='2026-10',group='서울',fingerprint=v['fingerprint'],target=target,reference='명세서 시험',note='대조 확인 완료 사유',reviewStatus='완료',confirmed=True,acknowledgeIssues=True,password='Branch-test-pass!',**extra))
 def test_review_excludes_in_progress_and_unapproved_imports(self):
  approved=self.seed_approved()
  with self.a.db() as db:
   state=self.a.get_state();state['expenseHistory'] += [{**approved,'id':11,'status':'이관완료','historicalImport':True},{**approved,'id':12,'status':'승인취소'},{**approved,'id':13,'status':'반려됨'}];state['expense']=[{**approved,'id':14,'status':'승인대기'}];self.a.persist_state(db,state,'fixture')
  self.assertEqual([x['id'] for x in self.review()['issues']],['10'])
 def test_review_complete_removes_only_matching_source_and_preserves_business(self):
  self.seed_approved();v=self.review();target=v['issues'][0];before=copy.deepcopy(self.a.get_state());result=self.ack(v,target);self.assertEqual(result[0],200,result);self.assertEqual(self.a.get_state(),before);v=self.review();self.assertEqual(v['issues'],[]);self.assertTrue(v['reviews'][0]['current'])
  with self.a.db() as db:
   state=self.a.get_state();state['expenseHistory'][0]['amount']=2000;self.a.persist_state(db,state,'fixture')
  value=self.review();self.assertEqual(len(value['issues']),1);self.assertFalse(value['reviews'][0]['current']);self.assertEqual(len(value['reviews']),1)
 def test_completed_branch_review_visible_to_admin_without_global_summary_leak(self):
  self.seed_approved();value=self.review();self.assertEqual(self.ack(value,value['issues'][0])[0],200)
  admin=self.c.request('/api/business-review?period=2026-10',cookie=self.c.admin)[1];self.assertEqual(admin['issues'],[]);self.assertEqual(len(admin['reviews']),1)
  self.assertNotIn('summary',admin['reviews'][0]);self.assertEqual(admin['reviews'][0]['group'],'서울')
 def test_review_forged_target_and_changed_source_are_rejected(self):
  self.seed_approved();v=self.review();target={**v['issues'][0],'sourceFingerprint':'forged'};self.assertEqual(self.ack(v,target)[0],409)
 def test_v4122_schema10_upgrade_keeps_legacy_incident_and_review(self):
  import business_review
  with self.a.db() as db:
   state=self.a.get_state();state['cards'][0].update(managementStatus='분실',managementHistory=[{'time':'2026-01-01','actor':'admin','reason':'구버전 분실접수','before':{},'after':{'managementStatus':'분실'}}]);self.a.persist_state(db,state,'fixture');hashes=dict(db.execute('SELECT username,password_hash FROM users'));db.execute('DELETE FROM schema_versions');db.execute("INSERT INTO schema_versions VALUES(10,'2026-01-01')");business_review.initialize(db);payload={'id':'old-review','fingerprint':'old','reference':'기존명세','note':'기존점검','period':'2026-10','group':'서울','actor':'branch','createdAt':'2026-01-01'};db.execute('INSERT INTO business_reviews VALUES(?,?,?,?,?,?)',('old-review','2026-10','서울','branch','2026-01-01',json.dumps(payload)));db.commit()
  before=copy.deepcopy(self.a.get_state()['cards']);self.a.prepare_db();self.assertEqual(self.a.get_state()['cards'],before)
  with self.a.db() as db:
   self.assertEqual(db.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],self.a.storage.SCHEMA_VERSION)
   for name,digest in hashes.items():self.assertEqual(db.execute('SELECT password_hash FROM users WHERE username=?',(name,)).fetchone()[0],digest)
  self.assertEqual(self.review()['reviews'][0]['note'],'기존점검')
 def test_legacy_incident_details_and_existing_review_payload_are_not_fabricated(self):
  import business_review
  with self.a.db() as db:
   state=self.a.get_state();state['cards'][0].update(managementStatus='분실',managementHistory=[{'time':'2026-01-01','actor':'admin','reason':'기존 기록','before':{},'after':{'managementStatus':'분실'}}]);self.a.persist_state(db,state,'fixture');business_review.initialize(db);value={'id':'legacy','period':'2026-10','group':'서울','actor':'branch','createdAt':'2026-01-01','fingerprint':'old','reference':'기존명세','note':'기존 점검'};db.execute('INSERT INTO business_reviews VALUES(?,?,?,?,?,?)',('legacy','2026-10','서울','branch','2026-01-01',json.dumps(value)));db.commit()
  self.assertNotIn('incident',self.a.get_state()['cards'][0]);self.assertEqual(self.review()['reviews'][0]['note'],'기존 점검')

"""Source reception is independent of card registration; preserve original mappings."""
import copy,json,sqlite3,unittest
from urllib.parse import urlencode
import test_v4116 as fixture
import external_documents as docs
import excel_intake
class Base(fixture.ExcelTests):pass
for name in dir(fixture.ExcelTests):
    if name.startswith('test_'):setattr(Base,name,None)
class PendingCardTests(Base):
    def no_cards(self):self.assertEqual(self.c.save({'cards':[]},self.c.admin)[0],200)
    def test_missing_catalog_does_not_block_application_and_total_settlement_reception(self):
        self.no_cards();status,preview,_=self.preview();self.assertEqual(status,200);self.assertEqual(preview['counts']['ready'],1);row=preview['rows'][0];self.assertEqual(row['cardLinkStatus'],'unregistered');self.assertIsNone(row['cardId'])
        status,result,_=self.imported();self.assertEqual(status,200,result);self.assertEqual(result['applications'],1);self.assertEqual(result['settlements'],1);self.assertEqual(result['pendingCards'],1);self.assertEqual(self.a.get_state()['cards'],[]);self.assertEqual(self.a.get_state()['expense'],[])
    def test_ambiguous_suffix_can_receive_without_binds_and_not_generate_a_card(self):
        cards=copy.deepcopy(self.a.get_state()['cards']);cards.append({'id':3,'num':'OTHER-5545','group':'서울','status':'available','company':'시험'});self.c.save({'cards':cards},self.c.admin)
        self.assertEqual(self.imported()[0],200)
        with self.a.db() as conn:doc=docs.load(conn,self.list()['items'][0]['key']);self.assertEqual(doc['selectedCardId'],'');self.assertEqual(doc['selectedCardNum'],'');self.assertEqual(conn.execute('SELECT COUNT(*) FROM external_document_bindings').fetchone()[0],0)
        self.assertEqual(len(self.a.get_state()['cards']),3)
    def test_original_column_mapping_is_preserved_on_both_documents(self):
        self.no_cards();self.imported()
        with self.a.db() as conn:rows=[json.loads(r[0]) for r in conn.execute('SELECT payload FROM external_documents')]
        for row in rows:
            self.assertEqual(row['sourceBank'],fixture.ROW[1]);self.assertEqual(row['sourceIssueDate'],fixture.ROW[9]);self.assertEqual(row['sourceDueDate'],fixture.ROW[10]);self.assertEqual(row['sourceReturnDate'],fixture.ROW[11]);self.assertEqual(row['dept'],fixture.ROW[5]);self.assertEqual(row['sourceAmount'],fixture.ROW[8]);self.assertTrue(row['sourceAssumptions']['applicationDateFromIssue']);self.assertTrue(row['sourceAssumptions']['applicantFromUser'])
        for kind in ('application','settlement'):
            item=self.list(kind)['items'][0];self.assertEqual(item['sourceBank'],fixture.ROW[1]);self.assertEqual(item['sourceReturnDate'],fixture.ROW[11])
    def test_register_later_reupload_stays_duplicate_no_sources_or_bindings_rewritten(self):
        self.no_cards();self.imported();before=self.list()['items'][0]
        cards=[{'id':10,'num':'LATER-5545','group':'서울','status':'available','company':'시험'}];self.c.save({'cards':cards},self.c.admin)
        status,review,_=self.preview();self.assertEqual(review['counts']['duplicate'],1);self.assertEqual(self.list()['items'][0]['key'],before['key']);self.assertEqual(self.list()['total'],1)
    def test_legacy_v4116_hash_still_deduplicates_after_catalog_change(self):
        self.imported()
        with self.a.db() as conn:
            row=excel_intake.normalized(excel_intake.workbook(fixture.upload())['rows'][0][1],'서울',False)
            conn.execute('UPDATE excel_import_rows SET content_hash=?',(excel_intake.digest({**row,'selectedCardNum':'TEST-5545'}),));conn.commit()
        self.c.save({'cards':[]},self.c.admin);status,review,_=self.preview();self.assertEqual(review['counts']['duplicate'],1)
        changed=fixture.ROW.copy();changed[8]=19000;self.assertEqual(self.preview(fixture.upload([changed]))[1]['counts']['conflict'],1)
    def test_wrong_explicit_card_selection_remains_error(self):
        status,review,_=self.preview(fixture.upload()|{'overrides':[{'rowNumber':2,'cardId':2}]});self.assertEqual(review['counts']['error'],1)
    def test_pending_match_becomes_issue_ready_only_after_real_matching_card_registered(self):
        self.no_cards();self.imported();app=self.list()['items'][0];settle=self.list('settlement')['items'][0]
        payload={'applicationKey':app['key'],'settlementKey':settle['key'],'applicationRevision':1,'settlementRevision':1,'confirmed':True};self.assertEqual(self.op('/api/external-matches/create',payload)[0],200)
        def target():return self.c.request('/api/external-matches',cookie=self.c.branch)[1]['items'][0]['target']['phase']
        self.assertEqual(target(),'awaiting_card');self.assertEqual(self.op('/api/cards/rent',{'cardId':1,'dept':'총무팀','user':'시험 사용자','purpose':'업무','dueDate':'2099-01-01'})[0],400)
        self.c.save({'cards':[{'id':1,'num':'LATER-5545','group':'서울','status':'available','company':'시험'}]},self.c.admin);self.assertEqual(target(),'awaiting_issue')
        status,value,_=self.rent(**self.selected(app['key']),user=fixture.ROW[3],applicantName=fixture.ROW[3],purpose='[출장] '+fixture.ROW[7]);self.assertEqual(status,200,value);self.assertEqual(target(),'rented');self.assertFalse(self.a.get_state()['cards'][0]['sourceAdjusted'])
    def test_catalog_changes_never_create_zero_or_missing_amount_settlement(self):
        self.no_cards()
        for amount in (None,0):
            row=fixture.ROW.copy();row[8]='' if amount is None else 0;row[3]+=' '+str(amount);status,value,_=self.imported(fixture.upload([row]));self.assertEqual(status,200,value);self.assertEqual(value['settlements'],0)
        self.assertEqual(self.list()['total'],2);self.assertEqual(self.list('settlement')['total'],0)
    def test_import_still_cannot_use_another_branch_or_fabricate_full_card_number(self):
        self.no_cards();status,value,_=self.preview(fixture.upload()|{'defaultGroup':'인천'});self.assertEqual(value['counts']['error'],1)
        self.imported()
        with self.a.db() as conn:doc=docs.load(conn,self.list()['items'][0]['key'])
        self.assertEqual(doc['selectedCardNum'],'');self.assertFalse(docs.card_matches(doc,{'id':1,'num':'WRONG-9999','group':'서울'}));self.assertFalse(docs.card_matches(doc,{'id':1,'num':'SAME-5545','group':'인천'}))
    def test_original_workflow_columns_are_reference_only_not_yby_approval(self):
        self.no_cards();headers=fixture.HEADERS+['직급','전표','정리','처리확인','불출','관리','사용기간','총분출횟수'];values=fixture.ROW+['직원','접수','완료','확인','처리','종료','2일',10]
        self.assertEqual(self.imported(fixture.upload([values],headers))[0],200)
        with self.a.db() as conn:doc=docs.load(conn,self.list()['items'][0]['key'])
        self.assertEqual(doc['sourceReferences']['position'],'직원');self.assertEqual(doc['sourceReferences']['filingStatus'],'완료');self.assertEqual(doc['sourceReferences']['sourceTotalIssueCount'],'10');self.assertNotEqual(doc['approvalStatus'],'승인완료');self.assertEqual(self.a.get_state()['expense'],[])
    def test_pending_reception_is_atomic_on_storage_failure(self):
        from unittest import mock
        self.no_cards()
        with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('fixture rollback')):self.assertEqual(self.imported()[0],500)
        self.assertEqual(self.list()['total'],0)
if __name__=='__main__':unittest.main()

"""V4.1.21 attachment-based changes: real HTTP, SQLite and race/failure tests."""
import base64,copy,json,sqlite3,unittest
from concurrent.futures import ThreadPoolExecutor
from unittest import mock
import test_security as fixtures
import test_v4 as workflow
import test_v4119 as historical
import business_review
class Workflow122Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):fixtures.SecurityTests.setUpClass()
 @classmethod
 def tearDownClass(cls):fixtures.SecurityTests.tearDownClass()
 def setUp(self):
  self.w=workflow.V4Tests();self.w.setUp();self.c=self.w.c;self.a=self.w.a
  with self.a.db() as db:
   db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_rent','v_card_reg','v_stats','v_expense','v_card_history','v_expense_history']),));db.commit()
 def op(self,path,value,cookie=None):return self.w.operation('/api/cards/'+path,value,cookie or self.c.branch)
 def draft(self,**values):return self.op('draft-save',dict(cardId=1,dept='시험부서',user='시험사용자',purpose='[출장] 업무',applicationDate=self.a.business_date(),applicantName='신청자',dueDate='2099-01-01',attachments=[],**values))
 def seeded(self):
  result=self.draft();self.assertEqual(result[0],200,result);return result[1]['draft']
 def confirm(self,row):return self.op('confirm-draft',{'draftId':row['id'],'expectedVersion':row['version']})
 def test_draft_edit_delete_never_changes_card_or_ledger(self):
  before=copy.deepcopy(self.a.get_state());row=self.seeded()
  result=self.draft(draftId=row['id'],expectedVersion=row['version']);self.assertEqual(result[0],200,result);row=result[1]['draft'];self.assertEqual(len(row['changes']),1)
  self.assertEqual(self.op('draft-delete',{'draftId':row['id'],'expectedVersion':row['version']})[0],200)
  after=self.a.get_state();self.assertEqual(after['cards'],before['cards']);self.assertEqual(after['history'],before['history']);self.assertEqual(after['rentalDrafts'][0]['status'],'삭제')
 def test_confirm_is_atomic_and_idempotent(self):
  row=self.seeded();body={'draftId':row['id'],'expectedVersion':row['version'],'requestId':'confirm-idempotent-122','revision':self.c.state(self.c.branch)['revision']}
  first=self.c.request('/api/cards/confirm-draft',body,self.c.branch);second=self.c.request('/api/cards/confirm-draft',body,self.c.branch);self.assertEqual(first[0],200,first);self.assertEqual(first[1],second[1])
  after=self.a.get_state();self.assertEqual(after['cards'][0]['status'],'rented');self.assertEqual(len(after['history']),1);self.assertEqual(after['rentalDrafts'][0]['status'],'불출확정');self.assertEqual(self.confirm(row)[0],409)
 def test_two_drafts_race_only_one_card_can_be_issued(self):
  one=self.seeded();two=self.seeded();revision=self.c.state(self.c.branch)['revision']
  def go(row):return self.c.request('/api/cards/confirm-draft',{'draftId':row['id'],'expectedVersion':row['version'],'requestId':'race-'+row['id'],'revision':revision},self.c.branch)[0]
  with ThreadPoolExecutor(2) as pool:statuses=list(pool.map(go,[one,two]))
  self.assertEqual(sorted(statuses),[200,409]);self.assertEqual(len(self.a.get_state()['history']),1)
 def test_confirm_failure_rolls_back_draft_and_card(self):
  row=self.seeded();before=copy.deepcopy(self.a.get_state())
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('synthetic failed save')):self.assertEqual(self.confirm(row)[0],500)
  self.assertEqual(self.a.get_state(),before)
 def test_foreign_branch_and_unprivileged_cannot_change_drafts(self):
  row=self.seeded();readonly=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.op('confirm-draft',{'draftId':row['id'],'expectedVersion':row['version']},readonly)[0],403)
  with self.a.db() as db:db.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_card_rent']),));db.commit()
  self.assertEqual(self.c.state(readonly)['state']['rentalDrafts'],[]);self.assertEqual(self.op('draft-delete',{'draftId':row['id'],'expectedVersion':row['version']},readonly)[0],403)
 def test_incident_blocks_both_direct_and_draft_issue_preserves_history(self):
  row=self.seeded();history=copy.deepcopy(self.a.get_state()['history'])
  result=self.op('manage',{'cardId':1,'expectedVersion':'','reason':'분실 신고 접수','managementStatus':'분실','incident':{'recognizedAt':'2026-01-01T00:00:00Z','reporter':'제보자','receiver':'접수자','description':'분실 확인','actions':'사용정지 접수'},'withdrawalAccount':'시험은행 1234','limitAmount':100000});self.assertEqual(result[0],200,result)
  self.assertEqual(self.confirm(row)[0],400);self.assertEqual(self.w.rent()[0],400);state=self.a.get_state();self.assertEqual(state['history'],history);self.assertEqual(state['cards'][0]['limitAmount'],100000);self.assertEqual(len(state['cards'][0]['managementHistory']),1)
  version=state['cards'][0]['managementVersion'];self.assertEqual(self.op('archive',{'cardId':1,'expectedVersion':version,'reason':'재발급 후 사용중지'})[0],200);self.assertTrue(self.a.get_state()['cards'][0]['archived']);self.assertEqual(self.confirm(row)[0],400)
 def test_new_management_fields_cannot_be_changed_through_legacy_save(self):
  card=copy.deepcopy(self.a.get_state()['cards'][0]);card['managementStatus']='분실';self.assertEqual(self.c.save({'cards':[card]},self.c.admin)[0],403)
 def test_attachment_is_scoped_and_preserved_through_issue_return(self):
  file=self.c.request('/api/attachments',{'purpose':'rental','group':'서울','name':'신청서.txt','content':base64.b64encode('시험 출장 문서'.encode()).decode()},self.c.branch);self.assertEqual(file[0],200,file)
  result=self.op('draft-save',{'cardId':1,'dept':'부서','user':'사용자','purpose':'출장','applicationDate':self.a.business_date(),'applicantName':'신청자','dueDate':'2099-01-01','attachments':[{'id':file[1]['attachment_id']}]});self.assertEqual(result[0],200,result)
  row=result[1]['draft'];self.assertEqual(self.confirm(row)[0],200);self.assertEqual(self.op('return',{'cardId':1,'used':False})[0],200)
  self.assertEqual(self.a.get_state()['history'][0]['attachments'][0]['id'],file[1]['attachment_id']);self.assertEqual(self.a.get_state()['history'][1]['attachments'][0]['id'],file[1]['attachment_id'])
  with self.a.db() as db:db.execute("UPDATE users SET scope='인천',permissions_json=? WHERE username='readonly'",(json.dumps(['v_card_rent']),));db.commit()
  other=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.c.request('/api/attachments/'+file[1]['attachment_id'],cookie=other)[0],403)
 def test_item_review_completion_preserves_business_and_old_record(self):
  with self.a.db() as db:
   state=self.a.get_state();state['expenseHistory']=[{'id':1,'group':'서울','requester':'branch','user':'시험','cardNum':'TEST','date':'2026-10-01','amount':1000,'status':'승인완료'}];state['accounts']=self.a.account_metadata(db);self.a.persist_state(db,state,'fixture')
  business=copy.deepcopy(self.a.get_state());value=self.c.request('/api/business-review?period=2026-10',cookie=self.c.branch)[1];target=value['issues'][0]
  body={'period':'2026-10','group':'서울','fingerprint':value['fingerprint'],'target':target,'reviewStatus':'미완료','reference':'시험 명세 001','note':'개별 명세 대조 중입니다','confirmed':True,'acknowledgeIssues':True,'password':'Branch-test-pass!'}
  first=self.w.operation('/api/business-review/acknowledge',body);self.assertEqual(first[0],200,first)
  second=self.w.operation('/api/business-review/acknowledge',{**body,'reviewId':first[1]['review']['id'],'reviewStatus':'완료','note':'원본 명세와 대조 완료'});self.assertEqual(second[0],200,second)
  self.assertEqual(self.a.get_state(),business);result=self.c.request('/api/business-review?period=2026-10',cookie=self.c.branch)[1];self.assertEqual(len(result['reviews']),2);self.assertEqual(result['reviews'][0]['status'],'완료');self.assertEqual(result['reviews'][1]['status'],'미완료')
  self.assertEqual(self.w.operation('/api/business-review/acknowledge',{**body,'reviewId':first[1]['review']['id']})[0],409)
 def test_forged_review_target_cannot_be_saved(self):
  value=self.c.request('/api/business-review?period=2026-10',cookie=self.c.branch)[1]
  result=self.w.operation('/api/business-review/acknowledge',{'period':'2026-10','fingerprint':value['fingerprint'],'target':{'kind':'rented','id':'999','group':'인천'},'reference':'명세서','note':'시험 점검','confirmed':True,'acknowledgeIssues':True,'password':'Branch-test-pass!'})
  self.assertEqual(result[0],409)
 def test_schema9_upgrade_preserves_accounts_ledger_and_attachments(self):
  row=self.seeded();before=copy.deepcopy(self.a.get_state())
  with self.a.db() as db:
   hashes=dict(db.execute('SELECT username,password_hash FROM users'));db.execute('DELETE FROM schema_versions WHERE version>=10');db.execute('DROP TABLE rental_drafts');db.commit()
  marker=self.a.ATTACHMENT_DIR/'synthetic-preservation.txt';marker.write_text('attachment preservation')
  self.a.prepare_db()
  with self.a.db() as db:
   self.assertEqual(db.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],self.a.storage.SCHEMA_VERSION)
   for name,digest in hashes.items():self.assertEqual(db.execute('SELECT password_hash FROM users WHERE username=?',(name,)).fetchone()[0],digest)
  self.assertEqual(self.a.get_state()['cards'],before['cards']);self.assertEqual(self.a.get_state()['history'],before['history']);self.assertEqual(marker.read_text(),'attachment preservation');self.assertTrue(list(self.a.BACKUP_DIR.glob('*before_upgrade.zip')))
 def test_backup_restores_drafts_and_review_records(self):
  import backup_manager,tempfile
  from pathlib import Path
  row=self.seeded()
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);archive=root/'workflow.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,archive);backup_manager.restore(archive,root/'restored')
   with sqlite3.connect(root/'restored'/self.a.DB_PATH.name) as db:
    saved=json.loads(db.execute('SELECT payload FROM rental_drafts').fetchone()[0]);self.assertEqual(saved['id'],row['id']);self.assertEqual(saved['status'],'대기')
class Import122Tests(historical.Base):
 def test_extended_business_correction_preserves_original_and_numbers(self):
  helper=historical.LedgerTests();helper.setUp();ex=helper.seeded();before=copy.deepcopy(helper.a.get_state());patch={'used':True,'returnDate':'2026-10-03','dept':'수정부서','manualProgress':'반납완료 · 정산완료','user':'수정 사용자','cardNum':'확인-5545','cardCompany':'수정은행','date':'2026-10-01','applicationDate':'2026-09-30','applicantName':'수정 신청자','dueDate':'2026-10-04','category':'출장','merchant':'수정 사용처','purpose':'수정 목적','attendees':'참석자','note':'정정 비고'}
  result=helper.correction(ex,patch=patch);self.assertEqual(result[0],200,result);state=helper.a.get_state();row=state['expenseHistory'][0]
  for k,v in patch.items():self.assertEqual(row[k],v)
  for k in ('id','ledgerSerial','group','sourceRef','sourceSnapshot','amount','status'):self.assertEqual(row[k],ex[k])
  self.assertEqual(state['cards'],before['cards']);self.assertEqual(state['history'][0]['user'],'수정 사용자');self.assertEqual(state['history'][0]['cardNum'],'확인-5545');self.assertEqual(len(row['manualCorrections']),1)

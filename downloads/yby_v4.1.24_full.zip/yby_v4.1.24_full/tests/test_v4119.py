"""Input-order numbering, scope-safe linked historical corrections, immutable originals."""
import copy,json,sqlite3,unittest
from unittest import mock
import test_v4118 as f
import test_v4116 as x
class Base(f.HistoricalTests):pass
for name in dir(f.HistoricalTests):
 if name.startswith('test_'):setattr(Base,name,None)
class LedgerTests(Base):
 def seeded(self,data=None,cookie=None):
  status,value,_=self.historic(data,cookie);self.assertEqual(status,200,value);return copy.deepcopy(self.a.get_state()['expenseHistory'][-1])
 def correction(self,ex,cookie=None,**extra):
  return self.op('/api/external-excel/history-correct',{'id':ex['id'],'group':ex['group'],'requester':ex['requester'],'expectedVersion':ex.get('manualVersion',''),'password':'Branch-test-pass!','reason':'원본 확인 후 정정','patch':{'used':True,'returnDate':'2026-10-03','dept':'정정부서','manualProgress':'반납완료 · 정산완료'},**extra},cookie or self.c.branch)
 def test_ledger_serial_input_order_not_use_date_and_retains_on_edit(self):
  ex1=self.seeded();r=x.ROW.copy();r[3]='과거사용';r[9]='2025-01-01';r[11]='2025-01-02';ex2=self.seeded(x.upload([r]));self.assertGreater(ex2['ledgerSerial'],ex1['ledgerSerial']);self.assertTrue(ex1['createdAt']);self.assertEqual(ex1['createdAtBasis'],'등록 시각')
  self.assertEqual(self.correction(ex1)[0],200);after=self.a.get_state()['expenseHistory'][0];self.assertEqual((after['createdAt'],after['ledgerSerial']),(ex1['createdAt'],ex1['ledgerSerial']))
 def test_correction_syncs_only_linked_events_preserves_original_money_current_card_and_dedup(self):
  ex=self.seeded();r=x.ROW.copy();r[3]='다른행';other=self.seeded(x.upload([r]));before=copy.deepcopy(self.a.get_state());self.assertEqual(self.correction(ex)[0],200);state=self.a.get_state();a=state['expenseHistory'][0]
  self.assertEqual(a['dept'],'정정부서');self.assertEqual(a['amount'],ex['amount']);self.assertEqual(a['sourceSnapshot'],ex['sourceSnapshot']);self.assertEqual(state['cards'],before['cards']);self.assertEqual(state['expenseHistory'][1],other)
  events=[h for h in state['history'] if h['expenseRef']['id']==a['id']];self.assertEqual(len(events),2);self.assertTrue(all(h['dept']=='정정부서' for h in events));self.assertEqual(events[1]['returnDate'],'2026-10-03');self.assertEqual(a['manualCorrections'][0]['before']['returnDate'],'2026-10-02');self.assertEqual(self.historic_preview()[1]['counts']['duplicate'],1)
 def test_add_missing_return_remove_restore_without_duplicate_events(self):
  r=x.ROW.copy();r[11]='';ex=self.seeded(x.upload([r]));self.assertEqual(len(self.a.get_state()['history']),1);self.assertEqual(self.correction(ex)[0],200);state=self.a.get_state();self.assertEqual(len(state['history']),2);event=state['history'][1];self.assertTrue(event['ledgerSerial']>state['history'][0]['ledgerSerial']);ex=state['expenseHistory'][0]
  patch={'used':None,'returnDate':'','dept':'정정부서','manualProgress':'반납대기'};self.assertEqual(self.correction(ex,patch=patch)[0],200);state=self.a.get_state();self.assertTrue(state['history'][1]['voidedReturn']);self.assertIsNone(state['expenseHistory'][0]['returnEventId'])
  self.assertEqual(self.correction(state['expenseHistory'][0])[0],200);state=self.a.get_state();self.assertEqual(len(state['history']),2);self.assertEqual(state['history'][1]['id'],event['id']);self.assertFalse(state['history'][1]['voidedReturn']);self.assertEqual(len(state['expenseHistory'][0]['manualCorrections']),3)
 def test_wrong_password_reason_scope_and_readonly_cannot_correct(self):
  ex=self.seeded();before=copy.deepcopy(self.a.get_state());self.assertEqual(self.correction(ex,password='wrong')[0],403);self.assertEqual(self.correction(ex,reason='')[0],400)
  with self.a.db() as c:c.execute('UPDATE users SET scope=? WHERE username=?',('인천','readonly'));c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_rent','v_expense']),'readonly'));c.commit()
  foreign=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.correction(ex,cookie=foreign)[0],403);self.assertEqual(self.a.get_state(),before)
 def test_history_only_permissions_are_denied_and_admin_can_correct_other_branch(self):
  ex=self.seeded()
  with self.a.db() as c:c.execute('UPDATE users SET permissions_json=? WHERE username=?',(json.dumps(['v_card_history','v_expense_history']),'readonly'));c.commit()
  reader=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.correction(ex,cookie=reader)[0],403);self.assertEqual(self.correction(ex,cookie=self.c.admin,password='Admin-test-pass!')[0],200)
 def test_unknown_fields_inconsistent_states_and_invalid_dates_do_not_write(self):
  ex=self.seeded();base={'used':True,'returnDate':'2026-10-03','dept':'정정','manualProgress':''}
  for change in ({'amount':1},{'used':'yes'},{'returnDate':'2025-01-01'},{'returnDate':'bad'},{'returnDate':'','manualProgress':'반납완료 · 정산완료'},{'manualProgress':'승인완료'},{'manualProgress':'반납대기'},{'manualProgress':'반납완료 · 미사용'},{'used':False,'manualProgress':'반납완료 · 정산완료'}):self.assertEqual(self.correction(ex,patch=base|change)[0],400,change)
  self.assertEqual(len(self.a.get_state()['expenseHistory'][0].get('manualCorrections',[])),0)
  self.assertEqual(self.correction(ex,patch={'used':ex['used'],'returnDate':ex['returnDate'],'dept':ex['dept'],'manualProgress':''})[0],400)
 def test_stale_revision_or_manual_version_prevents_lost_updates(self):
  ex=self.seeded();self.assertEqual(self.correction(ex)[0],200);self.assertEqual(self.correction(ex)[0],409);self.assertEqual(len(self.a.get_state()['expenseHistory'][0]['manualCorrections']),1)
 def test_failure_rolls_back_corrected_records_registry_and_audit(self):
  ex=self.seeded();before=copy.deepcopy(self.a.get_state())
  with self.a.db() as c:registry=c.execute('SELECT payload FROM excel_import_rows').fetchone()[0]
  with mock.patch.object(self.a.storage,'write',side_effect=sqlite3.OperationalError('correction rollback fixture')):self.assertEqual(self.correction(ex)[0],500)
  self.assertEqual(self.a.get_state(),before)
  with self.a.db() as c:self.assertEqual(c.execute('SELECT payload FROM excel_import_rows').fetchone()[0],registry)
 def test_generic_state_cannot_modify_order_or_correction_or_original_snapshot(self):
  ex=self.seeded();self.correction(ex)
  for field,value in [('dept','위조'),('ledgerSerial',99),('createdAt','2020-01-01'),('manualCorrections',[])]:
   rows=copy.deepcopy(self.a.get_state()['expenseHistory']);rows[0][field]=value;self.assertEqual(self.c.save({'expenseHistory':rows},self.c.admin)[0],403)
 def test_non_imported_history_cannot_be_manually_corrected(self):
  self.rent();self.op('/api/cards/return',{'cardId':1,'used':False});h=self.a.get_state()['history'][0];self.assertEqual(self.correction({'id':h['id'],'group':'서울','requester':'branch'})[0],400)
 def test_backup_preserves_corrections_order_and_original_snapshot(self):
  import backup_manager,tempfile
  from pathlib import Path
  ex=self.seeded();self.correction(ex)
  with tempfile.TemporaryDirectory() as folder:
   out=Path(folder)/'full.zip';backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,out);dest=Path(folder)/'restored';backup_manager.restore(out,dest)
   with sqlite3.connect(dest/self.a.DB_PATH.name) as c:row=json.loads(c.execute('SELECT payload FROM expense_ledger').fetchone()[0]);self.assertEqual(row['ledgerSerial'],ex['ledgerSerial']);self.assertEqual(row['sourceSnapshot'],ex['sourceSnapshot']);self.assertEqual(len(row['manualCorrections']),1)
if __name__=='__main__':unittest.main()

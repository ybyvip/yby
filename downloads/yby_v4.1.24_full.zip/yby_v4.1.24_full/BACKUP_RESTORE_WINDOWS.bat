@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
where py.exe >nul 2>&1
if not errorlevel 1 goto use_py
where python.exe >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.11 이상을 설치하고 PATH에 추가하세요.
pause
exit /b 1
:use_py
py -3 "%~dp0maintenance_wizard.py" %*
goto finished
:use_python
python "%~dp0maintenance_wizard.py" %*
:finished
set "RESULT=%ERRORLEVEL%"
echo.
echo 백업·복구 안내를 확인하세요. 프로그램을 시작하려면 RUN_LAN_WINDOWS.bat를 실행하세요.
pause
exit /b %RESULT%

# 화면·코드 구조와 유지보수 방법

## 큰 단일 HTML 분리

기존 templates/index.html 약3,913줄에서 CSS와 주요 JavaScript를 분리해 HTML은 약800줄입니다. 기존 전역 함수/실행 순서를 유지해 업무 모듈과 호환되도록 했습니다. 새 기능을 붙일 때 HTML에 업무 코드를 다시 누적하지 않습니다.

| 파일 | 담당 |
|---|---|
| templates/index.html | 화면 뼈대·폼/메뉴와 스크립트 로드 순서 |
| static/app-v4121.css | 기존 공통 화면 스타일 |
| static/app-core-v4121.js | 상태·동기화·공지·메모·공통 데이터 |
| static/app-auth-v4121.js | 로그인·로그아웃·권한·메뉴/대시보드 |
| static/app-cards-v4121.js | 카드 현황·불출/반납·명세 입력 |
| static/app-ledgers-v4121.js | 대장·정산/결재·내부보고·재보고 |
| static/app-admin-v4121.js | 계정·권한·비밀번호 UI·공통 모달 |
| static/app-collaboration-v4121.js | 채팅·쪽지·화면 보호·별도 창 |
| static/stability-v4121.js/css | 업무 점검·회사 정책·백업 관리 |
| static/*v4114~v4119*.js | 기존 하이패스/통계/Excel/대장/매칭 전용 모듈 |
| stability_api.py | 새 기능 HTTP 경계·권한·재인증 |
| business_review.py | 지점별 월별 집계·미결·점검 기록 |
| company_policy.py | 회사 정책·지점 마스터·변경 감사 |
| reauthentication.py / attachment_guard.py | 재인증 예산·문서 형식 검사 |
| backup_crypto.py / backup_manager.py / backup_operations.py | 암호화·검증/복원·보존/별도 보관/예약 |

## 다음 변경 시 원칙

- 권한·금액·날짜·상태는 서버가 검사합니다. UI 숨김만으로 권한을 구현하지 않습니다.
- 원본과 취소/정정 이력, 이관과 승인, 본인/다른 지점 자료의 경계를 유지합니다.
- 새 업무는 전용 API·requestId·revision·트랜잭션·실패 검사를 사용합니다. 상태 통째 덮어쓰기 경로를 우회로로 추가하지 않습니다.
- 화면 모듈 로드 순서와 전역 함수 이름을 바꾸면 로그인·모달·보고서·메신저까지 회귀 검사합니다.
- 이후 ES모듈/컴포넌트와 업무별 부분 DB 갱신으로 전환할 때는 작은 단위로 나누어 자료 호환을 검증합니다. 이번 분리는 프레임워크 전면 재작성이나 모든 전역 결합 제거가 아닙니다.
- 배포 전에 MANIFEST/ZIP 해시·PowerShell BOM·추출 기동·기존 버전 업데이트·다운로드를 확인합니다. 회사 실제 자료·암호·키·운영 설정은 공개 ZIP에 넣지 않습니다.

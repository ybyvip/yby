"""Explicit historical XLSX -> immutable ledgers. Never operates live cards or approves."""
import copy,json,re,uuid
import domain,excel_intake,external_matching,external_documents as docs


def require(a,user):
    external_matching.require(a,user)
    a.require_permission(user,'v_card_rent','v_card_history')
    a.require_permission(user,'v_expense','v_expense_history')

def old_record(conn,key):
    row=conn.execute('SELECT payload FROM excel_import_rows WHERE record_key=?',(key,)).fetchone()
    return json.loads(row[0]) if row else None

def source_bindings(conn,record):
    return [(key,conn.execute('SELECT target_ref FROM external_document_bindings WHERE document_key=?',(key,)).fetchone()) for key in ((record or {}).get('applicationKey'),(record or {}).get('settlementKey')) if key]

def preview(a,conn,state,data,user,scope):
    require(a,user);review=excel_intake.preview(a,conn,state,data,user,scope);seen=set()
    for row in review['rows']:
        if row['status'] not in ('ready','duplicate'):continue
        if row['rowKey'] in seen:
            row['status']='duplicate';continue
        seen.add(row['rowKey'])
        record=old_record(conn,row['rowKey'])
        if (record or {}).get('historyRef'):
            row['status']='duplicate';row['warnings'].append('이력대장에 이미 반영한 원본입니다.')
        elif any(binding for key,binding in source_bindings(conn,record)):
            row['status']='conflict';row['warnings'].append('이미 불출·반납·정산 업무에 적용한 원본입니다. 중복 이관하지 않습니다.')
        else:
            row['status']='ready'
            if record:row['warnings'].append('기존 수신 자료를 재생성하지 않고 이력대장으로 이관합니다.')
        row['warnings']=[w for w in row['warnings'] if not w.startswith(('금액 없음:', '0원:', '세부 거래 없음:', '카드 등록 전 수신 가능', '끝자리 중복 · 수신 후'))]
        row['warnings'].append('과거 이력으로 반영 · 현재 카드 상태 변경 없음 · YBY 결재 기록 아님')
        if row.get('amount') is None:row['warnings'].append('금액미기재를 원본대로 보존하며 사용금액 합계에서 제외합니다.')
        row['historyExpenseStatus']='이관완료' if isinstance(row.get('amount'),int) and row['amount']>0 else '금액미기재' if row.get('amount') is None else '금액0원'
        row['historyEventCount']=1+bool(row.get('returnDate'))
        row['historyReturnStatus']='원본 반납완료' if row.get('returnDate') else '원본 미반납'
    review['counts']={status:sum(row['status']==status for row in review['rows']) for status in ('ready','duplicate','conflict','error')}
    ready=[row for row in review['rows'] if row['status']=='ready']
    review['historySummary']={'rows':len(ready),'expenses':len(ready),'issues':len(ready),'returns':sum(bool(r.get('returnDate')) for r in ready),'knownAmount':sum(r['amount'] for r in ready if isinstance(r.get('amount'),int)),'missingAmounts':sum(r.get('amount') is None for r in ready),'unreturned':sum(not r.get('returnDate') for r in ready)}
    return review

def commit(a,conn,state,data,user,scope):
    require(a,user)
    if data.get('confirmed') is not True:raise ValueError('선택 행의 이력대장 직접 반영 내용을 확인하세요.')
    selection=data.get('selectedRows')
    if not isinstance(selection,list) or not 1<=len(selection)<=excel_intake.MAX_ROWS or len(set(selection))!=len(selection) or any(type(x)!=int for x in selection):raise ValueError('반영할 행을 선택하세요.')
    review=preview(a,conn,state,data,user,scope)
    if data.get('fileHash')!=review['fileHash']:raise ValueError('파일이 변경되었습니다. 다시 검사하세요.')
    rows=[r for r in review['rows'] if r['rowNumber'] in selection]
    if len(rows)!=len(selection) or any(r['status'] not in ('ready','duplicate') for r in rows):raise ValueError('선택 행에 오류·기존 업무 적용·충돌이 있습니다. 다시 검사하세요.')
    history=state.setdefault('history',[]);ledger=state.setdefault('expenseHistory',[])
    next_event=max([int(x['id']) for x in history if str(x.get('id','')).isdigit()]+[0])+1
    batch=uuid.uuid4().hex;at=a.now();result={'importedRows':0,'duplicateRows':0,'ledgerRows':0,'issueEvents':0,'returnEvents':0,'missingAmounts':0,'knownAmount':0,'importBatch':batch}
    for row in rows:
        if row['status']=='duplicate':result['duplicateRows']+=1;continue
        key=row['rowKey'];old=old_record(conn,key) or {};expense_id=uuid.uuid4().hex;issue_id=next_event;next_event+=1;return_id=next_event if row['returnDate'] else None
        if return_id is not None:next_event+=1
        ref={'id':expense_id,'group':row['group'],'requester':user}
        source={'key':key,'documentNo':'엑셀 원본 '+review['sheet']+' '+str(row['rowNumber'])+'행','kind':'history','group':row['group'],'revision':1,'approvalStatus':'원본 이관 · YBY 결재 없음'}
        common={'group':row['group'],'cardNum':row['last4'],'cardLast4':row['last4'],'cardNumberBasis':'last4','cardCompany':row['bank'],'dept':row['dept'],'user':row['user'],'purpose':'['+row['category']+'] '+row['purpose'],'applicationDate':row['applicationDate'],'applicantName':row['applicant'],'dueDate':row['dueDate'],'rentDate':row['issueDate'],'entrySource':'EXCEL','inputRoute':'EXCEL_LEDGER','historicalImport':True,'importRecordKey':key,'importBatch':batch,'importedBy':user,'importedAt':at,'sourceRef':source,'sourceSnapshot':{k:copy.deepcopy(row[k]) for k in ('bank','last4','user','applicant','dept','category','purpose','issueDate','applicationDate','dueDate','returnDate','amount','sourceUseCount','sourceReferences','assumptions')},'expenseRef':ref,'used':True if isinstance(row['amount'],int) and row['amount']>0 else None}
        expense={**copy.deepcopy(common),'id':expense_id,'date':row['issueDate'],'requester':user,'requestedAt':'','merchant':'원본 미기재','category':row['category'],'amount':row['amount'],'status':row['historyExpenseStatus'],'rentalEventId':issue_id,'returnEventId':return_id,'returnDate':row['returnDate'],'used':True if isinstance(row['amount'],int) and row['amount']>0 else None,'attachments':[],'note':'엑셀 과거 업무자료 이관. 카드 끝자리만 원본 보존. YBY 승인 기록 아님.'}
        ledger.append(expense)
        history.append({**copy.deepcopy(common),'id':issue_id,'type':'불출','time':row['issueDate'],'rentalEventId':issue_id,'handler':user,'historicalReturnDate':row['returnDate']})
        if return_id is not None:history.append({**copy.deepcopy(common),'id':return_id,'type':'반납','time':row['returnDate'],'returnDate':row['returnDate'],'rentalEventId':issue_id,'handler':user,'used':True if isinstance(row['amount'],int) and row['amount']>0 else None})
        # Previously received but unprocessed sources become handled, preserving snapshots.
        for name,target in [('applicationKey',{'group':row['group'],'rentalEventId':issue_id,'historicalImport':True}),('settlementKey',{**ref,'historicalImport':True})]:
            if old.get(name):docs.bind(conn,docs.load(conn,old[name]),target,user,at)
        stored={**old,'group':row['group'],'last4':row['last4'],'user':row['user'],'dept':row['dept'],'issueDate':row['issueDate'],'returnDate':row['returnDate'],'amount':row['amount'],'sourceUseCount':row['sourceUseCount'],'fileHash':review['fileHash'],'sheet':review['sheet'],'rowNumber':row['rowNumber'],'warnings':row['warnings'],'historyRef':{'expense':ref,'issueId':issue_id,'returnId':return_id,'batch':batch,'at':at,'by':user}}
        if old:conn.execute('UPDATE excel_import_rows SET payload=? WHERE record_key=?',(json.dumps(stored,ensure_ascii=False),key))
        else:conn.execute('INSERT INTO excel_import_rows VALUES(?,?,?,?,?,?)',(key,row['group'],row['contentHash'],json.dumps(stored,ensure_ascii=False),user,at))
        result['importedRows']+=1;result['ledgerRows']+=1;result['issueEvents']+=1;result['returnEvents']+=return_id is not None;result['missingAmounts']+=row['amount'] is None;result['knownAmount']+=row['amount'] if isinstance(row['amount'],int) else 0
    return result

PROGRESS=('','반납대기','반납완료 · 정산확인중','반납완료 · 정산완료','반납완료 · 미사용','확인필요')

def correct(a,conn,state,data,user,scope):
    require(a,user)
    row=next((x for x in state.get('expenseHistory',[]) if str(x.get('id'))==str(data.get('id')) and x.get('group')==data.get('group') and x.get('requester')==data.get('requester')),None)
    if row is None:raise ValueError('이관 이력을 찾을 수 없습니다.')
    if scope!='ALL' and scope!=row.get('group'):raise PermissionError('다른 지점 이력은 정정할 수 없습니다.')
    if not row.get('historicalImport') or row.get('inputRoute')!='EXCEL_LEDGER':raise PermissionError('엑셀 직접 이관 자료만 수기 정정할 수 있습니다.')
    if data.get('expectedVersion','')!=row.get('manualVersion',''):raise a.StateConflict('다른 사용자가 정정했습니다. 최신 이력을 확인하세요.')
    reason=docs.short(data.get('reason',''),'정정 사유',True)
    digest=conn.execute('SELECT password_hash FROM users WHERE username=? AND active=1',(user,)).fetchone()
    if not digest or not a.verify_password(digest[0],data.get('password','')):raise PermissionError('현재 로그인 비밀번호를 확인하세요.')
    patch=data.get('patch')
    if not isinstance(patch,dict) or not {'used','returnDate','dept','manualProgress'}<=set(patch) or set(patch)-{'used','returnDate','dept','manualProgress','user','cardNum','cardCompany','date','applicationDate','applicantName','dueDate','category','merchant','purpose','attendees','note'}:raise ValueError('허용된 업무 항목만 정정할 수 있습니다.')
    used=patch.get('used');returned=patch.get('returnDate');dept=docs.short(patch.get('dept'),'부서',True);progress=patch.get('manualProgress')
    if used is not None and type(used)!=bool:raise ValueError('사용 여부를 확인하세요.')
    if not isinstance(returned,str):raise ValueError('반납일 형식 오류')
    domain.date_value(returned,'반납일')
    if returned and returned<patch.get('date',row['date']):raise ValueError('반납일이 지급일보다 빠릅니다.')
    if progress not in PROGRESS:raise ValueError('진행상태를 확인하세요.')
    if progress.startswith('반납완료') and not returned:raise ValueError('반납완료 상태에는 반납일이 필요합니다.')
    if progress=='반납대기' and returned:raise ValueError('반납대기는 반납일을 비운 뒤 선택하세요.')
    if progress=='반납완료 · 미사용' and used is not False:raise ValueError('미사용 상태는 사용 여부를 미사용으로 지정하세요.')
    if progress=='반납완료 · 정산완료' and used is False:raise ValueError('미사용은 미사용 반납 상태를 선택하세요.')
    extras={}
    for key in set(patch)-{'used','returnDate','dept','manualProgress'}:
        if key in ('date','applicationDate','dueDate'):
            domain.date_value(patch[key],key,key=='date');extras[key]=patch[key]
        else:extras[key]=docs.short(patch[key],key,key in ('user','cardNum','purpose'))
    issue_date=extras.get('date',row['date'])
    if returned and returned<issue_date:raise ValueError('반납일이 불출일보다 빠릅니다.')
    if extras.get('dueDate') and extras['dueDate']<issue_date:raise ValueError('반납예정일이 불출일보다 빠릅니다.')
    fields=('used','returnDate','dept','manualProgress',*extras)
    before={k:row.get(k) for k in fields};before['used']=row.get('used',True if isinstance(row.get('amount'),int) and row['amount']>0 else None);before['manualProgress']=row.get('manualProgress','');after={'used':used,'returnDate':returned,'dept':dept,'manualProgress':progress,**extras}
    if before==after:raise ValueError('변경된 항목이 없습니다.')
    record=old_record(conn,row['importRecordKey'])
    if not record or (record.get('historyRef') or {}).get('expense',{}).get('id')!=row['id']:raise ValueError('원본 이관 연결을 확인할 수 없습니다.')
    events=[h for h in state.get('history',[]) if h.get('importRecordKey')==row['importRecordKey'] and h.get('group')==row['group'] and h.get('expenseRef',{}).get('id')==row['id'] and h.get('historicalImport')]
    issue=next((h for h in events if h.get('type')=='불출'),None);ret=next((h for h in events if h.get('type')=='반납'),None)
    if not issue:raise ValueError('연결된 불출 이력을 찾을 수 없습니다.')
    at=a.now();version=uuid.uuid4().hex
    if returned and ret is None:
        ret=copy.deepcopy(issue)
        for k in ('id','ledgerSerial','createdAt','createdAtBasis','historicalReturnDate','manualCorrections'):ret.pop(k,None)
        ret.update(id=max([int(h['id']) for h in state['history'] if str(h.get('id','')).isdigit()]+[0])+1,type='반납',time=returned,handler=user)
        # A newly added return is entered now, not at the old import time.
        ret['importedAt']=at;state['history'].append(ret);events.append(ret)
    row.update(after,manualVersion=version,correctedAt=at,correctedBy=user,returnEventId=ret['id'] if ret and returned else None)
    for h in events:
        h.update({k:v for k,v in extras.items() if k not in ('date','note')})
        if 'date' in extras:
            h['rentDate']=extras['date']
            if h['type']=='불출':h['time']=extras['date']
        h.update(dept=dept,used=used,manualProgress=progress,manualVersion=version,correctedAt=at,correctedBy=user)
        if h['type']=='불출':h['historicalReturnDate']=returned
        else:h.update(returnDate=returned,voidedReturn=not bool(returned),time=returned or h.get('time',''))
    change={'version':version,'time':at,'actor':user,'reason':reason,'before':before,'after':after}
    row.setdefault('manualCorrections',[]).append(change)
    record['historyRef']['returnId']=row['returnEventId'];record['historyRef']['manualVersion']=version
    conn.execute('UPDATE excel_import_rows SET payload=? WHERE record_key=?',(json.dumps(record,ensure_ascii=False),row['importRecordKey']))
    return {'expenseRef':{'id':row['id'],'group':row['group'],'requester':row['requester']},'manualVersion':version,'returnEventId':row['returnEventId']}

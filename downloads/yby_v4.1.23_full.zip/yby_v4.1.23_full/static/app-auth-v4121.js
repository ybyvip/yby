/* YBY V4.1.21 auth screen module; global compatibility preserved. */
const loginBackdrop={active:false,timer:null,weatherTimer:null,weather:null,fetching:false,controller:null,
    layer:0,scene:'day',loadingScene:null,failedScene:null,serial:0,manualUntil:0,motion:false,weatherPolls:0,weatherRetry:null,weatherRetries:0};
const loginScenes={day:'낮의 해변',sunrise:'아침 햇살의 해변',sunset:'노을의 해변',night:'달빛 아래 해변',rain:'비 오는 해변',snow:'겨울 바다',classic:'처음의 해변'};
function selectLoginScene(hour,condition){
    if(hour<5||hour>=19)return 'night';
    if(condition==='snow')return 'snow';
    if(condition==='rain')return 'rain';
    if(hour<9)return 'sunrise';
    if(hour>=17)return 'sunset';
    return 'day';
}
function loginWeatherUsable(weather,now=Date.now()){
    if(!weather||weather.ready!==true||!['clear','cloudy','rain','snow'].includes(weather.condition))return false;
    const stamp=Date.parse(weather.forecastAt),age=now-stamp;
    return Number.isFinite(stamp)&&age>=-3600000&&age<=10800000&&Number.isFinite(weather.temperatureC)&&weather.temperatureC>=-80&&weather.temperatureC<=60;
}
function setLoginMotion(enabled){
    loginBackdrop.motion=!!enabled;
    const modal=document.getElementById('loginModal'),button=document.getElementById('loginMotion');
    modal.dataset.motion=enabled?'on':'off';
    button.textContent=enabled?'움직임 끄기':'움직임 켜기';button.setAttribute('aria-pressed',String(enabled));
}
function toggleLoginMotion(){
    setLoginMotion(!loginBackdrop.motion);
    try{localStorage.setItem('ybyLoginMotion',loginBackdrop.motion?'on':'off');}catch(_){}
}
function applyLoginScene(key){
    if(!Object.hasOwn(loginScenes,key)||!loginBackdrop.active)return;
    document.getElementById('loginSceneLabel').textContent=loginScenes[key]+(loginBackdrop.manualUntil?' · 미리보기':'');
    if(loginBackdrop.scene===key){loginBackdrop.serial++;loginBackdrop.loadingScene=null;return;}
    if(loginBackdrop.loadingScene===key)return;
    if(loginBackdrop.failedScene?.key===key&&Date.now()-loginBackdrop.failedScene.time<60000)return;
    loginBackdrop.loadingScene=key;
    const serial=++loginBackdrop.serial,image=new Image();
    image.onload=()=>{
        if(!loginBackdrop.active||serial!==loginBackdrop.serial)return;
        const layers=document.querySelectorAll('.login-scene'),next=1-loginBackdrop.layer;
        layers[next].style.backgroundImage=`url('/static/login-${key}-v416.jpg')`;
        layers[next].classList.add('is-active');layers[loginBackdrop.layer].classList.remove('is-active');
        loginBackdrop.layer=next;loginBackdrop.scene=key;loginBackdrop.loadingScene=null;loginBackdrop.failedScene=null;
        document.getElementById('loginModal').dataset.scene=key;
    };
    image.onerror=()=>{if(loginBackdrop.active&&serial===loginBackdrop.serial){loginBackdrop.loadingScene=null;loginBackdrop.failedScene={key,time:Date.now()};document.getElementById('loginSceneLabel').textContent=loginScenes[loginBackdrop.scene]+' · 사진 연결 대기';}};
    image.src=`/static/login-${key}-v416.jpg`;
}
function updateLoginAtmosphere(now=new Date()){
    if(!loginBackdrop.active)return;
    const modal=document.getElementById('loginModal');
    modal.dataset.visible=String(!document.hidden);
    if(document.hidden)return;
    const time=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(now);
    document.getElementById('loginClock').textContent=time;
    document.getElementById('loginDate').textContent=new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'long',day:'numeric',weekday:'long'}).format(now);
    const valid=loginWeatherUsable(loginBackdrop.weather,now.getTime());
    const condition=valid?loginBackdrop.weather.condition:'clear';
    modal.dataset.weather=condition;
    const weatherText=valid?`청주시 · ${loginBackdrop.weather.description||'날씨 예보'} · ${Math.round(loginBackdrop.weather.temperatureC)}°C${loginBackdrop.weather.stale?' · 최근 예보':''}`:'청주시 · 날씨 연결 대기 · 시간대 배경';
    document.getElementById('loginWeather').textContent=weatherText;
    if(loginBackdrop.manualUntil&&Date.now()>=loginBackdrop.manualUntil)loginBackdrop.manualUntil=0;
    document.getElementById('loginAutoScene').hidden=!loginBackdrop.manualUntil;
    if(!loginBackdrop.manualUntil)applyLoginScene(selectLoginScene(Number(time.slice(0,2)),condition));
}
function nextLoginScene(){
    const keys=Object.keys(loginScenes),key=keys[(keys.indexOf(loginBackdrop.scene)+1)%keys.length];
    loginBackdrop.manualUntil=Date.now()+300000;document.getElementById('loginAutoScene').hidden=false;
    applyLoginScene(key);
}
function resumeLoginScenes(){loginBackdrop.manualUntil=0;updateLoginAtmosphere();}
async function refreshLoginWeather(){
    if(!loginBackdrop.active||loginBackdrop.fetching||document.hidden)return;
    loginBackdrop.fetching=true;loginBackdrop.weatherPolls++;
    const controller=new AbortController();loginBackdrop.controller=controller;
    const timeout=setTimeout(()=>controller.abort(),4500);
    try{
        const response=await fetch('/api/login-weather',{cache:'no-store',credentials:'omit',signal:controller.signal});
        if(response.ok){const data=await response.json();if(loginBackdrop.active&&loginBackdrop.controller===controller){
            loginBackdrop.weather=data;
            if(data.loading&&!data.ready&&loginBackdrop.weatherRetries<4){
                loginBackdrop.weatherRetries++;clearTimeout(loginBackdrop.weatherRetry);
                loginBackdrop.weatherRetry=setTimeout(refreshLoginWeather,1600);
            }
        }}
    }catch(_){/* A weather outage never prevents authentication. */}
    finally{
        clearTimeout(timeout);
        if(loginBackdrop.controller===controller){loginBackdrop.controller=null;loginBackdrop.fetching=false;}
        if(loginBackdrop.active)updateLoginAtmosphere();
    }
}
function startLoginBackdrop(){
    if(loginBackdrop.active){updateLoginAtmosphere();return;}
    loginBackdrop.active=true;loginBackdrop.manualUntil=0;loginBackdrop.weatherRetries=0;
    let preference='auto';try{preference=localStorage.getItem('ybyLoginMotion')||'auto';}catch(_){}
    setLoginMotion(preference==='auto'?!matchMedia('(prefers-reduced-motion: reduce)').matches:preference==='on');
    document.getElementById('loginModal').dataset.scene=loginBackdrop.scene;
    updateLoginAtmosphere();refreshLoginWeather();
    loginBackdrop.timer=setInterval(updateLoginAtmosphere,1000);
    loginBackdrop.weatherTimer=setInterval(refreshLoginWeather,600000);
}
function stopLoginBackdrop(){
    loginBackdrop.active=false;loginBackdrop.serial++;loginBackdrop.loadingScene=null;
    clearTimeout(loginBackdrop.weatherRetry);loginBackdrop.weatherRetry=null;
    clearInterval(loginBackdrop.timer);clearInterval(loginBackdrop.weatherTimer);
    loginBackdrop.timer=null;loginBackdrop.weatherTimer=null;
    if(loginBackdrop.controller)loginBackdrop.controller.abort();
    loginBackdrop.controller=null;loginBackdrop.fetching=false;
    document.getElementById('loginModal').dataset.visible='false';
}
document.addEventListener('visibilitychange',()=>{if(loginBackdrop.active)updateLoginAtmosphere();});
matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',event=>{
    let preference=null;try{preference=localStorage.getItem('ybyLoginMotion');}catch(_){}
    if(!preference)setLoginMotion(!event.matches);
});

async function initLoginScreen() {
    resizeDesktopClient('login');
    startLoginBackdrop();
    ensureAdminLoginFallback();
    const select=document.getElementById('loginUserSelect');
    const status=document.getElementById('loginAccountStatus');
    if(status)status.textContent=`서버 계정 확인 중 · ${location.host}`;
    let serverListLoaded=false, serverVersion='알 수 없음', serverCount=0, loadError='';
    let timeoutId;
    try {
        const fetchAccounts=(async()=>{
        const r=await fetch(`/api/bootstrap?client=${encodeURIComponent('4.1.21')}`,{cache:'no-store',credentials:'same-origin'});
            if(!r.ok)throw new Error(`서버 응답 HTTP ${r.status}`);
            return await r.json();
        })();
        const timeout=new Promise((_,reject)=>{timeoutId=setTimeout(()=>reject(new Error('8초 동안 서버 응답이 없습니다. 서버 실행창과 접속 주소를 확인해 주세요.')),8000);});
        const b=await Promise.race([fetchAccounts,timeout]);
        if (!Array.isArray(b.users)) throw new Error('서버 계정 응답 형식 오류');
        if(b.branches)applyCompanyPolicy({...(stability.policy||{}),branches:b.branches});
        const localAccounts=accountsData, serverAccounts={};
        b.users.forEach(u => {
            if(!u || !u.username) return;
            const cached=localAccounts[u.username]||{};
            serverAccounts[u.username]={...cached,scope:u.scope||cached.scope||'ALL',
                permissions:Array.isArray(u.permissions)?u.permissions:(cached.permissions||[])};

        });
        accountsData=serverAccounts;for(const info of Object.values(accountsData)){delete info.passwordHash;delete info.pw;}
        cacheCurrentState();
        serverListLoaded=true;serverVersion=b.version||'알 수 없음';serverCount=Object.keys(serverAccounts).length;
    } catch(e) {
        loadError=e?.message||String(e);
        console.error('서버 로그인 계정 목록 조회 실패:',e);
    } finally {
        if(timeoutId)clearTimeout(timeoutId);
    }
    // Keep the server-rendered options if client-side bootstrap fails.
    if(serverListLoaded)renderLoginUserSelect();
    const retry=document.getElementById('retryLoginAccounts');
    if(retry)retry.style.display=serverListLoaded?'none':'inline-block';
    if(!serverListLoaded)document.querySelector('.login-server-details').open=true;
    if(status){
        status.textContent=serverListLoaded
            ? `연결 서버 ${location.host} · 버전 ${serverVersion} · 활성 계정 ${serverCount}개`
            : `서버 목록 조회 실패 · ${location.host} · ${loadError||'응답 형식 오류'} (다시 확인을 누르세요)`;
        status.style.color=serverListLoaded?'#15803d':'#b91c1c';
    }
    try { await migrateAccountPasswords(); } catch(e) { console.warn('password migration skipped', e); }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLoginScreen, { once: true });
} else {
    initLoginScreen();
}

function renderLoginUserSelect() {
    ensureAdminLoginFallback();
    const list=document.getElementById('loginAccounts');if(!list)return;
    list.replaceChildren();
    for(const username of Object.keys(accountsData)){
        const option=document.createElement('option');option.value=username;list.appendChild(option);
    }
    // Account refresh must not erase credentials being typed by the user.
}
function updateDefaultPasswordNotice() {
    const input=document.getElementById('loginPasswordInput');if(input)input.value='';
    setLoginError('');
}
function setLoginError(message){
    const error=document.getElementById('loginError');if(!error)return;
    error.textContent=message;error.hidden=!message;
}
function resizeDesktopClient(mode){
    const parameters=new URLSearchParams(location.search);
    const desktop=parameters.get('desktop')==='1';
    document.documentElement.dataset.ybyScreen=mode;
    if(!desktop)return;
    document.title=mode==='app'?'YBY 법인카드 · 하이패스':'YBY 로그인';
    // The Windows host restores maximized windows and applies DPI-aware native sizing.
    if(parameters.get('managed')==='1')return;
    const availableWidth=screen.availWidth||1366,availableHeight=screen.availHeight||900;
    const width=Math.min(mode==='app'?1360:440,availableWidth),height=Math.min(mode==='app'?900:720,availableHeight);
    try{window.resizeTo(width,height);window.moveTo((screen.availLeft||0)+Math.max(0,Math.round((availableWidth-width)/2)),(screen.availTop||0)+Math.max(0,Math.round((availableHeight-height)/2)));}catch(_){/* User can maximize a window if browser policy prevents resizing. */}
}
let loginInFlight=false;
async function handleLogin(e) {
    e.preventDefault();if(loginInFlight)return;if(!window.ybyModulesReady||typeof renderCardStatus!=='function'||typeof renderExpenseHistory!=='function'){setLoginError('화면 파일을 준비 중입니다. 잠시 후 다시 시도하거나 새로고침하세요.');return;}
    const u=document.getElementById('loginUserSelect').value.trim(),pw=document.getElementById('loginPasswordInput').value;
    if(!u||!pw){setLoginError('아이디와 비밀번호를 입력해주세요.');return;}
    const button=document.getElementById('loginSubmitButton');
    loginInFlight=true;button.disabled=true;button.textContent='로그인 중…';setLoginError('');
    let loginStage='서버 인증';
    try {
        const response=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:pw})});
        const info=await response.json().catch(()=>({}));
        if(!response.ok){setLoginError(info.message||'아이디 또는 비밀번호를 확인해주세요.');return;}
        document.getElementById('loginPasswordInput').value='';
        if(info.mustChangePassword){await showPasswordChange(pw,true);return;}
        accountsData[info.username]={scope:info.scope,permissions:info.permissions};
        loginStage='서버 자료 불러오기';await loadServerState();
        currentUser=info.username;seedMessageNotificationBaseline();userScope=info.scope;
        if(accountsData[currentUser])accountsData[currentUser].lastLogin=localDateTime(true);
        audit(`'${currentUser}' 로그인`);
        loginStage='화면 초기화';
        document.getElementById('loginModal').style.display='none';
        document.getElementById('appContainer').style.display='flex';
        document.getElementById('currentUserLabel').innerText=currentUser;
        document.getElementById('userScopeLabel').innerText=userScope==='ALL'?'최고관리자 (전체)':userScope+' 지점';
        document.getElementById('adminTreeNode').style.display=userScope==='ALL'?'block':'none';
        stopLoginBackdrop();resizeDesktopClient('app');applyUserPermissions();initApp();
        if(userScope==='ALL')loadAdminAccountDirectory();
        startLiveSync();
    }catch(error){
        console.error(error);setLoginError('로그인 중 연결을 확인하지 못했습니다. ('+loginStage+') '+(error?.message||String(error)));
    }finally{
        loginInFlight=false;button.disabled=false;button.textContent='로그인';
    }
}


async function handleLogout() {
    resetStability();intakeSessionReset();workflowSessionReset();resetExternalMatching();fleetUI.owner=null;fleetUI.openBranches.clear();
    clearCredentialView();
    stopLiveSync();
    await saveQueue;
    try { await fetch('/api/logout', {method:'POST'}); } catch(e) {}
    currentUser = null; userScope = null;serverStateRevision=null;serverSnapshot={};onlineUsers=[];
    clearBusinessCache();
    for(const entry of detachedChatWindows.values()){try{(entry.win||entry.window||entry).close();}catch(_) {}}
    detachedChatWindows.clear();
    cardsData=[];cardHistoryData=[];hipassData=[];hipassBoxLogs=[];expenseData=[];expenseHistoryData=[];
    complaintData=[];reportList=[];auditLogs=[];chatMessagesList=[];inboxMessages=[];customMemos={};noticeData=[];userShortcuts={};
    accountsData=JSON.parse(JSON.stringify(defaultAccounts));
    adminDirectorySerial++;adminPasswordRows=Object.create(null);accountHistoryRows=[];accountHistoryLoaded=false;
    activeDashboardReport=null;returnExpenseFiles=[];chatAttachedFile=null;chatSelectedRecipients=[];chatPickerSelection.clear();
    if(chatPreviewUrl){URL.revokeObjectURL(chatPreviewUrl);chatPreviewUrl=null;}
    pendingChatNotifications.length=0;seenChatNotificationIds.clear();seenInboxNotificationIds.clear();
    document.getElementById('chatNotificationStack').replaceChildren();
    if(chartInstance1){chartInstance1.destroy();chartInstance1=null;}if(chartInstance2){chartInstance2.destroy();chartInstance2=null;}
    document.getElementById('appContainer').innerHTML=initialAppMarkup;
    document.getElementById('modalBody').replaceChildren();document.getElementById('modalFooter').replaceChildren();
    document.getElementById('commonModal').style.display='none';
    const chatPanel=document.querySelector('.chat-area');if(chatPanel){chatPanel.classList.remove('open');chatPanel.style.display='none';}
    document.getElementById("appContainer").style.display = "none";
    document.getElementById("loginModal").style.display = "flex";
    document.getElementById("loginPasswordInput").value = "";
    setLoginError('');
    await initLoginScreen();
}

async function showPasswordChange(currentPassword='', mandatory=false) {
    document.getElementById('modalTitle').textContent=mandatory?'최초 비밀번호 변경':'내 비밀번호 변경';
    document.getElementById('modalBody').innerHTML='<p>새 비밀번호는 10~128자로 입력하세요. 변경 후 다시 로그인해야 합니다.</p><label>현재 비밀번호<input id="ownCurrentPassword" type="password" autocomplete="current-password" style="display:block;width:100%"></label><label>새 비밀번호<input id="ownNewPassword" type="password" autocomplete="new-password" minlength="10" maxlength="128" style="display:block;width:100%"></label><label>새 비밀번호 확인<input id="ownConfirmPassword" type="password" autocomplete="new-password" style="display:block;width:100%"></label><div id="ownPasswordError" style="color:#dc2626"></div>';
    document.getElementById('ownCurrentPassword').value=currentPassword;
    document.getElementById('modalFooter').innerHTML='<button id="ownPasswordSave" class="btn-primary">변경 후 로그아웃</button>';
    const cancel=document.createElement('button');cancel.className='btn-secondary';cancel.textContent='취소';cancel.onclick=async()=>{if(mandatory)await handleLogout();closeModal();};document.getElementById('modalFooter').appendChild(cancel);
    document.getElementById('ownPasswordSave').onclick=async()=>{
        const newPassword=document.getElementById('ownNewPassword').value;
        const error=document.getElementById('ownPasswordError');
        if(newPassword!==document.getElementById('ownConfirmPassword').value){error.textContent='새 비밀번호가 일치하지 않습니다.';return;}
        if(newPassword.length<10||newPassword.length>128){error.textContent='비밀번호는 10~128자로 입력하세요.';return;}
        const button=document.getElementById('ownPasswordSave');button.disabled=true;
        try{
            const r=await fetch('/api/change-password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({currentPassword:document.getElementById('ownCurrentPassword').value,newPassword})});
            const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'변경 실패');
            await handleLogout();closeModal();alert('비밀번호를 변경했습니다. 새 비밀번호로 로그인하세요.');
        }catch(e){error.textContent=e.message;button.disabled=false;}
    };
    document.getElementById('commonModal').style.display='flex';
}

function hasViewPermission(viewId) {
    if(['v_backup_ops','v_company_policy'].includes(viewId))return userScope==='ALL';
    if(viewId==='v_business_review')return userScope==='ALL'||(accountsData[currentUser]?.permissions||[]).some(x=>['v_stats','v_business_review'].includes(x));
    if(viewId==='v_external_match'&&(accountsData[currentUser]?.permissions||[]).some(x=>['v_card_rent','v_expense'].includes(x)))return true;
    if(viewId==='v_admin'&&userScope!=='ALL')return false;
    if(userScope==='ALL')return true;
    if(viewId==='v_hipass_box'&&accountsData[currentUser]?.permissions?.includes('v_hipass_reg'))return true;
    if(['v_hipass_status','v_hipass_history'].includes(viewId)){const p=accountsData[currentUser]?.permissions||[];if(p.includes('v_hipass_reg')||p.includes('v_hipass_box'))return true;}
    const permissions=accountsData[currentUser]?.permissions;
    return Array.isArray(permissions)&&permissions.includes(viewId);
}

function applyUserPermissions() {
    if(currentUser&&accountsData[currentUser])userScope=accountsData[currentUser].scope;
    if(userScope!=='ALL'){adminPasswordRows=Object.create(null);accountHistoryRows=[];clearCredentialView();}
    const label=document.getElementById('userScopeLabel');if(label)label.textContent=userScope==='ALL'?'최고관리자 (전체)':userScope;

    allViewIds.forEach(vId => {
        let navEl = document.getElementById(`nav_${vId}`);
        if(navEl) navEl.style.display = hasViewPermission(vId) ? "block" : "none";
        const panel=document.getElementById(vId);
        if(panel&&!hasViewPermission(vId)){panel.style.display='none';panel.classList.remove('active');}
    });
    if(currentUser&&!document.querySelector('.view-panel.active')){const fallback=allViewIds.find(hasViewPermission);if(fallback)switchView(fallback,document.getElementById('nav_'+fallback));}
    ['dashboard', 'card', 'hipass', 'stats', 'report'].forEach(groupKey => {
        let groupNode = document.getElementById(`menuGroup_${groupKey}`);
        if(groupNode) {
            let subItems = groupNode.querySelectorAll('.sub-item');
            let visibleCount = Array.from(subItems).filter(item => item.style.display !== 'none').length;
            groupNode.style.display = visibleCount > 0 ? 'block' : 'none';
        }
    });
}


let retryOperation=null;
async function businessOperation(path,payload){
    const signature=JSON.stringify([path,{...payload,password:undefined}]);
    if(!retryOperation||retryOperation.signature!==signature)retryOperation={signature,requestId:crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random().toString(36).slice(2),revision:serverStateRevision};
    const operation={...payload,requestId:retryOperation.requestId,revision:retryOperation.revision};
    stateSavePending++;
    try{
        const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(operation)});
        const value=await response.json();
        if(!response.ok||!value.ok){if(response.status===409){retryOperation=null;await loadServerState();initApp();}throw new Error(value.message||'업무 처리 실패');}
        retryOperation=null;await loadServerState();initApp();return value;
    }finally{stateSavePending=Math.max(0,stateSavePending-1);}
}
let lastUserTouch=0;
['pointerdown','keydown','touchstart'].forEach(event=>document.addEventListener(event,()=>{if(!currentUser||Date.now()-lastUserTouch<30000)return;lastUserTouch=Date.now();fetch('/api/session/touch',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{});},{passive:true}));
function updateApprovalChoices(reset=false){
    const reviewer=document.getElementById('approver1'),approver=document.getElementById('approver2');if(!reviewer||!approver)return;
    const group=document.getElementById('repGroup');if(group){group.disabled=userScope!=='ALL';if(userScope!=='ALL')group.value=userScope;}
    const reviewGroup=userScope==='ALL'?(group?.value||'본사'):userScope,owner=JSON.stringify([currentUser,reviewGroup]);
    const previous=[reviewer.value,approver.value],preserve=!reset&&reviewer.dataset.choiceOwner===owner;
    reviewer.replaceChildren(new Option('검토 단계 없음',''));approver.replaceChildren(new Option('최종 승인자 선택',''));
    if(currentUser)reviewer.add(new Option(currentUser+' (본인 · 상신 시 검토 완료)',currentUser));
    Object.entries(accountsData).forEach(([name,info])=>{
        if(info.scope==='ALL')approver.add(new Option(name+(name===currentUser?' (최고관리자 · 본인)':' (최고관리자)'),name));
        if(name!==currentUser&&(info.scope==='ALL'||(info.scope===reviewGroup&&(info.permissions||[]).includes('v_report_box'))))reviewer.add(new Option(name,name));
    });
    const available=(select,value)=>[...select.options].some(option=>option.value===value);
    reviewer.value=preserve&&available(reviewer,previous[0])?previous[0]:currentUser||'';
    const admins=[...approver.options].map(option=>option.value).filter(Boolean);
    const defaultAdmin=userScope==='ALL'&&admins.includes(currentUser)?currentUser:admins.includes('admin')?'admin':admins.length===1?admins[0]:'';
    approver.value=preserve&&available(approver,previous[1])?previous[1]:defaultAdmin;
    reviewer.dataset.choiceOwner=owner;
    document.getElementById('repAuthor').value=currentUser||'';document.getElementById('repAuthor').readOnly=true;
}

function wireMenuKeyboard(){document.querySelectorAll('.sub-item,.node-header').forEach(el=>{if(el.dataset.keyboardWired)return;el.dataset.keyboardWired='1';el.tabIndex=0;el.setAttribute('role','button');el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click();}});});}
function initApp() {
    hydrateBranchSelects();
    refreshWorkflowInbox();
    wireMenuKeyboard();
    updateApprovalChoices();
    const complaintAuthor=document.getElementById('compAuthor');if(complaintAuthor){complaintAuthor.value=currentUser||'';complaintAuthor.readOnly=true;}
    updateRegionTitles();
    renderDashboard();
    renderDashboardNotices();
    renderUserShortcuts();
    renderCardStatus();
    renderRentDropdowns();
    renderCardHistory();
    renderRegisteredCards();
    renderExpenseTable();refreshExternalMatching();
    renderExpenseHistory();
    renderHiPassTable();
    renderHiPassBoxTable();
    renderComplaintTable();
    renderAdminPermissions();
    renderAccessStatus();
    renderReportList();
    updateChatRecipients();
    renderChatMessages();
    updateInboxCount();
    renderMemos();

    let activePanel = document.querySelector(".view-panel.active");
    if(!activePanel || activePanel.style.display === 'none' || !hasViewPermission(activePanel.id)) {
        const firstAllowed=allViewIds.find(id=>hasViewPermission(id));
        if(firstAllowed)switchView(firstAllowed,document.getElementById(`nav_${firstAllowed}`));
    }
}

function updateRegionTitles() {
    document.querySelectorAll(".region-title").forEach(el => {
        el.innerText = userScope === "ALL" ? "전체 통합" : userScope + " 지점";
    });
}

function toggleTreeNode(header) {
    header.classList.toggle("open");
    let subTree = header.nextElementSibling;
    if(subTree) subTree.classList.toggle("open");
}

function switchView(viewId, el) {
    if(!hasViewPermission(viewId)){alert('해당 화면에 대한 접근 권한이 없습니다.');return;}
    if(viewId==='v_business_review')loadBusinessReview();
    if(viewId==='v_backup_ops'&&userScope==='ALL')loadBackupStatus();
    if(viewId==='v_company_policy'&&userScope==='ALL')loadCompanyPolicy();
    if(viewId==='v_admin'&&userScope==='ALL')loadAdminAccountDirectory();
    if(!hasViewPermission(viewId)) {
        alert("해당 화면에 대한 접근 권한이 없습니다.");
        return;
    }

    ledgerEnter(viewId,el);
    document.querySelectorAll(".view-panel").forEach(p => { p.style.display = 'none'; p.classList.remove("active"); });
    let target = document.getElementById(viewId);
    if(target) { target.style.display = "block"; target.classList.add("active"); }

    document.querySelectorAll(".sub-item").forEach(i => i.classList.remove("active"));
    if(el) el.classList.add("active");

    if(viewId === 'v_dashboard') { renderDashboard(); renderDashboardNotices(); renderUserShortcuts(); }
    else if(viewId === 'v_external_match') { refreshExternalMatching(); }
    else if(viewId === 'v_stats') { renderStats(); }
    else if(viewId === 'v_card_history') { renderCardHistory(); }
    else if(viewId === 'v_expense_history') { renderExpenseHistory(); }
    else if(['v_hipass_box','v_hipass_status','v_hipass_history','v_hipass_reg'].includes(viewId)) { renderHiPassTable(); }
    else if(viewId === 'v_access_status') { renderAccessStatus(); }
    else if(viewId === 'v_report_box') { renderReportList(); }
    renderMemos();refreshWorkflowInbox();
}

function renderDashboard() {
    let scopedCards = (userScope === "ALL" ? cardsData : cardsData.filter(c => c.group === userScope)).filter(c=>!c.archived);
    let scopedHipass = userScope === "ALL" ? hipassData : hipassData.filter(h => h.group === userScope);
    let scopedExpense = userScope === "ALL" ? expenseData : expenseData.filter(e => e.group === userScope);

    document.getElementById("dashTotalCards").innerHTML = `${dashboardSummary?.cards??scopedCards.length}개 <small class="dash-abnormal" title="정상 이외의 활성 카드">(${dashboardSummary?.abnormalCards??scopedCards.filter(c=>(c.managementStatus||'정상')!=='정상').length})</small>`;
    document.getElementById("dashRentedCards").innerText = `${dashboardSummary?.rented??scopedCards.filter(c => c.status === 'rented').length}개`;
    document.getElementById("dashPendingExpense").innerText = `${dashboardSummary?.pending??scopedExpense.filter(e => e.status === '승인대기').length}건`;
    document.getElementById("dashHipassCount").innerText = `${dashboardSummary?.hipass??scopedHipass.filter(x=>x.hipassEnabled!==false).length}개`;
    document.getElementById("dashFuelCount").innerText = `${dashboardSummary?.fuel??scopedHipass.filter(x=>x.fuelEnabled).length}개`;
}

let activeDashboardReport = null;
function dashboardEscape(value) {
    return String(value ?? '-').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function openDashboardMetric(metric) {
    const required={cards:['v_card_status','v_card_reg','v_card_rent'],rented:['v_card_status','v_card_rent'],pending:['v_expense'],hipass:['v_hipass_reg','v_hipass_box','v_hipass_status'],fuel:['v_hipass_reg','v_hipass_box','v_hipass_status']}[metric];if(userScope!=='ALL'&&!required.some(hasViewPermission)){alert('요약 수치는 볼 수 있지만 상세 업무 조회 권한은 없습니다.');return;}
    const scopedCards = userScope === 'ALL' ? cardsData : cardsData.filter(c => c.group === userScope);
    const scopedHipass = userScope === 'ALL' ? hipassData : hipassData.filter(h => h.group === userScope);
    const scopedExpense = userScope === 'ALL' ? expenseData : expenseData.filter(e => e.group === userScope);
    const configs = {
        cards: {title:'총 보유 카드 상세 현황', rows:scopedCards, columns:[['소속 지점','group'],['카드사','company'],['카드번호','num'],['상태',r=>r.status==='rented'?'대여 중':'사용 가능'],['사용 부서','dept'],['사용자','user'],['불출일','rentDate'],['반납 예정일','dueDate']]},
        rented: {title:'현재 대여 중 카드 상세 현황', rows:scopedCards.filter(c=>c.status==='rented'), columns:[['소속 지점','group'],['카드사','company'],['카드번호','num'],['사용 부서','dept'],['사용자','user'],['사용 목적','purpose'],['불출일','rentDate'],['반납 예정일','dueDate']]},
        pending: {title:'승인 대기 정산 상세 내역', rows:scopedExpense.filter(e=>e.status==='승인대기'), columns:[['사용일','date'],['소속 지점','group'],['카드번호','cardNum'],['사용자','user'],['사용 부서','dept'],['사용처','merchant'],['사용 목적','purpose'],['금액(원)',r=>Number(r.amount||0).toLocaleString('ko-KR')],['신청자','requester'],['신청 일시','requestedAt']]},
        fuel: {title:'유류대카드 상세 현황', rows:scopedHipass.filter(x=>x.fuelEnabled).map(x=>({...x,...x.fuelCard,hipassUser:x.hipassUser,car:x.car,group:x.group,distributionStatus:fleetStatus(x),review:fleetReview(x)})),columns:[['소속 지점','group'],['분류','classification'],['카드사','company'],['카드번호','num'],['신용/체크','paymentType'],['사용 범위','usageScope'],['실사용자','hipassUser'],['차량번호','car'],['배부 상태','distributionStatus'],['입력 확인','review']]},
        hipass: {title:'하이패스 카드 상세 현황', rows:scopedHipass.filter(x=>x.hipassEnabled!==false), columns:[['소속 지점','group'],['구분','type'],['카드사','company'],['카드번호','num'],['사용자','hipassUser'],['차량번호','car'],['발급일','issueDate'],['반납일','returnDate'],['등록 사유','reason']]}
    };
    const config=configs[metric]; if(!config) return;
    activeDashboardReport={title:config.title, columns:config.columns, rows:config.rows};
    const headers=config.columns.map(c=>`<th style="padding:9px;border:1px solid #cbd5e1;background:#eff6ff;white-space:nowrap;">${dashboardEscape(c[0])}</th>`).join('');
    const body=config.rows.length ? config.rows.map(row=>`<tr>${config.columns.map(col=>`<td style="padding:8px;border:1px solid #cbd5e1;vertical-align:top;">${dashboardEscape(typeof col[1]==='function'?col[1](row):row[col[1]])}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${escapeHtml(config.columns.length)}" style="padding:24px;text-align:center;border:1px solid #cbd5e1;color:#64748b;">해당 내역이 없습니다.</td></tr>`;
    document.getElementById('modalTitle').innerText=`${config.title}`;
    document.getElementById('modalBody').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;color:#475569;"><span>조회 범위: ${dashboardEscape(userScope==='ALL'?'전체 지점':userScope+' 지점')}</span><b>총 ${escapeHtml(config.rows.length)}건</b></div><div style="overflow:auto;max-height:58vh;"><table style="width:100%;border-collapse:collapse;font-size:12px;"><thead><tr>${headers}</tr></thead><tbody>${body}</tbody></table></div>`;
    document.getElementById('modalFooter').innerHTML=`<button class="btn-primary" onclick="printDashboardMetric()">🖨️ 보고서 출력</button><button class="btn-secondary" onclick="closeModal()">닫기</button>`;
    document.getElementById('commonModal').style.display='flex';
}
function printDashboardMetric() {
    if(!activeDashboardReport) return;
    const win=window.open('','_blank');
    if(!win){alert('보고서 창이 차단되었습니다. 브라우저의 팝업 허용 후 다시 시도해 주세요.');return;}
    const report=activeDashboardReport;
    const headers=report.columns.map(c=>`<th>${dashboardEscape(c[0])}</th>`).join('');
    const rows=report.rows.length?report.rows.map(row=>`<tr>${report.columns.map(col=>`<td>${dashboardEscape(typeof col[1]==='function'?col[1](row):row[col[1]])}</td>`).join('')}</tr>`).join(''):`<tr><td colspan="${escapeHtml(report.columns.length)}" class="empty">해당 내역이 없습니다.</td></tr>`;
    win.document.write(`<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>${dashboardEscape(report.title)}</title><style>body{font-family:Arial,'Malgun Gothic',sans-serif;color:#0f172a;margin:24px}h1{font-size:22px;margin:0 0 8px}.meta{color:#475569;margin-bottom:18px;font-size:12px}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #94a3b8;padding:7px;text-align:left;vertical-align:top;word-break:break-word}th{background:#eff6ff}.empty{text-align:center;padding:24px;color:#64748b}@media print{body{margin:10mm}button{display:none}}</style></head><body><h1>${dashboardEscape(report.title)}</h1><div class="meta">조회 범위: ${dashboardEscape(userScope==='ALL'?'전체 지점':userScope+' 지점')}　|　기준 시각: ${dashboardEscape(localDateTime(true))}　|　총 ${escapeHtml(report.rows.length)}건</div><table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table><script>window.onload=()=>window.print()<\/script></body></html>`);
    win.document.close();
}

function renderAccessStatus() {
    let totalAccounts = Object.keys(accountsData).length;
    document.getElementById("statTotalUsers").innerText = `${totalAccounts}개 계정`;
    document.getElementById("statActiveSessions").innerText = onlineUsers.length + "개 세션";
    document.getElementById("statAdminStatus").innerText = onlineUsers.includes("admin") ? "최고관리자 접속중" : "최고관리자 미접속";

    let tbody = document.getElementById("accessListTableBody");
    if(!tbody) return;
    tbody.innerHTML = "";
    let idx = 1;
    Object.keys(accountsData).forEach(accName => {
        let accInfo = accountsData[accName];
        let isCurrentActive = onlineUsers.includes(accName);
        let tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${escapeHtml(idx++)}</td>
            <td><b>${escapeHtml(accName)}</b> ${isCurrentActive ? '<span class="badge badge-approved" style="margin-left:5px;">현재 본인</span>' : ''}</td>
            <td><span class="card-tag tag-${escapeHtml(accInfo.scope === 'ALL' ? '본사' : accInfo.scope)}">${escapeHtml(accInfo.scope)}</span></td>
            <td>${accInfo.scope === 'ALL' ? '<b class="account-role-label">최고관리자</b>' : '지점 담당자'}</td>
            <td>${escapeHtml(accInfo.lastLogin || '기록 없음')}</td>
            <td><span class="badge ${escapeHtml(isCurrentActive ? 'badge-approved' : 'badge-pending')}">${escapeHtml(isCurrentActive ? '접속 중 (Online)' : '대기중 (Offline)')}</span></td>
            <td><code>${escapeHtml(accInfo.ip || '192.168.x.x')}</code></td>
        `;
        tbody.appendChild(tr);
    });
}

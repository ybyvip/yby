"""Immutable, minimal activity journal captured within the business transaction."""
import hashlib,json,uuid
from datetime import datetime,timezone,timedelta,date
SPECS={'notices':('v_notices','공지'),'rentalDrafts':('v_card_rent','불출예정'),'history':('v_card_history','불출·반납'),'expense':('v_expense','정산·결재'),'expenseHistory':('v_expense_history','정산이력'),'cards':('v_card_reg','카드 관리'),'hipass':('v_hipass_box','하이패스 배부'),'hipassBox':('v_hipass_history','하이패스'),'complaint':('v_complaint','민원·고충'),'reports':('v_report_box','보고서')}
def encode(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def digest(v):return hashlib.sha256(encode(v).encode()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat(timespec='microseconds')
def initialize(c):
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_events(event_key TEXT PRIMARY KEY,view TEXT NOT NULL,group_name TEXT NOT NULL,payload_json TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_item_reads(username TEXT NOT NULL,event_key TEXT NOT NULL,read_at TEXT NOT NULL,PRIMARY KEY(username,event_key))')
 c.execute('CREATE TABLE IF NOT EXISTS notice_reads(username TEXT NOT NULL,notice_id TEXT NOT NULL,notice_digest TEXT NOT NULL,first_read_at TEXT NOT NULL,last_read_at TEXT NOT NULL,read_count INTEGER NOT NULL,PRIMARY KEY(username,notice_id,notice_digest))')
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_meta(name TEXT PRIMARY KEY,value TEXT NOT NULL)')
 c.execute('CREATE INDEX IF NOT EXISTS ix_dashboard_events_scope ON dashboard_events(group_name,view)')
def snapshot(state):
 result={}
 for field,(view,kind) in SPECS.items():
  for i,row in enumerate(state.get(field,[])):
   if not isinstance(row,dict):continue
   identity=str(row.get('id',i));group=str(row.get('group',''));title=str(row.get('title') or row.get('cardAlias') or row.get('user') or row.get('hipassUser') or row.get('company') or kind)
   at=str(row.get('updatedAt') or row.get('approvedAt') or row.get('requestedAt') or row.get('time') or row.get('date') or row.get('createdAt') or '')
   safe=dict(id=identity,group=group,view=view,kind=kind,title=title,time=at,status=str(row.get('status') or row.get('action') or row.get('managementStatus') or row.get('distributionStatus') or ''))
   version=digest({k:v for k,v in row.items() if k not in ('cardKey','passwordHash','ledgerSerial','createdAtBasis')})
   result[encode([field,group,identity])]=(safe,version)
   if field=='cards':
    for j,event in enumerate(row.get('managementHistory',[])):
     safe_event={**safe,'time':str(event.get('time') or ''),'title':title+' · '+str((event.get('after') or {}).get('managementStatus','상태 변경')),'status':str((event.get('after') or {}).get('managementStatus',''))}
     result[encode([field,group,identity,'history',j])]=(safe_event,digest(event))
 return result

def insert(c,row,action,backfill=False):
 value={**row,'eventKey':uuid.uuid4().hex,'change':action,'backfilled':backfill}
 if not backfill:value['time']=now()
 value['day']=day(value['time']);c.execute('INSERT INTO dashboard_events VALUES(?,?,?,?)',(value['eventKey'],value['view'],value['group'],encode(value)))
def ensure(c,state):
 initialize(c)
 if c.execute("SELECT 1 FROM dashboard_meta WHERE name='seeded'").fetchone():return
 for row,_ in snapshot(state).values():insert(c,row,'기존 보존 자료',True)
 c.execute("INSERT INTO dashboard_meta VALUES('seeded',?)",(now(),))
def capture(c,before,after):
 ensure(c,before);old=snapshot(before);new=snapshot(after)
 for key,(row,version) in new.items():
  if key not in old or old[key][1]!=version:insert(c,row,'등록' if key not in old else '변경')
 for key,(row,_) in old.items():
  if key not in new:insert(c,{**row,'deleted':True},'삭제')
def day(value):
 try:
  parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
  return (parsed.astimezone(timezone(timedelta(hours=9))) if parsed.tzinfo else parsed).date().isoformat()
 except (ValueError,TypeError,AttributeError):return ''
def allowed(a,user,row,scope=None,perms=None):
 scope=a.user_scope(user) if scope is None else scope;p=a.permissions_for(user) if perms is None else perms;view=row['view']
 if view!='v_notices' and scope not in ('ALL',row['group']):return False
 return scope=='ALL' or view=='v_notices' or view in p or view=='v_report_box' and 'v_report_write' in p or view in ('v_hipass_box','v_hipass_history') and bool(p&{'v_hipass_reg','v_hipass_box'})
def listing(a,c,user,params):
 start=params.get('from',[''])[0];end=params.get('to',[''])[0]
 for val in (start,end):
  if val:
   try:assert date.fromisoformat(val).isoformat()==val
   except (ValueError,AssertionError):raise ValueError('조회 기간은 올바른 날짜로 입력하세요.')
 if start and end and start>end:raise ValueError('시작일이 종료일보다 늦습니다.')
 try:offset=int(params.get('offset',['0'])[0]);limit=int(params.get('limit',['50'])[0]);assert offset>=0 and 1<=limit<=200
 except (ValueError,TypeError,AssertionError):raise ValueError('페이지 범위를 확인하세요.')
 reads=dict(c.execute('SELECT event_key,read_at FROM dashboard_item_reads WHERE username=?',(user,)))
 rows=[];undated=0
 scope=a.user_scope(user);perms=a.permissions_for(user)
 query='SELECT payload_json FROM dashboard_events'+('' if scope=='ALL' else " WHERE group_name=? OR view='v_notices'")
 for saved in c.execute(query,() if scope=='ALL' else (scope,)):
  row=json.loads(saved[0])
  if not allowed(a,user,row,scope,perms):continue
  if not row['day']:undated+=1
  if (start or end) and (not row['day'] or start and row['day']<start or end and row['day']>end):continue
  if row['view']=='v_report_box' and scope!='ALL' and 'v_report_box' not in perms:row['view']='v_report_write'
  rows.append({**row,'readAt':reads.get(row['eventKey'])})
 rows.sort(key=lambda r:(r['day'],r['time'],r['eventKey']),reverse=True)
 return dict(items=rows[offset:offset+limit],total=len(rows),offset=offset,limit=limit,undated=undated)

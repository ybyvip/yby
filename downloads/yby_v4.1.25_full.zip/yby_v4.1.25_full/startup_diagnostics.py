"""Startup-only diagnostics without environment variables or local variable dumps."""
from datetime import datetime,timezone
import os
from pathlib import Path
import sys
import traceback

STAGE='시작 준비'
TARGET=None

def stage(name,target=None):
    global STAGE,TARGET
    STAGE=name;TARGET=str(target) if target is not None else None
    print('[시작 확인] '+name+((': '+TARGET) if TARGET else ''),flush=True)

def report(error,root=None):
    text='\n'.join(['YBY V4.1.25 시작 오류','단계: '+STAGE,
        '대상: '+str(getattr(error,'filename',None) or TARGET or root or '(경로 미제공)'),
        '종류: '+type(error).__name__,'오류: '+str(error),
        'errno: '+str(getattr(error,'errno',None)),'winerror: '+str(getattr(error,'winerror',None)),
        '호출 위치(지역변수/환경변수/비밀번호 미포함):',*traceback.format_tb(error.__traceback__)])
    print(text,file=sys.stderr)
    candidates=[]
    if os.environ.get('LOCALAPPDATA'):candidates.append(Path(os.environ['LOCALAPPDATA'])/'YBY'/'diagnostics')
    if root is not None:candidates.append(Path(root)/'logs')
    for folder in candidates:
        try:
            folder.mkdir(parents=True,exist_ok=True)
            name='startup_error_'+datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')+'_'+str(os.getpid())+'.txt'
            path=folder/name;path.write_text(text,encoding='utf-8');print('오류 진단 파일: '+str(path),file=sys.stderr);break
        except OSError:continue
    print('회사 보안 정책이 차단하면 위 단계·경로와 진단 파일을 IT 담당자에게 전달하세요.',file=sys.stderr)

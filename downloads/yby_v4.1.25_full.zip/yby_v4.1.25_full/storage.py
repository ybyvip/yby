"""Versioned per-record SQLite storage with read-only legacy JSON compatibility."""
import json
import uuid
from datetime import datetime,timezone
SCHEMA_VERSION=13

TABLES = {'rentalDrafts':'rental_drafts','cards':'business_cards','history':'card_events','hipass':'hipass_cards',
          'hipassBox':'hipass_events','expense':'expense_requests','expenseHistory':'expense_ledger',
          'complaint':'complaints','reports':'documents','chat':'messages','inbox':'inbox_messages',
          'notices':'notices'}


def initialize(conn):
    import dashboard_api
    dashboard_api.initialize(conn)
    import external_documents
    external_documents.initialize(conn)
    import external_matching
    external_matching.initialize(conn)
    import external_reception,excel_intake
    external_reception.initialize(conn);excel_intake.initialize(conn)
    for table in TABLES.values():
        conn.execute(f'CREATE TABLE IF NOT EXISTS {table}(record_key TEXT PRIMARY KEY,branch TEXT,actor TEXT,payload TEXT NOT NULL,position INTEGER NOT NULL)')
        conn.execute(f'CREATE INDEX IF NOT EXISTS ix_{table}_branch ON {table}(branch)')
    conn.execute('CREATE TABLE IF NOT EXISTS state_metadata(name TEXT PRIMARY KEY,payload TEXT NOT NULL)')
    conn.execute('CREATE TABLE IF NOT EXISTS operation_receipts(request_id TEXT PRIMARY KEY,actor TEXT NOT NULL,kind TEXT NOT NULL,result_json TEXT NOT NULL,created_at TEXT NOT NULL)')
    conn.execute('CREATE TABLE IF NOT EXISTS password_changes(username TEXT PRIMARY KEY,updated_at TEXT,updated_by TEXT)')
    conn.execute('CREATE TABLE IF NOT EXISTS schema_versions(version INTEGER PRIMARY KEY,installed_at TEXT NOT NULL)')
    conn.execute("INSERT OR IGNORE INTO schema_versions VALUES(?,strftime('%Y-%m-%dT%H:%M:%fZ','now'))",(SCHEMA_VERSION,))


def key(item):
    return json.dumps([str(item.get('group','')),str(item.get('requester') or item.get('author') or item.get('handler') or item.get('sender') or ''),str(item.get('id',''))],ensure_ascii=False)


def read(conn,branch=None):
    head=conn.execute('SELECT state_json FROM system_state WHERE id=1').fetchone()
    if not head:return None
    if head['state_json']:
        value=json.loads(head['state_json'])
        if not isinstance(value,dict):raise ValueError('지원하지 않는 구형 업무 데이터 형식입니다.')
        return value
    result={r['name']:json.loads(r['payload']) for r in conn.execute('SELECT * FROM state_metadata')}
    for field,table in TABLES.items():
        if branch is not None and field in ('rentalDrafts','cards','history','hipass','hipassBox','expense','expenseHistory','complaint','reports'):
            result[field]=[json.loads(r['payload']) for r in conn.execute(f'SELECT payload FROM {table} WHERE branch=? ORDER BY position',(branch,))]
        else:
            result[field]=[json.loads(r['payload']) for r in conn.execute(f'SELECT payload FROM {table} ORDER BY position')]
    return result


def write(conn,state,user,version,revision=None):
    initialize(conn)
    before=read(conn) or {}
    revision=revision or uuid.uuid4().hex
    for field,table in TABLES.items():
        rows=state.get(field,[])
        if not isinstance(rows,list):raise ValueError(field+': 목록 형식이 필요합니다.')
        saved=list(conn.execute(f'SELECT record_key,payload,position FROM {table}'))
        existing={r['record_key']:r['payload'] for r in saved}
        metadata={r['record_key']:(json.loads(r['payload']),r['position']) for r in saved} if field in ('history','expenseHistory') else {}
        serial=max([len(saved)]+[int(v[0].get('ledgerSerial') or v[1]+1) for v in metadata.values()])
        keep=set()
        for position,item in enumerate(rows):
            if not isinstance(item,dict):raise ValueError(field+': 잘못된 항목입니다.')
            identity=key(item)
            # Historical rows without IDs receive stable identities during migration.
            if item.get('id') is None:identity+=':'+str(position)
            if identity in keep:raise ValueError(field+': 중복 식별자가 있습니다.')
            keep.add(identity)
            if field in ('history','expenseHistory'):
                previous,position_before=metadata.get(identity,({},None))
                if position_before is None:serial+=1
                item['ledgerSerial']=int(previous.get('ledgerSerial') or (position_before+1 if position_before is not None else serial))
                if 'createdAt' in previous:item['createdAt']=previous['createdAt']
                elif position_before is not None or user=='migration':
                    original=previous if position_before is not None else item
                    item['createdAt']=original.get('importedAt') or original.get('requestedAt') or original.get('time') or ''
                else:item['createdAt']=item.get('importedAt') or datetime.now(timezone.utc).isoformat(timespec='seconds')
                item['createdAtBasis']=previous.get('createdAtBasis') or ('기존 기록 기준' if position_before is not None or user=='migration' else '등록 시각')
            payload=json.dumps(item,ensure_ascii=False,separators=(',',':'))
            if existing.get(identity)!=payload:
                conn.execute(f'INSERT INTO {table} VALUES(?,?,?,?,?) ON CONFLICT(record_key) DO UPDATE SET branch=excluded.branch,actor=excluded.actor,payload=excluded.payload,position=excluded.position',
                             (identity,str(item.get('group','')),str(item.get('requester') or item.get('author') or item.get('sender') or ''),payload,position))
            else:conn.execute(f'UPDATE {table} SET position=? WHERE record_key=? AND position!=?',(position,identity,position))
        for identity in existing.keys()-keep:conn.execute(f'DELETE FROM {table} WHERE record_key=?',(identity,))
    conn.execute('DELETE FROM state_metadata')
    for name,value in state.items():
        if name not in TABLES:conn.execute('INSERT INTO state_metadata VALUES(?,?)',(name,json.dumps(value,ensure_ascii=False)))
    conn.execute('''INSERT INTO system_state(id,version,state_json,updated_at,updated_by) VALUES(1,?,NULL,?,?)
                    ON CONFLICT(id) DO UPDATE SET version=excluded.version,state_json=NULL,updated_at=excluded.updated_at,updated_by=excluded.updated_by''',(version,revision,user))
    import activity_journal
    activity_journal.capture(conn,before,state)
    return revision


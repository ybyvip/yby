# YBY V4.1.25 — V4.1.24 기반 추가 개선

이번 변경은 [CHANGES_V4_1_25_KO.md](CHANGES_V4_1_25_KO.md), 검증 범위는 [VALIDATION_V4_1_25_KO.md](VALIDATION_V4_1_25_KO.md)를 먼저 확인하세요.

# YBY V4.1.24 — V4.1.23 기반 추가 개선

이번 변경은 [CHANGES_V4_1_24_KO.md](CHANGES_V4_1_24_KO.md), 실제 검증은 [VALIDATION_V4_1_24_KO.md](VALIDATION_V4_1_24_KO.md)를 먼저 확인하세요.

# YBY V4.1.23 — V4.1.22 기반 추가 수정본

이번 추가 수정은 [CHANGES_V4_1_23_KO.md](CHANGES_V4_1_23_KO.md), 실제 검증은 [VALIDATION_V4_1_23_KO.md](VALIDATION_V4_1_23_KO.md)를 먼저 확인하세요.


이번 수정 안내는 [CHANGES_V4_1_22_KO.md](CHANGES_V4_1_22_KO.md), 실제 검증은 [VALIDATION_V4_1_22_KO.md](VALIDATION_V4_1_22_KO.md)를 먼저 확인하세요.

이전 V4.1.21의 변경·설치 순서는 [CHANGES_V4_1_21_KO.md](CHANGES_V4_1_21_KO.md), 실제 검사 결과는 [VALIDATION_V4_1_21_KO.md](VALIDATION_V4_1_21_KO.md)입니다.

1. 기존 운영 자료로 전체백업을 만들고 서버를 Ctrl+C로 중지합니다.
2. 이 전체 ZIP을 새 폴더에 압축 해제하고 RUN_LAN_WINDOWS.bat를 실행합니다. 기존 `%LOCALAPPDATA%\YBY\app\data`를 계속 사용하며 새 data로 덮어쓰지 않습니다.
3. 새 설치는 admin만 생성하며 최초 임시 암호는 서버 창에 무작위로 표시됩니다. 기존 계정은 유지합니다. 신규 계정은 관리자가 필요한 지점·메뉴만 부여해 만듭니다.
4. 비밀번호 열람은 기본 꺼짐이며 관리자 초기화 시 대상 세션만 종료합니다. 자기 승인은 기본 사유·재인증이 필요합니다. 시스템 관리의 회사 정책·지점 관리에서 기준을 확인하세요.
5. 암호화 백업은 INSTALL_BACKUP_ENCRYPTION.bat를 최초1회 실행해 같은 Python에 지원 패키지를 설치합니다. 회사 설치 정책이 막으면 IT 담당자에게 요청하세요.

새 메뉴: 정산 및 통계 → 업무 점검 및 대사 / 시스템 관리 → 백업·복구 관리, 회사 정책·지점 관리.

- [보고서 권고 대응표](REPORT_REMEDIATION_KO.md)
- [자료/새 PC 복구 안내](RECOVERY_GUIDE_KO.md): BACKUP_RESTORE_WINDOWS.bat
- [회사 인수 체크리스트](ACCEPTANCE_CHECKLIST_KO.md)
- [운영 안내](OPERATIONS_GUIDE_KO.md)
- [화면 모듈 구조](ARCHITECTURE_V4_1_21_KO.md)

다른 PC에는 서버 실행 폴더의 LAN_CLIENT만 전달합니다. 개인키를 포함한 재해 복구 백업은 접속용 배포 파일이 아닙니다. Oracle 실제 연결, SSO/MFA·이중화·회계 마감은 완료 항목이 아니며 회사 Windows/새 PC 실기 확인이 필요합니다.

구버전 안내는 docs/legacy에 보관했습니다. 구버전의 초기 암호·실행/복원 절차 대신 현재 안내를 따르세요.
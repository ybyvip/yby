"""Drafts are not reservations. Confirmation joins the existing atomic issue operation."""
import copy, uuid
from datetime import datetime, timezone
import domain, external_documents
MANAGEMENT=('정상','분실','파손','장기사용','교체','사용중지','기타')
def usable(card):return not card.get('archived') and card.get('managementStatus','정상')=='정상'
def finance(data):
    account=external_documents.short(data.get('withdrawalAccount',''),'인출 계좌정보')
    amount=data.get('limitAmount')
    if amount in ('',None):amount=None
    elif type(amount)!=int or not 0<=amount<=10**12:raise ValueError('한도금액은 0~1조 원의 정수입니다.')
    return dict(withdrawalAccount=account,limitAmount=amount)
def draft(a,conn,state,data,user,scope,path,attachments):
    a.require_permission(user,'v_card_rent')
    rows=state.setdefault('rentalDrafts',[])
    row=next((x for x in rows if x['id']==data.get('draftId')),None)
    if data.get('draftId'):
        if not row:raise ValueError('불출예정을 찾을 수 없습니다.')
        if scope not in ('ALL',row['group']):raise PermissionError('다른 지점 불출예정입니다.')
        if row['status']!='대기':raise a.StateConflict('이미 처리된 불출예정입니다.')
        if row['version']!=data.get('expectedVersion'):raise a.StateConflict('불출예정이 변경되었습니다.')
    if path.endswith('/draft-delete'):
        if not row:raise ValueError('불출예정이 필요합니다.')
        row.update(status='삭제',version=uuid.uuid4().hex,updatedAt=a.now(),updatedBy=user)
        return {'draft':row}
    card=next((x for x in state.get('cards',[]) if str(x['id'])==str(data.get('cardId'))),None)
    if not card:raise ValueError('카드가 없습니다.')
    if scope not in ('ALL',card['group']):raise PermissionError('다른 지점 카드입니다.')
    if row and row['group']!=card['group']:raise ValueError('불출예정의 지점은 바꿀 수 없습니다.')
    if not usable(card):raise ValueError('사고·교체·사용중지 또는 삭제된 카드는 불출할 수 없습니다.')
    values={k:external_documents.short(data.get(k,''),k,True) for k in ('dept','user','purpose','applicantName')}
    for k in ('applicationDate','dueDate'):
        domain.date_value(data.get(k),k,True);values[k]=data[k]
    if values['dueDate']<max(values['applicationDate'],a.business_date()):raise ValueError('반납예정일을 확인하세요.')
    if row is None:
        row=dict(id=uuid.uuid4().hex,group=card['group'],createdAt=a.now(),createdBy=user,status='대기',changes=[]);rows.append(row)
    else:row.setdefault('changes',[]).append({k:copy.deepcopy(v) for k,v in row.items() if k!='changes'})
    values.update({k:copy.deepcopy(data[k]) for k in ('externalDocumentId','externalRevision','externalConfirmed','externalMatchVersion') if k in data})
    for k in ('externalDocumentId','externalRevision','externalConfirmed','externalMatchVersion'):row.pop(k,None)
    row.update(values,cardId=card['id'],cardNum=card['num'],attachments=attachments(a,data.get('attachments',[]),user,card['group'],row.get('attachments',[])),version=uuid.uuid4().hex,updatedAt=a.now(),updatedBy=user)
    return {'draft':row}
def manage(a,state,data,user,scope,path):
    a.require_permission(user,'v_card_reg')
    card=next((x for x in state.get('cards',[]) if str(x['id'])==str(data.get('cardId'))),None)
    if card is None:raise ValueError('카드가 없습니다.')
    if scope not in ('ALL',card['group']):raise PermissionError('다른 지점 카드입니다.')
    if data.get('expectedVersion','')!=card.get('managementVersion',''):raise a.StateConflict('카드 관리정보가 변경되었습니다.')
    reason=data.get('reason','')
    if not isinstance(reason,str) or not reason.strip():raise ValueError('변경 사유를 입력하세요. (1~1,000자)')
    if len(reason)>1000:raise ValueError('변경 사유는 1,000자 이내로 입력하세요.')
    reason=reason.strip()
    before=copy.deepcopy({k:v for k,v in card.items() if k not in ('cardKey','managementHistory')})
    if card.get('archived') and not path.endswith('/archive'):raise ValueError('종료된 카드는 변경할 수 없습니다. 종료 이력을 확인하세요.')
    if path.endswith('/archive'):
        if card['status']=='rented':raise ValueError('불출중 카드는 반납 후 삭제하세요.')
        card.update(archived=True,closedAt=a.now(),closedBy=user,closureReason=reason,closingSnapshot=before)
    else:
        status=data.get('managementStatus','정상')
        if status not in MANAGEMENT:raise ValueError('관리 상태 오류')
        if status!='정상':card['incident']=incident(data.get('incident'),user,a.now())
        card.update(finance(data),managementStatus=status)
        for k in ('company','num','userType','assignedUser','issueDate','expiryDate','cardAlias','paymentType','usageScope'):
            if k in data:card[k]=external_documents.short(data[k],k,k in ('company','num'))
        if 'group' in data and data['group']!=card['group']:
            if scope!='ALL':raise PermissionError('지점 이동은 최고관리자만 가능합니다.')
            if card['status']=='rented':raise ValueError('불출 중에는 지점을 바꿀 수 없습니다.')
            card['group']=data['group']
    card['managementVersion']=uuid.uuid4().hex
    after=copy.deepcopy({k:v for k,v in card.items() if k not in ('cardKey','managementHistory')})
    card.setdefault('managementHistory',[]).append(dict(time=a.now(),actor=user,reason=reason,before=before,after=after))
    return {'card':card}

INCIDENT_FIELDS={'recognizedAt':'인지 시점','reporter':'제보자','receiver':'접수자','description':'이상징후 내용','actions':'조치사항'}
def incident(value,user,at):
    if not isinstance(value,dict):raise ValueError('정상 이외의 상태에는 이상징후 접수 내용을 입력하세요.')
    result={}
    for key,label in INCIDENT_FIELDS.items():
        raw=value.get(key,'')
        if not isinstance(raw,str) or not raw.strip() or len(raw)>(4000 if key in ('description','actions') else 200):raise ValueError(label+'을 입력하고 길이를 확인하세요.')
        result[key]=raw.strip()
    try:
        recognized=datetime.fromisoformat(result['recognizedAt'].replace('Z','+00:00'))
        if recognized.tzinfo is None or recognized>datetime.now(timezone.utc):raise ValueError()
    except (TypeError,ValueError):raise ValueError('인지 시점은 시간대가 포함된 현재 이전 시각이어야 합니다.')
    return dict(result,id=uuid.uuid4().hex,recordedBy=user,recordedAt=at)
def replace(a,state,data,user,scope):
    a.require_permission(user,'v_card_reg')
    cards=state.setdefault('cards',[])
    old=next((c for c in cards if str(c['id'])==str(data.get('cardId'))),None)
    if not old:raise ValueError('기존 카드가 없습니다.')
    if scope not in ('ALL',old['group']):raise PermissionError('다른 지점 카드입니다.')
    if old.get('managementVersion','')!=data.get('expectedVersion',''):raise a.StateConflict('기존 카드가 변경되었습니다.')
    if old.get('archived') or old.get('replacedBy'):raise a.StateConflict('이미 종료·대체된 카드입니다.')
    if old['status']=='rented':raise ValueError('불출 중인 카드는 먼저 반납해야 대체할 수 있습니다.')
    replacement=data.get('replacement')
    if not isinstance(replacement,dict):raise ValueError('대체카드 정보를 입력하세요.')
    reason=external_documents.short(data.get('reason'),'대체 사유',True)
    before=copy.deepcopy({k:v for k,v in old.items() if k not in ('cardKey','managementHistory')})
    new_id=max([int(c['id']) for c in cards]+[int(state.get('_next_card_id',0))])+1
    row={k:external_documents.short(replacement.get(k,''),k,k in ('num','company')) for k in ('num','company','userType','assignedUser','issueDate','expiryDate','cardAlias','paymentType','usageScope')}
    if not row['issueDate'] or not row['expiryDate'] or not row['paymentType'] or not row['usageScope']:raise ValueError('대체카드의 발급일·만료일·신용/체크·사용 범위를 입력하세요.')
    row.update(finance(replacement),id=new_id,group=old['group'],status='available',managementStatus='정상',dept='',user='',purpose='',rentDate='',dueDate='')
    at=a.now();link=dict(id=uuid.uuid4().hex,time=at,actor=user,reason=reason)
    row['replaces']={**link,'cardId':old['id'],'cardNum':old['num'],'group':old['group']}
    old.update(archived=True,managementStatus='교체',closedAt=at,closedBy=user,closureReason=reason,closingSnapshot=before,replacedBy={**link,'cardId':new_id,'cardNum':row['num'],'group':row['group']},managementVersion=uuid.uuid4().hex)
    old.setdefault('managementHistory',[]).append(dict(time=at,actor=user,reason=reason,before=before,after={'managementStatus':'교체','archived':True,'replacedBy':old['replacedBy']}))
    cards.append(row);state['_next_card_id']=new_id
    return {'card':old,'replacement':row}

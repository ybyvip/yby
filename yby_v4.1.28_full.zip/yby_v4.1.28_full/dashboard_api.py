"""Permission-scoped dashboard activity, per-user read cursors and aggregate details."""
import hashlib,json
import activity_journal as journal
from urllib.parse import parse_qs,urlparse
from types import SimpleNamespace
GET={'/api/dashboard/activity','/api/dashboard/details','/api/dashboard/notice-readers','/api/dashboard/users','/api/dashboard/header'}
DEFAULT_PREFS={'navPinned':False,'notices':True,'shortcuts':True,'activity':True,'expenseSummary':True,'adminAccounts':True,'adminChanges':True,'adminPasswords':True}
POST={'/api/dashboard/seen','/api/dashboard/preferences','/api/dashboard/item-seen','/api/dashboard/notice-read'}
def initialize(c):
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_users(username TEXT PRIMARY KEY,seen_json TEXT NOT NULL,preferences_json TEXT NOT NULL)');journal.initialize(c)
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def settings(c,user):
 initialize(c);row=c.execute('SELECT seen_json,preferences_json FROM dashboard_users WHERE username=?',(user,)).fetchone()
 return (json.loads(row[0]),{**DEFAULT_PREFS,**json.loads(row[1])}) if row else ({},dict(DEFAULT_PREFS))
def events(a,user,state):
 visible=a.get_state_for(user,state);perms=a.permissions_for(user);admin=a.user_scope(user)=='ALL';rows=[];by_view={}
 def add(view,kind,row,label,time=None):
  if not admin and view not in perms and not (view=='v_notices') and not (view in ('v_hipass_history','v_hipass_box') and bool(perms&{'v_hipass_reg','v_hipass_box'})):return
  safe={'id':str(row.get('id','')),'group':row.get('group',''),'view':view,'kind':kind,'title':label,'time':str(time or row.get('updatedAt') or row.get('approvedAt') or row.get('requestedAt') or row.get('time') or row.get('date') or row.get('createdAt') or ''),'status':str(row.get('status') or row.get('action') or row.get('managementStatus') or '')}
  # Detect business changes without exposing content, account secrets or attachment metadata.
  version=digest({k:v for k,v in row.items() if k not in ('cardKey','passwordHash')});by_view.setdefault(view,[]).append([safe['id'],safe['group'],version]);rows.append(safe)
 for row in visible.get('notices',[]):add('v_notices','공지',row,row.get('title') or '공지사항')
 for row in visible.get('rentalDrafts',[]):add('v_card_rent','불출예정',row,(row.get('user') or '사용자')+' · '+row.get('status','대기'))
 for row in visible.get('history',[]):add('v_card_history','불출·반납',row,row.get('type','이력')+' · '+str(row.get('user','')))
 for row in visible.get('expense',[]):add('v_expense','정산·결재',row,str(row.get('user',''))+' · '+row.get('status',''))
 for row in visible.get('expenseHistory',[]):add('v_expense_history','정산이력',row,str(row.get('user',''))+' · '+row.get('status',''))
 for row in visible.get('cards',[]):
  if row.get('managementHistory'):
   event=row['managementHistory'][-1];add('v_card_reg','카드 관리',row,(row.get('cardAlias') or row.get('company','카드'))+' · '+row.get('managementStatus','정상'),event.get('time'))
 for row in visible.get('hipass',[]):add('v_hipass_box','하이패스 배부',row,str(row.get('hipassUser',''))+' · '+str(row.get('distributionStatus','')))
 for row in visible.get('hipassBox',[]):add('v_hipass_history','하이패스',row,row.get('action','변경')+' · '+str((row.get('after') or row.get('before') or {}).get('hipassUser','')))
 for row in visible.get('complaint',[]):add('v_complaint','민원·고충',row,row.get('title','민원'))
 for row in visible.get('reports',[]):add('v_report_box' if admin or 'v_report_box' in perms else 'v_report_write','보고서',row,row.get('title','보고서'))
 for view in ('v_notices','v_card_rent','v_card_history','v_card_reg','v_expense','v_expense_history','v_hipass_history','v_hipass_box','v_complaint','v_report_box','v_report_write'):
  if admin or view in perms or view=='v_notices' or (view in ('v_hipass_history','v_hipass_box') and perms&{'v_hipass_reg','v_hipass_box'}):by_view.setdefault(view,[])
 return sorted(rows,key=lambda x:(x['time'],x['id']),reverse=True),{v:digest(sorted(values)) for v,values in by_view.items()}
def activity(a,c,user,state,revision,params=None):
 seen,prefs=settings(c,user);rows,versions=events(a,user,state)
 # Establish a first-use baseline; later logins retain each user's unacknowledged changes.
 first=not c.execute('SELECT 1 FROM dashboard_users WHERE username=?',(user,)).fetchone()
 if first:seen=dict(versions);c.execute('INSERT INTO dashboard_users VALUES(?,?,?)',(user,json.dumps(seen),json.dumps(prefs)))
 unread={v:seen.get(v)!=value for v,value in versions.items()}
 journal.ensure(c,state)
 return dict(ok=True,revision=revision,digests=versions,unread=unread,preferences=prefs,**journal.listing(a,c,user,params or {}))
def details(a,user,state):
 scope=a.user_scope(user);perms=a.permissions_for(user);admin=scope=='ALL'
 if not admin and not perms&{'v_dashboard','v_card_reg','v_card_status','v_stats'}:raise PermissionError('대시보드 상세 조회 권한이 없습니다.')
 can=lambda *views:admin or bool(perms&({'v_dashboard','v_stats'}|set(views)))
 scoped=lambda k:[r for r in state.get(k,[]) if isinstance(r,dict) and (admin or r.get('group')==scope)]
 cards=[r for r in scoped('cards') if not r.get('archived')];today=a.business_date()
 groups=sorted({r.get('group','') for k in ('cards','history','expense','expenseHistory','hipass','reports','complaint') for r in scoped(k)}|({scope} if not admin else set()))
 branches=[]
 for group in groups:
  cc=[r for r in cards if r['group']==group];hh=[r for r in scoped('history') if r['group']==group] if can('v_card_history','v_card_rent') else []
  row={'group':group,'cards':len(cc),'available':sum(r.get('status')=='available' and r.get('managementStatus','정상')=='정상' and (not r.get('expiryDate') or r['expiryDate']>=today) for r in cc),'rented':sum(r.get('status')=='rented' for r in cc),'abnormal':sum(r.get('managementStatus','정상')!='정상' for r in cc),'uses':sum(r.get('type')=='불출' and not r.get('voidedReturn') for r in hh)}
  row.update(credit=sum(r.get('paymentType')=='신용' for r in cc),check=sum(r.get('paymentType')=='체크' for r in cc),domestic=sum(r.get('usageScope')=='국내전용' for r in cc),overseas=sum(r.get('usageScope')=='해외겸용' for r in cc),designated=sum(r.get('userType')=='지정' for r in cc),undesignated=sum(r.get('userType','비지정')=='비지정' for r in cc),expired=sum(bool(r.get('expiryDate')) and r['expiryDate']<today for r in cc),overdue=sum(r.get('status')=='rented' and bool(r.get('dueDate')) and r['dueDate']<today for r in cc))
  for names,fields,permission in [(('pendingExpense','approvedExpense','rejectedExpense','approvedAmount'),('expense','expenseHistory'),('v_expense','v_expense_history')),(('hipass','fuel'),('hipass',),('v_hipass_box','v_hipass_reg','v_hipass_status')),(('pendingReports','approvedReports'),('reports',),('v_report_box','v_report_write')),(('complaints',),('complaint',),('v_complaint',))]:
   rr=[r for field in fields for r in scoped(field) if r['group']==group]
   values={}
   if fields[0]=='expense':
    # The same source may appear in both queues; count each ID/group once.
    rr=list({(str(r.get('id')),r.get('group')):r for r in rr}.values());approved=[r for r in rr if r.get('status')=='승인완료' and not r.get('isCorrection') and not r.get('unused') and not r.get('isUnused')]
    values=dict(pendingExpense=sum(r.get('status') in ('승인대기','재보고대기') for r in rr),approvedExpense=len(approved),rejectedExpense=sum(r.get('status')=='반려됨' for r in rr),approvedAmount=sum(r.get('amount') or 0 for r in approved))
   elif fields[0]=='hipass':values=dict(hipass=sum(r.get('hipassEnabled',True) for r in rr),fuel=sum(bool(r.get('fuelEnabled')) for r in rr))
   elif fields[0]=='reports':values=dict(pendingReports=sum(r.get('status') in ('pending','pending_review') for r in rr),approvedReports=sum(r.get('status')=='approved' for r in rr))
   else:values=dict(complaints=len(rr))
   row.update({name:values.get(name,0) if can(*permission) else None for name in names})
  branches.append(row)
 card_read=admin or bool(perms&{'v_card_reg','v_card_status','v_card_rent','v_expense','v_stats','v_business_review'})
 abnormal=[{'id':r['id'],'group':r['group'],'company':r.get('company',''),'last4':str(r.get('num',''))[-4:],'status':r.get('managementStatus'),'user':r.get('user','')} for r in cards if r.get('managementStatus','정상')!='정상'] if card_read else None
 return dict(ok=True,branches=branches,abnormal=abnormal)

def get(h,g,path):
 if path not in GET:return False
 a=SimpleNamespace(**g)
 try:
  user=h.session_user()
  if not user:h.send_json({'ok':False,'message':'로그인이 필요합니다.'},401);return True
  if getattr(h,'must_change_password',False):raise PermissionError('비밀번호를 먼저 변경하세요.')
  with a.LOCK,a.db() as c:
   state=a.storage.read(c) or {};row=c.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone();revision=row[0] if row else None
   params=parse_qs(urlparse(h.path).query)
   if path.endswith('/header'):result=header(a,user,state)
   elif path.endswith('/activity'):result=activity(a,c,user,state,revision,params)
   elif path.endswith('/users'):
    import refinements_api
    result=refinements_api.users(a,user,state)
   elif path.endswith('/notice-readers'):result=notice_readers(a,c,user,state,params.get('id',[''])[0])
   else:result=details(a,user,state)
   c.commit()
  h.send_json(result)
 except PermissionError as e:h.send_json({'ok':False,'message':str(e)},403)
 except (ValueError,TypeError) as e:h.send_json({'ok':False,'message':str(e)},400)
 return True
def post(h,g,path,data):
 if path not in POST:return False
 a=SimpleNamespace(**g)
 try:
  user=h.session_user()
  if not user:raise PermissionError('로그인이 필요합니다.')
  if getattr(h,'must_change_password',False):raise PermissionError('비밀번호를 먼저 변경하세요.')
  with a.LOCK,a.db() as c:
   seen,prefs=settings(c,user)
   if path.endswith('/preferences'):
    if not {'notices','shortcuts'}<=set(data)<=set(DEFAULT_PREFS) or any(type(v)!=bool for v in data.values()):raise ValueError('표시 설정 형식을 확인하세요.')
    if a.user_scope(user)!='ALL' and any(k.startswith('admin') and data[k]!=prefs[k] for k in data):raise PermissionError('관리자 표시 설정은 최고관리자 전용입니다.')
    prefs.update(data)
   elif path.endswith('/item-seen'):
    if set(data)!={'eventKey'}:raise ValueError('업무 확인 요청 형식을 확인하세요.')
    saved=c.execute('SELECT payload_json FROM dashboard_events WHERE event_key=?',(str(data.get('eventKey','')),)).fetchone()
    if not saved or not journal.allowed(a,user,json.loads(saved[0])):raise PermissionError('확인 가능한 업무가 아닙니다.')
    c.execute('INSERT INTO dashboard_item_reads VALUES(?,?,?) ON CONFLICT(username,event_key) DO NOTHING',(user,data['eventKey'],journal.now()))
   elif path.endswith('/notice-read'):
    if set(data)!={'id','notice'}:raise ValueError('공지 확인 요청 형식을 확인하세요.')
    state=a.storage.read(c) or {};notice=next((r for r in state.get('notices',[]) if str(r['id'])==str(data.get('id'))),None)
    if notice is None:raise ValueError('공지사항을 찾을 수 없습니다.')
    if journal.digest(notice)!=journal.digest(data.get('notice')):raise a.StateConflict('공지 내용이 변경되었습니다. 다시 열어 확인하세요.')
    at=journal.now();c.execute('INSERT INTO notice_reads VALUES(?,?,?,?,?,1) ON CONFLICT(username,notice_id,notice_digest) DO UPDATE SET last_read_at=excluded.last_read_at,read_count=read_count+1',(user,str(notice['id']),journal.digest(notice),at,at))
   else:
    state=a.storage.read(c) or {};_,versions=events(a,user,state);view=data.get('view');row=c.execute('SELECT updated_at FROM system_state WHERE id=1').fetchone()
    if view not in versions:raise PermissionError('확인 가능한 메뉴가 아닙니다.')
    if data.get('digest')!=versions[view] or data.get('revision')!=(row[0] if row else None):raise a.StateConflict('표시한 자료 이후 변경이 있습니다. 갱신 후 확인하세요.')
    seen[view]=versions[view]
   c.execute('INSERT INTO dashboard_users VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET seen_json=excluded.seen_json,preferences_json=excluded.preferences_json',(user,json.dumps(seen),json.dumps(prefs)));c.commit()
  h.send_json({'ok':True,'preferences':prefs})
 except PermissionError as e:h.send_json({'ok':False,'message':str(e)},403)
 except a.StateConflict as e:h.send_json({'ok':False,'message':str(e)},409)
 except (TypeError,ValueError) as e:h.send_json({'ok':False,'message':str(e)},400)
 return True

def notice_readers(a,c,user,state,identity):
 if a.user_scope(user)!='ALL':raise PermissionError('공지 열람 정보는 최고관리자만 조회할 수 있습니다.')
 notice=next((r for r in state.get('notices',[]) if str(r['id'])==identity),None)
 if notice is None:raise ValueError('공지사항을 찾을 수 없습니다.')
 reads={r['username']:dict(r) for r in c.execute('SELECT * FROM notice_reads WHERE notice_id=? AND notice_digest=?',(identity,journal.digest(notice)))}
 rows=[{'username':r['username'],'scope':r['scope'],'active':bool(r['active']),'read':r['username'] in reads,**{k:v for k,v in reads.get(r['username'],{}).items() if k in ('first_read_at','last_read_at','read_count')}} for r in c.execute('SELECT username,scope,active FROM users ORDER BY username')]
 return dict(ok=True,title=notice.get('title',''),readers=rows)


def header(a,user,state):
 # Aggregate-only, authenticated header: never includes identifiers or other branches.
 scope=a.user_scope(user)
 if not scope:raise PermissionError('활성 계정이 필요합니다.')
 cards=[r for r in state.get('cards',[]) if isinstance(r,dict) and not r.get('archived') and (scope=='ALL' or r.get('group')==scope)]
 today=a.business_date();total=len(cards)
 available=sum(r.get('status')=='available' and r.get('managementStatus','정상')=='정상' and (not r.get('expiryDate') or r['expiryDate']>=today) for r in cards)
 rented=sum(r.get('status')=='rented' for r in cards)
 return dict(ok=True,scope=scope,total=total,available=available,rented=rented,other=total-available-rented)

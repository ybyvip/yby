/* V4.1.28: readable column pickers, scoped card summaries and weekly writing scenes. */
let ledgerPopup28=null;
function closeLedgerPicker28(restore=false){
 if(!ledgerPopup28)return;
 const {popup,trigger}=ledgerPopup28;popup.remove();trigger.setAttribute('aria-expanded','false');trigger.removeAttribute('aria-controls');ledgerPopup28=null;
 if(restore&&trigger.isConnected)trigger.focus();
}
function installLedgerPicker28(combo,input,select,kind,index){
 const trigger=document.createElement('button');trigger.type='button';trigger.className='ledger-choice-trigger28';trigger.textContent='⌄';trigger.setAttribute('aria-label',select.getAttribute('aria-label'));trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');trigger.title='선택 목록 열기 · 아래 방향키';
 // Keep the native select as the single source of exact-match values; only its visual control is replaced.
 select.hidden=true;select.tabIndex=-1;select.setAttribute('aria-hidden','true');
 trigger.onclick=()=>ledgerPopup28?.trigger===trigger?closeLedgerPicker28():openLedgerPicker28(trigger,input,select,kind,index);
 const key=e=>{if(e.key==='ArrowDown'){e.preventDefault();openLedgerPicker28(trigger,input,select,kind,index);}};
 input.addEventListener('keydown',key);trigger.addEventListener('keydown',key);combo.append(input,select,trigger);
}
function openLedgerPicker28(trigger,input,select,kind,index){
 closeLedgerPicker28();
 const popup=document.createElement('div');popup.id='ledgerChoices28';popup.className='ledger-options28';popup.role='listbox';popup.setAttribute('aria-label',select.getAttribute('aria-label'));popup.tabIndex=-1;
 for(const option of select.options){
  const button=document.createElement('button');button.type='button';button.role='option';button.tabIndex=-1;button.textContent=option.textContent;button.dataset.value=option.value;button.setAttribute('aria-selected',String(option.value===select.value));
  button.onclick=()=>{select.value=option.value;closeLedgerPicker28();select.dispatchEvent(new Event('change'));input.focus();};popup.append(button);
 }
 document.body.append(popup);ledgerPopup28={popup,trigger};trigger.setAttribute('aria-expanded','true');trigger.setAttribute('aria-controls',popup.id);
 const rect=input.getBoundingClientRect(),gap=8,availableWidth=Math.max(0,innerWidth-gap*2);
 popup.style.maxWidth=availableWidth+'px';popup.style.minWidth=Math.min(availableWidth,Math.max(rect.width,220))+'px';
 const width=popup.getBoundingClientRect().width;popup.style.left=Math.max(gap,Math.min(rect.left,innerWidth-width-gap))+'px';
 const below=innerHeight-rect.bottom-gap,above=rect.top-gap,down=below>=Math.min(240,above);
 popup.style.maxHeight=Math.max(48,Math.min(360,down?below:above))+'px';
 popup.style.top=(down?rect.bottom+4:Math.max(gap,rect.top-popup.getBoundingClientRect().height-4))+'px';
 popup.onkeydown=e=>{const options=[...popup.children],at=options.indexOf(document.activeElement);let next=null;
  if(e.key==='ArrowDown')next=(at+1)%options.length;
  if(e.key==='ArrowUp')next=(at-1+options.length)%options.length;
  if(e.key==='Home')next=0;if(e.key==='End')next=options.length-1;
  if(next!==null){e.preventDefault();options[next]?.focus();}
  if(e.key==='Escape'){e.preventDefault();closeLedgerPicker28(true);}
  if(e.key==='Tab')closeLedgerPicker28(true);
 };
 (popup.querySelector('[aria-selected="true"]')||popup.firstElementChild)?.focus();
}
document.addEventListener('pointerdown',e=>{if(ledgerPopup28&&!ledgerPopup28.popup.contains(e.target)&&!ledgerPopup28.trigger.contains(e.target))closeLedgerPicker28();});
document.addEventListener('scroll',e=>{if(ledgerPopup28&&!ledgerPopup28.popup.contains(e.target))closeLedgerPicker28();},true);
window.addEventListener('resize',()=>closeLedgerPicker28());
const switch28=switchView;switchView=function(view,el){closeLedgerPicker28();switch28(view,el);applySeason24();};

function cardReason28(card){return card.archived?'삭제 보존':cardAvailable24(card)?'사용가능':(card.managementStatus||'정상')!=='정상'?card.managementStatus:card.status==='rented'?'대여중':card.expiryDate&&card.expiryDate<localDate()?'만료':'기타';}
function cardCounts28(rows){const counts=new Map([['사용가능',0],['대여중',0]]);for(const card of rows){const label=cardReason28(card);counts.set(label,(counts.get(label)||0)+1);}return counts;}
const summary28=renderCardSummary24;
renderCardSummary24=function(){
 summary28();const chips=document.querySelector('#registeredCardSummary24 .reason-chips25');if(chips){const rows=cardsData.filter(c=>!c.archived&&(userScope==='ALL'||c.group===userScope));chips.replaceChildren();for(const [label,n] of cardCounts28(rows)){const chip=document.createElement('span');chip.append(label+' ');const count=document.createElement('b');count.textContent=n+'장';chip.append(count);chips.append(chip);}}
 let summary=document.getElementById('registeredSelection28');
 if(!summary){const checkbox=document.getElementById('registeredCardArchived'),label=checkbox?.closest('label');if(!label)return;const bar=document.createElement('div');bar.className='registered-selection-bar28';label.before(bar);bar.append(label);summary=document.createElement('div');summary.id='registeredSelection28';summary.role='status';summary.setAttribute('aria-live','polite');bar.append(summary);}
 const group=document.getElementById('registeredCardGroup').value,query=document.getElementById('registeredCardSearch').value.trim(),active=!!(group||query);summary.hidden=!active;summary.replaceChildren();if(!active)return;
 const rows=filteredRegisteredCards(),title=document.createElement('strong');title.textContent=(group||'권한 범위 전체')+(query?' · 검색: '+query:'')+' · 조회 '+rows.length+'장';summary.append(title);
 for(const [label,n] of cardCounts28(rows)){const chip=document.createElement('span');chip.textContent=label+' '+n+'장';summary.append(chip);}
 summary.title='현재 표와 동일한 검색·지점·삭제 보존 조건입니다. 카드별 대표 사유로 한 번씩 집계합니다.';
};

const writingScene28={weather:null,busy:false,lastFetch:0};
function writingWeek28(now=new Date()){
 const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now),part=type=>parts.find(x=>x.type===type).value;
 const stamp=Date.UTC(Number(part('year')),Number(part('month'))-1,Number(part('day'))),weekday=new Date(stamp).getUTCDay(),monday=stamp-((weekday+6)%7)*86400000;
 return {key:new Date(monday).toISOString().slice(0,10),index:Math.floor((monday-Date.UTC(2024,0,1))/604800000),month:Number(part('month')),hour:Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Seoul',hour:'2-digit',hourCycle:'h23'}).format(now))};
}
function writingPhoto28(now=new Date(),weather=writingScene28.weather){
 const week=writingWeek28(now),season=week.month>=3&&week.month<=5?'spring':week.month>=6&&week.month<=8?'summer':week.month>=9&&week.month<=11?'autumn':'winter';
 const condition=loginWeatherUsable(weather,now.getTime())?weather.condition:'season';
 const pools={spring:['day','sunrise','classic'],summer:['beach','day','classic'],autumn:['sunset','classic','sunrise'],winter:['snow','classic','day'],rain:['rain','classic','sunset'],snow:['snow','classic','sunrise'],cloudy:['classic','sunset','day'],night:['night','sunset','classic']};
 const pool=condition==='rain'||condition==='snow'||condition==='cloudy'?pools[condition]:week.hour<6||week.hour>=19?pools.night:pools[season],scene=pool[((week.index%pool.length)+pool.length)%pool.length];
 return {...week,season,condition,scene,file:scene==='beach'?'login-beach-v415.jpg':'login-'+scene+'-v416.jpg'};
}
const season28=applySeason24;
applySeason24=function(){
 season28();const scene=writingPhoto28();
 for(const id of ['v_complaint','v_report_write']){const panel=document.getElementById(id);if(!panel)continue;panel.dataset.season=scene.season;panel.style.setProperty('--season-photo24','url("/static/'+scene.file+'")');const side=panel.querySelector('.writing-aside25');if(!side)continue;
  let figure=side.querySelector('.weekly-photo28');if(!figure){figure=document.createElement('figure');figure.className='weekly-photo28';const image=document.createElement('img');image.loading='lazy';image.decoding='async';const caption=document.createElement('figcaption');figure.append(image,caption);side.prepend(figure);}
  const image=figure.querySelector('img'),path='/static/'+scene.file;if(image.getAttribute('src')!==path)image.src=path;image.alt='이번 주 쉬어가는 풍경 · '+(loginScenes[scene.scene]||'여름 해변');
  figure.dataset.week=scene.key;figure.dataset.scene=scene.scene;figure.querySelector('figcaption').textContent=scene.key+' 주간 풍경 · '+({rain:'청주시 비 예보 반영',snow:'청주시 눈 예보 반영',cloudy:'청주시 흐린 날씨 반영',clear:'청주시 맑은 날씨 반영',season:'날씨 연결 대기 · 계절·시간대 반영'}[scene.condition]);
 }
 const reader=document.getElementById('noticeReader25');if(reader)reader.style.setProperty('--season-photo24','url("/static/'+scene.file+'")');
};
async function refreshWritingWeather28(){
 if(!currentUser||document.hidden||!['v_complaint','v_report_write'].includes(dashboard24.active))return;
 applySeason24();if(writingScene28.busy||Date.now()-writingScene28.lastFetch<600000)return;
 writingScene28.busy=true;writingScene28.lastFetch=Date.now();const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),4500);
 try{const response=await fetch('/api/login-weather',{cache:'no-store',credentials:'omit',signal:controller.signal});if(response.ok){writingScene28.weather=await response.json();applySeason24();}}catch(_){/* Cached local photos work without weather access. */}finally{clearTimeout(timeout);writingScene28.busy=false;}
}
setInterval(refreshWritingWeather28,60000);
const writingView28=switchView;switchView=function(view,el){writingView28(view,el);refreshWritingWeather28();};
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshWritingWeather28();});

const reviewProcedures28={
 approved:{title:'YBY 승인',meaning:'선택 월·소속의 사용정산이력 중 승인완료이며 미사용으로 표시되지 않은 자료입니다. 조회 건수와 점검 필요 건수는 다를 수 있습니다.',steps:[['대상·증빙 준비','조회월과 소속을 확인하고 아래 목록의 사용자·사용일·카드 끝자리·사용처·금액을 카드사 명세 및 영수증과 맞춥니다.'],['원문·결재 확인','사용정산이력대장에서 같은 건의 상세 보기로 명세·첨부·결재자·결재시각을 확인합니다. 금액이나 결재 오류는 권한 있는 담당자가 원문의 정정 절차로 처리합니다.'],['항목별 대조 기록','업무 점검 화면의 확인할 업무에서 해당 건의 명세대조를 열고, 대조 명세 문서명·번호와 항목별 대조값·차이 사유·조치를 적습니다.'],['보완 또는 완료','증빙이 부족하면 미완료(보완중)로 저장합니다. 모든 항목을 확인한 뒤 완료로 저장하고, 원본 변경 시 저장된 점검기록에서 후속 점검합니다.']]},
 imported:{title:'이관 기록',meaning:'엑셀 등 과거 원본에서 이관한 자료 중 미사용·승인취소를 제외한 기록입니다. 이관은 YBY에서 새로 승인했다는 뜻이 아닙니다.',steps:[['원본 식별','원본 엑셀 파일명·행·이관 배치를 확보하고 아래 목록의 소속·사용자·일자·카드 끝자리를 맞춥니다.'],['원본과 대장 대조','사용정산이력대장 상세 보기에서 원본과 금액·사용 여부·반납일을 확인하고 불출/반납이력대장의 연결 기록과 대조합니다.'],['이관 오류 정정','허용된 항목은 수기 정정에서 사유와 현재 비밀번호를 입력해 정정합니다. 원본 금액과 YBY 결재 기록은 이 기능으로 덮어쓰지 않습니다. 금액 차이는 원본 증빙과 별도 조치 내역으로 남깁니다.'],['추적·보관','이관 파일·증빙과 차이·처리 담당자·기한을 보관합니다. 확인할 업무에 실제 표시된 건은 명세대조로 기록하고, 목록에 없는 이관 건을 승인완료로 간주하지 않습니다.']]},
 missingAmount:{title:'금액 미기재',meaning:'유효한 이관 기록 중 원본 금액이 비어 있는 건입니다. 미기재와 0원은 구분하며, 미기재 금액은 합계에 더하지 않습니다.',steps:[['누락 범위 확인','아래 목록의 금액이 미기재인지 확인합니다. 빈 값을 임의로 0원이나 추정 금액으로 바꾸지 않습니다.'],['증빙 확보','원본 엑셀·영수증·카드사 명세에서 같은 사용자·사용일·카드 끝자리·사용처를 찾아 실제 금액과 근거 문서번호를 확인합니다.'],['차이와 조치 기록','원본 금액은 보존합니다. 확인할 업무에 표시된 건은 명세대조의 금액 대조값과 누락 사유를 기록하고, 표시되지 않는 이관 건은 원문 상세·관련 보고서로 증빙과 후속 조치를 보관합니다.'],['확인 종료 기준','증빙이 없거나 금액이 확정되지 않으면 보완중으로 관리합니다. 점검기록 저장만으로 원본 금액이나 집계 금액이 바뀌지 않으므로, 권한 담당자의 정식 정정·재반영 후 재조회합니다.']]},
 unused:{title:'미사용 / 0원',meaning:'미사용으로 기록된 건 또는 유효한 이관 기록 중 금액이 0원인 건입니다. 0원이라는 이유만으로 실제 미사용을 단정하지 않습니다.',steps:[['미사용과 0원 분리','사용 여부가 미사용인지, 사용 기록은 있으나 금액만 0원인지 원문 상세에서 구분합니다. 금액 미기재는 별도 항목에서 확인합니다.'],['실물 반납 대조','불출/반납이력대장의 불출일·반납일·처리자와 실제 카드 반납 여부를 확인합니다. 반납 기록이 없으면 담당자에게 회수·확인을 요청합니다.'],['거래 사실 확인','카드사 승인·취소 명세와 영수증으로 거래 유무를 확인합니다. 사용 사실이 있으면 허용된 수기 정정 또는 정산 보완 절차로 처리하고 사유·증빙을 남깁니다.'],['재확인·보관','실제 사용 없음과 반납을 확인한 후 근거를 보관합니다. 확인할 업무에 표시되지 않는 건에는 개별 점검 저장 기능이 없으며, 목록 조회로 반납이나 정산이 자동 완료되지 않습니다.']]},
 cancelled:{title:'승인 취소',meaning:'사용정산이력에서 승인취소로 표시된 기록입니다. 시스템의 승인취소와 카드사의 실제 거래 취소는 각각 확인해야 합니다.',steps:[['취소 원문 확인','사용정산이력대장 상세 보기에서 취소 대상 원문·취소 사유·처리자·시각 및 연결된 정정·재보고 기록을 확인합니다.'],['카드사·회계 대조','카드사 취소명세·환급내역과 회계 반영 여부를 확인합니다. 시스템 상태가 승인취소라고 해서 카드사 환급이 완료된 것은 아닙니다.'],['대체 기록 확인','재보고·정정으로 생성된 후속 건이 있으면 기존 건과 연결해 중복 청구·중복 집계를 점검합니다. 취소 건은 승인 사용금액에서 제외합니다.'],['미결 조치 추적','미환급·회계 미반영은 담당자·기한·근거를 관련 보고서에 남깁니다. 취소 건은 일반 승인 명세대조 대상이 아닐 수 있으며, 재승인은 별도 권한·정식 절차로 진행합니다.']]},
 selfApproved:{title:'자기 결재',meaning:'자기 결재 또는 자기 승인 표시가 있는 기록입니다. 현재 승인 상태와 별개로 독립된 담당자의 사후 검토가 필요합니다.',steps:[['정책·사유 확인','원문에서 신청자와 결재자, 자기 결재 사유·시각·증빙을 확인하고 회사 정책의 허용 조건과 대조합니다.'],['독립 검토 요청','해당 결재와 이해관계가 없는 권한 담당자에게 카드사 명세·영수증·사용 목적·금액 검토를 요청합니다. 본인이 자신의 검토를 독립 검토로 대신하지 않습니다.'],['검토 결과 남기기','확인할 업무에 표시된 유효 승인 건은 명세대조로 항목별 확인값과 독립 검토자·검토일·근거·차이 및 조치를 기록합니다. 취소·미사용 등 제외 건은 원문·관련 보고서에서 추적합니다.'],['후속 조치 확인','정책 위반이나 증빙 부족은 보완중으로 두고 정정·취소 등 권한 절차를 요청합니다. 모든 확인과 조치 후 점검완료로 저장하며 점검완료는 새로운 결재 승인이 아닙니다.']]}
};
function reviewProcedure28(metric){
 const guide=reviewProcedures28[metric];if(!guide)return '';
 const v=stability.review;return '<section class="review-procedure28" aria-label="'+sEsc(guide.title)+' 업무진행절차"><h3>업무진행절차 · '+sEsc(guide.title)+'</h3><p class="review-scope28">조회 기준: '+sEsc(v?.period||'')+' · '+sEsc(v?.group==='ALL'?'권한 범위 전체':v?.group||'')+'</p><p>'+sEsc(guide.meaning)+'</p><ol>'+guide.steps.map(([title,text])=>'<li><strong>'+sEsc(title)+'</strong><p>'+sEsc(text)+'</p></li>').join('')+'</ol><p class="review-procedure-note28">아래는 조회 목록입니다. 점검기록은 업무점검 화면의 「확인할 업무 → 명세대조」에서, 미완료·후속 확인은 「저장된 점검기록」에서 진행합니다. 접근·정정은 본인의 권한 범위에 한하며, 조회와 점검 저장은 원문 금액·결재 상태를 변경하지 않습니다.</p></section>';
}

// Dynamic and static tables share local scrolling; the page itself stays within its work area.
function adaptTables28(){
 for(const table of document.querySelectorAll('.view-panel table,.modal-body table')){
  if(table.closest('[contenteditable=true],.responsive-table28,.card-history-wrap,.expense-history-wrap,.registered-card-scroll,.s-table-wrap,.activity-scroll24,.excel-preview-scroll'))continue;
  const wrap=document.createElement('div');wrap.className='responsive-table28';wrap.tabIndex=0;wrap.setAttribute('role','region');wrap.setAttribute('aria-label','표 · 내용이 넓으면 좌우로 스크롤');table.before(wrap);wrap.append(table);
 }
}
let adaptPending28=false;
const adaptiveObserver28=new MutationObserver(()=>{if(adaptPending28)return;adaptPending28=true;requestAnimationFrame(()=>{adaptPending28=false;adaptTables28();});});
adaptiveObserver28.observe(document.getElementById('mainContentArea'),{childList:true,subtree:true});
adaptiveObserver28.observe(document.getElementById('modalBody'),{childList:true,subtree:true});
adaptTables28();
const logout28=handleLogout;handleLogout=function(){closeLedgerPicker28();return logout28();};

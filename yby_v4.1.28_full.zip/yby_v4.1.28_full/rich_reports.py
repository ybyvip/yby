"""Restricted rich document model. No supplied HTML, scripts, URLs or CSS are stored."""
import json,re
from pathlib import Path
TAGS={'p','div','br','strong','b','em','i','u','s','span','h2','h3','ul','ol','li','table','thead','tbody','tr','th','td','blockquote'}
FONTS={'sans','serif','mono'}
def validate(value,attachments,directory):
 if not isinstance(value,dict) or set(value)!={'version','nodes'} or type(value['version'])!=int or value['version']!=1 or not isinstance(value['nodes'],list):raise ValueError('서식 문서 형식을 확인하세요.')
 if len(json.dumps(value,ensure_ascii=False))>600000:raise ValueError('서식 문서는 600KB 이내입니다.')
 refs={r['id'] for r in attachments};count=0;plain=[]
 def node(n,depth=0):
  nonlocal count
  count+=1
  if count>10000 or depth>24 or not isinstance(n,dict):raise ValueError('문서 구조가 너무 복잡합니다.')
  if set(n)=={'text'}:
   if not isinstance(n['text'],str):raise ValueError('문자 형식 오류')
   plain.append(n['text']);return {'text':n['text']}
  if n.get('tag')=='img':
   if set(n)-{'tag','id','alt'} or not isinstance(n.get('id'),str) or n['id'] not in refs:raise ValueError('본문 그림은 이 보고서의 첨부 이미지여야 합니다.')
   meta=json.loads((Path(directory)/(n['id']+'.json')).read_text())
   if meta.get('mime') not in {'image/png','image/jpeg','image/gif','image/webp'}:raise ValueError('본문 그림은 PNG·JPEG·GIF·WebP 파일만 가능합니다.')
   alt=n.get('alt','그림')
   if not isinstance(alt,str) or len(alt)>200:raise ValueError('그림 설명은 200자 이내입니다.')
   plain.append('[그림: '+alt+']');return dict(tag='img',id=n['id'],alt=alt)
  if set(n)-{'tag','children','format'} or not isinstance(n.get('tag'),str) or n.get('tag') not in TAGS or not isinstance(n.get('children'),list):raise ValueError('허용되지 않는 문서 요소입니다.')
  fmt=n.get('format',{})
  if not isinstance(fmt,dict) or set(fmt)-{'font','size','color','align'}:raise ValueError('서식 속성 오류')
  for key,v in fmt.items():
   valid=(key=='font' and isinstance(v,str) and v in FONTS) or (key=='size' and type(v)==int and v in (12,14,16,18,24,32)) or (key=='color' and isinstance(v,str) and re.fullmatch(r'#[0-9a-fA-F]{6}',v)) or (key=='align' and v in ('left','center','right'))
   if not valid:raise ValueError('허용되지 않는 글꼴·크기·색상·정렬입니다.')
  result=dict(tag=n['tag'],children=[node(c,depth+1) for c in n['children']])
  if fmt:result['format']=fmt
  if n['tag'] in ('p','div','br','h2','h3','li','tr','blockquote'):plain.append('\n')
  elif n['tag'] in ('td','th'):plain.append('\t')
  return result
 nodes=[node(n) for n in value['nodes']];text=''.join(plain).strip()
 if not text or len(text)>100000:raise ValueError('보고서 본문은 1~100,000자입니다.')
 return dict(version=1,nodes=nodes),text

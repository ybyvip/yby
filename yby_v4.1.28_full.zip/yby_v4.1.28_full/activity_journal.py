"""Immutable, minimal activity journal captured within the business transaction."""
import hashlib,json,uuid
from datetime import datetime,timezone,timedelta,date
SPECS={'notices':('v_notices','공지'),'rentalDrafts':('v_card_rent','불출예정'),'history':('v_card_history','불출·반납'),'expense':('v_expense','정산·결재'),'expenseHistory':('v_expense_history','정산이력'),'cards':('v_card_reg','카드 관리'),'hipass':('v_hipass_box','하이패스 배부'),'hipassBox':('v_hipass_history','하이패스'),'complaint':('v_complaint','민원·고충'),'reports':('v_report_box','보고서')}
def encode(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def digest(v):return hashlib.sha256(encode(v).encode()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat(timespec='microseconds')
def initialize(c):
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_events(event_key TEXT PRIMARY KEY,view TEXT NOT NULL,group_name TEXT NOT NULL,payload_json TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_item_reads(username TEXT NOT NULL,event_key TEXT NOT NULL,read_at TEXT NOT NULL,PRIMARY KEY(username,event_key))')
 c.execute('CREATE TABLE IF NOT EXISTS notice_reads(username TEXT NOT NULL,notice_id TEXT NOT NULL,notice_digest TEXT NOT NULL,first_read_at TEXT NOT NULL,last_read_at TEXT NOT NULL,read_count INTEGER NOT NULL,PRIMARY KEY(username,notice_id,notice_digest))')
 c.execute('CREATE TABLE IF NOT EXISTS dashboard_meta(name TEXT PRIMARY KEY,value TEXT NOT NULL)')
 c.execute('CREATE INDEX IF NOT EXISTS ix_dashboard_events_scope ON dashboard_events(group_name,view)')
def special(row):
 if 'important' in row:return row['important'] is True
 return (row.get('view')=='v_card_reg' and row.get('status') in ('분실','파손','사용중지','교체','장기사용')) or row.get('status') in ('승인취소','반려됨','재보고대기','rejected') or row.get('view') in ('v_report_box','v_report_write') and row.get('change')=='변경'
def state_label(value):return {'pending':'최종 결재대기','pending_review':'1차 검토대기','approved':'승인완료','rejected':'반려됨','available':'사용가능','rented':'대여중'}.get(value,str(value or '미기록'))
def describe(field,row,before=None):
 before=before or {};status=row.get('managementStatus') if field=='cards' else row.get('status') or row.get('distributionStatus') or '';old=before.get('managementStatus') if field=='cards' else before.get('status') or before.get('distributionStatus') or ''
 important=False;reason=''
 if field=='cards':
  important=(status or '정상')!='정상' or (old and old!='정상' and status=='정상');reason='카드 관리상태 '+str(old or '정상')+' → '+str(status or '정상')
  if row.get('incident'):reason+=' · '+str(row['incident'].get('description',''))[:180]
 elif field in ('reports','expense','expenseHistory'):
  important=bool(before) and digest(row)!=digest(before) or status in ('승인취소','반려됨','재보고대기','rejected');reason=('보고서' if field=='reports' else '정산')+' 상태 '+state_label(old or '신규')+' → '+state_label(status or '미기록')
 elif field=='notices':important=row.get('noticeType')=='긴급공지' or row.get('priority')=='긴급';reason=str(row.get('noticeType','일반공지'))+' · '+str(row.get('title',''))
 elif field=='hipass':important=status in ('분실','파손','사용중지');reason='배부 상태 '+str(status)
 return important,reason
def snapshot(state):
 result={}
 for field,(view,kind) in SPECS.items():
  for i,row in enumerate(state.get(field,[])):
   if not isinstance(row,dict):continue
   identity=str(row.get('id',i));group=str(row.get('group',''));title=str(row.get('title') or row.get('cardAlias') or row.get('user') or row.get('hipassUser') or row.get('company') or kind)
   at=str(row.get('updatedAt') or row.get('approvedAt') or row.get('requestedAt') or row.get('time') or row.get('date') or row.get('createdAt') or '')
   important,detail=describe(field,row)
   safe=dict(hasManagementHistory=bool(row.get('managementHistory')),important=important and not (field=='cards' and row.get('managementHistory')),description=detail,entityKind=field,cardLast4=str(row.get('num') or row.get('cardNum') or '')[-4:],requester=str(row.get('requester','')),id=identity,group=group,view=view,kind=kind,title=title,time=at,status=str((row.get('managementStatus') or '정상') if field=='cards' else row.get('status') or row.get('action') or row.get('distributionStatus') or ''))
   version=digest({k:v for k,v in row.items() if k not in ('cardKey','passwordHash','ledgerSerial','createdAtBasis')})
   result[encode([field,group,identity])]=(safe,version)
   if field=='cards':
    for j,event in enumerate(row.get('managementHistory',[])):
     event_important,event_detail=describe('cards',event.get('after') or {},event.get('before') or {})
     safe_event={**safe,'managementEvent':True,'important':event_important,'description':event_detail,'time':str(event.get('time') or ''),'title':title+' · '+str((event.get('after') or {}).get('managementStatus','상태 변경')),'status':str((event.get('after') or {}).get('managementStatus',''))}
     result[encode([field,group,identity,'history',j])]=(safe_event,digest(event))
 return result

def insert(c,row,action,backfill=False):
 value={**row,'eventKey':uuid.uuid4().hex,'change':action,'backfilled':backfill}
 if not backfill:value['time']=now()
 value['day']=day(value['time']);c.execute('INSERT INTO dashboard_events VALUES(?,?,?,?)',(value['eventKey'],value['view'],value['group'],encode(value)))
def ensure(c,state):
 initialize(c)
 if c.execute("SELECT 1 FROM dashboard_meta WHERE name='seeded'").fetchone():return
 for row,_ in snapshot(state).values():insert(c,row,'기존 보존 자료',True)
 c.execute("INSERT INTO dashboard_meta VALUES('seeded',?)",(now(),))
def capture(c,before,after):
 ensure(c,before);old=snapshot(before);new=snapshot(after)
 for key,(row,version) in new.items():
  if key not in old or old[key][1]!=version:
   row=dict(row)
   if key in old and row.get('entityKind') in ('reports','expense','expenseHistory'):
    row['important']=True;row['description']=row['kind']+' 변경 · '+state_label(old[key][0].get('status','미기록'))+' → '+state_label(row.get('status','미기록'))+' · 현재 원문에서 변경 결과를 확인하세요.'
   if key in old and row.get('entityKind')=='cards' and old[key][0].get('status') not in ('','정상'):
    row['important']=True
   if row.get('entityKind')=='cards' and row.get('hasManagementHistory') and not row.get('managementEvent'):row['important']=False
   insert(c,row,'등록' if key not in old else '변경')
 ledger_targets={(r['id'],r['group'],r.get('requester','')):r for r,_ in new.values() if r.get('entityKind')=='expenseHistory'}
 for key,(row,_) in old.items():
  if key not in new:
   moved=ledger_targets.get((row['id'],row['group'],row.get('requester',''))) if row.get('entityKind')=='expense' else None
   if moved:
    insert(c,{**moved,'important':True,'description':'정산 처리결과 · '+state_label(row.get('status'))+' → '+state_label(moved.get('status'))},'변경')
   else:insert(c,{**row,'important':row.get('important',False) or row.get('entityKind') in ('reports','expense','expenseHistory'),'deleted':True},'삭제')
def day(value):
 try:
  parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
  return (parsed.astimezone(timezone(timedelta(hours=9))) if parsed.tzinfo else parsed).date().isoformat()
 except (ValueError,TypeError,AttributeError):return ''
def allowed(a,user,row,scope=None,perms=None):
 scope=a.user_scope(user) if scope is None else scope;p=a.permissions_for(user) if perms is None else perms;view=row['view']
 if view!='v_notices' and scope not in ('ALL',row['group']):return False
 return scope=='ALL' or view=='v_notices' or view in p or view=='v_report_box' and 'v_report_write' in p or view in ('v_hipass_box','v_hipass_history') and bool(p&{'v_hipass_reg','v_hipass_box'})
def listing(a,c,user,params):
 start=params.get('from',[''])[0];end=params.get('to',[''])[0]
 for val in (start,end):
  if val:
   try:assert date.fromisoformat(val).isoformat()==val
   except (ValueError,AssertionError):raise ValueError('조회 기간은 올바른 날짜로 입력하세요.')
 if start and end and start>end:raise ValueError('시작일이 종료일보다 늦습니다.')
 try:offset=int(params.get('offset',['0'])[0]);limit=int(params.get('limit',['50'])[0]);assert offset>=0 and 1<=limit<=200
 except (ValueError,TypeError,AssertionError):raise ValueError('페이지 범위를 확인하세요.')
 reads=dict(c.execute('SELECT event_key,read_at FROM dashboard_item_reads WHERE username=?',(user,)))
 rows=[];undated=0
 scope=a.user_scope(user);perms=a.permissions_for(user)
 query='SELECT payload_json FROM dashboard_events'+('' if scope=='ALL' else " WHERE group_name=? OR view='v_notices'")
 for saved in c.execute(query,() if scope=='ALL' else (scope,)):
  row=json.loads(saved[0])
  if not allowed(a,user,row,scope,perms):continue
  if params.get('important',['0'])[0]=='1' and not special(row):continue
  if not row.get('description'):row['description']=row['kind']+' · '+row.get('title','')+' · '+row.get('status','')+' · 현재 원문에서 상세 내용을 확인하세요.'
  if not row['day']:undated+=1
  if (start or end) and (not row['day'] or start and row['day']<start or end and row['day']>end):continue
  if row['view']=='v_report_box' and scope!='ALL' and 'v_report_box' not in perms:row['view']='v_report_write'
  rows.append({**row,'readAt':reads.get(row['eventKey'])})
 rows.sort(key=lambda r:(r['day'],r['time'],r['eventKey']),reverse=True)
 return dict(items=rows[offset:offset+limit],total=len(rows),offset=offset,limit=limit,undated=undated)

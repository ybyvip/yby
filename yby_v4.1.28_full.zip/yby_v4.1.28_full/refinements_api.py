"""V4.1.26 scoped user analytics and notice publication options."""
from datetime import date
TYPES=('일반공지','긴급공지','수시공지','점검안내','정책변경','행사안내')
def notice_options(data):
 kind=data.get('noticeType','일반공지');priority=data.get('priority','보통');audience=data.get('audience','전체');start=data.get('startsOn','');end=data.get('endsOn','')
 if kind not in TYPES or priority not in ('보통','중요','긴급') or audience not in ('전체','본사','지점'):raise ValueError('공지 유형·중요도·안내 대상을 확인하세요.')
 for v in (start,end):
  if v:
   try:assert type(v)==str and date.fromisoformat(v).isoformat()==v
   except (ValueError,TypeError,AssertionError):raise ValueError('공지 안내 기간은 올바른 날짜로 입력하세요.')
 if start and end and start>end:raise ValueError('공지 안내 종료일이 시작일보다 빠릅니다.')
 return dict(noticeType=kind,priority=priority,audience=audience,startsOn=start,endsOn=end)
def users(a,user,state):
 p=a.permissions_for(user);admin=a.user_scope(user)=='ALL'
 if not admin and not p&{'v_stats','v_card_reg','v_card_status','v_card_rent','v_expense','v_expense_history'}:raise PermissionError('사용자별 상세 집계 권한이 필요합니다.')
 visible=a.get_state_for(user,state);today=a.business_date();rows={}
 card_ok=admin or bool(p&{'v_stats','v_card_reg','v_card_status','v_card_rent','v_expense'})
 exp_ok=admin or bool(p&{'v_stats','v_expense','v_expense_history'})
 hip_ok=admin or bool(p&{'v_hipass_box','v_hipass_reg','v_hipass_status'})
 rep_ok=admin or bool(p&{'v_report_box','v_report_write'});comp_ok=admin or 'v_complaint' in p
 def target(r,name):
  name=str(name or '').strip() or '미배정·미기록';branch=r.get('group','');key=(branch,name)
  if key not in rows:
   rows[key]=dict(group=name+' ('+branch+')',user=name,branch=branch,**{k:0 for k in ('cards','available','rented','uses','abnormal','expired','overdue','credit','check','domestic','overseas','designated','undesignated')},**{k:0 if allow else None for allow,fields in [(exp_ok,('pendingExpense','approvedExpense','rejectedExpense','approvedAmount')),(hip_ok,('hipass','fuel')),(rep_ok,('pendingReports','approvedReports')),(comp_ok,('complaints',))] for k in fields})
  return rows[key]
 if card_ok:
  for r in visible.get('cards',[]):
   if r.get('archived'):continue
   x=target(r,r.get('user') if r.get('status')=='rented' else r.get('assignedUser'));x['cards']+=1;x['rented']+=r.get('status')=='rented';x['abnormal']+=r.get('managementStatus','정상')!='정상';x['expired']+=bool(r.get('expiryDate')) and r['expiryDate']<today;x['overdue']+=r.get('status')=='rented' and bool(r.get('dueDate')) and r['dueDate']<today
   x['available']+=r.get('status')=='available' and r.get('managementStatus','정상')=='정상' and (not r.get('expiryDate') or r['expiryDate']>=today)
   for key,field,val in [('credit','paymentType','신용'),('check','paymentType','체크'),('domestic','usageScope','국내전용'),('overseas','usageScope','해외겸용'),('designated','userType','지정'),('undesignated','userType','비지정')]:x[key]+=r.get(field,'비지정' if field=='userType' else '')==val
 for r in visible.get('history',[]):
  if r.get('type')=='불출' and not r.get('voidedReturn'):target(r,r.get('user'))['uses']+=1
 if exp_ok:
  expenses={(str(r.get('id')),r.get('group'),r.get('requester')):r for field in ('expense','expenseHistory') for r in visible.get(field,[])}
  for r in expenses.values():
   x=target(r,r.get('user'));status=r.get('status');x['pendingExpense']+=status in ('승인대기','재보고대기');x['rejectedExpense']+=status=='반려됨'
   if status=='승인완료' and not r.get('isCorrection') and r.get('used') is not False:
    x['approvedExpense']+=1;x['approvedAmount']+=r['amount'] if type(r.get('amount'))==int and r['amount']>=0 else 0
 if hip_ok:
  for r in visible.get('hipass',[]):x=target(r,r.get('hipassUser'));x['hipass']+=r.get('hipassEnabled',True);x['fuel']+=bool(r.get('fuelEnabled'))
 if rep_ok:
  for r in visible.get('reports',[]):x=target(r,r.get('author'));x['pendingReports']+=r.get('status') in ('pending','pending_review');x['approvedReports']+=r.get('status')=='approved'
 if comp_ok:
  for r in visible.get('complaint',[]):target(r,r.get('author'))['complaints']+=1
 return dict(ok=True,users=sorted(rows.values(),key=lambda r:(r['branch'],r['user'])),basis='동일 지점의 기록된 이름 기준. 카드 실사용자·지정사용자, 이력 사용자, 보고서·민원 작성자를 집계하며 미기록은 분리합니다.')

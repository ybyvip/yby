"""V4.1.27: scoped counters, durable followups, restricted rich documents and safe preferences."""
import copy,json,base64,unittest
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode
import test_v4126 as base
class Upgrade127Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.Refinements126Tests.setUpClass()
 @classmethod
 def tearDownClass(cls):base.Refinements126Tests.tearDownClass()
 def setUp(self):
  self.t=base.Refinements126Tests();self.t.setUp();self.a=self.t.a;self.c=self.t.c;self.prior=self.t.prior
 def get(self,path,cookie=None):return self.t.get(path,cookie)
 def op(self,path,value,cookie=None):return self.t.op(path,value,cookie)
 def mutate(self,callback):self.t.t.t.mutate(callback)
 def model(self):return dict(version=1,nodes=[dict(tag='h2',children=[dict(text='시험 보고서')]),dict(tag='p',format=dict(font='serif',size=18,color='#335577',align='center'),children=[dict(tag='strong',children=[dict(text='명확한 결론')])]),dict(tag='table',children=[dict(tag='tr',children=[dict(tag='th',children=[dict(text='구분')]),dict(tag='td',children=[dict(text='내용')])])])])
 def submit(self,**patch):return self.op('/api/documents/submit',dict(group='서울',title='서식 기안',content='기존 일반 내용',approver='admin',reviewer='',attachments=[])|patch)
 def saved(self):
  value=self.t.seed();detail=self.t.detail(value)[1];result=self.t.ack(value,self.t.comparison(detail));self.assertEqual(result[0],200,result);return value,result[1]['review']
 def follow(self,review,cookie=None):return self.get('/api/business-review/details?'+urlencode(dict(period='2026-10',reviewId=review['id'])),cookie)
 def test_header_all_authenticated_roles_and_scope_without_identifiers(self):
  self.mutate(lambda s:s['cards'].extend([dict(s['cards'][0],id=2,status='rented'),dict(s['cards'][0],id=3,managementStatus='分失'),dict(s['cards'][0],id=4,expiryDate='2000-01-01'),dict(s['cards'][0],id=5,archived=True),dict(s['cards'][0],id=6,group='인천')]))
  for cookie in [self.c.branch,self.c.login('readonly','Branch-test-pass!')]:
   code,v,*_=self.get('/api/dashboard/header',cookie);self.assertEqual(code,200);self.assertEqual((v['total'],v['available'],v['rented'],v['other']),(4,1,1,2));self.assertNotIn('num',json.dumps(v));self.assertEqual(v['scope'],'서울')
  self.assertEqual(self.get('/api/dashboard/header',self.c.admin)[1]['total'],5);self.assertEqual(self.c.request('/api/dashboard/header')[0],401)
 def test_header_counts_update_on_incident_and_recovery(self):
  self.assertEqual(self.get('/api/dashboard/header')[1]['available'],1);self.assertEqual(self.prior.manage(managementStatus='기타')[0],200);self.assertEqual(self.get('/api/dashboard/header')[1]['other'],1);self.assertEqual(self.prior.manage(managementStatus='정상')[0],200);self.assertEqual(self.get('/api/dashboard/header')[1]['available'],1)
 def test_other_incident_is_durable_and_blocks_issue(self):
  self.assertEqual(self.prior.manage(managementStatus='기타')[0],200);self.assertEqual(self.prior.w.rent()[0],400);self.assertEqual(self.a.get_state()['cards'][0]['managementHistory'][-1]['after']['managementStatus'],'기타')
 def test_menu_preferences_are_per_user_and_do_not_overwrite_others(self):
  self.assertEqual(self.c.request('/api/dashboard/preferences',dict(notices=False,shortcuts=True,navPinned=True),self.c.branch)[0],200);branch=self.get('/api/dashboard/activity')[1]['preferences'];self.assertTrue(branch['navPinned']);self.assertFalse(branch['notices']);self.assertFalse(self.get('/api/dashboard/activity',self.c.admin)[1]['preferences']['navPinned']);self.assertEqual(self.c.request('/api/dashboard/preferences',dict(notices=True,shortcuts=True,navPinned='true'),self.c.branch)[0],400)
 def test_followup_author_admin_and_same_branch_outsider(self):
  value,review=self.saved();self.assertEqual(self.follow(review)[0],200);self.assertEqual(self.follow(review,self.c.admin)[0],200)
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_stats']),));db.commit()
  outsider=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.follow(review,outsider)[0],403)
  current=self.get('/api/business-review?period=2026-10',outsider)[1];payload=dict(period='2026-10',fingerprint=current['fingerprint'],reviewId=review['id'],reference='다른 작성자',note='타인 후속점검 거절',confirmed=True,acknowledgeIssues=True,password='Branch-test-pass!');self.assertEqual(self.op('/api/business-review/acknowledge',payload,outsider)[0],403)
 def test_legacy_target_without_requester_has_unique_safe_resolution(self):
  value,review=self.saved()
  with self.a.db() as db:
   row=json.loads(db.execute('SELECT payload FROM business_reviews WHERE id=?',(review['id'],)).fetchone()[0]);row['target'].pop('requester');row['target']['id']=int(row['target']['id']);db.execute('UPDATE business_reviews SET payload=? WHERE id=?',(json.dumps(row),review['id']));db.commit()
  code,detail,*_=self.follow(review);self.assertEqual(code,200,detail);self.assertEqual(detail['source']['fields']['amount'],1000)
 def test_missing_original_shows_saved_snapshot_without_false_permission_denial(self):
  value,review=self.saved();self.mutate(lambda s:s.update(expenseHistory=[]));code,detail,*_=self.follow(review);self.assertEqual(code,200,detail);self.assertTrue(detail['unavailable']);self.assertEqual(detail['source']['fields']['amount'],1000);self.assertEqual(self.follow(review,self.c.admin)[0],200)
 def test_followup_is_append_only_and_preserves_business_states(self):
  value,review=self.saved();current=self.get('/api/business-review?period=2026-10')[1];detail=self.follow(review)[1];before=copy.deepcopy(self.a.get_state());payload=dict(period='2026-10',fingerprint=current['fingerprint'],reviewId=review['id'],reference='후속 명세서',note='추가 확인 내용 기록',confirmed=True,acknowledgeIssues=True,password='Branch-test-pass!',comparison=self.t.comparison(detail),reviewStatus='완료');result=self.op('/api/business-review/acknowledge',payload);self.assertEqual(result[0],200,result);self.assertEqual(result[1]['review']['previousId'],review['id']);self.assertEqual(self.a.get_state(),before);self.assertEqual(len(self.get('/api/business-review?period=2026-10')[1]['reviews']),2)
 def test_rich_report_round_trip_font_table_and_plain_compatibility(self):
  result=self.submit(richContent=self.model());self.assertEqual(result[0],200,result);row=result[1]['document'];self.assertEqual(row['richContent'],self.model());self.assertIn('명확한 결론',row['content']);self.assertIn('구분',row['content']);self.assertEqual(self.submit()[0],200)
 def test_unsafe_rich_nodes_styles_urls_and_depth_are_rejected_atomically(self):
  before=copy.deepcopy(self.a.get_state());nodes=[dict(tag='script',children=[dict(text='alert(1)')]),dict(tag='p',children=[],onclick='alert(1)'),dict(tag='img',id='https://external.example/a.png'),dict(tag='p',children=[],format=dict(color='url(x)')),dict(tag='a',children=[],href='javascript:x'),dict(tag='p',children=[],format=dict(size=500))]
  for node in nodes:self.assertEqual(self.submit(richContent=dict(version=1,nodes=[node]))[0],400,node)
  nested={'text':'hello'}
  for _ in range(26):nested={'tag':'p','children':[nested]}
  self.assertEqual(self.submit(richContent=dict(version=1,nodes=[nested]))[0],400);self.assertEqual(self.a.get_state(),before)
 def upload(self,name,raw,group='서울',cookie=None):
  result=self.c.request('/api/attachments',dict(purpose='report',name=name,content=base64.b64encode(raw).decode(),group=group),cookie or self.c.branch);self.assertEqual(result[0],200,result);return dict(id=result[1]['attachment_id'],name=name)
 def test_rich_image_requires_owned_same_group_report_image_attachment(self):
  ref=self.upload('diagram.png',b'\x89PNG\r\n\x1a\nTEST');model=dict(version=1,nodes=[dict(tag='img',id=ref['id'],alt='근거 도표')]);self.assertEqual(self.submit(richContent=model,attachments=[ref])[0],200);self.assertEqual(self.submit(richContent=model)[0],400)
  text=self.upload('note.txt',b'test');model['nodes'][0]['id']=text['id'];self.assertEqual(self.submit(richContent=model,attachments=[text])[0],400)
  foreign=self.upload('foreign.png',b'\x89PNG\r\n\x1a\nTEST','인천',self.c.admin);model['nodes'][0]['id']=foreign['id'];self.assertEqual(self.submit(richContent=model,attachments=[foreign])[0],403)
 def test_rich_submission_idempotency_and_concurrent_receipts(self):
  import uuid
  revision=self.c.request('/api/state',cookie=self.c.branch)[1]['revision'];request_id=uuid.uuid4().hex
  payload=dict(requestId=request_id,revision=revision,group='서울',title='동시 서식 상신',content='본문',approver='admin',richContent=self.model(),attachments=[])
  with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:self.c.request('/api/documents/submit',payload,self.c.branch),range(2)))
  self.assertTrue(all(r[0]==200 for r in results),results);self.assertEqual(results[0][1]['document']['id'],results[1][1]['document']['id']);self.assertEqual(len(self.a.get_state()['reports']),1)
 def test_ambiguous_legacy_review_never_selects_another_requester(self):
  value,review=self.saved();self.mutate(lambda s:s['expenseHistory'].append(dict(s['expenseHistory'][0],requester='other')))
  with self.a.db() as db:
   row=json.loads(db.execute('SELECT payload FROM business_reviews WHERE id=?',(review['id'],)).fetchone()[0]);row['target'].pop('requester');db.execute('UPDATE business_reviews SET payload=? WHERE id=?',(json.dumps(row),review['id']));db.commit()
  detail=self.follow(review);self.assertEqual(detail[0],200);self.assertTrue(detail[1]['unavailable'])
 def test_unauthorized_report_is_denied_and_new_assets_are_served(self):
  cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.op('/api/documents/submit',dict(group='서울',title='x',content='x',approver='admin',richContent=self.model()),cookie)[0],403)
  for asset in ['app-upgrade-v4127.js','app-upgrade-v4127.css']:self.assertEqual(self.get('/static/'+asset)[0],200)

"""V4.1.25: reason regression, durable period journal, notice privacy and scoped metrics."""
import copy,json,sqlite3,tempfile,unittest
from pathlib import Path
from unittest import mock
import test_v4124 as base
import activity_journal as journal
class Improvements125Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.Dashboard124Tests.setUpClass()
 @classmethod
 def tearDownClass(cls):base.Dashboard124Tests.tearDownClass()
 def setUp(self):
  self.t=base.Dashboard124Tests();self.t.setUp();self.a=self.t.a;self.c=self.t.c
 def get(self,path='/api/dashboard/activity',cookie=None):return self.t.get(path,cookie)
 def post(self,path,data,cookie=None):return self.c.request('/api/dashboard/'+path,data,cookie or self.c.branch)
 def notice(self,title='공지 시험'):
  result=self.t.notice(title);self.assertEqual(result[0],200,result);return result[1]['notice']
 def count(self,table):
  with self.a.db() as c:return c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]
 def test_reason_empty_reports_specific_field_and_preserves_business(self):
  before=copy.deepcopy(self.a.get_state());value=self.t.t.manage(reason='');self.assertEqual(value[0],400);self.assertIn('변경 사유를 입력',value[1]['message']);self.assertEqual(self.a.get_state(),before)
 def test_long_reason_previously_over_200_now_saves_and_retains_exact_history(self):
  reason='현장에서 확인한 변경 사유입니다.\n'*30;self.assertGreater(len(reason),200);self.assertLess(len(reason),1001)
  value=self.t.t.manage(reason=reason);self.assertEqual(value[0],200,value);card=self.a.get_state()['cards'][0];self.assertEqual(card['managementHistory'][-1]['reason'],reason.strip());self.assertEqual(card['incident']['reporter'],'시험 제보자')
 def test_invalid_reason_type_and_length_and_missing_incident_are_atomic(self):
  before=copy.deepcopy(self.a.get_state())
  for reason in [None,[],123,' '*3,'가'*1001]:self.assertEqual(self.t.t.manage(reason=reason)[0],400)
  self.assertEqual(self.t.t.manage(reason='사유 정상',incident={})[0],400);self.assertEqual(self.a.get_state(),before)
 def test_period_pagination_covers_every_matching_row_over_old_100_limit(self):
  with mock.patch.object(journal,'now',return_value='2026-02-01T15:00:00+00:00'):
   self.t.mutate(lambda s:s.update(notices=[{'id':i,'title':'기간공지 '+str(i),'text':'본문','createdAt':'2026-02-01T15:00:00Z'} for i in range(125)]))
  items=[]
  for offset in (0,50,100):
   status,value,_=self.get('/api/dashboard/activity?from=2026-02-02&to=2026-02-02&offset='+str(offset));self.assertEqual(status,200);self.assertEqual(value['total'],125);items+=value['items']
  self.assertEqual(len({r['eventKey'] for r in items}),125);self.assertEqual(self.get('/api/dashboard/activity?from=2026-02-01&to=2026-02-01')[1]['total'],0)
 def test_bad_range_and_pagination_rejected_without_internal_error(self):
  for query in ['from=2026-02-31','from=2026-02-03&to=2026-02-01','offset=-1','limit=201','offset=abc']:
   self.assertEqual(self.get('/api/dashboard/activity?'+query)[0],400,query)
 def test_item_read_is_per_user_persistent_and_does_not_change_business_revision(self):
  self.notice();value=self.get()[1];row=next(r for r in value['items'] if r['view']=='v_notices');before=copy.deepcopy(self.a.get_state());revision=value['revision'];self.assertFalse(row['readAt'])
  self.assertEqual(self.post('item-seen',{'eventKey':row['eventKey']})[0],200);self.assertEqual(self.post('item-seen',{'eventKey':row['eventKey']})[0],200)
  re=self.c.login('branch','Branch-test-pass!');value=self.get(cookie=re)[1];self.assertTrue(next(r for r in value['items'] if r['eventKey']==row['eventKey'])['readAt']);other=self.c.login('readonly','Branch-test-pass!');self.assertFalse(next(r for r in self.get(cookie=other)[1]['items'] if r['eventKey']==row['eventKey'])['readAt']);self.assertEqual(self.a.get_state(),before);self.assertEqual(value['revision'],revision)
 def test_item_read_cannot_bypass_view_or_branch_permissions(self):
  self.t.t.manage();row=next(r for r in self.get()[1]['items'] if r['view']=='v_card_reg');cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.post('item-seen',{'eventKey':row['eventKey']},cookie)[0],403)
  with self.a.db() as db:db.execute("UPDATE users SET scope='인천' WHERE username='branch'");db.commit()
  self.assertEqual(self.post('item-seen',{'eventKey':row['eventKey']})[0],403)
 def test_changed_and_deleted_source_keep_independent_activity_records(self):
  notice=self.notice();row=next(r for r in self.get()[1]['items'] if r['view']=='v_notices');self.post('item-seen',{'eventKey':row['eventKey']});self.t.mutate(lambda s:s['notices'][0].update(title='수정된 공지'))
  changed=[r for r in self.get()[1]['items'] if r['view']=='v_notices'];self.assertEqual(len(changed),2);self.assertFalse(changed[0]['readAt']);self.assertTrue(changed[1]['readAt'])
  self.assertEqual(self.t.t.w.operation('/api/notices/delete',{'id':notice['id']},self.c.admin)[0],200);value=[r for r in self.get()[1]['items'] if r['view']=='v_notices'];self.assertEqual(len(value),3);self.assertTrue(value[0]['deleted'])
 def test_journal_insert_failure_rolls_back_original_business_transaction(self):
  before=copy.deepcopy(self.a.get_state());count=self.count('dashboard_events')
  with mock.patch.object(journal,'insert',side_effect=sqlite3.OperationalError('journal rollback fixture')):self.assertEqual(self.t.t.manage()[0],500)
  self.assertEqual(self.a.get_state(),before);self.assertEqual(self.count('dashboard_events'),count)
 def test_legacy_backfill_retains_known_dates_and_marks_unknown_times(self):
  self.t.mutate(lambda s:s.update(notices=[{'id':1,'title':'구자료','text':'본문','createdAt':'2020-02-01'}]))
  with self.a.db() as c:c.execute('DELETE FROM dashboard_events');c.execute('DELETE FROM dashboard_meta');c.commit()
  value=self.get('/api/dashboard/activity?from=2020-02-01&to=2020-02-01')[1];self.assertEqual(value['total'],1);self.assertTrue(value['items'][0]['backfilled']);self.assertGreaterEqual(value['undated'],1)
 def test_notice_readers_admin_only_self_record_and_no_business_change(self):
  notice=self.notice();before=copy.deepcopy(self.a.get_state());revision=self.get()[1]['revision'];self.assertEqual(self.post('notice-read',{'id':str(notice['id']),'notice':notice})[0],200)
  path='/api/dashboard/notice-readers?id='+str(notice['id']);self.assertEqual(self.get(path)[0],403);self.assertEqual(self.c.request(path)[0],401);value=self.get(path,self.c.admin)[1];readers={r['username']:r for r in value['readers']};self.assertTrue(readers['branch']['read']);self.assertFalse(readers['admin']['read']);self.assertFalse(readers['readonly']['read']);self.assertEqual(self.a.get_state(),before);self.assertEqual(self.get()[1]['revision'],revision)
 def test_notice_revision_change_requires_fresh_read_and_preserves_old_record(self):
  notice=self.notice();self.post('notice-read',{'id':notice['id'],'notice':notice});self.t.mutate(lambda s:s['notices'][0].update(text='새 본문'))
  self.assertEqual(self.post('notice-read',{'id':notice['id'],'notice':notice})[0],409);path='/api/dashboard/notice-readers?id='+str(notice['id']);value=self.get(path,self.c.admin)[1];self.assertFalse(next(r for r in value['readers'] if r['username']=='branch')['read']);fresh=self.a.get_state()['notices'][0];self.assertEqual(self.post('notice-read',{'id':fresh['id'],'notice':fresh})[0],200);self.assertEqual(self.count('notice_reads'),2)
 def test_new_preferences_persist_and_admin_panels_remain_admin_only(self):
  from dashboard_api import DEFAULT_PREFS
  prefs={**DEFAULT_PREFS,'activity':False,'expenseSummary':False};self.assertEqual(self.post('preferences',prefs)[0],200);self.assertEqual(self.get()[1]['preferences'],prefs)
  self.assertEqual(self.post('preferences',{**prefs,'adminPasswords':False})[0],403);admin={**prefs,'adminAccounts':False,'adminChanges':False,'adminPasswords':False};self.assertEqual(self.post('preferences',admin,self.c.admin)[0],200);self.assertEqual(self.get(cookie=self.c.admin)[1]['preferences'],admin)
 def test_schema12_upgrade_preserves_legacy_preferences_and_business(self):
  with self.a.db() as db:
   db.execute('INSERT INTO dashboard_users VALUES(?,?,?)',('branch','{}',json.dumps({'notices':False,'shortcuts':True})));db.execute('DELETE FROM schema_versions');db.execute("INSERT INTO schema_versions VALUES(12,'2026-01-01')");db.commit()
  before=copy.deepcopy(self.a.get_state());self.a.prepare_db();self.assertEqual(self.a.get_state(),before);value=self.get()[1]['preferences'];self.assertFalse(value['notices']);self.assertTrue(value['activity']);self.assertTrue(value['expenseSummary'])
 def test_additional_graphs_obey_scope_and_domain_permissions(self):
  self.t.mutate(lambda s:s['cards'][0].update(paymentType='신용',usageScope='해외겸용',userType='지정',assignedUser='사용자'));self.t.t.seed_approved();self.t.mutate(lambda s:s['expenseHistory'].append(dict(s['expenseHistory'][0],id=99,group='인천',amount=99999)))
  row=self.get('/api/dashboard/details')[1]['branches'][0];self.assertEqual(row['credit'],1);self.assertEqual(row['overseas'],1);self.assertEqual(row['approvedAmount'],1000)
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_reg']),));db.commit()
  row=self.get('/api/dashboard/details')[1]['branches'][0];self.assertIsNone(row['approvedAmount']);self.assertIsNone(row['hipass']);self.assertIsNone(row['complaints'])
 def test_full_backup_contains_new_read_journal_tables_and_preferences(self):
  import backup_manager
  notice=self.notice();self.post('notice-read',{'id':notice['id'],'notice':notice});row=self.get()[1]['items'][0];self.post('item-seen',{'eventKey':row['eventKey']})
  with tempfile.TemporaryDirectory() as temp:
   folder=Path(temp);archive=backup_manager.create(self.a.DB_PATH,self.a.ATTACHMENT_DIR,folder/'saved.zip');stage=folder/'restore';stage.mkdir();backup_manager.verify(archive,stage)
   with sqlite3.connect(stage/'data'/self.a.DB_PATH.name) as db:
    self.assertEqual(db.execute('SELECT COUNT(*) FROM notice_reads').fetchone()[0],1);self.assertEqual(db.execute('SELECT COUNT(*) FROM dashboard_item_reads').fetchone()[0],1);self.assertGreater(db.execute('SELECT COUNT(*) FROM dashboard_events').fetchone()[0],0)
if __name__=='__main__':unittest.main()

"""V4.1.28 real Chromium regression with synthetic, disposable data."""
import sys,json,os,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright,expect
import test_v4127 as fixture
fixture.Upgrade127Tests.setUpClass();t=fixture.Upgrade127Tests();t.setUp();a=t.a;c=t.c
screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/workspace/v4128-screens'));screens.mkdir(exist_ok=True,parents=True)
try:
 t.t.seed()
 long_text='사용 목적과 증빙 자료를 확인하는 아주 긴 검색 선택 항목입니다. '*14+'끝까지 표시'
 with a.db() as db:
  s=a.get_state();base=s['cards'][0];base.update(expiryDate='2099-12-31',managementStatus='정상',status='available')
  s['cards']=[base,dict(base,id=2,num='2222',status='rented'),dict(base,id=3,num='3333',managementStatus='분실'),dict(base,id=4,num='4444',archived=True),dict(base,id=5,group='인천',num='5555',assignedUser='다른 지점 비밀')]
  ex=s['expenseHistory'][0];ex.update(cardNum=base['num'],purpose=long_text,merchant='긴 사용처',used=True)
  s['expenseHistory'] += [dict(ex,id=11,status='이관완료',historicalImport=True,amount=None,used=True),dict(ex,id=12,status='이관완료',historicalImport=True,amount=0,used=False),dict(ex,id=13,status='승인취소'),dict(ex,id=14,selfApproved=True)]
  s['history']=[dict(id=1,ledgerSerial=1,group='서울',cardNum=base['num'],type='불출',time='2026-10-01T00:00:00Z',user='시험 사용자',dept='시험부서',handler='branch',purpose=long_text,dueDate='2026-10-30',date='2026-10-01')]
  a.persist_state(db,s,'fixture')
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);context=browser.new_context(viewport={'width':1440,'height':900},timezone_id='Asia/Seoul');page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.route('**/api/login-weather',lambda r:r.fulfill(json={'ready':False}))
  def login(name='admin',pw='Admin-test-pass!'):
   page.goto('http://127.0.0.1:'+str(c.server.server_port));page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',pw);page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>!!currentUser&&!loginInFlight');page.evaluate('stopLiveSync()');page.wait_for_function('()=>!!dashboard24.data')
  def view(name):page.evaluate('(v)=>switchView(v,document.getElementById("nav_"+v))',name)
  def close():page.locator('#modalFooter button').first.click()
  login()
  for kind,viewname,body,column in [('expense','v_expense_history','expenseHistoryTable',9),('card','v_card_history','cardHistoryTable',13)]:
   view(viewname);combo=page.locator('#'+body).locator('xpath=preceding-sibling::thead').locator('.ledger-filter-combo').nth(column);button=combo.locator('.ledger-choice-trigger28');inp=combo.locator('input');button.scroll_into_view_if_needed();page.mouse.move(4,4);page.locator('#navTrigger26').focus();page.wait_for_timeout(160);assert button.evaluate('(e)=>getComputedStyle(e).opacity')=='0'
   combo.hover();expect(button).to_have_css('opacity','1');button.click();popup=page.locator('#ledgerChoices28');expect(popup).to_be_visible();target=popup.get_by_role('option',name=long_text,exact=True);expect(target).to_have_count(1);assert target.inner_text().endswith('끝까지 표시');rect=popup.bounding_box();assert rect['width']>inp.bounding_box()['width'];assert rect['x']>=0 and rect['x']+rect['width']<=1440;assert target.evaluate('(e)=>e.scrollWidth<=e.clientWidth+1');target.click();assert page.evaluate('(k)=>Object.keys(ledgerView[k].choices).length',kind)==1;expect(page.locator('#'+body)).to_contain_text('시험 사용자');inp.fill('결과가 없는 검색');expect(page.locator('#'+body)).not_to_contain_text('시험 사용자');inp.fill('');inp.focus();page.keyboard.press('ArrowDown');expect(popup).to_be_visible();page.keyboard.press('Escape');expect(popup).to_have_count(0);page.keyboard.press('ArrowDown');page.keyboard.press('Home');page.keyboard.press('Enter');assert page.evaluate('(k)=>Object.keys(ledgerView[k].choices).length',kind)==0
   page.screenshot(path=str(screens/(kind+'-filters.png')))
  print('PASS both ledgers: hidden/hover arrow, full 600+ character option, exact choice, search, reset, keyboard and viewport bounds',flush=True)
  view('v_card_reg');expect(page.locator('#registeredSelection28')).to_be_hidden();page.select_option('#registeredCardGroup','서울');summary=page.locator('#registeredSelection28');expect(summary).to_contain_text('조회 3장');expect(summary).to_contain_text('사용가능 1장');expect(summary).to_contain_text('대여중 1장');page.check('#registeredCardArchived');expect(summary).to_contain_text('조회 4장');expect(summary).to_contain_text('삭제 보존 1장');page.fill('#registeredCardSearch','2222');expect(summary).to_contain_text('조회 1장');expect(summary).to_contain_text('대여중 1장');page.fill('#registeredCardSearch','없는카드');expect(summary).to_contain_text('조회 0장');page.fill('#registeredCardSearch','');page.select_option('#registeredCardGroup','');expect(summary).to_be_hidden();labels=page.locator('#registeredCardSummary24 .reason-chips25>span').all_text_contents();assert labels[0].startswith('사용가능') and labels[1].startswith('대여중');page.screenshot(path=str(screens/'card-summary.png'))
  login('branch','Branch-test-pass!');view('v_card_reg');expect(page.locator('#registeredCardGroup')).to_be_disabled();expect(page.locator('#registeredSelection28')).not_to_contain_text('인천');expect(page.locator('#registeredCardTable')).not_to_contain_text('다른 지점 비밀')
  print('PASS selected-card summary follows search, archived, empty result and role scope; available/rented always first',flush=True)
  for name in ['v_complaint','v_report_write']:
   view(name);img=page.locator('#'+name+' .weekly-photo28 img');expect(img).to_be_visible();page.wait_for_function('(id)=>{const e=document.querySelector("#"+id+" .weekly-photo28 img");return e.complete&&e.naturalWidth>0}',arg=name);expect(page.locator('#'+name+' figcaption')).to_contain_text('계절·시간대');page.screenshot(path=str(screens/(name+'-weekly.png')))
  checks=page.evaluate('''()=>{
   const date=new Date('2026-10-19T03:00:00Z'),next=new Date('2026-10-26T03:00:00Z');
   const weather={ready:true,condition:'rain',temperatureC:12,forecastAt:date.toISOString()};
   return {same:writingPhoto28(date,null).file===writingPhoto28(new Date('2026-10-25T03:00:00Z'),null).file,different:writingPhoto28(date,null).file!==writingPhoto28(next,null).file,rain:writingPhoto28(date,weather).condition,stale:writingPhoto28(next,weather).condition,sunday:writingWeek28(new Date('2026-10-25T14:59:00Z')).key,monday:writingWeek28(new Date('2026-10-25T15:00:00Z')).key};
  }''');assert checks==dict(same=True,different=True,rain='rain',stale='season',sunday='2026-10-19',monday='2026-10-26'),checks
  print('PASS both local weekly photos load, stable week, weekly change, KST Monday boundary, fresh weather and stale fallback',flush=True)
  before=copy.deepcopy(a.get_state());view('v_business_review');page.evaluate('loadBusinessReview()');page.wait_for_function('()=>!!stability.review');
  for index,metric in enumerate(['approved','imported','missingAmount','unused','cancelled','selfApproved']):
   page.locator('#reviewContent .s-metrics>div').nth(index).click();expect(page.locator('.review-procedure28')).to_be_visible();expect(page.locator('.review-procedure28 h3')).to_contain_text('업무진행절차');expect(page.locator('.review-procedure28 ol>li')).to_have_count(4);expect(page.locator('#modalBody table')).to_be_visible();expect(page.locator('#modalBody')).to_contain_text('시험 사용자');assert page.locator('.review-procedure28').bounding_box()['y']<page.locator('#modalBody table').bounding_box()['y'];close()
  assert a.get_state()==before
  print('PASS six real metric drilldowns display tailored workflow above records without business-state mutation',flush=True)
  login();views=page.locator('.view-panel').evaluate_all('(els)=>els.map(e=>e.id)');sizes=[(2560,1440),(1920,1080),(1600,900),(1536,864),(1366,768),(1280,720),(1024,768),(800,600),(768,1024),(390,844)]
  for width,height in sizes:
   page.set_viewport_size({'width':width,'height':height});view('v_business_review');page.evaluate('loadBusinessReview()');page.wait_for_function('()=>!!stability.review');page.evaluate("reviewMetric26('approved')");expect(page.locator('.review-procedure28')).to_be_visible();rect=page.locator('#commonModal .modal-card').bounding_box();assert rect['x']>=-1 and rect['y']>=-1 and rect['x']+rect['width']<=width+1 and rect['y']+rect['height']<=height+1,(width,height,rect);close()
  print('PASS work-review dialogs remain inside all 10 viewport sizes',flush=True)
  results=[]
  for pinned in [False,True]:
   page.locator('#navPinned27').set_checked(pinned);page.wait_for_function('()=>!dashboard24.prefSaving')
   for width,height in sizes:
    page.set_viewport_size({'width':width,'height':height})
    for name in views:
     view(name);page.locator('#'+name+' details.ledger-advanced').evaluate_all('(els)=>els.forEach(e=>e.open=true)');page.wait_for_timeout(35)
     failure=page.evaluate('''()=>{
      const main=document.getElementById('mainContentArea'),panel=document.querySelector('.view-panel.active'),m=main.getBoundingClientRect(),p=panel.getBoundingClientRect();
      const forms=[...panel.querySelectorAll('input:not([type=hidden]),select,textarea,button')].filter(e=>e.getClientRects().length&&!e.closest('table'));
      const overflow=forms.filter(e=>{const r=e.getBoundingClientRect();return r.width>m.width+2||r.right>m.right+2||r.left<m.left-2;}).map(e=>e.id||e.className).slice(0,8);
      return {doc:document.documentElement.scrollWidth>innerWidth+2,panel:p.width>m.width+2,controls:overflow,main:m.width};
     }''')
     if failure['doc'] or failure['panel'] or failure['controls'] or failure['main']<150:results.append((pinned,width,height,name,failure))
    if width in [2560,1366,800,390]:view('v_report_write');page.screenshot(path=str(screens/('layout-'+str(width)+'-'+str(pinned)+'.png')))
  Path('/workspace/v4128-layout-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));assert not results,results[:12];assert not errors,errors
  print('PASS all '+str(len(views))+' screens at 10 viewports, pinned/auto navigation: '+str(len(views)*len(sizes)*2)+' layout checks; no page JavaScript errors',flush=True);browser.close()
finally:fixture.Upgrade127Tests.tearDownClass()

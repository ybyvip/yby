"""Real stability UI: policy, monthly review, self-decision and encrypted restore drill."""
from pathlib import Path
import importlib.util,json,tempfile,os,sys
from playwright.sync_api import sync_playwright,expect
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('f',ROOT/'tests/test_security.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.SecurityTests.setUpClass();c=f.SecurityTests();screens=Path(os.environ.get('YBY_TEST_SCREENSHOTS','/tmp/yby4121-screens'));screens.mkdir(exist_ok=True,parents=True)
try:
 c.setUp();a=f.app
 assert c.save({'cards':[{'id':1,'group':'서울','company':'시험은행','num':'TEST','status':'available'}]},c.admin)[0]==200
 with a.db() as conn:conn.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_stats','v_card_rent','v_expense','v_hipass_reg']),));conn.commit()
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.route('**/api/login-weather',lambda r:r.fulfill(status=200,content_type='application/json',body='{"ready":false}'))
  def login(name,pw):
   page.goto('http://127.0.0.1:'+str(c.server.server_port)+'/');page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',pw);page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>!!currentUser&&!loginInFlight');page.evaluate('stopLiveSync()')
  def view(name):page.evaluate('(name)=>switchView(name,document.getElementById("nav_"+name))',name)
  login('admin','Admin-test-pass!')
  view('v_company_policy');expect(page.locator('#policyBranches')).to_contain_text('광주');page.fill('#policyBranches',page.input_value('#policyBranches')+'\n부산');page.fill('#policyReasonText','실제 지점 마스터 추가 시험');page.fill('#policyPassword','Admin-test-pass!');page.click('#companyPolicySave');expect(page.locator('#companyPolicyStatus')).to_contain_text('정책을 저장');view('v_card_reg');assert '부산' in page.locator('#regCardGroup option').all_text_contents();page.locator('#v_card_reg').screenshot(path=str(screens/'branches.png'))
  view('v_business_review');expect(page.locator('#reviewContent')).to_contain_text('YBY 승인');page.fill('#reviewMonth','2026-10');page.click('#businessReviewRoot button:has-text("점검 조회")');expect(page.locator('#reviewStatus')).to_contain_text('조회 시점');assert page.locator('#reviewReference').count()==0;page.locator('#v_business_review').screenshot(path=str(screens/'review.png'))
  with page.expect_download() as exported:page.locator('#businessReviewRoot').get_by_role('button',name='엑셀',exact=True).click()
  assert exported.value.suggested_filename.endswith('.xlsx')
  # Submit through the real server, then approve own settlement through the new reason/password dialog.
  state=c.state(c.admin);body={'expense':{'date':'2026-10-15','cardNum':'TEST','group':'서울','user':'시험사용자','merchant':'시험상점','purpose':'안정화 승인 시험','amount':12000},'revision':state['revision'],'requestId':'self-approval-ui-test'}
  status,value,_=c.request('/api/expenses/submit',body,c.admin);assert status==200,value
  page.evaluate('async()=>{await loadServerState();initApp();}');view('v_expense');page.locator('#expenseTable button').filter(has_text='승인').first.click();expect(page.locator('#selfDecisionReason')).to_be_visible();page.fill('#selfDecisionReason','예외 승인 후 독립 점검 예정');page.fill('#selfDecisionPassword','Admin-test-pass!');page.locator('#modalFooter button').filter(has_text='사유 확인').click();expect(page.locator('#commonModal')).to_be_hidden();assert a.get_state()['expenseHistory'][0]['selfApproved']
  view('v_backup_ops');expect(page.locator('#backupOpsRoot')).to_contain_text('별도 보관');page.locator('#backupOpsRoot button').filter(has_text='암호화 백업 다운로드').click();page.fill('#backupPassword','Admin-test-pass!');page.fill('#backupArchivePassword','Portable-ui-secret!');page.fill('#backupArchiveConfirm','Portable-ui-secret!')
  with page.expect_download(timeout=30000) as downloaded:page.locator('#modalFooter button').filter(has_text='생성·검증').click()
  with tempfile.TemporaryDirectory() as t:
   dest=Path(t)/downloaded.value.suggested_filename;downloaded.value.save_as(dest);assert dest.read_bytes().startswith(b'YBYBACKUP1\n')
  expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#backupFileRows')).to_contain_text('yby_protected_');page.locator('#backupFileRows tr').filter(has_text='yby_protected_').first.locator('button').click();page.fill('#drillPassword','Admin-test-pass!');page.fill('#drillArchivePassword','Wrong-ui-secret!');page.locator('#modalFooter button').filter(has_text='검증·시험').click();expect(page.locator('#backupDrillStatus')).to_contain_text('암호가 다르거나');page.fill('#drillPassword','Admin-test-pass!');page.fill('#drillArchivePassword','Portable-ui-secret!');page.locator('#modalFooter button').filter(has_text='검증·시험').click();expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#backupOpsRoot')).to_contain_text('최근 시험 복원');page.locator('#v_backup_ops').screenshot(path=str(screens/'backup.png'))
  # No administrator policy page is disclosed to a non-administrator through navigation.
  page.evaluate('handleLogout()');page.wait_for_function('()=>currentUser===null');login('branch','Branch-test-pass!');expect(page.locator('#nav_v_company_policy')).to_be_hidden();expect(page.locator('#nav_v_backup_ops')).to_be_hidden();assert page.evaluate('!hasViewPermission("v_company_policy")&&!hasViewPermission("v_backup_ops")');view('v_business_review');expect(page.locator('#reviewContent')).to_contain_text('YBY 승인');expect(page.locator('#reviewGroup')).to_be_disabled();assert page.input_value('#reviewGroup')=='서울';assert not errors,errors
  for width in [1440,1024,768,390]:
   page.set_viewport_size({'width':width,'height':1000});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),width
  browser.close()
 print('PASS: dynamic branch/policy UI, scoped monthly review query/export, protected self-approval, encrypted download and wrong/correct password restore drill, role isolation and 1440/1024/768/390 layout; no JS errors')
finally:f.SecurityTests.tearDownClass()

"""Real Chromium acceptance, using only temporary synthetic business data."""
from pathlib import Path
import sys,json,copy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import test_security as f
import test_v4119 as historic
from playwright.sync_api import sync_playwright,expect
screens=Path('/workspace/v4122-screens');screens.mkdir(exist_ok=True)
f.SecurityTests.setUpClass();c=f.SecurityTests();a=f.app
try:
 c.setUp();branches=['본사','서울','인천','정봉','임원실','광주'];perms=['v_hipass_reg','v_hipass_history','v_card_status','v_card_rent','v_card_reg','v_card_history','v_expense','v_expense_history','v_stats','v_business_review','v_complaint','v_report_write']
 with a.db() as db:
  for i,branch in enumerate(branches):db.execute('INSERT INTO users(username,password_hash,scope,permissions_json,active,must_change_password) VALUES(?,?,?,?,1,0)',('role'+str(i),f.SecurityTests.branch_hash,branch,json.dumps(perms)))
  a.persist_state(db,{'cards':[dict(id=i+1,num='ROLE-'+str(i+1),group=branch,company='은행'+str(i),paymentType='신용',usageScope='국내전용',status='rented',dept='부서'+str(i),user='사용자'+str(i),purpose='출장'+str(i),rentDate='2026-10-20',dueDate='2099-01-01') for i,branch in enumerate(branches)]},'fixture')
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--no-proxy-server']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];dialogs=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:(dialogs.append(d.message),d.accept()));page.route('**/api/login-weather',lambda r:r.fulfill(json={'ready':False}))
  def login(name,pw='Branch-test-pass!'):
   page.goto('http://127.0.0.1:'+str(c.server.server_port));page.fill('#loginUserSelect',name);page.fill('#loginPasswordInput',pw);page.press('#loginPasswordInput','Enter');page.wait_for_function('()=>!!currentUser&&!loginInFlight');page.evaluate('stopLiveSync()')
  def view(name):page.evaluate('(v)=>switchView(v,document.getElementById("nav_"+v))',name)
  for i,branch in enumerate(branches):
   login('role'+str(i));view('v_card_status');expect(page.locator('#rentedTable tr')).to_have_count(1);values=page.locator('#rentedTable tr td').all_text_contents();assert len(values)==11,values;assert values[1]==branch and values[2]=='신용' and values[3]=='국내전용' and values[4]=='은행'+str(i) and values[5]=='부서'+str(i) and values[6]=='사용자'+str(i),values;assert len(page.evaluate('cardsData'))==1;page.screenshot(path=str(screens/('role-'+str(i)+'.png')))
  print('PASS six branch account scoped 11-column rental table')
  login('admin','Admin-test-pass!');view('v_card_status');expect(page.locator('#adminBranchTreeSection')).to_be_visible();assert page.locator('#branchTreeContainer .branch-node').count()==6
  # New synthetic workflow fixture, including a real XLSX-import record.
  h=historic.LedgerTests();h.setUp();ex=h.seeded();c=h.c
  with a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(perms),));db.commit()
  login('branch');view('v_card_rent');page.fill('#rentDept','출장부서');page.fill('#rentUser','출장사용자');page.fill('#rentDueDate','2099-01-01');page.check('[name=purposeChk][value="출장"]');page.fill('#rentDetailPurpose','현장 출장');page.set_input_files('#rentalDocuments',{'name':'출장신청서.txt','mimeType':'text/plain','buffer':'첨부 시험'.encode()});page.click('#rentalApplyButton');expect(page.locator('#rentalDraftTable tr')).to_contain_text('출장사용자');assert a.get_state()['cards'][0]['status']=='available';assert len(a.get_state()['history'])==2
  page.locator('#rentalDraftTable button').filter(has_text='수정').click();page.fill('#rentDept','수정출장부서');page.click('#rentalApplyButton');expect(page.locator('#rentalDraftTable')).to_contain_text('수정출장부서');assert a.get_state()['cards'][0]['status']=='available'
  page.screenshot(path=str(screens/'drafts.png'));page.locator('#rentalDraftTable button').filter(has_text='불출 확정').click();page.wait_for_function('()=>cardsData.find(x=>x.id===1).status==="rented"');assert a.get_state()['rentalDrafts'][0]['status']=='불출확정';assert a.get_state()['history'][-1]['attachments'];page.locator('#returnTable button').filter(has_text='반납 회수').first.click();page.check('#returnUnusedCheckbox');page.click('#returnCardSubmitButton');expect(page.locator('#commonModal')).to_be_hidden();assert a.get_state()['cards'][0]['status']=='available'
  print('PASS UI attachment draft/edit/confirm/unused return; draft leaves live card and history unchanged')
  # Deletion leaves audit record and no card state transition.
  page.fill('#rentDept','삭제부서');page.fill('#rentUser','삭제사용자');page.fill('#rentDueDate','2099-01-01');page.check('[name=purposeChk][value="출장"]');page.fill('#rentDetailPurpose','대기 후 취소');page.click('#rentalApplyButton');expect(page.locator('#rentalDraftTable')).to_contain_text('삭제사용자');page.locator('#rentalDraftTable button').filter(has_text='삭제').click();expect(page.locator('#rentalDraftTable')).to_contain_text('없습니다');assert a.get_state()['rentalDrafts'][-1]['status']=='삭제'
  view('v_expense_history');headers=page.locator('#expenseHistoryTable').evaluate('(e)=>[...e.previousElementSibling.querySelector("tr").children].map(x=>x.textContent)');assert headers[1:6]==['입력경로','소속','카드번호','사용자','부서'],headers;assert page.locator('#expenseHistoryTable tr').first.locator('td').count()==len(headers)
  page.locator('#expenseHistoryTable button').filter(has_text='수기 정정').first.click();expect(page.locator('#importCorrectionForm')).to_contain_text('원본 스냅샷');expect(page.locator('#importExtra_user')).to_have_value(ex['user']);page.fill('#importExtra_user','화면 정정사용자');page.fill('#importExtra_merchant','정정 사용처');page.fill('#importCorrectReason','명세 대조 후 사용자 정정');page.fill('#importCorrectPassword','Branch-test-pass!');page.click('#importCorrectSave');expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#expenseHistoryTable')).to_contain_text('화면 정정사용자');assert a.get_state()['expenseHistory'][0]['sourceSnapshot']==ex['sourceSnapshot'];assert a.get_state()['history'][0]['user']=='화면 정정사용자'
  page.screenshot(path=str(screens/'expense-ledger.png'));view('v_card_history');expect(page.locator('#cardHistoryTable')).to_contain_text('화면 정정사용자')
  # Sticky search geometry after real main panel scrolling.
  for panel in ['v_card_history','v_expense_history']:
   view(panel);page.evaluate('(id)=>{const el=document.createElement("div");el.style.height="1800px";el.id="scrollProbe";document.getElementById(id).append(el);document.querySelector(".main-content").scrollTop=500}',panel);page.wait_for_timeout(100);assert page.locator('#'+panel+' .history-filter-grid').evaluate('(e)=>getComputedStyle(e).position')=='sticky';box=page.locator('#'+panel+' .history-filter-grid').bounding_box();main=page.locator('.main-content').bounding_box();assert 0<=box['y']-main['y']<=30,(box,main);page.evaluate('document.getElementById("scrollProbe").remove();document.querySelector(".main-content").scrollTop=0')
  print('PASS separated expense columns, expanded linked correction, immutable origin and both sticky searches')
  view('v_card_reg');page.locator('#registeredCardTable button').filter(has_text='수정').first.click();page.select_option('#editCardManagementStatus','분실');page.fill('#editCardWithdrawalAccount','시험은행 계좌');page.fill('#editCardLimitAmount','200000');page.fill('#editCardReason','분실 신고 확인');page.locator('#modalFooter button').filter(has_text='저장').click();expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#registeredCardTable')).to_contain_text('분실');assert a.get_state()['cards'][0]['limitAmount']==200000;view('v_card_rent');assert '1' not in page.locator('#rentCardSelect option').evaluate_all('(xs)=>xs.map(x=>x.value)')
  # Open imported historical return issue; record incomplete and complete follow-up.
  result=h.op('/api/expenses/submit',{'expense':{'date':'2026-10-21','cardNum':'TEST-5545','group':'서울','user':'점검사용자','merchant':'점검처','purpose':'점검 대상','amount':1000,'category':'일반'}});assert result[0]==200,result
  page.evaluate('async()=>{await loadServerState();initApp();stopLiveSync()}')
  view('v_business_review');expect(page.locator('#reviewContent')).to_contain_text('확인할 업무');page.locator('#reviewIssueRows button').filter(has_text='명세대조 점검').first.click();page.fill('#itemReviewReference','명세대조 시험 문서');page.fill('#itemReviewNote','개별 업무 명세 대조 중');page.check('#itemReviewConfirmed');page.fill('#itemReviewPassword','Branch-test-pass!');before=copy.deepcopy(a.get_state());page.locator('#modalFooter button').filter(has_text='점검 기록 저장').click();expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('#reviewStatus')).to_contain_text('저장했습니다');assert a.get_state()==before
  record=page.locator('.s-review-record[data-review-state="미완료"]').first;record.locator('summary').click();record.locator('button').filter(has_text='후속 점검 작성').click();page.select_option('#itemReviewState','완료');page.fill('#itemReviewNote','명세 대조와 후속 조치 완료');page.check('#itemReviewConfirmed');page.fill('#itemReviewPassword','Branch-test-pass!');page.locator('#modalFooter button').filter(has_text='점검 기록 저장').click();expect(page.locator('#commonModal')).to_be_hidden();expect(page.locator('.s-review-record[data-review-state="완료"]')).to_have_count(1);expect(page.locator('.s-review-record[data-review-state="미완료"]')).to_have_count(1);assert a.get_state()==before;page.screenshot(path=str(screens/'item-review.png'))
  print('PASS incident card limit/account UI and block, item review save/follow-up/completion/history without changing business state')
  for panel,field in [('v_complaint','compContent'),('v_report_write','reportEditor27')]:view(panel);assert page.locator('#'+field).bounding_box()['height']>=300
  for width in [1440,1024,768,390]:
   page.set_viewport_size({'width':width,'height':1000});view('v_expense_history');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),width
  page.set_viewport_size({'width':1440,'height':1000})
  from test_v4112 import FleetTests
  result=h.op('/api/hipass/register',FleetTests().payload(distributionStatus='불출중'));assert result[0]==200,result;row=result[1]['hipass']
  result=h.op('/api/hipass/confirm',{'id':row['id'],'recordGroup':'서울','expectedVersion':row['recordVersion'],'physicalChecks':{'holder':True,'hipass':True,'fuel':True}});assert result[0]==200,result
  page.evaluate('async()=>{await loadServerState();initApp();stopLiveSync()}');view('v_hipass_history');expect(page.locator('#fleetHistoryTable tr')).to_have_count(2);latest=page.locator('#fleetHistoryTable tr[data-latest="true"]');old=page.locator('#fleetHistoryTable tr[data-latest="false"]');expect(latest).to_contain_text('현재 상태');expect(old).to_contain_text('과거 작업 완료');assert latest.get_attribute('data-progress')=='issued';assert latest.locator('td').first.evaluate('(e)=>getComputedStyle(e).backgroundColor')!=old.locator('td').first.evaluate('(e)=>getComputedStyle(e).backgroundColor');page.screenshot(path=str(screens/'fleet-history.png'))
  view('v_card_history');assert page.locator('#cardHistoryTable tr[data-progress]').count()>=1
  print('PASS fleet history current issue tint separated from past completed record')
  assert not errors,errors;print('PASS expanded writing areas, responsive ledger at 1440/1024/768/390; no JavaScript runtime errors');browser.close()
finally:f.SecurityTests.tearDownClass()

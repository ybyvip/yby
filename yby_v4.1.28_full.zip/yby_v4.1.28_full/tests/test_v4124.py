"""V4.1.24 dashboard authorization, read cursors, migration and retained incidents."""
import copy,json,unittest
from dashboard_api import DEFAULT_PREFS
import test_v4123 as prior
import test_v4112 as fleet
class Dashboard124Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):prior.Additions123Tests.setUpClass()
 @classmethod
 def tearDownClass(cls):prior.Additions123Tests.tearDownClass()
 def setUp(self):
  self.t=prior.Additions123Tests();self.t.setUp();self.a=self.t.a;self.c=self.t.c
  with self.a.db() as db:db.execute('DELETE FROM dashboard_users');db.commit()
 def get(self,path='/api/dashboard/activity',cookie=None):return self.c.request(path,cookie=cookie or self.c.branch)
 def mutate(self,callback):
  with self.a.db() as db:
   state=self.a.get_state();callback(state);self.a.persist_state(db,state,'fixture')
 def notice(self,title='새 공지'):
  return self.t.w.operation('/api/notices/create',{'title':title,'text':'시험 공지 본문'},self.c.admin)
 def seen(self,value,**changes):
  return self.c.request('/api/dashboard/seen',{'view':'v_notices','digest':value['digests']['v_notices'],'revision':value['revision'],**changes},self.c.branch)
 def test_login_required_and_no_permission_can_read_only_public_notices(self):
  self.assertEqual(self.c.request('/api/dashboard/activity')[0],401)
  self.notice();self.t.seed_approved();cookie=self.c.login('readonly','Branch-test-pass!');value=self.get(cookie=cookie)[1]
  self.assertEqual({r['kind'] for r in value['items']},{'공지'});self.assertEqual(self.get('/api/dashboard/details',cookie)[0],403)
 def test_branch_scope_and_permissions_filter_activity_before_hashing(self):
  self.t.manage();self.t.seed_approved()
  self.mutate(lambda s:s['expenseHistory'].append(dict(s['expenseHistory'][0],id=999,group='인천',user='다른지점비밀')))
  value=self.get()[1];self.assertNotIn('다른지점비밀',json.dumps(value,ensure_ascii=False));self.assertIn('카드 관리',[r['kind'] for r in value['items']])
  # No ledger permission means neither title nor digest for that screen.
  self.assertNotIn('v_expense_history',value['digests'])
 def test_first_use_baseline_then_user_isolated_persistent_unread_and_ack(self):
  first=self.get()[1];self.assertFalse(any(first['unread'].values()));self.assertEqual(self.notice()[0],200)
  changed=self.get()[1];self.assertTrue(changed['unread']['v_notices']);cookie=self.c.login('readonly','Branch-test-pass!');self.assertFalse(self.get(cookie=cookie)[1]['unread']['v_notices'])
  self.assertEqual(self.seen(changed)[0],200);self.assertFalse(self.get()[1]['unread']['v_notices']);self.assertEqual(self.notice('둘째 공지')[0],200)
  self.assertTrue(self.get()[1]['unread']['v_notices']);relogin=self.c.login('branch','Branch-test-pass!');self.assertTrue(self.get(cookie=relogin)[1]['unread']['v_notices']);self.assertTrue(self.get(cookie=cookie)[1]['unread']['v_notices'])
 def test_stale_ack_is_conflict_and_cross_menu_ack_denied(self):
  self.get();self.notice();changed=self.get()[1];self.notice('동시 새 공지');self.assertEqual(self.seen(changed)[0],409)
  current=self.get()[1];self.assertEqual(self.seen(current,view='v_admin')[0],403);self.assertTrue(self.get()[1]['unread']['v_notices']);self.assertEqual(self.seen(current)[0],200)
 def test_preferences_and_seen_do_not_change_business_data_or_revision(self):
  self.get();self.notice();value=self.get()[1];before=copy.deepcopy(self.a.get_state());revision=value['revision'];prefs={'notices':False,'shortcuts':True}
  self.assertEqual(self.c.request('/api/dashboard/preferences',prefs,self.c.branch)[0],200);self.assertEqual(self.seen(value)[0],200);self.assertEqual(self.a.get_state(),before);self.assertEqual(self.get()[1]['revision'],revision);self.assertEqual(self.get()[1]['preferences'],{**DEFAULT_PREFS,**prefs})
  cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get(cookie=cookie)[1]['preferences'],DEFAULT_PREFS)
  for bad in [{'notices':'false','shortcuts':True},{'notices':False},{**prefs,'username':'admin'}]:self.assertEqual(self.c.request('/api/dashboard/preferences',bad,self.c.branch)[0],400)
 def test_graphs_scoped_aggregate_only_has_no_card_identities_and_archived_excluded(self):
  self.t.manage();self.mutate(lambda s:s['cards'].append(dict(s['cards'][0],id=99,group='인천',num='OTHER')))
  value=self.get('/api/dashboard/details')[1];self.assertEqual(len(value['branches']),1);self.assertEqual(value['branches'][0]['abnormal'],1);self.assertEqual(value['abnormal'][0]['id'],1)
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_dashboard']),));db.commit()
  cookie=self.c.login('readonly','Branch-test-pass!');self.assertIsNone(self.get('/api/dashboard/details',cookie)[1]['abnormal']);self.assertEqual(self.get('/api/dashboard/details',self.c.admin)[1]['branches'][0]['cards'],1)
  self.t.replace();value=self.get('/api/dashboard/details')[1];self.assertEqual(value['branches'][0]['cards'],1);self.assertEqual(value['branches'][0]['abnormal'],0);self.assertEqual(value['abnormal'],[])
 def test_return_to_normal_preserves_history_and_source_business_states(self):
  self.assertEqual(self.t.manage()[0],200);before=copy.deepcopy(self.a.get_state()['cards'][0]);self.assertEqual(self.t.manage(managementStatus='정상')[0],200);after=self.a.get_state()['cards'][0]
  self.assertEqual(after['managementHistory'][:1],before['managementHistory']);self.assertEqual(len(after['managementHistory']),2);self.assertEqual(after['status'],before['status']);self.assertEqual(after['managementStatus'],'정상')
 def test_hipass_query_permission_cannot_modify_even_with_direct_api(self):
  ft=fleet.FleetTests();ft.w=self.t.w;ft.a=self.a;ft.c=self.c
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg','v_hipass_box']),));db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_hipass_box']),));db.commit()
  row=ft.register();row=ft.confirm(row)[1]['hipass'];cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(len(self.c.state(cookie)['state']['hipass']),1)
  payload={**ft.payload(),**ft.ref(row),'changeReason':'변경','password':'Branch-test-pass!','car':'변경차량'};self.assertEqual(self.t.w.operation('/api/hipass/update',payload,cookie)[0],403);self.assertEqual(ft.update(row,car='허용된 변경')[0],200)
 def test_expired_card_is_not_available_and_empty_branch_retains_usage_graph(self):
  self.mutate(lambda s:s['cards'][0].update(expiryDate='2020-01-01'))
  self.assertEqual(self.get('/api/dashboard/details')[1]['branches'][0]['available'],0)
  self.mutate(lambda s:s['history'].append({'id':99,'group':'인천','type':'불출'}))
  value=self.get('/api/dashboard/details',self.c.admin)[1];other=next(r for r in value['branches'] if r['group']=='인천');self.assertEqual(other['cards'],0);self.assertEqual(other['uses'],1)
 def test_hipass_export_respects_selected_card_types(self):
  from zipfile import ZipFile
  from io import BytesIO
  ft=fleet.FleetTests();ft.a=self.a;ft.c=self.c;ft.w=self.t.w
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_hipass_reg','v_hipass_box']),));db.commit()
  row=ft.register();ft.confirm(row)
  for hp,fuel_on,expected,excluded in [('1','0','HP-001','FUEL-001'),('0','1','FUEL-001','HP-001'),('0','0',None,'HP-001')]:
   status,raw,_=self.c.request('/api/hipass/export?mode=list&hipass='+hp+'&fuel='+fuel_on,cookie=self.c.branch);self.assertEqual(status,200)
   with ZipFile(BytesIO(raw)) as z:
    xml=z.read('xl/worksheets/sheet1.xml').decode();self.assertNotIn(excluded,xml)
    if expected:self.assertIn(expected,xml)
 def test_schema11_upgrade_preserves_accounts_history_and_preferences(self):
  self.t.manage();self.get();self.c.request('/api/dashboard/preferences',{'notices':False,'shortcuts':False},self.c.branch);before=copy.deepcopy(self.a.get_state())
  with self.a.db() as db:
   hashes=list(db.execute('SELECT username,password_hash FROM users ORDER BY username'));db.execute('DELETE FROM schema_versions');db.execute("INSERT INTO schema_versions VALUES(11,'2026-01-01')");db.commit()
  self.a.prepare_db();self.assertEqual(self.a.get_state(),before);self.assertEqual(self.get()[1]['preferences'],{**DEFAULT_PREFS,'notices':False,'shortcuts':False})
  with self.a.db() as db:self.assertEqual(list(db.execute('SELECT username,password_hash FROM users ORDER BY username')),hashes);self.assertEqual(db.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],self.a.storage.SCHEMA_VERSION)
if __name__=='__main__':unittest.main()

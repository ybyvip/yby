"""Scoped user analytics, exception-only news, detailed notices and statement review."""
import copy,json,unittest
from concurrent.futures import ThreadPoolExecutor
import test_v4125 as base
class Refinements126Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):base.Improvements125Tests.setUpClass()
 @classmethod
 def tearDownClass(cls):base.Improvements125Tests.tearDownClass()
 def setUp(self):
  self.t=base.Improvements125Tests();self.t.setUp();self.a=self.t.a;self.c=self.t.c;self.prior=self.t.t.t
 def get(self,path,cookie=None):return self.c.request(path,cookie=cookie or self.c.branch)
 def op(self,path,data,cookie=None):return self.prior.op(path,data,cookie or self.c.branch)
 def news(self):return self.get('/api/dashboard/activity?important=1')[1]['items']
 def seed(self):self.prior.seed_approved();return self.get('/api/business-review?period=2026-10')[1]
 def detail(self,v,**extra):
  from urllib.parse import urlencode
  target=v['issues'][0];params=dict(period=v['period'],group='',targetId=target['id'],recordGroup=target['group'],recordKind=target['recordKind'],requester=target['requester'],**extra)
  return self.get('/api/business-review/details?'+urlencode(params))
 def comparison(self,detail,checked=True):return [dict(field=k,observed=v,checked=checked) for k,v in detail['source']['fields'].items()]
 def ack(self,v,comparison,**extra):return self.op('/api/business-review/acknowledge',dict(period=v['period'],group='',fingerprint=v['fingerprint'],target=v['issues'][0],reference='시험 명세서 001',note='원본과 명세를 대조한 결과',reviewStatus='완료',confirmed=True,acknowledgeIssues=True,password='Branch-test-pass!',comparison=comparison)|extra)
 def test_notice_type_priority_period_validated_and_preserved(self):
  result=self.op('/api/notices/create',dict(title='긴급 공지',text='상세 공지 본문',noticeType='긴급공지',priority='긴급',audience='지점',startsOn='2026-10-22',endsOn='2026-10-30'),self.c.admin);self.assertEqual(result[0],200,result);self.assertEqual(result[1]['notice']['noticeType'],'긴급공지');self.assertEqual(len(self.news()),1)
 def test_invalid_notice_metadata_is_atomic_and_nonadmin_cannot_publish(self):
  before=copy.deepcopy(self.a.get_state());body=dict(title='시험',text='본문')
  for patch in [dict(noticeType='bad'),dict(priority='bad'),dict(audience='bad'),dict(startsOn='2026-02-31'),dict(startsOn='2026-10-30',endsOn='2026-10-22')]:self.assertEqual(self.op('/api/notices/create',body|patch,self.c.admin)[0],400)
  self.assertEqual(self.op('/api/notices/create',body)[0],403);self.assertEqual(self.a.get_state(),before)
 def test_user_analytics_are_grouped_by_person_and_branch_not_branch_titles(self):
  self.t.t.mutate(lambda s:s['cards'].extend([dict(s['cards'][0],id=2,user='다른 사용자',status='rented'),dict(s['cards'][0],id=3,group='인천',user='외부 비밀',status='rented')]))
  result=self.get('/api/dashboard/users');self.assertEqual(result[0],200);users={r['user']:r for r in result[1]['users']};self.assertIn('미배정·미기록',users);self.assertEqual(users['다른 사용자']['rented'],1);self.assertNotIn('외부 비밀',users);self.assertNotIn('num',json.dumps(result[1]))
 def test_user_analytics_aggregate_only_and_readonly_accounts_are_denied(self):
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='readonly'",(json.dumps(['v_dashboard']),));db.commit()
  cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get('/api/dashboard/users',cookie)[0],403);self.assertEqual(self.c.request('/api/dashboard/users')[0],401)
 def test_user_analytics_does_not_leak_names_from_unpermitted_domains(self):
  self.prior.seed_approved();self.t.t.mutate(lambda s:s['expenseHistory'][0].update(user='정산 전용 이름'))
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_reg']),));db.commit()
  value=self.get('/api/dashboard/users')[1];self.assertNotIn('정산 전용 이름',json.dumps(value,ensure_ascii=False));self.assertTrue(all(r['approvedAmount'] is None for r in value['users']))
 def test_routine_events_are_excluded_and_incident_and_recovery_are_not_duplicated(self):
  self.t.notice();self.assertEqual(self.news(),[]);self.assertEqual(self.prior.manage()[0],200);lost=self.news();self.assertEqual(len(lost),1,lost);self.assertIn('분실',lost[0]['description']);self.assertEqual(lost[0]['id'],'1');self.assertTrue(lost[0]['managementEvent'])
  self.assertEqual(self.prior.manage(managementStatus='정상')[0],200);self.assertEqual(len(self.news()),2);self.assertIn('정상',self.news()[0]['description'])
 def test_report_after_submission_change_is_important_and_permission_scoped(self):
  result=self.op('/api/documents/submit',dict(group='서울',title='변경 보고',content='본문',reviewer='',approver='admin',attachments=[]));self.assertEqual(result[0],200);self.assertEqual(self.news(),[])
  self.t.t.mutate(lambda s:s['reports'][0].update(status='rejected'));rows=self.news();self.assertEqual(len(rows),1);self.assertIn('변경',rows[0]['description']);cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get('/api/dashboard/activity?important=1',cookie)[1]['items'],[])
 def test_deleted_submitted_report_remains_important_journal_record(self):
  self.op('/api/documents/submit',dict(group='서울',title='삭제 보고',content='본문',reviewer='',approver='admin',attachments=[]));self.t.t.mutate(lambda s:s.update(reports=[]));self.assertTrue(self.news()[0]['deleted'])
 def test_review_metric_drilldowns_match_own_branch_month_and_conditions(self):
  self.seed();self.t.t.mutate(lambda s:s['expenseHistory'].extend([dict(s['expenseHistory'][0],id=20,status='이관완료',historicalImport=True,amount=None),dict(s['expenseHistory'][0],id=21,used=False),dict(s['expenseHistory'][0],id=22,status='승인취소'),dict(s['expenseHistory'][0],id=23,selfApproved=True),dict(s['expenseHistory'][0],id=24,group='인천',user='타지점비밀')]))
  expected={'approved':{'10','23'},'imported':{'20'},'missingAmount':{'20'},'unused':{'21'},'cancelled':{'22'},'selfApproved':{'23'}}
  for metric,ids in expected.items():
   result=self.get('/api/business-review/details?period=2026-10&metric='+metric);self.assertEqual(result[0],200,result);self.assertEqual({r['id'] for r in result[1]['rows']},ids);self.assertNotIn('타지점비밀',json.dumps(result[1],ensure_ascii=False))
 def test_individual_review_displays_actual_source_fields_without_full_card_number(self):
  v=self.seed();value=self.detail(v);self.assertEqual(value[0],200);self.assertEqual(value[1]['source']['fields']['amount'],1000);self.assertEqual(value[1]['source']['fields']['dept'],'시험부서');self.assertNotIn('cardNum',value[1]['source']);self.assertEqual(value[1]['sourceFingerprint'],v['issues'][0]['sourceFingerprint'])
 def test_comparison_edit_is_saved_and_does_not_rewrite_approved_business(self):
  v=self.seed();d=self.detail(v)[1];items=self.comparison(d)
  for r in items:
   if r['field']=='amount':r['observed']=1500
  before=copy.deepcopy(self.a.get_state());result=self.ack(v,items,note='대조 명세에는 1500원으로 기재되어 보완 필요 확인');self.assertEqual(result[0],200,result);record=result[1]['review'];self.assertEqual(record['differenceCount'],1);self.assertEqual(record['sourceSnapshot']['fields']['amount'],1000);self.assertEqual(self.a.get_state(),before);self.assertEqual(self.get('/api/business-review?period=2026-10')[1]['issues'],[])
 def test_complete_requires_all_checks_and_forbidden_fields_are_rejected(self):
  v=self.seed();d=self.detail(v)[1];items=self.comparison(d,False);self.assertEqual(self.ack(v,items)[0],400)
  for bad in [[dict(field='status',observed='승인완료',checked=True)],self.comparison(d)+[self.comparison(d)[0]],self.comparison(d)[:-1]]:self.assertEqual(self.ack(v,bad)[0],400)
  items=self.comparison(d);next(r for r in items if r['field']=='amount')['observed']=True;self.assertEqual(self.ack(v,items)[0],400)
 def test_incomplete_followup_keeps_both_comparison_versions(self):
  v=self.seed();d=self.detail(v)[1];first=self.ack(v,self.comparison(d,False),reviewStatus='미완료');self.assertEqual(first[0],200,first);fresh=self.get('/api/business-review?period=2026-10')[1];self.assertEqual(len(fresh['issues']),1);second=self.ack(fresh,self.comparison(d),reviewId=first[1]['review']['id']);self.assertEqual(second[0],200,second);rows=self.get('/api/business-review?period=2026-10')[1]['reviews'];self.assertEqual(len(rows),2);self.assertEqual(rows[0]['previousId'],rows[1]['id']);self.assertTrue(all(r['comparison'] for r in rows))
 def test_review_foreign_permission_stale_source_and_password_are_enforced(self):
  v=self.seed();d=self.detail(v)[1];items=self.comparison(d);cookie=self.c.login('readonly','Branch-test-pass!');self.assertEqual(self.get('/api/business-review/details?period=2026-10&metric=approved',cookie)[0],403);self.assertEqual(self.ack(v,items,password='wrong')[0],403)
  self.t.t.mutate(lambda s:s['expenseHistory'][0].update(amount=2000));self.assertEqual(self.ack(v,items)[0],409)
 def test_concurrent_review_completion_has_one_winner(self):
  v=self.seed();items=self.comparison(self.detail(v)[1]);revision=self.c.state(self.c.branch)['revision'];payload=dict(period=v['period'],group='',fingerprint=v['fingerprint'],target=v['issues'][0],reference='시험 명세',note='개별 원본과 대조 완료',reviewStatus='완료',confirmed=True,acknowledgeIssues=True,password='Branch-test-pass!',comparison=items,revision=revision)
  def run(i):return self.c.request('/api/business-review/acknowledge',{**payload,'requestId':'review-race26-'+str(i)},self.c.branch)[0]
  with ThreadPoolExecutor(2) as pool:statuses=list(pool.map(run,[1,2]))
  self.assertEqual(sorted(statuses),[200,409])
 def test_expense_queue_to_ledger_is_processing_change_not_deleted_source(self):
  with self.a.db() as db:db.execute("UPDATE users SET permissions_json=? WHERE username='branch'",(json.dumps(['v_card_reg','v_expense','v_expense_history']),));db.commit()
  self.t.t.mutate(lambda state:state.update(expense=[dict(id=50,group='서울',requester='branch',user='신청자',status='승인대기',date='2026-10-01',amount=1000)]))
  self.assertEqual(self.news(),[])
  def move(state):
   state['expenseHistory'].append(dict(state['expense'][0],status='승인완료'));state['expense']=[]
  self.t.t.mutate(move);rows=self.news();self.assertEqual(len(rows),1);self.assertEqual(rows[0]['view'],'v_expense_history');self.assertFalse(rows[0].get('deleted'));self.assertIn('승인완료',rows[0]['description'])
 def test_schema13_upgrade_preserves_old_news_notice_incident_accounts_and_reviews(self):
  self.prior.manage();notice=self.t.notice('이전 공지');v=self.seed();detail=self.detail(v)[1];self.assertEqual(self.ack(v,self.comparison(detail))[0],200)
  self.t.t.mutate(lambda state:[row.pop(k,None) for row in state['notices'] for k in ('noticeType','priority','audience','startsOn','endsOn')])
  before=copy.deepcopy(self.a.get_state())
  with self.a.db() as db:
   hashes=list(db.execute('SELECT username,password_hash FROM users ORDER BY username'));events=list(db.execute('SELECT event_key,payload_json FROM dashboard_events ORDER BY event_key'));reviews=list(db.execute('SELECT id,payload FROM business_reviews ORDER BY id'));db.execute('DELETE FROM schema_versions');db.execute("INSERT INTO schema_versions VALUES(13,'2026-10-22')");db.commit()
  self.a.prepare_db();self.assertEqual(self.a.get_state(),before)
  with self.a.db() as db:
   self.assertEqual(list(db.execute('SELECT username,password_hash FROM users ORDER BY username')),hashes);self.assertEqual(list(db.execute('SELECT event_key,payload_json FROM dashboard_events ORDER BY event_key')),events);self.assertEqual(list(db.execute('SELECT id,payload FROM business_reviews ORDER BY id')),reviews);self.assertEqual(db.execute('SELECT MAX(version) FROM schema_versions').fetchone()[0],self.a.storage.SCHEMA_VERSION)
if __name__=='__main__':unittest.main()

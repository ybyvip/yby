"""Scoped management review. An inspection acknowledgement is not accounting close."""
import hashlib,json,re,uuid
from datetime import date
import fleet_cards

def require(a,user):
    if a.user_scope(user)!='ALL' and not a.permissions_for(user)&{'v_stats','v_business_review'}:raise PermissionError('통계·업무 점검 권한이 없습니다.')
def initialize(conn):conn.execute('CREATE TABLE IF NOT EXISTS business_reviews(id TEXT PRIMARY KEY,period TEXT NOT NULL,branch TEXT NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL,payload TEXT NOT NULL)')
def snapshot(a,conn,state,user,period,group=''):
    require(a,user)
    if not isinstance(period,str) or not re.fullmatch(r'\d{4}-\d{2}',period):raise ValueError('조회월은 YYYY-MM입니다.')
    date.fromisoformat(period+'-01');scope=a.user_scope(user)
    if scope!='ALL':group=scope
    import domain
    if group and group not in domain.BRANCHES:raise ValueError('지점 오류')
    allowed=lambda r:isinstance(r,dict) and (not group or r.get('group')==group)
    rows=lambda k:[r for r in state.get(k,[]) if allowed(r)]
    at=a.business_date();today=date.fromisoformat(at);issues=[]
    def item(kind,row,text,view):
        record_kind='report' if view=='v_report_box' else 'expense'
        if row.get('status')!=('approved' if record_kind=='report' else '승인완료'):return
        if record_kind=='expense' and (row.get('used') is False or row.get('isCorrection')):return
        identity=(record_kind,str(row.get('id','')),row.get('group',''),row.get('requester',''))
        existing=next((x for x in issues if target_key(x)==identity),None)
        if existing:
            if text not in existing['message']:existing['message']+=' · '+text
            return
        issues.append({'kind':kind,'recordKind':record_kind,'id':str(row.get('id','')),'group':row.get('group',''),'requester':row.get('requester',''),'user':row.get('user') or row.get('author') or row.get('requester') or '', 'cardLast4':re.sub(r'\D','',str(row.get('cardNum') or ''))[-4:],'message':text,'view':view,'sourceFingerprint':source_fingerprint(row)})
    pending=rows('expense')
    ledger=[r for r in rows('expenseHistory') if str(r.get('date','')).startswith(period)]
    summary={'documents':len(ledger),'approved':0,'approvedAmount':0,'imported':0,'importedAmount':0,'missingAmount':0,'zeroAmount':0,'unused':0,'cancelled':0,'selfApproved':0,'invalidAmounts':0}
    for e in ledger:
        used=e.get('used',e.get('manualUsed',True));unused=used is False
        amount=e.get('amount');valid_amount=type(amount)==int and 0<=amount<=10**12
        if not unused and e.get('status')!='승인취소' and not valid_amount and (amount is not None or not e.get('historicalImport')):
            summary['invalidAmounts']+=1;item('invalidAmount',e,'원본 금액 형식/범위 확인 · 금액 합계에서 제외','v_expense_history')
        if unused:summary['unused']+=1
        if e.get('status')=='승인취소':summary['cancelled']+=1
        elif not unused and e.get('status')=='승인완료':summary['approved']+=1;summary['approvedAmount']+=(amount if valid_amount else 0)
        if e.get('historicalImport') and not unused and e.get('status')!='승인취소':
            summary['imported']+=1;summary['importedAmount']+=(amount if valid_amount else 0)
            if e.get('amount') is None:summary['missingAmount']+=1;item('missingAmount',e,'이관 원본 금액 미기재','v_expense_history')
            elif e.get('amount')==0:summary['zeroAmount']+=1
            if not e.get('returnDate'):item('unconfirmedReturn',e,'이관 원본 반납일 미확인','v_expense_history')
        if e.get('selfApproved') or e.get('selfDecision'):
            summary['selfApproved']+=1;item('selfApproval',e,'자기 결재 · 독립 사후 검토 필요','v_expense_history')
    for row in ledger:
        if row.get('status')=='승인완료' and not row.get('isCorrection') and row.get('used') is not False:
            item('approvedCheck',row,'승인완료 · 명세대조 점검 대상','v_expense_history')
    visible_reports=rows('reports') if scope=='ALL' or a.permissions_for(user)&{'v_report_write','v_report_box'} else []
    for r in visible_reports:
        ref=r.get('sourceExpenseRef')
        if not isinstance(ref,dict):continue
        original=next((e for e in state.get('expense',[])+state.get('expenseHistory',[]) if all(str(e.get(k,''))==str(ref.get(k,'')) for k in ('id','group','requester'))),None)
        if original and (original.get('status')!=r.get('sourceExpenseStatus') or original.get('amount')!=(r.get('sourceExpenseSnapshot') or {}).get('amount')):item('reportChanged',r,'복사 후 원본 정산 상태/금액 변경 · 보고서 재검토','v_report_box')
    # Membership and amounts are scoped on the server before hashes or acknowledgement.
    payload={'period':period,'group':group or 'ALL','summary':summary,'issues':issues,'pendingCount':len(pending)}
    fingerprint=hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    initialize(conn)
    reviews=[]
    query='SELECT payload FROM business_reviews WHERE period=?'+(' AND branch=?' if group else '')+' ORDER BY created_at DESC, rowid DESC'
    params=(period,group) if group else (period,)
    for row in conn.execute(query,params):
        value=json.loads(row[0]);target=value.get('target')
        if target and target.get('sourceFingerprint'):
            import review_detail
            source=review_detail.source_for(state,target)
            value['current']=bool(source and source_fingerprint(source)==target['sourceFingerprint'])
        else:value['current']=value['fingerprint']==fingerprint
        reviews.append(value)
    latest={}
    for review in reviews:
        if review.get('target'):latest.setdefault(target_key(review['target']),review)
    visible=[x for x in issues if not (latest.get(target_key(x),{}).get('status')=='완료' and latest[target_key(x)].get('current'))]
    payload['issues']=visible
    return {**payload,'fingerprint':fingerprint,'checkedAt':a.now(),'reviews':reviews,'notice':'관리용 대사·점검입니다. 회계 마감/승인 변경이 아닙니다. 과거 이관과 YBY 승인 금액은 별도로 대조하세요.','issueCounts':{kind:sum(x['kind']==kind for x in visible) for kind in sorted({x['kind'] for x in visible})}}

def acknowledge(a,conn,state,data,user):
    require(a,user)
    if a.user_scope(user)!='ALL' and not a.permissions_for(user)&{'v_stats','v_business_review'}:raise PermissionError('통계 권한이 있어야 대사 점검을 기록할 수 있습니다.')
    result=snapshot(a,conn,state,user,data.get('period'),data.get('group',''))
    if data.get('fingerprint')!=result['fingerprint']:raise a.StateConflict('점검 자료가 바뀌었습니다. 다시 조회하여 확인하세요.')
    target=None;previous=None
    if data.get('reviewId'):
        previous=next((x for x in result['reviews'] if x['id']==data['reviewId']),None)
        if not previous or not previous.get('target'):raise ValueError('기존 개별 점검기록을 찾을 수 없습니다.')
        import review_detail
        review_detail.require_followup(a,user,previous)
        if any(x.get('previousId')==previous['id'] for x in result['reviews']):raise a.StateConflict('이미 후속 점검기록이 있습니다. 최신 기록을 확인하세요.')
        target=previous['target']
        if target.get('sourceFingerprint'):
            current=next((x for x in result['issues'] if target_key(x)==target_key(target)),None)
            if current:target=current
            elif not previous.get('current'):raise a.StateConflict('원본이 변경되어 현재 점검 대상과 일치하지 않습니다. 다시 조회하세요.')
    elif data.get('target') is not None:
        requested=data['target']
        if not isinstance(requested,dict):raise ValueError('점검 대상 오류')
        target=next((x for x in result['issues'] if all(x.get(k)==requested.get(k) for k in ('kind','id','group','requester','sourceFingerprint'))),None)
        if not target:raise a.StateConflict('점검 대상이 변경되었습니다. 다시 조회하세요.')
    status=data.get('reviewStatus','완료')
    if status not in ('미완료','완료'):raise ValueError('점검 상태 오류')
    ref=data.get('reference','');note=data.get('note','')
    if not isinstance(ref,str) or not 3<=len(ref.strip())<=300:raise ValueError('대조한 카드사/회계 명세의 문서명·번호를 3~300자로 입력하세요.')
    if not isinstance(note,str) or not 3<=len(note.strip())<=1000:raise ValueError('점검 결과·미결 처리 계획을 3~1,000자로 입력하세요.')
    if data.get('confirmed') is not True or (result['issues'] and data.get('acknowledgeIssues') is not True):raise ValueError('명세 대조와 미결 사항을 확인하세요.')
    value={k:result[k] for k in ('period','group','fingerprint','summary','issueCounts')};value.update(id=uuid.uuid4().hex,actor=user,createdAt=a.now(),reference=ref.strip(),note=note.strip(),hasOpenIssues=bool(result['issues']))
    if target:
        value.update(group=target['group'],target=target,status=status,previousId=previous['id'] if previous else None)
        value.pop('summary',None);value.pop('issueCounts',None)
    if data.get('comparison') is not None:
        if not target:raise ValueError('개별 대상이 있어야 명세대조 내용을 저장할 수 있습니다.')
        import review_detail
        value.update(review_detail.comparison(state,target,data['comparison'],status))
    conn.execute('INSERT INTO business_reviews VALUES(?,?,?,?,?,?)',(value['id'],value['period'],value['group'],user,value['createdAt'],json.dumps(value,ensure_ascii=False)))
    conn.execute('INSERT INTO audit_events(event_time,username,action,ip,details) VALUES(?,?,?,?,?)',(a.now(),user,'BUSINESS_REVIEW','',json.dumps(value,ensure_ascii=False)));return value

def target_key(target):return (target.get('recordKind','expense'),str(target.get('id','')),target.get('group',''),target.get('requester',''))
def source_fingerprint(row):return hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

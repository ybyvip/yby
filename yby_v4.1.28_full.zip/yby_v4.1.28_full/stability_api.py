"""Small HTTP boundary for company policy, business reviews and backup operations."""
import json,secrets,tempfile,time
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs,urlparse
import business_review,company_policy,backup_operations,backup_crypto,backup_manager,reauthentication
GET={'/api/company-policy','/api/business-review','/api/business-review/details','/api/admin/backup-status'}
POST={'/api/company-policy/update','/api/business-review/acknowledge','/api/admin/backup-policy','/api/admin/backup-drill','/api/admin/protected-backup'}

def respond_error(h,a,error):
    code=429 if isinstance(error,reauthentication.Limited) else 403 if isinstance(error,PermissionError) else 409 if isinstance(error,a.StateConflict) else 400
    h.send_json({'ok':False,'message':str(error)},code)

def get(h,g,path):
    if path not in GET:return False
    a=SimpleNamespace(**g)
    try:
        user=h.session_user()
        if not user:h.send_json({'ok':False,'message':'로그인이 필요합니다.'},401);return True
        if getattr(h,'must_change_password',False):raise PermissionError('최초 비밀번호를 변경하세요.')
        if path=='/api/company-policy':
            with a.db() as c:value=company_policy.get(c)
            h.send_json({'ok':True,'policy':value});return True
        if path=='/api/business-review/details':
            import review_detail
            q=parse_qs(urlparse(h.path).query)
            with a.LOCK,a.db() as c:value=review_detail.details(a,c,a.storage.read(c) or {},user,q);c.commit()
            h.send_json(value);return True
        if path=='/api/business-review':
            q=parse_qs(urlparse(h.path).query)
            with a.LOCK,a.db() as c:value=business_review.snapshot(a,c,a.storage.read(c) or {},user,q.get('period',[a.business_date()[:7]])[0],q.get('group',[''])[0]);c.commit()
            h.send_json({'ok':True,**value});return True
        if a.user_scope(user)!='ALL':raise PermissionError('최고관리자만 백업 설정을 조회할 수 있습니다.')
        h.send_json({'ok':True,**backup_operations.status(a)})
    except (ValueError,PermissionError,a.StateConflict) as error:respond_error(h,a,error)
    except Exception:
        import logging;logging.exception('Stability status failed');h.send_json({'ok':False,'message':'점검 상태를 읽지 못했습니다. 서버 로그를 확인하세요.'},500)
    return True

def post(h,g,path,data):
    if path not in POST:return False
    a=SimpleNamespace(**g)
    try:
        user=h.session_user()
        if not user:h.send_json({'ok':False,'message':'로그인이 필요합니다.'},401);return True
        if getattr(h,'must_change_password',False):raise PermissionError('최초 비밀번호를 변경하세요.')
        if path=='/api/business-review/acknowledge':
            business_review.require(a,user);reauthentication.verify(a,user,data.get('password'),h.client_address[0])
            return a.operations.transaction(h,g,path,data,user,lambda s,c:{'review':business_review.acknowledge(a,c,s,data,user)}) or True
        if a.user_scope(user)!='ALL':raise PermissionError('최고관리자 권한이 필요합니다.')
        reauthentication.verify(a,user,data.get('password'),h.client_address[0])
        if path=='/api/company-policy/update':return a.operations.transaction(h,g,path,data,user,lambda s,c:{'policy':company_policy.change(c,data,user,a.now(),s)}) or True
        if path=='/api/admin/backup-policy':
            with a.LOCK:
                cfg=backup_operations.configure(a,data,user);a.audit(user,'BACKUP_POLICY_CHANGE',h.client_address[0],json.dumps({k:v for k,v in cfg.items() if k!='destination'},ensure_ascii=False))
                if cfg['enabled']:
                    try:a.backup('manual')
                    except Exception:backup_operations.update_state(a,lastError='설정 저장 후 초기 전체백업에 실패했습니다. 경로·공간을 확인하세요.',lastFailure=a.now())
                partial=bool(cfg['enabled'] and backup_operations.state(a).get('lastError'))
            h.send_json({'ok':True,'policy':cfg,'partial':partial,'message':'설정은 저장했으나 첫 별도 보관에 실패했습니다. 경로·공간을 확인하세요.' if partial else '설정 저장'+(' · 첫 암호화 별도 보관 검증 완료' if cfg['enabled'] else ' 완료')});return True
        if path=='/api/admin/backup-drill':
            result=backup_operations.drill(a,data.get('name'),data.get('backupPassword') or None);a.audit(user,'BACKUP_RESTORE_DRILL',h.client_address[0],json.dumps(result,ensure_ascii=False));h.send_json({'ok':True,'drill':result});return True
        secret=data.get('backupPassword');backup_crypto.password(secret)
        if type(data.get('recovery',False))!=bool:raise ValueError('복구 자료 선택 오류')
        stamp=a.datetime.now(a.timezone.utc).strftime('%Y%m%d_%H%M%S_%f');target=a.BACKUP_DIR/('yby_protected_'+stamp+'.ybybackup')
        with a.LOCK:
            if data.get('recovery'):backup_operations.recovery_backup(a,target,secret)
            else:backup_manager.create(a.DB_PATH,a.ATTACHMENT_DIR,target,a.APP_VERSION,password=secret)
            token=secrets.token_urlsafe(32);a.BACKUP_DOWNLOAD_TOKENS[token]={'name':target.name,'user':user,'expires':time.time()+300}
            backup_operations.update_state(a,lastProtectedSuccess=a.now(),lastProtectedFile=target.name)
            a.audit(user,'ENCRYPTED_BACKUP_CREATED',h.client_address[0],json.dumps({'name':target.name,'recovery':bool(data.get('recovery'))}))
        h.send_json({'ok':True,'message':'암호화 백업·복호 검증 완료. 암호는 다운로드 파일과 별도로 보관하세요.','download':'/api/admin/backup/download?token='+token,'name':target.name})
    except (ValueError,PermissionError,a.StateConflict) as error:respond_error(h,a,error)
    except ImportError:h.send_json({'ok':False,'message':'암호화 지원을 설치하세요: INSTALL_BACKUP_ENCRYPTION.bat'},400)
    except Exception:
        import logging;logging.exception('Stability operation failed');h.send_json({'ok':False,'message':'작업을 완료하지 못했습니다. 운영 자료를 삭제하지 않았습니다. 서버 로그·경로·저장 공간을 확인하세요.'},500)
    return True

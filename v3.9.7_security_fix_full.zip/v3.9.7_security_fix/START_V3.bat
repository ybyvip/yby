@echo off
setlocal
cd /d "%~dp0"
title V3.9.7 Launcher
echo ============================================================
echo Corporate Card / Hi-pass System V3.9.7
echo ============================================================
echo.
echo Starting launcher...
echo.

where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 --version >nul 2>&1
    if not errorlevel 1 (
        py -3 "%~dp0launcher.py"
        goto :finished
    )
)

where python.exe >nul 2>&1
if not errorlevel 1 (
    python "%~dp0launcher.py"
    goto :finished
)

echo [ERROR] Python 3 was not found.
echo Install Python 3.11 or later and enable "Add Python to PATH".
:finished
echo.
echo Launcher finished. If no browser opened, read the messages above.
pause

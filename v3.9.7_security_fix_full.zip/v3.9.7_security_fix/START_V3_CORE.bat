@echo off
setlocal
cd /d "%~dp0"
title V3.9.7 Server Diagnostic
echo ============================================================
echo V3.9.7 - Direct server diagnostic
echo ============================================================
echo.

where py.exe >nul 2>&1
if not errorlevel 1 (
    py -3 --version >nul 2>&1
    if not errorlevel 1 (
        py -3 "%~dp0app.py"
        goto :finished
    )
)

where python.exe >nul 2>&1
if not errorlevel 1 (
    python "%~dp0app.py"
    goto :finished
)

echo [ERROR] Python 3 was not found.
echo Install Python 3.11 or later and enable "Add Python to PATH".
:finished
echo.
echo Server process finished. Read any Python error above.
pause

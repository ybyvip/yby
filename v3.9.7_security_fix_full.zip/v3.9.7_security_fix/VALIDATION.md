# V3.9.7 검증 기록

## 통과한 검증

- 전체 Python 소스 AST 문법 검사, HTML 내부 JavaScript Node.js 문법 검사.
- `python -m unittest discover -s tests -v`: **26개 테스트 실행, 26개 통과**, 실패·건너뜀 없음.
- 임시 DB, 로컬 Chromium/Playwright의 실제 화면 흐름:
  - 정상 로그인과 초기 화면, 로컬 차트·엑셀 스크립트 로딩.
  - 카드 이력에 저장한 img/onerror·svg/onload 문자열이 HTML로 실행되지 않고 텍스트로 출력됨.
  - 작은따옴표·HTML 특수문자가 들어간 계정 이름의 생성과 권한 저장 버튼 동작.
  - 최초 임시 비밀번호 변경, 변경 후 재로그인.
  - 메신저 보호 화면의 오답 비밀번호 거부·정상 비밀번호 해제.
  - 카드 불출·미사용 반납, 사용 반납·정산 신청의 DB 반영.
  - 로그아웃 시 업무 상태 정리 및 localStorage 업무 캐시 부재.
  - 위 흐름에서 브라우저 JavaScript 런타임 오류 없음.
- `tests/tls_smoke.py`: 임시 인증서로 실제 서버 프로세스의 HTTPS 기동, CA 및 hostname 검증, 로그인, Secure/SameSite=Strict 쿠키 확인. 인증서 검증을 해제하지 않음.
- SQLite 백업 `PRAGMA integrity_check` 정상.

서버 테스트는 권한 없는 카드 저장·지점 밖 변경·담당자 승인·감사 기록 접근 차단, 세션 만료, 삭제 계정과 이전 상태의 재활성화 방지, 비밀번호 초기화 후 세션 폐기와 필수 변경, 저장 충돌, 메시지 ID 덮어쓰기 차단, 첨부 수신자 접근, 정산 신청 권한, 이전 비밀번호 해시 및 완료 정산 이력 이전, 지점별 카드 삭제를 포함합니다.

## 검증 환경과 실행 방법

Python 3.12, Node.js 24, Linux Chromium에서 임시 자료로 검증했습니다. 실제 업무 DB나 사용자의 비밀번호를 사용하지 않았습니다.

필수 회귀 테스트는 Python 표준 라이브러리만 사용합니다.

```sh
python -m unittest discover -s tests -v
```

추가 화면 검증에는 Playwright와 Chromium이 필요합니다. Linux 테스트의 기본 Chromium 경로는 `/usr/bin/chromium`입니다. 다른 경로는 `V3_TEST_CHROMIUM` 환경 변수에 지정할 수 있습니다.

```sh
python tests/browser_smoke.py
```

추가 HTTPS 테스트에는 OpenSSL 명령이 필요합니다. 테스트가 만드는 인증서와 개인키는 임시 폴더에 생성하고 제거합니다.

```sh
python tests/tls_smoke.py
```

## 검증하지 않은 항목

- 실제 Windows에서 BAT 실행·방화벽 설정·Edge 동작.
- 사용자의 기존 업무 DB 및 첨부파일로 하는 이전 검증.
- 실제 사내 인증서와 다른 PC에서의 HTTPS 접속.
- 전체 인쇄·엑셀 보고서 및 장시간 다중 사용자 부하 시험.

기본 실행은 HTTP입니다. 네트워크 통신이 자동으로 암호화된다고 가정하지 마세요. HTTPS 설정은 `README_V3_9_7.md`를 확인하세요.
